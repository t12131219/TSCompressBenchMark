// Fused FastLanes bit extraction + decimal reconstruction, binary64.
#include <stdint.h>
#include <arm_neon.h>
void alpn_neon_falp(const uint64_t*in,double*out,uint8_t bw,uint64_t base,int64_t factor,double frac){
 for(unsigned k=0;k<64;k++)for(unsigned lane=0;lane<16;lane+=2){
  unsigned bit=k*bw,word=bit/64,shift=bit%64;uint64x2_t v=vdupq_n_u64(0);
  if(bw){v=vld1q_u64(in+word*16+lane);if(shift)v=vshlq_u64(v,vdupq_n_s64(-(int)shift));
   if(shift+bw>64)v=vorrq_u64(v,vshlq_u64(vld1q_u64(in+(word+1)*16+lane),vdupq_n_s64(64-shift)));
   if(bw<64)v=vandq_u64(v,vdupq_n_u64((UINT64_C(1)<<bw)-1));}
  v=vaddq_u64(v,vdupq_n_u64(base));
  // AArch64 NEON has no 64-bit integer multiply; retain modulo arithmetic
  // in lanes before SIMD signed conversion and floating multiplication.
  uint64_t a[2];vst1q_u64(a,v);a[0]*=(uint64_t)factor;a[1]*=(uint64_t)factor;
  float64x2_t d=vcvtq_f64_s64(vreinterpretq_s64_u64(vld1q_u64(a)));
  vst1q_f64(out+16*k+lane,vmulq_n_f64(d,frac));
 }
}
