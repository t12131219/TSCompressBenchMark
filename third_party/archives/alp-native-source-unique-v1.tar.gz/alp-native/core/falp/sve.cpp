// Vector-length-independent fused FastLanes decoder. Never runs without HWCAP_SVE.
#include <stdint.h>
#include <arm_sve.h>
void alpn_sve_falp(const uint64_t*in,double*out,uint8_t bw,uint64_t base,int64_t factor,double frac){
 for(unsigned k=0;k<64;k++)for(uint64_t lane=0;lane<16;lane+=svcntd()){
  svbool_t pg=svwhilelt_b64(lane,(uint64_t)16);unsigned bit=k*bw,word=bit/64,shift=bit%64;
  svuint64_t v=svdup_u64(0);
  if(bw){v=svld1_u64(pg,in+word*16+lane);if(shift)v=svlsr_u64_x(pg,v,shift);
   if(shift+bw>64)v=svorr_u64_x(pg,v,svlsl_u64_x(pg,svld1_u64(pg,in+(word+1)*16+lane),64-shift));
   if(bw<64)v=svand_u64_x(pg,v,(UINT64_C(1)<<bw)-1);}
  v=svadd_u64_x(pg,v,base);v=svmul_u64_x(pg,v,(uint64_t)factor);
  svfloat64_t d=svcvt_f64_s64_x(pg,svreinterpret_s64_u64(v));
  svst1_f64(pg,out+16*k+lane,svmul_f64_x(pg,d,frac));
 }
}
