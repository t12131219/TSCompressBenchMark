#pragma once
#include <stdint.h>
void alpn_neon_falp(const uint64_t*,double*,uint8_t,uint64_t,int64_t,double);
void alpn_sve_falp(const uint64_t*,double*,uint8_t,uint64_t,int64_t,double);
