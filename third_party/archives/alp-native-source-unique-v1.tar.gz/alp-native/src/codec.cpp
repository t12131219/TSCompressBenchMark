#include "alp_native.h"
#include <algorithm>
#include <array>
#include <cfenv>
#include <cstring>
#include <limits>
#include <stdexcept>
#include <string>
#include <type_traits>
#include <vector>
#include "alp.hpp"
#include "alp/falp.hpp"
#include "../core/falp/arm_api.h"
#if defined(__aarch64__) && defined(__linux__)
#include <sys/auxv.h>
#include <asm/hwcap.h>
#endif
namespace impl = alp_port;

namespace {
static_assert(sizeof(float)==4 && sizeof(double)==8 && std::numeric_limits<float>::is_iec559 &&
              std::numeric_limits<double>::is_iec559,"ALP requires IEEE binary32/binary64");
constexpr size_t V=1024, RG=102400;
struct failure { alpn_status status; const char *message; };
[[noreturn]] void fail(alpn_status s,const char *m) { throw failure{s,m}; }
thread_local const char *message="";
struct writer {
    std::vector<uint8_t> data;
    template<class T> void word(T v) {
        using U=std::make_unsigned_t<T>; U u; std::memcpy(&u,&v,sizeof(T));
        for (size_t i=0;i<sizeof(T);++i) data.push_back(uint8_t(u>>(i*8)));
    }
    void var(size_t n) { do { auto b=uint8_t(n&127); n>>=7; word<uint8_t>(b|(n?128:0)); } while(n); }
    void append(const void *p,size_t n) {
        if(n) { const auto *b=static_cast<const uint8_t*>(p); data.insert(data.end(),b,b+n); }
    }
    template<class T> void packed(const T *p,size_t bytes) {
#if __BYTE_ORDER__ == __ORDER_LITTLE_ENDIAN__
        append(p,bytes);
#else
        for(size_t i=0;i<bytes/sizeof(T);++i) word(p[i]);
#endif
    }
};
struct reader {
    const uint8_t *p; size_t size,pos=0;
    reader(const void *s,size_t n):p(static_cast<const uint8_t*>(s)),size(n) {
        if(!p && n) fail(ALPN_INVALID,"null source");
    }
    void need(size_t n) { if(n>size-pos) fail(ALPN_CORRUPT,"truncated stream"); }
    template<class T> T word() {
        need(sizeof(T)); using U=std::make_unsigned_t<T>; U u=0;
        for(size_t i=0;i<sizeof(T);++i) u|=U(p[pos++])<<(8*i);
        T v; std::memcpy(&v,&u,sizeof(T)); return v;
    }
    size_t var() {
        size_t v=0; unsigned shift=0;
        for(;;) {
            uint8_t b=word<uint8_t>();
            if(shift>=sizeof(size_t)*8 || size_t(b&127)>(SIZE_MAX>>shift))
                fail(ALPN_CORRUPT,"varint overflow");
            v|=size_t(b&127)<<shift;
            if(!(b&128)) { if(shift && b==0) fail(ALPN_CORRUPT,"noncanonical varint"); return v; }
            shift+=7;
        }
    }
    void copy(void *out,size_t n) { need(n); if(n) std::memcpy(out,p+pos,n); pos+=n; }
    template<class T> void packed(T *out,size_t bytes) {
#if __BYTE_ORDER__ == __ORDER_LITTLE_ENDIAN__
        copy(out,bytes);
#else
        for(size_t i=0;i<bytes/sizeof(T);++i) { T v=word<T>(); std::memcpy(reinterpret_cast<uint8_t*>(out)+i*sizeof(T),&v,sizeof(T)); }
#endif
    }
};
void header(reader &r,unsigned &width,size_t &count) {
    if(r.word<uint32_t>()!=0x314e4c41u) fail(ALPN_CORRUPT,"bad ALN1 magic/version");
    width=r.word<uint8_t>(); if(width!=32 && width!=64) fail(ALPN_CORRUPT,"invalid float width");
    count=r.var(); if(count>SIZE_MAX/(width/8)) fail(ALPN_CORRUPT,"count overflow");
}
template<class T> struct workspace {
    using S=typename impl::inner_t<T>::st; using U=typename impl::inner_t<T>::ut;
    alignas(64) std::array<T,V> exceptions{},sample{},output{};
    alignas(64) std::array<S,V> ints{},packed_ints{};
    alignas(64) std::array<U,V> right{},packed_right{};
    alignas(64) std::array<uint16_t,V> left{},packed_left{},positions{},rd_exceptions{};
};
template<class T> writer encode(const void *input,size_t count,alpn_mode mode,alpn_stats &stats) {
    using S=typename workspace<T>::S; using U=typename workspace<T>::U;
    writer result; result.data.reserve(count*sizeof(T)+16+(count/RG));
    result.word<uint32_t>(0x314e4c41u); result.word<uint8_t>(sizeof(T)*8); result.var(count);
    workspace<T> w;
    for(size_t start=0;start<count;) {
        const size_t n=std::min(RG,count-start), padded=(n+V-1)/V*V;
        std::vector<T> values(padded);
        std::memcpy(values.data(),static_cast<const uint8_t*>(input)+start*sizeof(T),n*sizeof(T));
        // Repeat the last raw word: tail padding does not introduce new outliers.
        for(size_t j=n;j<padded;++j) std::memcpy(&values[j],&values[n-1],sizeof(T));
        impl::state<T> st;
        w.sample.fill(T(0));
        if(mode==ALPN_RD) impl::rd_encoder<T>::init(values.data(),0,n,w.sample.data(),st);
        else {
            impl::encoder<T>::init(values.data(),0,n,w.sample.data(),st);
            if(mode==ALPN_DECIMAL && st.scheme!=impl::Scheme::ALP) {
                st.scheme=impl::Scheme::ALP; st.best_k_combinations={{0,0}}; st.k_combinations=1;
            }
            if(st.scheme==impl::Scheme::ALP_RD)
                impl::rd_encoder<T>::init(values.data(),0,n,w.sample.data(),st);
        }
        const bool rd=st.scheme==impl::Scheme::ALP_RD;
        writer group; group.word<uint8_t>(rd?2:1);
        if(rd) {
            group.word(st.right_bit_width); group.word(st.left_bit_width);
            group.word(st.actual_dictionary_size);
            for(unsigned j=0;j<st.actual_dictionary_size;++j) group.word(st.left_parts_dict[j]);
        }
        uint64_t coded=0,raw=0;
        for(size_t offset=0;offset<n;offset+=V) {
            writer block; block.word<uint8_t>(1);
            uint16_t ex=0;
            if(!rd) {
                impl::encoder<T>::encode(values.data()+offset,w.exceptions.data(),w.positions.data(),&ex,w.ints.data(),st);
                S base=0; uint8_t bw=0;
                impl::encoder<T>::analyze_ffor(w.ints.data(),bw,&base);
                ffor::ffor(w.ints.data(),w.packed_ints.data(),bw,&base);
                block.word(bw); block.word(st.exp); block.word(st.fac); block.var(ex); block.word(base);
                block.packed(w.packed_ints.data(),128*bw);
                for(unsigned j=0;j<ex;++j) {
                    U bits; std::memcpy(&bits,&w.exceptions[j],sizeof(T)); block.word(bits); block.word(w.positions[j]);
                }
            } else {
                impl::rd_encoder<T>::encode(values.data()+offset,w.rd_exceptions.data(),w.positions.data(),&ex,
                                            w.right.data(),w.left.data(),st);
                U zero=0; uint16_t zero16=0;
                ffor::ffor(w.right.data(),w.packed_right.data(),st.right_bit_width,&zero);
                ffor::ffor(w.left.data(),w.packed_left.data(),st.left_bit_width,&zero16);
                block.var(ex);
                block.packed(w.packed_right.data(),128*st.right_bit_width);
                block.packed(w.packed_left.data(),128*st.left_bit_width);
                for(unsigned j=0;j<ex;++j) { block.word(w.rd_exceptions[j]); block.word(w.positions[j]); }
            }
            const size_t actual=std::min(V,n-offset);
            if(block.data.size()>=1+actual*sizeof(T)) {
                group.word<uint8_t>(0);
                group.packed(reinterpret_cast<const U*>(values.data()+offset),actual*sizeof(T)); ++raw;
            } else
            { group.append(block.data.data(),block.data.size()); ++coded; }
        }
        if(group.data.size()>=1+n*sizeof(T)) {
            result.word<uint8_t>(0); result.packed(reinterpret_cast<const U*>(values.data()),n*sizeof(T));
            ++stats.raw_groups; stats.raw_vectors+=(n+V-1)/V;
        } else
        {
            result.append(group.data.data(),group.data.size());
            if(rd) ++stats.rd_groups; else ++stats.alp_groups;
            stats.coded_vectors+=coded; stats.raw_vectors+=raw;
        }
        start+=n;
    }
    return result;
}
template<class T> void decode(reader &r,size_t count,void *dst,alpn_backend backend,alpn_decode_stats &stats) {
    using S=typename workspace<T>::S; using U=typename workspace<T>::U;
    workspace<T> w;
    for(size_t start=0;start<count;) {
        const size_t n=std::min(RG,count-start);
        uint8_t scheme=r.word<uint8_t>();
        if(scheme>2) fail(ALPN_CORRUPT,"invalid rowgroup scheme");
        if(scheme==0) {
            r.packed(reinterpret_cast<U*>(static_cast<uint8_t*>(dst)+start*sizeof(T)),n*sizeof(T)); stats.raw_vectors+=(n+V-1)/V; start+=n; continue;
        }
        impl::state<T> st;
        if(scheme==2) {
            st.right_bit_width=r.word<uint8_t>(); st.left_bit_width=r.word<uint8_t>();
            st.actual_dictionary_size=r.word<uint8_t>();
            if(st.right_bit_width<sizeof(T)*8-16 || st.right_bit_width>=sizeof(T)*8 ||
               st.left_bit_width<1 || st.left_bit_width>3 || st.actual_dictionary_size<1 ||
               st.actual_dictionary_size>8 || st.actual_dictionary_size>(1u<<st.left_bit_width))
                fail(ALPN_CORRUPT,"invalid RD dictionary metadata");
            for(unsigned j=0;j<st.actual_dictionary_size;++j) {
                st.left_parts_dict[j]=r.word<uint16_t>();
                if(st.left_parts_dict[j]>((U(1)<<(sizeof(T)*8-st.right_bit_width))-1))
                    fail(ALPN_CORRUPT,"RD dictionary word overflow");
            }
        }
        for(size_t offset=0;offset<n;offset+=V) {
            const size_t actual=std::min(V,n-offset); uint8_t kind=r.word<uint8_t>();
            if(kind>1) fail(ALPN_CORRUPT,"invalid vector kind");
            auto *out=static_cast<uint8_t*>(dst)+(start+offset)*sizeof(T);
            if(kind==0) { ++stats.raw_vectors; r.packed(w.right.data(),actual*sizeof(T)); std::memcpy(out,w.right.data(),actual*sizeof(T)); continue; }
            size_t ex=0;
            if(scheme==1) {
                uint8_t bw=r.word<uint8_t>(),exp=r.word<uint8_t>(),fac=r.word<uint8_t>();
                if(bw>sizeof(T)*8 || exp>impl::Constants<T>::MAX_EXPONENT ||
                   fac>=sizeof(impl::Constants<T>::FACT_ARR)/sizeof(impl::Constants<T>::FACT_ARR[0]) || fac>exp)
                    fail(ALPN_CORRUPT,"invalid ALP parameters");
                ex=r.var(); if(ex>V) fail(ALPN_CORRUPT,"exception count exceeds vector");
                S base=r.word<S>(); r.packed(w.packed_ints.data(),128*bw);
                if(backend==ALPN_FALP_SCALAR) {
                    generated::falp::fallback::scalar::falp(w.packed_ints.data(),w.output.data(),bw,&base,fac,exp);
                    ++stats.falp_scalar_vectors;
                }
                else if constexpr(std::is_same_v<T,double>) {
                    const auto*in=reinterpret_cast<const uint64_t*>(w.packed_ints.data());
                    const auto*bp=reinterpret_cast<const uint64_t*>(&base);
                    bool fused=false;
#if ALPN_HAVE_AVX2
                    if(backend==ALPN_FALP_AVX2){generated::falp::x86_64::avx2::falp(in,w.output.data(),bw,bp,fac,exp);++stats.falp_avx2_vectors;fused=true;}
#endif
#if ALPN_HAVE_AVX512BW
                    if(backend==ALPN_FALP_AVX512BW){generated::falp::x86_64::avx512bw::falp(in,w.output.data(),bw,bp,fac,exp);fused=true;}
#endif
#if ALPN_HAVE_NEON
                    if(backend==ALPN_FALP_NEON){alpn_neon_falp(in,w.output.data(),bw,*bp,impl::Constants<double>::FACT_ARR[fac],impl::Constants<double>::FRAC_ARR[exp]);fused=true;}
#endif
#if ALPN_HAVE_SVE
                    if(backend==ALPN_FALP_SVE){alpn_sve_falp(in,w.output.data(),bw,*bp,impl::Constants<double>::FACT_ARR[fac],impl::Constants<double>::FRAC_ARR[exp]);fused=true;}
#endif
                    if(!fused){unffor::unffor(w.packed_ints.data(),w.ints.data(),bw,&base);impl::decoder<T>::decode(w.ints.data(),fac,exp,w.output.data());++stats.scalar_vectors;}
                } else {unffor::unffor(w.packed_ints.data(),w.ints.data(),bw,&base);impl::decoder<T>::decode(w.ints.data(),fac,exp,w.output.data());++stats.scalar_vectors;}
                unsigned prev=0;
                for(size_t j=0;j<ex;++j) {
                    U value=r.word<U>(); unsigned pos=r.word<uint16_t>();
                    if(pos>=V || (j && pos<=prev)) fail(ALPN_CORRUPT,"invalid exception position");
                    prev=pos; std::memcpy(&w.output[pos],&value,sizeof(T));
                }
            } else {
                ex=r.var(); if(ex>V) fail(ALPN_CORRUPT,"RD exception count exceeds vector");
                r.packed(w.packed_right.data(),128*st.right_bit_width);
                r.packed(w.packed_left.data(),128*st.left_bit_width);
                U zero=0; uint16_t zero16=0;
                unffor::unffor(w.packed_right.data(),w.right.data(),st.right_bit_width,&zero);
                unffor::unffor(w.packed_left.data(),w.left.data(),st.left_bit_width,&zero16);
                // All packed IDs fit the allocated 8-entry table, including exception placeholders.
                unsigned prev=0;
                for(size_t j=0;j<ex;++j) {
                    w.rd_exceptions[j]=r.word<uint16_t>(); w.positions[j]=r.word<uint16_t>();
                    if(w.positions[j]>=V || (j && w.positions[j]<=prev) ||
                       w.rd_exceptions[j]>((U(1)<<(sizeof(T)*8-st.right_bit_width))-1))
                        fail(ALPN_CORRUPT,"invalid RD exception");
                    prev=w.positions[j];
                }
                size_t next=0;
                for(size_t j=0;j<V;++j) {
                    if(next<ex && w.positions[next]==j) { ++next; continue; }
                    if(w.left[j]>=st.actual_dictionary_size) fail(ALPN_CORRUPT,"RD index outside dictionary");
                }
                ++stats.rd_vectors;
                auto ex16=static_cast<uint16_t>(ex);
                impl::rd_encoder<T>::decode(w.output.data(),w.right.data(),w.left.data(),w.rd_exceptions.data(),
                                           w.positions.data(),&ex16,st);
            }
            std::memcpy(out,w.output.data(),actual*sizeof(T));
        }
        start+=n;
    }
    if(r.pos!=r.size) fail(ALPN_CORRUPT,"trailing bytes");
}
template<class F> alpn_status guarded(F f) noexcept {
    try { message=""; f(); return ALPN_OK; }
    catch(const failure &e) { message=e.message; return e.status; }
    catch(const std::bad_alloc&) { message="allocation failure"; return ALPN_NOMEM; }
    catch(...) { message="internal exception"; return ALPN_INTERNAL; }
}
}
extern "C" {
size_t alpn_compress_bound(size_t n,unsigned width) {
    if(width!=32 && width!=64) return 0;
    size_t groups=n/RG+size_t(n%RG!=0);
    if(n>(SIZE_MAX-16-groups)/(width/8)) return 0;
    return n*(width/8)+groups+16;
}
alpn_status alpn_compress(const void *values,size_t count,unsigned width,alpn_mode mode,
    void *dst,size_t capacity,size_t *written,alpn_stats *stats) {
    if(written) *written=0;
    if(stats) *stats={};
    return guarded([&] {
        if(!written || (!values && count) || (!dst && capacity) || !alpn_compress_bound(count,width) ||
           mode<ALPN_AUTO || mode>ALPN_RD) fail(ALPN_INVALID,"invalid compression arguments");
        if(std::fegetround()!=FE_TONEAREST) fail(ALPN_INVALID,"compression requires FE_TONEAREST");
        alpn_stats s{};
        writer stream=width==32?encode<float>(values,count,mode,s):encode<double>(values,count,mode,s);
        if(stream.data.size()>capacity) fail(ALPN_NOSPACE,"compressed output buffer too small");
        if(!stream.data.empty()) std::memcpy(dst,stream.data.data(),stream.data.size());
        *written=stream.data.size(); if(stats) *stats=s;
    });
}
alpn_status alpn_inspect(const void *src,size_t bytes,unsigned *width,size_t *count) {
    return guarded([&] { if(!width||!count) fail(ALPN_INVALID,"null info output"); reader r(src,bytes); header(r,*width,*count); });
}
alpn_status alpn_decompress(const void *src,size_t bytes,size_t max_count,void *dst,size_t capacity,size_t *written) {
    return alpn_decompress_ex(src,bytes,max_count,dst,capacity,written,ALPN_SCALAR,nullptr);
}
int alpn_backend_built(alpn_backend b,unsigned width){
 if(width!=32&&width!=64)return 0;
 if(b==ALPN_SCALAR||b==ALPN_FALP_SCALAR||b==ALPN_FALP_AUTO)return 1;
 if(width!=64)return 0;
 return (b==ALPN_FALP_AVX2&&ALPN_HAVE_AVX2)||(b==ALPN_FALP_AVX512BW&&ALPN_HAVE_AVX512BW)||(b==ALPN_FALP_NEON&&ALPN_HAVE_NEON)||(b==ALPN_FALP_SVE&&ALPN_HAVE_SVE);
}
int alpn_backend_available(alpn_backend b,unsigned width){
 if(!alpn_backend_built(b,width))return 0;
 if(b==ALPN_SCALAR||b==ALPN_FALP_SCALAR||b==ALPN_FALP_AUTO)return 1;
#if defined(__x86_64__) || defined(__i386__)
 __builtin_cpu_init();
 if(b==ALPN_FALP_AVX2)return __builtin_cpu_supports("avx2")!=0;
 if(b==ALPN_FALP_AVX512BW)return __builtin_cpu_supports("avx512f")&&__builtin_cpu_supports("avx512bw")&&__builtin_cpu_supports("avx512dq");
#endif
#if defined(__aarch64__) && defined(__linux__)
 if(b==ALPN_FALP_NEON)return (getauxval(AT_HWCAP)&HWCAP_ASIMD)!=0;
 if(b==ALPN_FALP_SVE)return (getauxval(AT_HWCAP)&HWCAP_SVE)!=0;
#elif defined(__aarch64__)
 if(b==ALPN_FALP_NEON)return 1;
#endif
 return 0;
}
const char *alpn_backend_name(alpn_backend backend) {
    switch(backend){case ALPN_SCALAR:return "scalar-unfused";case ALPN_FALP_SCALAR:return "falp-scalar";case ALPN_FALP_AVX2:return "falp-avx2";case ALPN_FALP_AUTO:return "falp-auto";case ALPN_FALP_AVX512BW:return "falp-avx512bw";case ALPN_FALP_NEON:return "falp-neon";case ALPN_FALP_SVE:return "falp-sve";default:return "invalid";}
}
alpn_status alpn_decompress_ex(const void *src,size_t bytes,size_t max_count,void *dst,size_t capacity,size_t *written,alpn_backend backend,alpn_decode_stats *stats) {
    if(written) *written=0;
    if(stats)*stats={};
    return guarded([&] {
        if(!written) fail(ALPN_INVALID,"null written output");
        reader r(src,bytes); unsigned width=0; size_t count=0; header(r,width,count);
        if(std::fegetround()!=FE_TONEAREST) fail(ALPN_INVALID,"decompression requires FE_TONEAREST");
        if(count>max_count || count>capacity) fail(ALPN_NOSPACE,"decoded count exceeds output limit");
        if(!dst && count) fail(ALPN_INVALID,"null decoded output");
        if(!alpn_backend_available(backend,width))fail(ALPN_INVALID,"requested decode backend unavailable for width/CPU/build");
        if(backend==ALPN_FALP_AUTO){backend=ALPN_FALP_SCALAR;for(auto b:{ALPN_FALP_AVX2,ALPN_FALP_NEON,ALPN_FALP_SVE,ALPN_FALP_AVX512BW})if(alpn_backend_available(b,width))backend=b;}
        alpn_decode_stats s{};s.effective_backend=backend;
        if(width==32) decode<float>(r,count,dst,backend,s); else decode<double>(r,count,dst,backend,s);
        *written=count;if(stats)*stats=s;
    });
}
const char *alpn_last_error(void) { return message; }
const char *alpn_version(void) {
    return "alp-native 1.0.0-fix2 (ALP 31ca0ed port + FALP backends)";
}
}
