#ifndef ALP_NATIVE_HPP
#define ALP_NATIVE_HPP
#include "alp_native.h"
#include <stdexcept>
#include <type_traits>
#include <vector>
namespace alp_native {
class error : public std::runtime_error {
public: explicit error(const char *s):std::runtime_error(s) {}
};
inline void check(alpn_status s) { if (s != ALPN_OK) throw error(alpn_last_error()); }
template<class T> std::vector<uint8_t> compress(const T *values, size_t count,
                                              alpn_mode mode=ALPN_AUTO) {
    static_assert(std::is_same_v<T,float> || std::is_same_v<T,double>);
    const size_t bound=alpn_compress_bound(count,sizeof(T)*8);
    if (!bound) throw error("invalid size");
    std::vector<uint8_t> result(bound); size_t n=0;
    check(alpn_compress(values,count,sizeof(T)*8,mode,result.data(),result.size(),&n,nullptr));
    result.resize(n); return result;
}
template<class T> std::vector<T> decompress(const uint8_t *src,size_t bytes,size_t max_count) {
    static_assert(std::is_same_v<T,float> || std::is_same_v<T,double>);
    unsigned width=0; size_t count=0;
    check(alpn_inspect(src,bytes,&width,&count));
    if (width!=sizeof(T)*8 || count>max_count) throw error("wrong type or output limit");
    std::vector<T> result(count); size_t written=0;
    check(alpn_decompress(src,bytes,max_count,result.data(),count,&written));
    return result;
}
template<class T> std::vector<T> decompress(const uint8_t *src,size_t bytes,size_t max_count,
                                            alpn_backend backend,alpn_decode_stats *stats=nullptr) {
    static_assert(std::is_same_v<T,float> || std::is_same_v<T,double>);
    unsigned width=0;size_t count=0;
    check(alpn_inspect(src,bytes,&width,&count));
    if(width!=sizeof(T)*8 || count>max_count)throw error("wrong type or output limit");
    std::vector<T> result(count);size_t written=0;
    check(alpn_decompress_ex(src,bytes,max_count,result.data(),count,&written,backend,stats));
    return result;
}

}
#endif
