#ifndef ALP_NATIVE_H
#define ALP_NATIVE_H
#include <stddef.h>
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
/* C ABI over the C++17 ALP implementation, not an independent C rewrite.
 * No ownership crosses this interface. Buffers must not overlap.
 * Input/output may be unaligned. All sizes are bytes except value counts.
 * Default IEEE round-to-nearest environment is required for both operations.
 * On error output contents are unspecified; written is set to zero.
 */
typedef enum { ALPN_OK=0, ALPN_INVALID=1, ALPN_NOSPACE=2,
               ALPN_CORRUPT=3, ALPN_NOMEM=4, ALPN_INTERNAL=5 } alpn_status;
typedef enum { ALPN_AUTO=0, ALPN_DECIMAL=1, ALPN_RD=2 } alpn_mode;
typedef struct {
    uint64_t alp_groups, rd_groups, raw_groups;
    uint64_t coded_vectors, raw_vectors;
} alpn_stats;
/* Returns zero on invalid width or overflow. Width is 32 or 64. */
size_t alpn_compress_bound(size_t count, unsigned width);
alpn_status alpn_compress(const void *values, size_t count, unsigned width,
    alpn_mode mode, void *dst, size_t capacity, size_t *written, alpn_stats *stats);
/* Header-only inspection; does not validate the complete payload. */
alpn_status alpn_inspect(const void *src, size_t bytes, unsigned *width, size_t *count);
/* max_count protects the caller against untrusted advertised sizes.
 * capacity_values is in values of the width recorded in the stream.
 * The decoder rejects trailing bytes and truncated/invalid metadata.
 * No CRC: not every corrupt stream can be detected.
 */
alpn_status alpn_decompress(const void *src, size_t bytes, size_t max_count,
    void *dst, size_t capacity_values, size_t *written);
/* Decode execution path; the encoded ALN1 bytes are independent of it.
 * Legacy scalar keeps the old two-pass unffor+decimal decode. FALP fuses them.
 * Frozen AVX2 FALP exists for binary64 only. Explicit unavailable backends
 * return ALPN_INVALID; AUTO selects the actually supported fused path. */
/* An integer token allows invalid values from C/FFI to be rejected without
 * first invoking C++ enum-range undefined behavior. */
typedef int alpn_backend;
enum { ALPN_SCALAR=0, ALPN_FALP_SCALAR=1, ALPN_FALP_AVX2=2,
       ALPN_FALP_AUTO=3, ALPN_FALP_AVX512BW=4, ALPN_FALP_NEON=5, ALPN_FALP_SVE=6 };
typedef struct {
    alpn_backend effective_backend;
    uint64_t scalar_vectors, falp_scalar_vectors, falp_avx2_vectors;
    uint64_t rd_vectors, raw_vectors;
} alpn_decode_stats;
/* built() is independent of host support; available() includes CPU/OS.
 * SSE/AVX512F/WASM declarations have no kernels in frozen Source. */
int alpn_backend_built(alpn_backend,unsigned width);
int alpn_backend_available(alpn_backend, unsigned width);
const char *alpn_backend_name(alpn_backend);
alpn_status alpn_decompress_ex(const void *src, size_t bytes, size_t max_count,
    void *dst, size_t capacity_values, size_t *written,
    alpn_backend backend, alpn_decode_stats *stats);
const char *alpn_last_error(void); /* Per-thread, valid until next API call. */
const char *alpn_version(void);
#ifdef __cplusplus
}
#endif
#endif
