#include "alp_native.h"
#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstring>
#include <fstream>
#include <iostream>
#include <limits>
#include <stdexcept>
#include <string>
#include <vector>
using bytes=std::vector<uint8_t>;
void check(alpn_status s) { if(s!=ALPN_OK) throw std::runtime_error(alpn_last_error()); }
bytes load(const char *path) {
    std::ifstream f(path,std::ios::binary|std::ios::ate);
    if(!f) throw std::runtime_error("cannot open input");
    auto size=f.tellg(); if(size<0) throw std::runtime_error("input size failed");
    bytes b(static_cast<size_t>(size)); f.seekg(0);
    if(!b.empty() && !f.read(reinterpret_cast<char*>(b.data()),b.size())) throw std::runtime_error("input read failed");
    return b;
}
void save(const char *path,const bytes &b) {
    std::ofstream f(path,std::ios::binary); if(!f) throw std::runtime_error("cannot open output");
    f.write(reinterpret_cast<const char*>(b.data()),b.size()); if(!f) throw std::runtime_error("output write failed");
}
size_t number(const char *s) {
    std::string v(s); if(v.empty() || v[0]=='-') throw std::runtime_error("invalid nonnegative number");
    size_t end=0; auto n=std::stoull(v,&end);
    if(end!=v.size() || n>SIZE_MAX) throw std::runtime_error("invalid number"); return size_t(n);
}
template<class F> double measure(F fn) {
    using clock=std::chrono::steady_clock;
    fn(); fn();
    std::vector<double> times;
    for(int r=0;r<7;++r) {
        size_t repeats=0; auto begin=clock::now(); double seconds=0;
        do {
            fn(); ++repeats;
            seconds=std::chrono::duration<double>(clock::now()-begin).count();
        } while(seconds<0.010);
        times.push_back(seconds/double(repeats));
    }
    std::sort(times.begin(),times.end()); return times[3];
}
int main(int argc,char **argv) {
    try {
        if(argc==6 && std::string(argv[1])=="encode") {
            auto nwidth=number(argv[2]),nmode=number(argv[3]);
            if((nwidth!=32&&nwidth!=64)||nmode>2) throw std::runtime_error("width=32/64, mode=0/1/2");
            unsigned width=unsigned(nwidth); bytes raw=load(argv[4]);
            if(raw.size()%(width/8)) throw std::runtime_error("partial floating word");
            bytes packed(alpn_compress_bound(raw.size()/(width/8),width)); size_t written=0;
            check(alpn_compress(raw.data(),raw.size()/(width/8),width,alpn_mode(nmode),packed.data(),packed.size(),&written,nullptr));
            packed.resize(written); save(argv[5],packed); return 0;
        }
        if((argc==5||argc==6) && std::string(argv[1])=="decode") {
            bytes packed=load(argv[2]); unsigned width=0; size_t n=0,written=0;
            check(alpn_inspect(packed.data(),packed.size(),&width,&n));
            if(n>number(argv[4])) throw std::runtime_error("output limit exceeded");
            auto backend=argc==6?number(argv[5]):0;
            if(backend>3)throw std::runtime_error("backend=0:scalar,1:falp-scalar,2:avx2,3:auto");
            bytes raw(n*(width/8)); check(alpn_decompress_ex(packed.data(),packed.size(),n,raw.data(),n,&written,alpn_backend(backend),nullptr));
            save(argv[3],raw); return 0;
        }
        if((argc==5||argc==6) && std::string(argv[1])=="bench") {
            size_t requested_width=number(argv[2]),mode=number(argv[3]),backend=argc==6?number(argv[5]):0;
            if(backend>3)throw std::runtime_error("invalid backend");
            if((requested_width!=32&&requested_width!=64)||mode>2) throw std::runtime_error("invalid width/mode");
            unsigned width=unsigned(requested_width);
            bytes raw=load(argv[4]); if(raw.size()%(width/8)) throw std::runtime_error("partial floating word");
            size_t count=raw.size()/(width/8),n=0,decoded=0;
            bytes packed(alpn_compress_bound(count,width)),restored(raw.size()); alpn_stats stats{};alpn_decode_stats ds{};
            auto enc=[&]{check(alpn_compress(raw.data(),count,width,alpn_mode(mode),packed.data(),packed.size(),&n,&stats));};
            auto dec=[&]{check(alpn_decompress_ex(packed.data(),n,count,restored.data(),count,&decoded,alpn_backend(backend),&ds));};
            enc(); dec();
            if(decoded!=count || restored!=raw) throw std::runtime_error("bitwise roundtrip failed");
            const double enc_seconds=measure(enc), dec_seconds=measure(dec);
            dec(); if(restored!=raw) throw std::runtime_error("timed stream mismatch");
            std::cout.precision(17);
            std::cout<<"{\"count\":"<<count<<",\"raw_bytes\":"<<raw.size()<<",\"compressed_bytes\":"<<n
                <<",\"encode_seconds\":"<<enc_seconds<<",\"decode_seconds\":"<<dec_seconds
                <<",\"alp_groups\":"<<stats.alp_groups<<",\"rd_groups\":"<<stats.rd_groups
                <<",\"raw_groups\":"<<stats.raw_groups<<",\"coded_vectors\":"<<stats.coded_vectors
                <<",\"raw_vectors\":"<<stats.raw_vectors
                <<",\"width\":"<<width<<",\"mode\":"<<mode<<",\"vector_size\":1024,\"rowgroup_size\":102400"
                <<",\"requested_backend\":\""<<alpn_backend_name(alpn_backend(backend))<<"\",\"effective_backend\":\""<<alpn_backend_name(ds.effective_backend)<<"\""
                <<",\"scalar_vectors\":"<<ds.scalar_vectors<<",\"falp_scalar_vectors\":"<<ds.falp_scalar_vectors<<",\"falp_avx2_vectors\":"<<ds.falp_avx2_vectors<<",\"decoded_rd_vectors\":"<<ds.rd_vectors<<",\"decoded_raw_vectors\":"<<ds.raw_vectors<<"}\n"; return 0;
        }
        std::cerr<<"Usage:\n  alp-native encode <32|64> <0:auto|1:decimal|2:rd> input.raw output.alpn\n"
                 <<"  alp-native decode input.alpn output.raw max_values [decode_backend]\n"
                 <<"  alp-native bench <32|64> <0|1|2> input.raw [0:scalar|1:falp-scalar|2:avx2|3:auto]\n";
        return 2;
    } catch(const std::exception &e) { std::cerr<<e.what()<<'\n'; return 1; }
}
