#pragma once
#include "sf_codec.hpp"
#include "bounds.hpp"
#include "native_compat.hpp"
#include <immintrin.h>
namespace sf {
// Uses the upstream generic RLE query templates. Lowdim packing uses query_scan.
QueryResult query_simd_delta(Config,const uint8_t*,size_t);
QueryResult query_simd_fire(Config,const uint8_t*,size_t);

// Per-stripe unsigned SIMD reductions. Widen before accumulating so uint16 sums
// can exceed 32 bits. Padded lanes remain internal and never become channels.
template<class T> class SimdReduction {
 unsigned dims,padded;
 std::vector<T> maxima;
 std::vector<uint64_t> counts,sums;
public:
 explicit SimdReduction(unsigned d):dims(d),padded((d+32/sizeof(T)-1)/(32/sizeof(T))*(32/sizeof(T))),maxima(padded),counts(padded),sums(padded){}
 void operator()(uint32_t stripe,const __m256i&,const __m256i& vals,uint32_t repeats=1){
  constexpr unsigned lanes=32/sizeof(T);unsigned start=stripe*lanes;
  require(start<padded);
  auto old=_mm256_loadu_si256(reinterpret_cast<const __m256i*>(maxima.data()+start));
  auto m=sizeof(T)==1?_mm256_max_epu8(old,vals):_mm256_max_epu16(old,vals);
  _mm256_storeu_si256(reinterpret_cast<__m256i*>(maxima.data()+start),m);
  alignas(32) T row[lanes];_mm256_store_si256(reinterpret_cast<__m256i*>(row),vals);
  const auto rep=_mm256_set1_epi64x(repeats);
  for(unsigned j=0;j<lanes;j+=4){
   __m128i group;
   // Only load the four contributing values; no read beyond the local row.
   if constexpr(sizeof(T)==1){uint32_t x;std::memcpy(&x,row+j,4);group=_mm_cvtsi32_si128(x);}
   else group=_mm_loadl_epi64(reinterpret_cast<const __m128i*>(row+j));
   __m256i wide;
   if constexpr(sizeof(T)==1)wide=_mm256_cvtepu8_epi64(group);else wide=_mm256_cvtepu16_epi64(group);
   auto sum=_mm256_loadu_si256(reinterpret_cast<const __m256i*>(sums.data()+start+j));
   auto count=_mm256_loadu_si256(reinterpret_cast<const __m256i*>(counts.data()+start+j));
   sum=_mm256_add_epi64(sum,_mm256_mul_epu32(wide,rep));
   count=_mm256_add_epi64(count,rep);
   _mm256_storeu_si256(reinterpret_cast<__m256i*>(sums.data()+start+j),sum);
   _mm256_storeu_si256(reinterpret_cast<__m256i*>(counts.data()+start+j),count);
  }
 }
 template<class I> void tail(const I* data,size_t n,size_t offset){
  const auto*bytes=reinterpret_cast<const uint8_t*>(data);
  for(size_t i=0;i<n;i++){
   T value;std::memcpy(&value,bytes+i*sizeof(T),sizeof(T));unsigned j=(offset+i)%dims;
   counts[j]++;sums[j]+=value;maxima[j]=std::max(maxima[j],value);
  }
 }
 QueryResult result()const{
  QueryResult r;r.count.assign(counts.begin(),counts.begin()+dims);r.sum.assign(sums.begin(),sums.begin()+dims);
  r.max.assign(maxima.begin(),maxima.begin()+dims);r.backend=QueryBackend::UpstreamSimd;return r;
 }
};
}
