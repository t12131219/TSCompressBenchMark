#pragma once
// New bounded grammar gate, 2026-10-24. Validates logical bytes before SIMD.
#include <cstdint>
#include <cstddef>
#include <cstring>
#include <stdexcept>
#include <vector>
#include <array>
#include <algorithm>
namespace sf {
inline void require(bool b){if(!b)throw std::runtime_error("malformed integer payload");}
struct Reader {
 const uint8_t*p;size_t z,pos=0;
 void take(size_t n){require(pos<=z&&n<=z-pos);pos+=n;}
 uint32_t word(){size_t k=pos;take(4);uint32_t v;std::memcpy(&v,p+k,4);return v;}
 uint8_t byte(){size_t k=pos;take(1);return p[k];}
 uint32_t at(size_t k)const{require(k<=z&&z-k>=4);uint32_t v;std::memcpy(&v,p+k,4);return v;}
};
}
