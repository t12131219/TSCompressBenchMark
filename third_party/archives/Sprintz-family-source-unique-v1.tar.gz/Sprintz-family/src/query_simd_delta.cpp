#include "query_simd.hpp"
#include "sprintz_delta_rle_query.hpp"
namespace sf {
template<class I,class U> static QueryResult run(Config c,const uint8_t*p,size_t n){
 sz_mem::scope allocations;
 uint16_t dims,tail;uint32_t groups;
 const I*src=reinterpret_cast<const I*>(p);
 src+=read_metadata_rle(src,&dims,&groups,&tail);
 require(dims==c.ndims);
 SimdReduction<U> reduce(dims);
 auto got=query_rowmajor_delta_rle<false>(src,static_cast<U*>(nullptr),dims,groups,tail,reduce);
 require(got>=0&&size_t(got)*sizeof(U)==n);
 return reduce.result();
}
QueryResult query_simd_delta(Config c,const uint8_t*p,size_t n){
 if(c.width==8)return run<int8_t,uint8_t>(c,p,n);
 return run<int16_t,uint16_t>(c,p,n);
}
}
