#pragma once
// Bounded streaming reduction: predictor state O(channels), no decoded column.
// Low-dimensional and generic Sprintz use different packing and FIRE coefficients.
#include <limits>
namespace sf {
inline int64_t q_signed(uint64_t v,unsigned bits){uint64_t mask=(uint64_t(1)<<bits)-1;v&=mask;return v&(uint64_t(1)<<(bits-1))?int64_t(v)-int64_t(uint64_t(1)<<bits):int64_t(v);}
inline int64_t q_shift(int64_t v,unsigned n){return v>=0?v/(int64_t(1)<<n):-((-v+(int64_t(1)<<n)-1)/(int64_t(1)<<n));}
inline unsigned q_bits(const uint8_t*p,size_t bit,unsigned width){unsigned v=0;for(unsigned j=0;j<width;j++)v|=unsigned((p[(bit+j)/8]>>((bit+j)%8))&1)<<j;return v;}
inline QueryResult query_scan(Config c,const uint8_t*p,size_t z,size_t n,size_t&used){
 const unsigned w=c.width,e=w/8,hb=e==1?3:4,d=c.ndims;
 const bool low=c.path==2||(c.path==0&&d<=(e==1?4:2));
 Reader r{p,z};size_t ng=r.word(),tail=r.byte();tail|=size_t(r.byte())<<8;
 require(r.byte()==(d&255)&&r.byte()==(d>>8));
 require(n%e==0);n/=e;require(tail<=n&&ng<=n/(8*d)+1);
 QueryResult result;result.count.assign(d,0);result.sum.assign(d,0);result.max.assign(d,0);
 std::vector<uint32_t>prev(d,0);std::vector<int64_t>delta(d,0),counter(d,0),coef(d,0),gradient(d,0);
 std::vector<unsigned>width(d);size_t produced=0;
 auto add=[&](unsigned j,unsigned value){result.count[j]++;result.sum[j]+=value;result.max[j]=std::max(result.max[j],value);};
 for(size_t g=0;g<ng;g++){
  size_t header=r.pos;r.take((2*d*hb+7)/8);
  for(unsigned b=0;b<2;b++){
   size_t sum=0;for(unsigned j=0;j<d;j++){unsigned code=q_bits(p+header,(b*d+j)*hb,hb);width[j]=code+(code==((1u<<hb)-1));sum+=width[j];}
   size_t block=r.pos,run=1;
   if(sum){r.take(low?sum:8*((sum+7)/8));}
   else{unsigned lo=r.byte();run=lo&127;if(lo&128)run|=size_t(r.byte())<<7;}
   require(run<=((n-tail-produced)/(8*d)));
   for(unsigned j=0;j<d;j++){
    unsigned quant=low?0:w-4;
    coef[j]=q_shift(counter[j],1+quant)*(int64_t(1)<<quant);
    if(!(low&&w==16))coef[j]=q_signed(uint64_t(coef[j]),16);
    gradient[j]=0;
   }
   size_t offset=0;
   for(unsigned j=0;j<d;j++){
    for(size_t blockrow=0;blockrow<8*run;blockrow++){
     unsigned packed=0;
     if(sum){size_t bit=low?offset*8+blockrow*width[j]:blockrow*((sum+7)/8)*8+offset;packed=q_bits(p+block,bit,width[j]);}
     int64_t residual=q_signed(uint64_t((packed>>1)^unsigned(-int(packed&1))),w);
     int64_t prediction=0;
     if(c.algorithm%2){int64_t product=delta[j]*coef[j];if(low&&w==16)product=q_signed(uint64_t(product),32);prediction=q_signed(uint64_t(q_shift(product,w)),w);}
     if(sum&&c.algorithm%2&&blockrow%2==1){int64_t grad=residual>0?delta[j]:residual<0?-delta[j]:0;gradient[j]=q_signed(uint64_t(gradient[j]+grad),w);}
     delta[j]=q_signed(uint64_t(residual+prediction),w);
     prev[j]=unsigned(uint64_t(prev[j]+delta[j])&((1u<<w)-1));add(j,prev[j]);
    }
    if(sum&&c.algorithm%2)counter[j]=q_signed(uint64_t(counter[j]+q_shift(gradient[j],2)),w*2);
    offset+=low?width[j]:width[j];
   }
   produced+=run*8*d;
  }
 }
 require(produced+tail==n);for(size_t j=0;j<tail;j++){unsigned v=r.byte();if(e==2)v|=unsigned(r.byte())<<8;add(unsigned((produced+j)%d),v);}
 used=r.pos;return result;
}
}
