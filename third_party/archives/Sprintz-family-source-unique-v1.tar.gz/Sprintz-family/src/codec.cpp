#include "sf_codec.hpp"
#include "native_bridge.hpp"
#include "bounds.hpp"
#include <array>
#include <cpuid.h>
#include <cstring>
#include <stdexcept>
#include <cstdlib>
#include <algorithm>
#include "native_alloc.hpp"
extern "C" {
#include "fse.h"
#include "huf.h"
}
int64_t lzbench_huff0_compress(char*,size_t,char*,size_t,size_t,size_t,void*);
int64_t lzbench_huff0_decompress(char*,size_t,char*,size_t,size_t,size_t,void*);
#include "query_scan.hpp"
#include "query_simd.hpp"
namespace sf {
constexpr size_t maxraw=65536,scratch=524288;
uint64_t rd(const uint8_t*p,unsigned n){uint64_t v=0;for(unsigned i=0;i<n;i++)v|=uint64_t(p[i])<<(i*8);return v;}
void wr(uint8_t*p,uint64_t v,unsigned n){for(unsigned i=0;i<n;i++)p[i]=uint8_t(v>>(i*8));}
size_t checked_limit(Config c,size_t limit){
 if(limit<maxraw || limit>16*1024*1024)throw std::invalid_argument("message limit");
 if(limit>maxraw && (c.algorithm<0 || c.algorithm>3 || c.path!=0))throw std::invalid_argument("large-message profile is Sprintz automatic path only");
 return limit;
}
struct Aligned{uint8_t*p=nullptr;explicit Aligned(size_t capacity){if(posix_memalign((void**)&p,64,capacity))throw std::bad_alloc();std::memset(p,0,capacity);}~Aligned(){free(p);} }; 
struct Codec::Impl{size_t limit,capacity;Aligned in,out,tmp;
 explicit Impl(size_t n):limit(n),capacity(n<=maxraw?scratch:n*8+8192),in(capacity),out(capacity),tmp(capacity){}
};
bool supported(){unsigned a,b,c,d;bool lz=__get_cpuid(0x80000001,&a,&b,&c,&d)&&(c&(1u<<5));__builtin_cpu_init();return __builtin_cpu_supports("avx2")&&__builtin_cpu_supports("bmi")&&__builtin_cpu_supports("bmi2")&&lz&&__builtin_cpu_supports("popcnt");}
const char*backend(){
return "repaired-reference-fix1";
}
Codec::Codec(Config c):Codec(c,maxraw){}
Codec::Codec(Config c,size_t limit):impl(std::make_unique<Impl>(checked_limit(c,limit))),config(c){
 if(!supported())throw std::runtime_error("unsupported CPU");
 if(c.algorithm<0||c.algorithm>3||(c.width!=8&&c.width!=16)||c.ndims<1||c.ndims>128||c.path<0||c.path>5||
 (c.path==2&&c.ndims>(c.width==8?4:2))||((c.path==3||c.path==4)&&c.algorithm%2!=0)||(c.path==5&&(c.width!=8||c.algorithm%2!=1)))throw std::invalid_argument("Sprintz configuration");
}
Codec::~Codec()=default;
size_t Codec::workspace_capacity()const{return impl->capacity*3;}
size_t Codec::message_limit()const{return impl->limit;}
// Independent length walk for the minimal repaired reference; no decoder invocation.
size_t sprintz_size(Config c,const uint8_t*p,size_t cap,size_t expected){
 Reader r{p,cap};bool rle=c.path<3;size_t e=c.width/8,d=c.ndims,n=expected/e,ng,tail;unsigned hb=e==1?3:4;
 if(rle){ng=r.word();tail=r.byte();tail|=size_t(r.byte())<<8;require(r.byte()==(d&255)&&r.byte()==(d>>8));}else{require(false);return 0;}
 size_t count=0;require(tail<=n&&ng<=n/(8*d)+1);for(size_t g=0;g<ng;g++){size_t head=r.pos;r.take((2*d*hb+7)/8);for(size_t b=0;b<2;b++){size_t sum=0;for(size_t j=0;j<d;j++){size_t bit=(b*d+j)*hb;unsigned code=(p[head+bit/8]>>(bit%8))&((1<<hb)-1);if(bit%8+hb>8)code|=(unsigned(p[head+bit/8+1])<<(8-bit%8))&((1<<hb)-1);sum+=code+(code==((1u<<hb)-1));}if(sum){r.take((c.path==2||(c.path==0&&d<=(e==1?4:2)))?sum:((sum+7)/8)*8);count+=8*d;}else{unsigned lo=r.byte();size_t run=lo&127;if(lo&128)run|=size_t(r.byte())<<7;count+=run*8*d;}require(count<=n);}}require(count+tail==n);r.take(tail*e);return r.pos;
}
Bytes Codec::encode(const uint8_t*p,size_t n){
 sz_mem::scope native_allocations;
 const size_t maxraw=impl->limit,scratch=impl->capacity;
 if(n>maxraw||(n&&!p))throw std::invalid_argument("input size");auto&a=*impl;int k=config.algorithm;
 std::memset(a.in.p,0,n+8192);if(n)std::memcpy(a.in.p,p,n);std::memset(a.out.p,0,scratch);size_t z=0;
 
  if(n%(config.width/8))throw std::invalid_argument("element size");std::memset(a.tmp.p,0,scratch);
  auto units=native_encode(config.width,k%2,config.path,a.in.p,n/(config.width/8),k>=2?a.tmp.p:a.out.p,config.ndims);if(units<0)throw std::runtime_error("native encode");z=units*(config.width/8);
  if(k>=2){if(config.width==16)z++;if(z>128*1024)throw std::invalid_argument("native Huff0 intermediate exceeds 128KiB; reduce message size");auto ret=lzbench_huff0_compress((char*)a.tmp.p,z,(char*)a.out.p,scratch,0,0,nullptr);require(ret>=0&&size_t(ret)<scratch);z=ret;}
  else z=sprintz_size(config,a.out.p,z+(config.width==16),n);
  require(z<scratch);return Bytes(a.out.p,a.out.p+z);
}
Bytes Codec::decode(const uint8_t*p,size_t z,size_t n){
 sz_mem::scope native_allocations;
 const size_t maxraw=impl->limit,scratch=impl->capacity;
 if(n>maxraw||z>maxraw*4||(z&&!p))throw std::invalid_argument("decode size");auto&a=*impl;int k=config.algorithm;std::memset(a.in.p,0,z+8192);if(z)std::memcpy(a.in.p,p,z);std::memset(a.out.p,0,n+8192);size_t got=0;
 
  if(k<2)require(sprintz_size(config,a.in.p,z,n)==z);
  const void*q=a.in.p;if(k>=2){lzbench_huff0_decompress((char*)a.in.p,z,(char*)a.tmp.p,scratch,0,0,nullptr);q=a.tmp.p;}auto ret=native_decode(config.width,k%2,config.path,q,a.out.p);require(ret>=0);got=ret*(config.width/8);
  require(got==n);return Bytes(a.out.p,a.out.p+n);
}
QueryResult Codec::query(const uint8_t*p,size_t z,size_t n){return query(p,z,n,QueryMode::Auto);}
QueryResult Codec::query(const uint8_t*p,size_t z,size_t n,QueryMode mode){
 if(config.algorithm<0||config.algorithm>3||config.path<0||config.path>2)throw std::invalid_argument("query requires Sprintz RLE path");
 if(n>impl->limit||n%(config.width/8)||!p||!z||z>impl->limit*4)throw std::invalid_argument("query size");
 const uint8_t*q=p;size_t bytes=z;
 if(config.algorithm>=2){
  auto&a=*impl;size_t declared=0;
  if(z==9){declared=rd(p,8);require(declared>0&&declared<=128*1024&&declared<a.capacity);std::memset(a.tmp.p,p[8],declared);}
  else{require(z>=4);declared=rd(p,4);
   if(!declared){require(z>=8);declared=rd(p+4,4);require(declared<=128*1024&&declared<a.capacity&&z==declared+8);std::memcpy(a.tmp.p,p+8,declared);}
   else{require(declared<=128*1024&&declared<a.capacity);size_t got=HUF_decompress(a.tmp.p,declared,p+4,z-4);require(!HUF_isError(got)&&got==declared);}
  }
  q=a.tmp.p;bytes=declared;
 }
 const bool low=config.path==2||(config.path==0&&config.ndims<=(config.width==8?4:2));
 if(mode!=QueryMode::Auto&&mode!=QueryMode::Scalar&&mode!=QueryMode::Simd)throw std::invalid_argument("query mode");
 if(mode==QueryMode::Simd&&low)throw std::invalid_argument("SIMD query requires generic packing");
 const bool simd=mode!=QueryMode::Scalar&&!low;
 size_t used=0;QueryResult result;
 if(simd){
  used=sprintz_size(config,q,bytes,n);
  // The upstream decoder uses wide loads: copy to owned, zero-padded staging.
  require(bytes+64<impl->capacity);std::memmove(impl->in.p,q,bytes);std::memset(impl->in.p+bytes,0,64);
  result=config.algorithm%2?query_simd_fire(config,impl->in.p,n):query_simd_delta(config,impl->in.p,n);
 }else result=query_scan(config,q,bytes,n,used);
 if(config.algorithm<2)require(used==bytes);
 else{require(used<=bytes&&bytes-used<=2);for(size_t j=used;j<bytes;j++)require(q[j]==0);}
 return result;
}
// SFB1: 32-byte per-message frame; all fields and native payload physically stored.
uint32_t crc32(const uint8_t*p,size_t n){
 static const std::array<uint32_t,256> table=[](){std::array<uint32_t,256> t{};for(unsigned i=0;i<256;i++){uint32_t c=i;for(unsigned j=0;j<8;j++)c=(c>>1)^(0xedb88320u&uint32_t(-int(c&1)));t[i]=c;}return t;}();
 uint32_t c=~0u;for(size_t i=0;i<n;i++)c=(c>>8)^table[(c^p[i])&255];return ~c;
}
Bytes frame(Config c,const uint8_t*raw,size_t n,const Bytes&payload){Bytes out(32+payload.size());std::memcpy(out.data(),"SFB1",4);out[4]=c.algorithm;out[5]=c.width;out[6]=c.path;wr(out.data()+8,c.ndims,4);wr(out.data()+12,n,4);wr(out.data()+16,payload.size(),4);wr(out.data()+20,crc32(raw,n),4);wr(out.data()+24,crc32(payload.data(),payload.size()),4);if(!payload.empty())std::memcpy(out.data()+32,payload.data(),payload.size());return out;}
Bytes unframe(Config c,const uint8_t*p,size_t z,size_t&n,uint32_t&checksum){return unframe(c,p,z,n,checksum,maxraw);}
Bytes unframe(Config c,const uint8_t*p,size_t z,size_t&n,uint32_t&checksum,size_t limit){require(z>=32&&std::memcmp(p,"SFB1",4)==0&&p[4]==c.algorithm&&p[5]==c.width&&p[6]==c.path&&p[7]==0&&rd(p+8,4)==unsigned(c.ndims)&&rd(p+28,4)==0);n=rd(p+12,4);size_t bytes=rd(p+16,4);require(n<=checked_limit(c,limit)&&bytes==z-32&&bytes<=4*limit);checksum=rd(p+20,4);require(crc32(p+32,bytes)==rd(p+24,4));return Bytes(p+32,p+z);}
}
