# Notices for this standalone delivery

Sprintz core: Apache-2.0 (dblalock/sprintz); FastPFOR core: Apache-2.0; embedded FSE/Huff0 sources carry BSD-2-Clause notices, and zstd root license is retained separately. Per-file notices are preserved. Modified source files and patches explicitly mark local changes.

The author lzbench benchmark program declares GPL-3.0-or-later in `_lzbench/lzbench.cpp`. The extracted Huff0 wrapper has no separate file header; its exact source lineage and GPL context are retained. In **this** delivery source_huff.cpp is linked into original/repaired/candidate research codec libraries. The older inherited notice in `ReWrite/sprintz/LICENSES/NOTICE.md` describes a previous package and must not be read as a statement that the current candidate research library avoids all lzbench wrapper code. No blanket Apache-only redistribution claim is made for this combined research package. The GPL text is included.

Frozen upstream repositories are archival provenance assets. Uncompiled embedded algorithms and tests retain their own source notices and are not all linked into the twelve delivered codec paths. No TSCompressBench code is included or integrated.
