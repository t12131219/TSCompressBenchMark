#include "sf_codec.hpp"
#include <fstream>
#include <iostream>
#include <iterator>
#include <chrono>
#include <algorithm>
#include <string>
#include <stdexcept>
#include <cstring>
#include <charconv>
#include <sys/resource.h>
using namespace sf;using Clock=std::chrono::steady_clock;
Bytes readfile(const std::string&p){std::ifstream f(p,std::ios::binary);if(!f)throw std::runtime_error("open input");return Bytes(std::istreambuf_iterator<char>(f),{});}
void u32(std::ostream&f,uint32_t x){f.write((char*)&x,4);}
uint32_t get32(std::istream&f){uint32_t x;f.read((char*)&x,4);if(!f)throw std::runtime_error("stream header");return x;}
struct Block{Bytes raw,payload,full;size_t n;};
volatile uint64_t sink=0;
int main(int argc,char**argv){try{
 if(argc<9)throw std::runtime_error("usage: worker op algorithm width dims path input stream [scope lifecycle]");
 std::string op=argv[1];Config c{std::stoi(argv[2]),std::stoi(argv[3]),std::stoi(argv[4]),std::stoi(argv[5])};
 size_t message_bytes=65536;const std::string last=argv[argc-1],prefix="--message-bytes=";
 if(last.compare(0,prefix.size(),prefix)==0){const auto text=last.substr(prefix.size());size_t size=0;const auto result=std::from_chars(text.data(),text.data()+text.size(),size);if(result.ec!=std::errc()||result.ptr!=text.data()+text.size())throw std::invalid_argument("message bytes");message_bytes=size;}
 Codec codec(c,message_bytes);std::vector<Block>blocks;size_t input=0,payload=0,representation=0;
 if(op=="decode"||op=="cross"){
  std::ifstream f(argv[7],std::ios::binary);std::ofstream out(argv[8],std::ios::binary);while(f.peek()!=EOF){uint8_t header[32];f.read((char*)header,32);if(!f)throw std::runtime_error("stream header");uint32_t n,z;std::memcpy(&n,header+12,4);std::memcpy(&z,header+16,4);if(n>codec.message_limit()||z>codec.message_limit()*4)throw std::runtime_error("stream limit");Bytes full(32+z);std::memcpy(full.data(),header,32);f.read((char*)full.data()+32,z);if(!f)throw std::runtime_error("stream truncated");size_t expected;uint32_t checksum;auto p=unframe(c,full.data(),full.size(),expected,checksum,codec.message_limit());if(expected!=n)throw std::runtime_error("outer length");auto restored=codec.decode(p.data(),p.size(),expected);if(crc32(restored.data(),restored.size())!=checksum)throw std::runtime_error("decoded CRC");out.write((char*)restored.data(),restored.size());input+=expected;}struct rusage ru;getrusage(RUSAGE_SELF,&ru);std::cout<<"{\"status\":\"PASS\",\"input_bytes\":"<<input<<",\"message_limit_bytes\":"<<codec.message_limit()<<",\"algorithm\":"<<c.algorithm<<",\"width\":"<<c.width<<",\"ndims\":"<<c.ndims<<",\"path\":"<<c.path<<",\"rss_kib\":"<<ru.ru_maxrss<<"}\n";return 0;
 }
 auto data=readfile(argv[6]);input=data.size();size_t stride=c.algorithm<4?c.ndims*(c.width/8):c.algorithm<=9?4:1;size_t chunk=(codec.message_limit()/stride)*stride;if(!chunk)throw std::runtime_error("chunk");
 std::ofstream stream;if(std::string(argv[7])!="-")stream.open(argv[7],std::ios::binary);
 for(size_t off=0;off<data.size()||(!off&&data.empty());off+=chunk){Block b;b.n=std::min(chunk,data.size()-off);b.raw.assign(data.begin()+off,data.begin()+off+b.n);b.payload=codec.encode(b.raw.data(),b.n);auto decoded=(op=="bench"||op=="encode")?b.raw:codec.decode(b.payload.data(),b.payload.size(),b.n);if(decoded!=b.raw){if(stream){auto f=frame(c,b.raw.data(),b.n,b.payload);stream.write((char*)f.data(),f.size());std::ofstream fail(std::string(argv[7])+".wrong-decoded",std::ios::binary);fail.write((char*)decoded.data(),decoded.size());}size_t first=0,wrong=0;while(first<b.n&&decoded[first]==b.raw[first])first++;for(size_t j=0;j<b.n;j++)wrong+=decoded[j]!=b.raw[j];throw std::runtime_error("wrong-output first_byte="+std::to_string(first)+" differences="+std::to_string(wrong));}if(op!="bench"||std::string(argv[8])=="frame")b.full=frame(c,b.raw.data(),b.n,b.payload);if(op!="bench"&&op!="encode"){size_t expected;uint32_t checksum;auto p=unframe(c,b.full.data(),b.full.size(),expected,checksum,codec.message_limit());if(expected!=b.n||p!=b.payload||crc32(decoded.data(),decoded.size())!=checksum)throw std::runtime_error("frame verification");}payload+=b.payload.size();representation+=32+b.payload.size();if(stream){stream.write((char*)b.full.data(),b.full.size());}blocks.push_back(std::move(b));if(data.empty())break;}
 if(op=="verify"||op=="encode"){struct rusage ru;getrusage(RUSAGE_SELF,&ru);std::cout<<"{\"status\":\"PASS\",\"input_bytes\":"<<input<<",\"payload_bytes\":"<<payload<<",\"representation_bytes\":"<<representation<<",\"blocks\":"<<blocks.size()<<",\"message_limit_bytes\":"<<codec.message_limit()<<",\"algorithm\":"<<c.algorithm<<",\"width\":"<<c.width<<",\"ndims\":"<<c.ndims<<",\"path\":"<<c.path<<",\"rss_kib\":"<<ru.ru_maxrss<<"}\n";return 0;}
 std::string scope=argv[8],life=argv[9];bool full=scope=="frame",cold=life=="cold";
 auto pass=[&](bool enc){for(auto&b:blocks){std::unique_ptr<Codec>fresh;if(cold)fresh=std::make_unique<Codec>(c,codec.message_limit());Codec& engine=cold?*fresh:codec;Bytes out;
   if(enc){out=engine.encode(b.raw.data(),b.n);if(full)out=frame(c,b.raw.data(),b.n,out);}
   else{if(full){size_t n;uint32_t checksum;auto p=unframe(c,b.full.data(),b.full.size(),n,checksum,codec.message_limit());out=engine.decode(p.data(),p.size(),n);if(crc32(out.data(),out.size())!=checksum)throw std::runtime_error("timed checksum");}else out=engine.decode(b.payload.data(),b.payload.size(),b.n);}
   sink+=out.size()+(out.empty()?0:out[0]);}}
 ;auto batch=[&](bool enc,size_t iters){auto t=Clock::now();for(size_t i=0;i<iters;i++)pass(enc);return std::chrono::duration<double>(Clock::now()-t).count();};
 pass(true);pass(false);size_t ei=1,di=1;while(ei<65536&&batch(true,ei)<0.001)ei*=2;while(di<65536&&batch(false,di)<0.001)di*=2;
 double et=batch(true,ei),dt=batch(false,di);for(auto&b:blocks){auto check=codec.encode(b.raw.data(),b.n);if(check!=b.payload||codec.decode(check.data(),check.size(),b.n)!=b.raw)throw std::runtime_error("post timing verification");}struct rusage ru;getrusage(RUSAGE_SELF,&ru);
 std::cout.precision(14);std::cout<<"{\"status\":\"PASS\",\"backend\":\""<<backend()<<"\",\"input_bytes\":"<<input<<",\"payload_bytes\":"<<payload<<",\"representation_bytes\":"<<representation<<",\"blocks\":"<<blocks.size()<<",\"encode_iterations\":"<<ei<<",\"decode_iterations\":"<<di<<",\"encode_elapsed_seconds\":"<<et<<",\"decode_elapsed_seconds\":"<<dt<<",\"encode_seconds\":"<<et/ei<<",\"decode_seconds\":"<<dt/di<<",\"workspace_capacity_bytes\":"<<codec.workspace_capacity()<<",\"message_limit_bytes\":"<<codec.message_limit()<<",\"algorithm\":"<<c.algorithm<<",\"width\":"<<c.width<<",\"ndims\":"<<c.ndims<<",\"path\":"<<c.path<<",\"rss_kib\":"<<ru.ru_maxrss<<"}\n";
 }catch(const std::exception&e){std::cerr<<e.what()<<"\n";return 2;}}
