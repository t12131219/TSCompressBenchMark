#include "sf_codec.hpp"
#include <chrono>
#include <fstream>
#include <iostream>
#include <iterator>
#include <stdexcept>
int main(int argc,char**argv){try{
 if(argc!=7)throw std::invalid_argument("usage: sprintz_query ALGORITHM WIDTH DIMS PATH INPUT.u8-or-u16 REPEATS");
 sf::Config c{std::stoi(argv[1]),std::stoi(argv[2]),std::stoi(argv[3]),std::stoi(argv[4])};sf::Codec codec(c);
 std::ifstream file(argv[5],std::ios::binary);if(!file)throw std::runtime_error("input");sf::Bytes raw(std::istreambuf_iterator<char>(file),{});size_t repeats=std::stoull(argv[6]);if(!repeats||repeats>1000000||raw.size()>codec.message_limit()||raw.size()%(c.width/8))throw std::invalid_argument("size/repeats");
 auto compressed=codec.encode(raw.data(),raw.size());sf::QueryResult expected;expected.count.assign(c.ndims,0);expected.sum.assign(c.ndims,0);expected.max.assign(c.ndims,0);
 for(size_t i=0;i<raw.size()/(c.width/8);i++){unsigned v=raw[i*(c.width/8)];if(c.width==16)v|=unsigned(raw[i*2+1])<<8;unsigned j=i%c.ndims;expected.count[j]++;expected.sum[j]+=v;expected.max[j]=std::max(expected.max[j],v);}
 sf::QueryResult result;auto start=std::chrono::steady_clock::now();for(size_t r=0;r<repeats;r++)result=codec.query(compressed.data(),compressed.size(),raw.size());double seconds=std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count();if(result.count!=expected.count||result.sum!=expected.sum||result.max!=expected.max)throw std::runtime_error("query mismatch");
 std::cout<<"{\"backend\":\""<<(result.backend==sf::QueryBackend::UpstreamSimd?"upstream_simd":"scalar_fallback")<<"\",\"status\":\"PASS\",\"operation\":\"compressed_query\",\"algorithm\":"<<c.algorithm<<",\"width\":"<<c.width<<",\"dimensions\":"<<c.ndims<<",\"raw_bytes\":"<<raw.size()<<",\"compressed_bytes\":"<<compressed.size()<<",\"iterations\":"<<repeats<<",\"elapsed_seconds\":"<<seconds<<",\"channels\":[";
 for(size_t j=0;j<result.count.size();j++){if(j)std::cout<<',';std::cout<<"{\"count\":"<<result.count[j]<<",\"sum\":"<<result.sum[j]<<",\"max\":"<<result.max[j]<<'}';}std::cout<<"]}\n";
 }catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 2;}}
