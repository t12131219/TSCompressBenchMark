# Sprintz SIMD query 修复与集成

日期：2026-11-10。唯一主实现仍为 repaired_codec / unique-v1。

- 直接复用作者 generic Delta/FIRE RLE query 模板（commit a056cdb67d049669875ab5487359aca99ae873ea），修改以 patches/*.patch 保留；没有用普通整列解压替代查询。
- 聚合器按 SIMD vector stripe 分开更新，不再使用上游 MaxQuery 错误的 state[0] 写入。unsigned max 保留 8/16 位语义；sum/count 先拓宽到 64 位，包含 RLE repeats。
- 补齐短输入、literal 尾部及不完整行的 count/sum/max；只返回真实通道，忽略 padding lanes。
- FIRE16 修复上游 query 多余的 prediction << 2，并应用主 codec 已有的 RLE 奇数系数 lane/Q12 修复。
- 非物化模式取消所有输出写入，以整数 produced 计数替代无效输出指针运算；使用现有可清理 allocator、真实 64B 零后缀和未对齐访问类型；16 位头暂存区按元素宽度分配。
- SIMD 调用前执行有界 grammar walk，输入复制到自有带零后缀的 staging；Huffman 先有界解熵。generic 默认 SIMD，lowdim 使用原标量扫描；可显式强制 Scalar/Simd，且结果报告 backend。

验证：Release 18,004 组，15,364 组选择 SIMD、2,640 组选择标量后备；每组比较默认查询、独立标量扫描、原数组直接归约及完整解码。覆盖四变体、8/16 位、多条带/非整向量通道、RLE/长 RLE、高位无符号、空/短/尾部/不完整行、百万点 sum>2^32 和 FIRE16 定向反例。原 4,080 组查询回归通过。相同 18,004 组通过 ASan+UBSan+LeakSanitizer（detect_leaks=1、halt_on_error=1）。

独立发布包解包构建和复验记录见交付树 docs/validation/sprintz-simd-query-20261110.json。测试代码存放在交付树外，不交付第二份算法实现。压缩输出与之前发布的 codec 另行核对；未重跑统一性能实验。
