# Sprintz-family · unique-v1

本工程只交付一个主选实现 `repaired_codec`，覆盖 18 Sprintz-Delta、19 Sprintz-FIRE、20 Sprintz-Delta-Huffman、21 Sprintz-FIRE-Huffman。

## 构建

```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j4
```

支持Linux x86_64，GCC/G++、CMake≥3.22、make。ISA要求及运行约束见下表。工程自带所需源码依赖；构建输出不在发布包内。

默认构建包含本工程主选功能组件。

独立C/C++对照、历史版本、上游oracle及独立验证程序不交付。辅助库、共享格式代码、ISA加速和训练/流式等模块服务于同一主实现。`reference`、`fpc-original` 等历史target名称是CSV主选标识，不代表存在另一份并列实现。

## 18. Sprintz-Delta

| 属性 | 支持范围与限制 |
| --- | --- |
| 技术家族 | 整数预测+位打包+可选Huffman |
| 方法角色 | 多通道整数codec |
| 编码流水线 | Delta预测+残差bitpack/RLE |
| 原生类型 | uint8 / uint16位模式 |
| 输入适配 | 原生整数；CSV将f64按16位limb重解释，非浮点量化模型 |
| 数值域与特殊值 | 按位保留8/16位输入；完整行合同 |
| 形状与多变量 | 多通道，同步行；各通道预测/共用块布局 |
| 时间轴或显式x | 不支持：仅隐式样本序号 |
| 布局与stride | row-major及核心内部转置/bitpack |
| 缺失值语义 | 未声明原生mask；不隐式插补 |
| 恢复与质量合同 | 整数位级无损；limb适配需完整schema |
| 核心参数 | 四变体、8/16位、1..128通道；主选PATH0；message_limit可配置 |
| 批处理 | 支持：整输入调用 |
| 增量编码 | 不支持：所选核心无此公开入口 |
| 增量解码 | 批量完整恢复 |
| 状态与复用 | 每消息预测器reset，消息内持续更新；无跨消息在线模型 |
| 点范围与seek | 不支持：所选核心无此公开入口 |
| 渐进恢复 | 不支持：所选核心无此公开入口 |
| 压缩域计算 | 支持：Codec::query / sprintz_query；四变体8/16bit逐通道count/uint64 unsigned sum/uint32 max；generic由修复上游AVX2 query执行，auto按实际packing分派，lowdim由标量扫描后备；RLE、短输入与不完整行/尾部均计入；QueryMode::Scalar可交叉核验，QueryResult::backend返回所选后端；不物化完整解压列；Huffman先解熵到临时缓冲；非任意SQL/filter |
| 训练或在线学习 | 无需训练；Delta历史状态 |
| 字典码本复用 | 不支持：所选核心无此公开入口 |
| SIMD或ISA | 压缩及generic query保留AVX2/BMI1/BMI2/LZCNT/POPCNT强ISA；query复用上游SIMD解包/预测并以无符号max、64位sum/count聚合；尾部及lowdim为标量；不是无ISA的codec fallback |
| 内部并行编码 | 不支持：所选调用路径串行 |
| 内部并行解码 | 不支持：所选调用路径串行 |
| GPU | 未确认：未对该冻结核心建立GPU入口证据 |
| 并发与所有权 | 独立Codec workspace；同对象独占 |
| 格式与兼容 | SFB1完整帧，32字节头及CRC |
| 独立恢复依赖 | 完整SFB1及limb/布局schema须计费 |
| 运行与构建依赖 | 主选C++17 repaired_codec及Huff0依赖；新增原生sprintz_query；无Python/Rust运行依赖 |
| 长度尾部与资源 | 默认64KiB；显式扩展至16MiB；1..128通道、完整行/尾部 |
| 确定性条件 | 未确认：未建立跨平台字节确定性保证 |
| 许可范围 | 源码许可声明及 fix_ReWrite/Sprintz-family/licenses 中的冻结归属材料。 |
| 已知限制与身份 | 默认codec/limb适配与SFB1计费保留；压缩域query单独工作负载；保留强ISA，无内部MT、跨消息stream或通用SQL接口 |
## 19. Sprintz-FIRE

| 属性 | 支持范围与限制 |
| --- | --- |
| 技术家族 | 整数预测+位打包+可选Huffman |
| 方法角色 | 多通道整数codec |
| 编码流水线 | FIRE在线自适应预测+残差bitpack/RLE |
| 原生类型 | uint8 / uint16位模式 |
| 输入适配 | 原生整数；CSV将f64按16位limb重解释，非浮点量化模型 |
| 数值域与特殊值 | 按位保留8/16位输入；完整行合同 |
| 形状与多变量 | 多通道，同步行；各通道预测/共用块布局 |
| 时间轴或显式x | 不支持：仅隐式样本序号 |
| 布局与stride | row-major及核心内部转置/bitpack |
| 缺失值语义 | 未声明原生mask；不隐式插补 |
| 恢复与质量合同 | 整数位级无损；limb适配需完整schema |
| 核心参数 | 四变体、8/16位、1..128通道；主选PATH0；message_limit可配置 |
| 批处理 | 支持：整输入调用 |
| 增量编码 | 不支持：所选核心无此公开入口 |
| 增量解码 | 批量完整恢复 |
| 状态与复用 | 每消息预测器reset，消息内持续更新；无跨消息在线模型 |
| 点范围与seek | 不支持：所选核心无此公开入口 |
| 渐进恢复 | 不支持：所选核心无此公开入口 |
| 压缩域计算 | 支持：Codec::query / sprintz_query；四变体8/16bit逐通道count/uint64 unsigned sum/uint32 max；generic由修复上游AVX2 query执行，auto按实际packing分派，lowdim由标量扫描后备；RLE、短输入与不完整行/尾部均计入；QueryMode::Scalar可交叉核验，QueryResult::backend返回所选后端；不物化完整解压列；Huffman先解熵到临时缓冲；非任意SQL/filter |
| 训练或在线学习 | FIRE消息内更新；无跨消息模型/离线训练 |
| 字典码本复用 | 不支持：所选核心无此公开入口 |
| SIMD或ISA | 压缩及generic query保留AVX2/BMI1/BMI2/LZCNT/POPCNT强ISA；query复用上游SIMD解包/预测并以无符号max、64位sum/count聚合；尾部及lowdim为标量；不是无ISA的codec fallback |
| 内部并行编码 | 不支持：所选调用路径串行 |
| 内部并行解码 | 不支持：所选调用路径串行 |
| GPU | 未确认：未对该冻结核心建立GPU入口证据 |
| 并发与所有权 | 独立Codec workspace；同对象独占 |
| 格式与兼容 | SFB1完整帧，32字节头及CRC |
| 独立恢复依赖 | 完整SFB1及limb/布局schema须计费 |
| 运行与构建依赖 | 主选C++17 repaired_codec及Huff0依赖；新增原生sprintz_query；无Python/Rust运行依赖 |
| 长度尾部与资源 | 默认64KiB；显式扩展至16MiB；1..128通道、完整行/尾部 |
| 确定性条件 | 未确认：未建立跨平台字节确定性保证 |
| 许可范围 | 源码许可声明及 fix_ReWrite/Sprintz-family/licenses 中的冻结归属材料。 |
| 已知限制与身份 | 默认codec/limb适配与SFB1计费保留；压缩域query单独工作负载；保留强ISA，无内部MT、跨消息stream或通用SQL接口 |
## 20. Sprintz-Delta-Huffman

| 属性 | 支持范围与限制 |
| --- | --- |
| 技术家族 | 整数预测+位打包+可选Huffman |
| 方法角色 | 多通道整数codec |
| 编码流水线 | Delta预测+残差bitpack/RLE+Huff0 |
| 原生类型 | uint8 / uint16位模式 |
| 输入适配 | 原生整数；CSV将f64按16位limb重解释，非浮点量化模型 |
| 数值域与特殊值 | 按位保留8/16位输入；完整行合同 |
| 形状与多变量 | 多通道，同步行；各通道预测/共用块布局 |
| 时间轴或显式x | 不支持：仅隐式样本序号 |
| 布局与stride | row-major及核心内部转置/bitpack |
| 缺失值语义 | 未声明原生mask；不隐式插补 |
| 恢复与质量合同 | 整数位级无损；limb适配需完整schema |
| 核心参数 | 四变体、8/16位、1..128通道；主选PATH0；message_limit可配置 |
| 批处理 | 支持：整输入调用 |
| 增量编码 | 不支持：所选核心无此公开入口 |
| 增量解码 | 批量完整恢复 |
| 状态与复用 | 每消息预测器reset，消息内持续更新；无跨消息在线模型 |
| 点范围与seek | 不支持：所选核心无此公开入口 |
| 渐进恢复 | 不支持：所选核心无此公开入口 |
| 压缩域计算 | 支持：Codec::query / sprintz_query；四变体8/16bit逐通道count/uint64 unsigned sum/uint32 max；generic由修复上游AVX2 query执行，auto按实际packing分派，lowdim由标量扫描后备；RLE、短输入与不完整行/尾部均计入；QueryMode::Scalar可交叉核验，QueryResult::backend返回所选后端；不物化完整解压列；Huffman先解熵到临时缓冲；非任意SQL/filter |
| 训练或在线学习 | 无需训练；Delta历史状态 |
| 字典码本复用 | 不支持：所选核心无此公开入口 |
| SIMD或ISA | 压缩及generic query保留AVX2/BMI1/BMI2/LZCNT/POPCNT强ISA；query复用上游SIMD解包/预测并以无符号max、64位sum/count聚合；尾部及lowdim为标量；不是无ISA的codec fallback |
| 内部并行编码 | 不支持：所选调用路径串行 |
| 内部并行解码 | 不支持：所选调用路径串行 |
| GPU | 未确认：未对该冻结核心建立GPU入口证据 |
| 并发与所有权 | 独立Codec workspace；同对象独占 |
| 格式与兼容 | SFB1完整帧，32字节头及CRC |
| 独立恢复依赖 | 完整SFB1及limb/布局schema须计费 |
| 运行与构建依赖 | 主选C++17 repaired_codec及Huff0依赖；新增原生sprintz_query；无Python/Rust运行依赖 |
| 长度尾部与资源 | 输入扩展至16MiB，但Huff0中间流≤128KiB；失败须显式缩块 |
| 确定性条件 | 未确认：未建立跨平台字节确定性保证 |
| 许可范围 | 源码许可声明及 fix_ReWrite/Sprintz-family/licenses 中的冻结归属材料。 |
| 已知限制与身份 | 默认codec/limb适配与SFB1计费保留；压缩域query单独工作负载；保留强ISA，无内部MT、跨消息stream或通用SQL接口 |
## 21. Sprintz-FIRE-Huffman

| 属性 | 支持范围与限制 |
| --- | --- |
| 技术家族 | 整数预测+位打包+可选Huffman |
| 方法角色 | 多通道整数codec |
| 编码流水线 | FIRE在线自适应预测+残差bitpack/RLE+Huff0 |
| 原生类型 | uint8 / uint16位模式 |
| 输入适配 | 原生整数；CSV将f64按16位limb重解释，非浮点量化模型 |
| 数值域与特殊值 | 按位保留8/16位输入；完整行合同 |
| 形状与多变量 | 多通道，同步行；各通道预测/共用块布局 |
| 时间轴或显式x | 不支持：仅隐式样本序号 |
| 布局与stride | row-major及核心内部转置/bitpack |
| 缺失值语义 | 未声明原生mask；不隐式插补 |
| 恢复与质量合同 | 整数位级无损；limb适配需完整schema |
| 核心参数 | 四变体、8/16位、1..128通道；主选PATH0；message_limit可配置 |
| 批处理 | 支持：整输入调用 |
| 增量编码 | 不支持：所选核心无此公开入口 |
| 增量解码 | 批量完整恢复 |
| 状态与复用 | 每消息预测器reset，消息内持续更新；无跨消息在线模型 |
| 点范围与seek | 不支持：所选核心无此公开入口 |
| 渐进恢复 | 不支持：所选核心无此公开入口 |
| 压缩域计算 | 支持：Codec::query / sprintz_query；四变体8/16bit逐通道count/uint64 unsigned sum/uint32 max；generic由修复上游AVX2 query执行，auto按实际packing分派，lowdim由标量扫描后备；RLE、短输入与不完整行/尾部均计入；QueryMode::Scalar可交叉核验，QueryResult::backend返回所选后端；不物化完整解压列；Huffman先解熵到临时缓冲；非任意SQL/filter |
| 训练或在线学习 | FIRE消息内更新；无跨消息模型/离线训练 |
| 字典码本复用 | 不支持：所选核心无此公开入口 |
| SIMD或ISA | 压缩及generic query保留AVX2/BMI1/BMI2/LZCNT/POPCNT强ISA；query复用上游SIMD解包/预测并以无符号max、64位sum/count聚合；尾部及lowdim为标量；不是无ISA的codec fallback |
| 内部并行编码 | 不支持：所选调用路径串行 |
| 内部并行解码 | 不支持：所选调用路径串行 |
| GPU | 未确认：未对该冻结核心建立GPU入口证据 |
| 并发与所有权 | 独立Codec workspace；同对象独占 |
| 格式与兼容 | SFB1完整帧，32字节头及CRC |
| 独立恢复依赖 | 完整SFB1及limb/布局schema须计费 |
| 运行与构建依赖 | 主选C++17 repaired_codec及Huff0依赖；新增原生sprintz_query；无Python/Rust运行依赖 |
| 长度尾部与资源 | 输入扩展至16MiB，但Huff0中间流≤128KiB；失败须显式缩块 |
| 确定性条件 | 未确认：未建立跨平台字节确定性保证 |
| 许可范围 | 源码许可声明及 fix_ReWrite/Sprintz-family/licenses 中的冻结归属材料。 |
| 已知限制与身份 | 默认codec/limb适配与SFB1计费保留；压缩域query单独工作负载；保留强ISA，无内部MT、跨消息stream或通用SQL接口 |

## SIMD query 修复（2026-11-10）

Generic RLE 直接调用作者的 `query_rowmajor_delta_rle<false>` / `query_rowmajor_xff_rle<false>` 模板。源码父版本为 `dblalock/sprintz` 的 `a056cdb67d049669875ab5487359aca99ae873ea`，两份模板的修改见 `patches/*.patch`。保留原 SIMD 解包和预测；新聚合器修复条带归属，使用无符号 max 与 64 位 sum/count。

`codec.query(payload, bytes, raw_bytes)` 默认自动分派。`QueryMode::Scalar` 强制独立标量扫描，`QueryMode::Simd` 强制 generic SIMD（lowdim 拒绝）；`result.backend` 区分 `UpstreamSimd` 与 `Scalar`。CLI JSON 的 `backend` 字段报告选择结果。短输入和末尾 literal 用标量计入，且不将 SIMD 填充通道返回给调用方。Huffman 先解熵后分派。

此接口新增结果字段，C++ 调用方需以本次头文件和库重新编译。没有新增无 AVX2 的 codec 后备，也没有重跑统一性能实验。
