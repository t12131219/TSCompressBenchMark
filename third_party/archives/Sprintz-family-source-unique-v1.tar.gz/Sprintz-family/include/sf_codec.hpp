#pragma once
#include <cstdint>
#include <cstddef>
#include <memory>
#include <vector>
namespace sf {
using Bytes=std::vector<uint8_t>;
struct Config{int algorithm=0,width=16,ndims=4,path=0;};
// Algorithm IDs: selected Sprintz 0..3.
// Unsigned per-channel reductions, including partial rows and literal tails.
enum class QueryBackend { Scalar, UpstreamSimd };
enum class QueryMode { Auto, Scalar, Simd };
struct QueryResult {std::vector<uint64_t> count,sum;std::vector<uint32_t> max;QueryBackend backend=QueryBackend::Scalar;};
struct Codec {
 struct Impl;std::unique_ptr<Impl> impl;Config config;
 explicit Codec(Config);Codec(Config,size_t max_input_bytes);~Codec();Codec(const Codec&)=delete;
 Bytes encode(const uint8_t*,size_t);Bytes decode(const uint8_t*,size_t,size_t);
 // Sprintz algorithm 0..3, paths 0..2. Huffman is unwrapped before scanning;
 // the Sprintz stage retains predictor state only, never a decoded column.
 QueryResult query(const uint8_t*,size_t compressed_bytes,size_t raw_bytes);
 // Scalar is the independent reference/fallback; Simd requires generic packing.
 QueryResult query(const uint8_t*,size_t,size_t,QueryMode);
 size_t workspace_capacity()const;
 size_t message_limit()const;
};
uint32_t crc32(const uint8_t*,size_t);
Bytes frame(Config,const uint8_t*,size_t,const Bytes&);
Bytes unframe(Config,const uint8_t*,size_t,size_t&,uint32_t&);
Bytes unframe(Config,const uint8_t*,size_t,size_t&,uint32_t&,size_t max_input_bytes);
const char*backend();bool supported();
}
