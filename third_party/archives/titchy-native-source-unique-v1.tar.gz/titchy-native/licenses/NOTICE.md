# 来源与许可声明

上游 https://github.com/DeSitterUniverse/Titchy-rs ，提交 d43af7b3b4323483bd894ce1d884f049957db376。随附 `upstream/` 保留来源内容，逐文件哈希见 `source-manifest.json`。其 Cargo.toml 的 license 字段声明 **MIT OR Apache-2.0**；冻结快照未提供单独 LICENSE 文本文件。本项目如实保留这一声明，不自行补写作者授权书或声称获得额外许可。

原版 Rust 核心未经改动；oracle/ 下代码仅提供FFI与实际操作计时。C、C++重写采用上游算法语义和文件格式；新增代码/文档在此工作区为本次任务编写，未从其他本地算法项目复制核心。此说明不是法律许可保证。

运行闭包：纯C库依赖系统 libc/libm；C++组合库另依赖系统 C++ runtime。Rust oracle 静态链接本机 Rust标准库至cdylib，无第三方crate。CMake、GCC/G++、Rust/Cargo、Python、NumPy、pandas为构建/验证工具，未把其源码重新打包为本项目代码。upstream测试/示例/文档整体作为追溯材料保留。
