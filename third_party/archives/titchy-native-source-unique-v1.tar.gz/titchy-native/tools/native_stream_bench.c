#include "native_bench.h"
#include "titchy.h"
/* TSTR v1 transport: 21-byte header + (u16 chunk_count,u32 bytes,payload).
 * The 32-byte TSC1 manifest below carries every external configuration field.
 * Both are charged. Stream kernel uses the C11 packet/LRU implementation. */
static void put(uint8_t *p,uint64_t n,unsigned size){for(unsigned j=0;j<size;j++)p[j]=(uint8_t)(n>>(8*j));}
static uint64_t get(const uint8_t *p,unsigned size){uint64_t n=0;for(unsigned j=0;j<size;j++)n|=(uint64_t)p[j]<<(8*j);return n;}
static void drain(titchy_stream_encoder *s,uint8_t **archive,size_t *used,size_t *capacity,uint32_t *packets,uint8_t *buf,size_t bufcap){
  size_t bytes,chunks;
  for(;;){if(titchy_stream_pop(s,buf,bufcap,&bytes,&chunks))nb_fail("stream pop failed");if(!bytes)return;
    if(chunks>65535||bytes>UINT32_MAX||bytes>SIZE_MAX-*used-6)nb_fail("stream record overflow");
    size_t need=*used+6+bytes;if(need>*capacity){uint8_t *p=realloc(*archive,need);if(!p)nb_fail("archive allocation failed");*archive=p;*capacity=need;}
    put(*archive+*used,chunks,2);put(*archive+*used+2,bytes,4);memcpy(*archive+*used+6,buf,bytes);*used=need;(*packets)++;
  }
}
int main(int argc,char **argv){
  nb_platform();if(argc<4||argc>12||strcmp(argv[1],"bench"))nb_fail("usage: titchy_stream_bench bench INPUT.u64 REPEATS [BITS [CHUNK [SPLIT [PACKET [THRESHOLD [LIMIT [ENDIAN [ARCHIVE]]]]]]]]");
  size_t bytes,n,reps=nb_number(argv[3],1000000);if(!reps)nb_fail("positive repeats required");
  uint8_t *raw=nb_read(argv[2],8000000,&bytes);if(bytes%8)nb_fail("incomplete u64 input");n=bytes/8;
  titchy_config c={64,4,1000,0,.25,UINT64_MAX};size_t target=1000;
  if(argc>4)c.bits_per_sample=(uint8_t)nb_number(argv[4],64);
  if(argc>5)c.samples_per_chunk=(uint8_t)nb_number(argv[5],255);
  if(argc>6)c.chunks_per_split=(uint16_t)nb_number(argv[6],65535);
  if(argc>7)target=nb_number(argv[7],65535);
  if(argc>8)c.threshold=nb_real(argv[8]);
  if(argc>9)c.max_active_bytes=nb_number(argv[9],SIZE_MAX);
  if(argc>10)c.endian=(uint8_t)nb_number(argv[10],1);
  if(!target||!titchy_bound(n,&c))nb_fail("invalid stream config");
  size_t bufcap=3+127*64+(target*(32+255)+7)/8;uint8_t *buf=nb_alloc(bufcap),*archive=NULL;size_t used=0,cap=0;
  uint64_t *y=nb_alloc((n+c.samples_per_chunk)*8);double et=0,dt=0;uint32_t packets=0;
  for(size_t r=0;r<reps;r++){
    double t=nb_clock();titchy_stream_encoder *s=NULL;if(titchy_stream_encoder_create(&c,target,n,&s))nb_fail("stream create failed");
    free(archive);archive=nb_alloc(21);cap=used=21;packets=0;
    for(size_t j=0;j<n;j++){if(titchy_stream_push(s,((uint64_t*)raw)[j]))nb_fail("stream push failed");drain(s,&archive,&used,&cap,&packets,buf,bufcap);}
    if(titchy_stream_finish(s))nb_fail("stream finish failed");
    drain(s,&archive,&used,&cap,&packets,buf,bufcap);titchy_stream_encoder_free(s);
    memcpy(archive,"TSTR\1",5);archive[5]=c.bits_per_sample;archive[6]=c.samples_per_chunk;put(archive+7,c.chunks_per_split,2);put(archive+9,n,8);put(archive+17,packets,4);et+=nb_clock()-t;
    t=nb_clock();titchy_stream_decoder *d=NULL;if(titchy_stream_decoder_create(&c,n+c.samples_per_chunk-1,&d))nb_fail("stream decoder create failed");
    size_t at=21,count=0;
    for(uint32_t j=0;j<packets;j++){
      if(used-at<6)nb_fail("stream record truncated");
      size_t chunks=(size_t)get(archive+at,2),length=(size_t)get(archive+at+2,4),got=0;at+=6;
      if(length>used-at||titchy_stream_decode_packet(d,archive+at,length,chunks,y+count,n+c.samples_per_chunk-count,&got))nb_fail("stream decode failed");
      count+=got;at+=length;
    }
    titchy_stream_decoder_free(d);dt+=nb_clock()-t;
    if(at!=used||count<n||count>=n+c.samples_per_chunk||memcmp(y,raw,bytes))nb_fail("stream recovery failed");
    for(size_t j=n;j<count;j++)if(y[j])nb_fail("nonzero stream padding");
  }
  /* Manifest enables reproducing every codec/transport parameter without Python. */
  uint8_t manifest[32]={0};memcpy(manifest,"TSC1",4);manifest[4]=c.bits_per_sample;manifest[5]=c.samples_per_chunk;put(manifest+6,c.chunks_per_split,2);manifest[8]=c.endian;put(manifest+10,target,2);memcpy(manifest+12,&c.threshold,8);put(manifest+20,c.max_active_bytes,8);
  if(argc>11){nb_write(argv[11],archive,used);size_t l=strlen(argv[11]);char *path=nb_alloc(l+6);memcpy(path,argv[11],l);memcpy(path+l,".tsc1",6);nb_write(path,manifest,32);free(path);}
  char configuration[512];snprintf(configuration,sizeof configuration,"{\"bits\":%u,\"chunk\":%u,\"split\":%u,\"packet_target\":%zu,\"threshold\":%.17g,\"limit\":%llu,\"endian\":%u,\"archive_bytes\":%zu,\"external_config_bytes\":32,\"packets\":%u,\"internal_threads\":1}",c.bits_per_sample,c.samples_per_chunk,c.chunks_per_split,target,c.threshold,(unsigned long long)c.max_active_bytes,c.endian,used,packets);
  nb_report("C11-Titchy-stream",bytes,used+32,reps,0,et,dt,0,0,configuration);
  free(raw);free(buf);free(archive);free(y);return 0;
}
