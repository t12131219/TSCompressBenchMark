#ifndef NATIVE_BENCH_IO_H
#define NATIVE_BENCH_IO_H
/* Standalone C11 bench support. Linux x86-64, little-endian IEEE input files. */
#ifndef _POSIX_C_SOURCE
#define _POSIX_C_SOURCE 200809L
#endif
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <errno.h>
#include <limits.h>
#include <float.h>
static inline void nb_fail(const char *message) {fprintf(stderr,"%s\n",message);exit(2);}
static inline size_t nb_number(const char *s,size_t limit) {
  char *end=NULL;errno=0;
  if(!s||!*s||*s=='-')nb_fail("invalid unsigned argument");
  unsigned long long n=strtoull(s,&end,10);
  if(errno||*end||n>limit)nb_fail("unsigned argument outside limit");
  return (size_t)n;
}
static inline double nb_real(const char *s) {char *end=NULL;errno=0;double v=strtod(s,&end);if(errno||end==s||*end||!isfinite(v))nb_fail("invalid real argument");return v;}
static inline void *nb_alloc(size_t n) {void *p=malloc(n?n:1);if(!p)nb_fail("allocation failed");return p;}
static inline uint8_t *nb_read(const char *path,size_t maximum,size_t *size) {
  FILE *f=fopen(path,"rb");if(!f)nb_fail("cannot open input");
  if(fseek(f,0,SEEK_END))nb_fail("input must be seekable");
  long n=ftell(f);if(n<0||(uint64_t)n>maximum||fseek(f,0,SEEK_SET))nb_fail("input size outside limit");
  uint8_t *p=nb_alloc((size_t)n);
  if(fread(p,1,(size_t)n,f)!=(size_t)n||fclose(f))nb_fail("input read failed");
  *size=(size_t)n;return p;
}
static inline void nb_write(const char *path,const void *p,size_t n) {
  FILE *f=fopen(path,"wb");if(!f)nb_fail("cannot open output");
  if(fwrite(p,1,n,f)!=n||fclose(f))nb_fail("output write failed");
}
static inline double nb_clock(void) {struct timespec t;if(clock_gettime(CLOCK_MONOTONIC,&t))nb_fail("clock failed");return (double)t.tv_sec+(double)t.tv_nsec*1e-9;}
static inline void nb_platform(void) {uint16_t x=1;if(*(uint8_t*)&x!=1||sizeof(double)!=8||sizeof(float)!=4)nb_fail("requires little-endian IEEE platform");}
static inline void nb_finite(const double *x,size_t n) {for(size_t i=0;i<n;i++)if(!isfinite(x[i]))nb_fail("finite f64 input required");}
static inline void nb_quality(const double *x,const double *y,size_t n,double *maximum,double *rmse) {
  long double ss=0,m=0;
  for(size_t i=0;i<n;i++){if(!isfinite(y[i]))nb_fail("nonfinite reconstruction");long double d=(long double)x[i]-y[i];if(fabsl(d)>m)m=fabsl(d);ss+=d*d;}
  if(m>DBL_MAX||(n&&sqrtl(ss/n)>DBL_MAX))nb_fail("quality metric outside binary64 range");
  *maximum=(double)m;*rmse=n?(double)sqrtl(ss/n):0;
}
static inline void nb_report(const char *backend,size_t raw,size_t packed,size_t repeats,double setup,double enc,double dec,double maximum,double rmse,const char *configuration) {
  printf("{\"status\":\"PASS\",\"backend\":\"%s\",\"raw_bytes\":%zu,\"frame_bytes\":%zu,\"repeats\":%zu,\"setup_seconds\":%.17g,\"encode_seconds\":%.17g,\"decode_seconds\":%.17g,\"max_abs_error\":%.17g,\"rmse\":%.17g,\"encode_MiB_s\":%.17g,\"decode_MiB_s\":%.17g,\"configuration\":%s,\"timing\":\"mean full codec calls; internal allocation and model serialization included; input/output buffers preallocated; file IO/setup/quality checks excluded; no corpus ranking claim\"}\n",backend,raw,packed,repeats,setup,enc/repeats,dec/repeats,maximum,rmse,enc>0?(double)raw*repeats/1048576/enc:0,dec>0?(double)raw*repeats/1048576/dec:0,configuration);
}
#endif
