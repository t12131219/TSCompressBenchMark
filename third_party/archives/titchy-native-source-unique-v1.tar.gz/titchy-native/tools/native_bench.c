#include "native_bench.h"
#include "titchy.h"
int main(int argc,char **argv) {
  nb_platform();
  if(argc<4||argc>12||argc==11||strcmp(argv[1],"bench"))nb_fail("usage: titchy_native bench INPUT.u64 REPEATS [BITS [CHUNK [SPLIT [THRESHOLD [LIMIT [ENDIAN [START LENGTH]]]]]]]");
  size_t bytes,n,repeats=nb_number(argv[3],1000000);if(!repeats)nb_fail("positive repeats required");
  uint8_t *input=nb_read(argv[2],1000000*8,&bytes);if(bytes%8)nb_fail("incomplete u64 input");n=bytes/8;
  titchy_config cfg={64,4,1000,0,.25,UINT64_MAX};
  if(argc>4)cfg.bits_per_sample=(uint8_t)nb_number(argv[4],64);
  if(argc>5)cfg.samples_per_chunk=(uint8_t)nb_number(argv[5],255);
  if(argc>6)cfg.chunks_per_split=(uint16_t)nb_number(argv[6],65535);
  if(argc>7)cfg.threshold=nb_real(argv[7]);
  if(argc>8)cfg.max_active_bytes=nb_number(argv[8],SIZE_MAX);
  if(argc>9)cfg.endian=(uint8_t)nb_number(argv[9],1);
  size_t start=argc>10?nb_number(argv[10],n):0,length=argc>11?nb_number(argv[11],n-start):n;
  size_t cap=titchy_bound(n,&cfg);if(!cap)nb_fail("invalid Titchy configuration");
  uint8_t *wire=nb_alloc(cap);uint64_t *y=nb_alloc(bytes);size_t used=0,count=0;double t,et=0,dt=0;
  for(size_t r=0;r<repeats;r++) {
    t=nb_clock();int e=titchy_c_encode((uint64_t*)input,n,&cfg,wire,cap,&used);et+=nb_clock()-t;if(e)nb_fail("Titchy C encode failed");
    t=nb_clock();e=titchy_c_decode(wire,used,y,n,n,&count);dt+=nb_clock()-t;if(e||count!=n||memcmp(input,y,bytes))nb_fail("Titchy C roundtrip failed");
  }
  t=nb_clock();if(titchy_c_range(wire,used,start,length,y,length,n))nb_fail("Titchy C range failed");
  double range=nb_clock()-t;if(memcmp(input+8*start,y,8*length))nb_fail("Titchy range mismatch");
  char configuration[512];snprintf(configuration,sizeof configuration,"{\"bits\":%u,\"chunk\":%u,\"split\":%u,\"threshold\":%.17g,\"limit\":%llu,\"endian\":%u,\"range_start\":%zu,\"range_length\":%zu,\"range_seconds\":%.17g,\"range_includes_container_validation\":true,\"internal_threads\":1}",cfg.bits_per_sample,cfg.samples_per_chunk,cfg.chunks_per_split,cfg.threshold,(unsigned long long)cfg.max_active_bytes,cfg.endian,start,length,range);
  nb_report("C11-Titchy-batch-range",bytes,used,repeats,0,et,dt,0,0,configuration);
  free(input);free(wire);free(y);return 0;
}
