#ifndef TITCHY_H
#define TITCHY_H
#include <stddef.h>
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
/* Pure integer/bit patterns, stateless/reentrant, no overlapping buffers.
 * caller owns buffers; count/capacity/max_values are u64 elements except
 * wire_capacity/wire_size in bytes. On any error the written/count result becomes zero
 * (output contents unspecified). Unlimited active dictionary uses UINT64_MAX.
 * See contract.md for domains, format, and malformed-stream strictness. */
typedef struct {
  uint8_t bits_per_sample, samples_per_chunk;
  uint16_t chunks_per_split;
  uint8_t endian;
  double threshold;
  uint64_t max_active_bytes;
} titchy_config;
enum {
  TITCHY_OK = 0,
  TITCHY_INVALID = 1,
  TITCHY_CAPACITY = 2,
  TITCHY_MEMORY = 3,
  TITCHY_STREAM = 4
};
size_t titchy_bound(size_t count, const titchy_config *config);
int titchy_c_encode(const uint64_t *samples, size_t count,
                    const titchy_config *config, uint8_t *wire,
                    size_t wire_capacity, size_t *written);
int titchy_c_decode(const uint8_t *wire, size_t wire_size, uint64_t *samples,
                    size_t capacity, size_t max_values, size_t *count);
/* After bounded whole-container validation, decode only intersecting chunks.
 * start/length in samples; capacity>=length, max_values limits original count.
 */
int titchy_c_range(const uint8_t *wire, size_t wire_size, size_t start,
                   size_t length, uint64_t *samples, size_t capacity,
                   size_t max_values);
/* Reusable indexed reader. open validates header/index once; queries validate
 * only accessed pairs, not unrelated payloads. read_at returns 0 on complete
 * read. Its context/backing bytes must remain immutable/alive until free.
 * File reader owns its FILE; single owner per reader. Bit indices are MSB first
 * within each sample, matching upstream get_by_bit_index. */
typedef struct titchy_reader titchy_reader;
typedef int (*titchy_read_at)(void*,uint64_t offset,void*,size_t bytes);
int titchy_reader_open(titchy_read_at,void*,size_t bytes,size_t max_values,titchy_reader**);
int titchy_reader_open_file(const char*,size_t max_values,titchy_reader**);
void titchy_reader_free(titchy_reader*);
size_t titchy_reader_count(const titchy_reader*);
int titchy_reader_range(titchy_reader*,size_t start,size_t count,uint64_t*,size_t capacity);
int titchy_reader_sample(titchy_reader*,size_t index,uint64_t*);
int titchy_reader_bit(titchy_reader*,size_t bit_index,uint8_t*);
/* Function-fix C11 streaming core, available in both libtitchy_c and libtitchy.
 * One-sample push does real work; drain pop before next push/finish.
 * pop on empty writes 0/0; capacity failure retains packet for retry.
 * Packet bytes are upstream paper-compatible; chunk_count is external framing.
 * finish zero-pads at most one chunk. Reset required to start independent stream.
 * max_values 0..1000000 encoder true samples; decoder allows +255 padded samples.
 * Encoder retains active LRU + <=one chunk + <=one pending packet, no input archive;
 * decoder retains persistent dictionary as upstream. Single owner per context.
 * Output-capacity/backpressure errors permit retry; data/quota/internal errors require reset/free.
 * All results zero on error.
 */
typedef struct titchy_stream_encoder titchy_stream_encoder;
typedef struct titchy_stream_decoder titchy_stream_decoder;
typedef struct {size_t samples,chunks,dictionary_bases,active_bases,pending_chunks,ready_packets;unsigned id_width,deviation_width;int finished;} titchy_stream_stats;
int titchy_stream_encoder_create(const titchy_config*,size_t chunks_per_packet,size_t max_values,titchy_stream_encoder**);
int titchy_stream_push(titchy_stream_encoder*,uint64_t);
int titchy_stream_finish(titchy_stream_encoder*);
int titchy_stream_pop(titchy_stream_encoder*,uint8_t*,size_t,size_t*bytes,size_t*chunks);
int titchy_stream_encoder_reset(titchy_stream_encoder*);
int titchy_stream_encoder_info(const titchy_stream_encoder*,titchy_config*,size_t*chunks_per_packet,titchy_stream_stats*);
void titchy_stream_encoder_free(titchy_stream_encoder*);
int titchy_stream_decoder_create(const titchy_config*,size_t max_values,titchy_stream_decoder**);
int titchy_stream_decode_packet(titchy_stream_decoder*,const uint8_t*,size_t,size_t chunk_count,uint64_t*,size_t,size_t*);
int titchy_stream_decoder_reset(titchy_stream_decoder*);
void titchy_stream_decoder_free(titchy_stream_decoder*);
#ifdef __cplusplus
}
#endif
#endif
