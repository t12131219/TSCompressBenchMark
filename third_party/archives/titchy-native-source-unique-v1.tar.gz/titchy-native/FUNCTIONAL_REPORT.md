# unique-v1 验证记录

本轮执行主选API/功能测试；未重跑统一性能实验。测试程序位于交付目录外。

- titchy-native-stream_c：PASS
- titchy-native-example：PASS

GPU相关声明仅限编译验证；可选设备运行受驱动限制。既有误差反例及输入域限制继续适用。
