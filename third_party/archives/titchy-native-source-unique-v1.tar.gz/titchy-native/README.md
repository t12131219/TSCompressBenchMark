# titchy-native · unique-v1

本工程只交付一个主选实现 `titchy_c`，覆盖 85 Titchy。

## 构建

```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j4
```

支持Linux x86_64，GCC/G++、CMake≥3.22、make。ISA要求及运行约束见下表。工程自带所需源码依赖；构建输出不在发布包内。

默认构建包含本工程主选功能组件。

独立C/C++对照、历史版本、上游oracle及独立验证程序不交付。辅助库、共享格式代码、ISA加速和训练/流式等模块服务于同一主实现。`reference`、`fpc-original` 等历史target名称是CSV主选标识，不代表存在另一份并列实现。

## 85. Titchy

| 属性 | 支持范围与限制 |
| --- | --- |
| 技术家族 | 位变换+活动字典 |
| 方法角色 | 整数/位模式chunk/packet codec |
| 编码流水线 | bit transform+base/deviation字典+ID/packet |
| 原生类型 | 1..64位无符号样本/位模式 |
| 输入适配 | u64位模式，可承载浮点原始bits；非浮点趋势建模 |
| 数值域与特殊值 | 字宽/chunkbits等合同；f64 bits不量化 |
| 形状与多变量 | 单变量1D |
| 时间轴或显式x | 不支持：仅隐式样本序号 |
| 布局与stride | 连续数组 |
| 缺失值语义 | 未声明原生mask；不隐式插补 |
| 恢复与质量合同 | 声明域位级无损；补零尾部按original_n裁剪 |
| 核心参数 | bits、chunk、split、threshold、endian、LRU配额、packet目标 |
| 批处理 | 支持：整输入调用 |
| 增量编码 | 支持：C11 titchy_stream_*逐样本push、packet pop/finish/reset、backpressure；batch/range仍为默认主选 |
| 增量解码 | 支持：C11逐packet解码，保留已发布字典；原batch/range完整恢复入口保持 |
| 状态与复用 | C11 packet/LRU有限活动字典、split自适应、reset及backpressure；decoder保留已发布字典，逻辑LRU字节不等于RSS |
| 点范围与seek | 支持：sample/bit/range访问；完整容器加载/校验成本另计 |
| 渐进恢复 | 不支持：所选核心无此公开入口 |
| 压缩域计算 | 不支持：所选核心无此公开入口 |
| 训练或在线学习 | 流内字典更新，无离线训练 |
| 字典码本复用 | 活动字典随流，不是免费外部字典 |
| SIMD或ISA | 无所选核独立SIMD路径 |
| 内部并行编码 | 不支持：所选调用路径串行 |
| 内部并行解码 | 不支持：所选调用路径串行 |
| GPU | 未确认：未对该冻结核心建立GPU入口证据 |
| 并发与所有权 | 不同context并发，同context独占；backpressure/capacity可重试 |
| 格式与兼容 | TCHY v2 batch/range；C11 stream保留TSTR v1及TSC1外部配置协议 |
| 独立恢复依赖 | 原n/packet目录/完整32字节TSC1等配置计费 |
| 运行与构建依赖 | 唯一C11 batch/range/stream核心；不交付旧C++独立核。 |
| 长度尾部与资源 | 生命周期≤1m样本，chunk1..255、split1..65535；完整尾部 |
| 确定性条件 | 未确认：未建立跨平台字节确定性保证 |
| 许可范围 | 源码许可声明及 fix_ReWrite/titchy-native/licenses 中的冻结归属材料。 |
| 已知限制与身份 | 在线stream已是C11；LRU限额为逻辑字典字节而非RSS；尾部补零并保存原长度，TSTR及TSC1完整计费；756配置参考为冻结旧C++核心，不声称本轮全部Rust互验 |
