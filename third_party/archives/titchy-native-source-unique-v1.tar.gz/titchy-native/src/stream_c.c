/* C11 port of the frozen packet transform and LRU state machine.
 * Shares only bounded bit I/O and configuration with the batch encoder. */
#include "internal.h"
#include <stdlib.h>
#define NIL UINT32_MAX
typedef struct {uint8_t key[TT_BASE];uint32_t id,prev,next;uint64_t hash;} active_entry;
typedef struct {uint32_t *table;active_entry *entry;size_t mask,used,capacity,limit;uint32_t head,tail,next_id;} active_dict;
typedef struct packet {uint8_t *data;size_t bytes,chunks;struct packet *next;} packet;
typedef struct {uint32_t id;uint8_t dev[255];} pair;
struct titchy_stream_encoder {
 titchy_config c;size_t target,max_values,samples,chunks,split_chunks,old_count;
 unsigned lid,ld;int parameters,finished,failed;
 active_dict dictionary;uint64_t sample[255];size_t buffered;
 uint8_t bases[127][TT_BASE];size_t nb;
 pair *pairs;size_t count,pair_capacity;packet *head,*tail;
};
struct titchy_stream_decoder {
 titchy_config c;size_t max_values,samples,dict_count,dict_capacity;
 unsigned lid,ld;int parameters,failed;uint8_t *dictionary;
};
static uint64_t hash_key(const uint8_t *p,size_t n){uint64_t h=UINT64_C(1469598103934665603);while(n--)h=(h^*p++)*UINT64_C(1099511628211);return h;}
static void unlink_entry(active_dict*d,uint32_t i){active_entry*e=d->entry+i;if(e->prev!=NIL)d->entry[e->prev].next=e->next;else d->head=e->next;if(e->next!=NIL)d->entry[e->next].prev=e->prev;else d->tail=e->prev;}
static void link_front(active_dict*d,uint32_t i){active_entry*e=d->entry+i;e->prev=NIL;e->next=d->head;if(d->head!=NIL)d->entry[d->head].prev=i;else d->tail=i;d->head=i;}
static void erase_table(active_dict*d,uint32_t slot){size_t i=(size_t)d->entry[slot].hash&d->mask;while(d->table[i]!=slot+1)i=(i+1)&d->mask;size_t hole=i,j=(i+1)&d->mask;while(d->table[j]){size_t home=(size_t)d->entry[d->table[j]-1].hash&d->mask;if(((j-home)&d->mask)>=((j-hole)&d->mask)){d->table[hole]=d->table[j];hole=j;}j=(j+1)&d->mask;}d->table[hole]=0;}
static int grow_dict(active_dict*d){
 size_t cap=d->capacity?d->capacity*2:8;if(cap>d->limit)cap=d->limit;
 if(cap<=d->capacity)return TITCHY_MEMORY;
 size_t ts=2;while(ts<cap*2)ts*=2;
 active_entry *e=malloc(cap*sizeof(*e));uint32_t*t=calloc(ts,sizeof(*t));
 if(!e||!t){free(e);free(t);return TITCHY_MEMORY;}
 if(d->used)memcpy(e,d->entry,d->used*sizeof(*e));
 for(size_t j=0;j<d->used;j++){size_t at=(size_t)e[j].hash&(ts-1);while(t[at])at=(at+1)&(ts-1);t[at]=(uint32_t)j+1;}
 free(d->entry);free(d->table);d->entry=e;d->table=t;d->capacity=cap;d->mask=ts-1;return 0;
}
static int lookup(titchy_stream_encoder*s,const uint8_t*key,uint32_t*id,int*is_new){
 active_dict*d=&s->dictionary;size_t bs=tt_base_bytes(&s->c);uint64_t hash=hash_key(key,bs);
 if(d->capacity){size_t at=(size_t)hash&d->mask;while(d->table[at]){uint32_t i=d->table[at]-1;active_entry*e=d->entry+i;if(e->hash==hash&&!memcmp(e->key,key,bs)){*id=e->id;*is_new=0;if(d->head!=i){unlink_entry(d,i);link_front(d,i);}return 0;}at=(at+1)&d->mask;}}
 if(d->used<d->limit&&d->used==d->capacity){int rc=grow_dict(d);if(rc)return rc;}
 *id=d->next_id++;*is_new=1;if(!d->limit)return 0;
 uint32_t i;if(d->used==d->limit){i=d->tail;erase_table(d,i);unlink_entry(d,i);}else i=(uint32_t)d->used++;
 active_entry*e=d->entry+i;memcpy(e->key,key,bs);e->id=*id;e->hash=hash;link_front(d,i);
 size_t at=(size_t)hash&d->mask;while(d->table[at])at=(at+1)&d->mask;d->table[at]=i+1;return 0;
}
static int flush_packet(titchy_stream_encoder*s){
 if(!s->count)return 0;
 size_t cb=(unsigned)s->c.bits_per_sample*s->c.samples_per_chunk;
 size_t bits=s->nb*cb+s->count*(s->lid+s->ld),header=s->parameters?3:1;
 packet*p=calloc(1,sizeof(*p));if(!p)return TITCHY_MEMORY;
 p->bytes=header+(bits+7)/8;p->chunks=s->count;p->data=calloc(p->bytes,1);
 if(!p->data){free(p);return TITCHY_MEMORY;}
 p->data[0]=(s->parameters?128:0)|(uint8_t)s->nb;
 if(s->parameters){p->data[1]=(uint8_t)s->lid;p->data[2]=(uint8_t)s->ld;}
 size_t pos=0;for(size_t j=0;j<s->nb;j++){size_t at=0;for(size_t k=0;k<cb;k++)tt_write(p->data+header,&pos,tt_read(s->bases[j],&at,1),1);}
 for(size_t j=0;j<s->count;j++){tt_write(p->data+header,&pos,s->pairs[j].id,s->lid);for(unsigned k=0;k<s->ld;k++)tt_write(p->data+header,&pos,s->pairs[j].dev[k],1);}
 if(s->tail)s->tail->next=p;else s->head=p;s->tail=p;s->nb=s->count=0;s->parameters=0;return 0;
}
static int encode_chunk(titchy_stream_encoder*s){
 if(s->split_chunks==s->c.chunks_per_split){int rc=flush_packet(s);if(rc)return rc;size_t count=s->dictionary.next_id;if(count+s->c.chunks_per_split>=(UINT64_C(1)<<s->lid))s->lid++;size_t added=count-s->old_count;s->old_count=count;if(!added){if(s->ld)s->ld--;}else if((double)added/s->c.chunks_per_split>s->c.threshold){unsigned max=(unsigned)s->c.bits_per_sample*s->c.samples_per_chunk;if(max>255)max=255;if(s->ld<max)s->ld++;}s->split_chunks=0;s->parameters=1;}
 if(s->count==s->pair_capacity){size_t cap=s->pair_capacity?s->pair_capacity*2:8;if(cap>s->target)cap=s->target;pair*p=realloc(s->pairs,cap*sizeof(*p));if(!p)return TITCHY_MEMORY;s->pairs=p;s->pair_capacity=cap;}
 for(size_t j=s->buffered;j<s->c.samples_per_chunk;j++)s->sample[j]=0;
 pair*p=s->pairs+s->count;unsigned q=s->ld/s->c.samples_per_chunk,r=s->ld%s->c.samples_per_chunk,at=0;
 for(unsigned level=0;level<s->c.bits_per_sample;level++)for(unsigned j=0;j<s->c.samples_per_chunk;j++)if(level<q+(r&&j>=(unsigned)s->c.samples_per_chunk-r)){p->dev[at++]=(uint8_t)((s->sample[j]>>level)&1);s->sample[j]&=~(UINT64_C(1)<<level);}
 uint8_t key[TT_BASE]={0};size_t pos=0;for(unsigned j=0;j<s->c.samples_per_chunk;j++)tt_write(key,&pos,s->sample[j],s->c.bits_per_sample);
 int added,rc=lookup(s,key,&p->id,&added);if(rc)return rc;if(added)memcpy(s->bases[s->nb++],key,tt_base_bytes(&s->c));
 s->count++;s->buffered=0;s->chunks++;s->split_chunks++;
 return (s->count==s->target||s->nb==127)?flush_packet(s):0;
}
static void clear_encoder(titchy_stream_encoder*s){free(s->dictionary.entry);free(s->dictionary.table);free(s->pairs);while(s->head){packet*p=s->head;s->head=p->next;free(p->data);free(p);}}
static void init_encoder(titchy_stream_encoder*s,titchy_config c,size_t target,size_t max){memset(s,0,sizeof(*s));s->c=c;s->target=target;s->max_values=max;s->lid=tt_log(c.chunks_per_split);s->ld=(unsigned)c.bits_per_sample*c.samples_per_chunk/2;s->parameters=1;s->dictionary.limit=c.max_active_bytes==UINT64_MAX?TT_MAX:(size_t)(c.max_active_bytes/(tt_base_bytes(&c)+4));if(s->dictionary.limit>tt_chunks(max,&c))s->dictionary.limit=tt_chunks(max,&c);s->dictionary.head=s->dictionary.tail=NIL;}
int titchy_stream_encoder_create(const titchy_config*c,size_t target,size_t max,titchy_stream_encoder**out){if(!out)return TITCHY_INVALID;*out=NULL;if(!tt_config(c)||!target||target>65535||max>TT_MAX)return TITCHY_INVALID;titchy_stream_encoder*s=malloc(sizeof(*s));if(!s)return TITCHY_MEMORY;init_encoder(s,*c,target,max);*out=s;return 0;}
void titchy_stream_encoder_free(titchy_stream_encoder*s){if(s){clear_encoder(s);free(s);}}
int titchy_stream_encoder_reset(titchy_stream_encoder*s){if(!s)return TITCHY_INVALID;titchy_config c=s->c;size_t target=s->target,max=s->max_values;clear_encoder(s);init_encoder(s,c,target,max);return 0;}
int titchy_stream_encoder_info(const titchy_stream_encoder*s,titchy_config*c,size_t*target,titchy_stream_stats*st){if(!s||!c||!target||!st)return TITCHY_INVALID;*c=s->c;*target=s->target;size_t ready=0;for(packet*p=s->head;p;p=p->next)ready++;*st=(titchy_stream_stats){s->samples,s->chunks,s->dictionary.next_id,s->dictionary.used,s->count,ready,s->lid,s->ld,s->finished};return 0;}
int titchy_stream_push(titchy_stream_encoder*s,uint64_t v){if(!s||s->failed||s->finished)return TITCHY_INVALID;if(s->head)return TITCHY_CAPACITY;if(s->samples==s->max_values||(s->c.bits_per_sample<64&&(v>>s->c.bits_per_sample))){s->failed=1;return TITCHY_INVALID;}s->sample[s->buffered++]=v;s->samples++;int rc=s->buffered==s->c.samples_per_chunk?encode_chunk(s):0;if(rc)s->failed=1;return rc;}
int titchy_stream_finish(titchy_stream_encoder*s){if(!s||s->failed||s->finished)return TITCHY_INVALID;if(s->head)return TITCHY_CAPACITY;int rc=s->buffered?encode_chunk(s):0;if(!rc)rc=flush_packet(s);if(rc)s->failed=1;else s->finished=1;return rc;}
int titchy_stream_pop(titchy_stream_encoder*s,uint8_t*out,size_t cap,size_t*bytes,size_t*chunks){if(bytes)*bytes=0;if(chunks)*chunks=0;if(!s||!bytes||!chunks||s->failed)return TITCHY_INVALID;if(!s->head)return 0;packet*p=s->head;if(!out||cap<p->bytes)return TITCHY_CAPACITY;memcpy(out,p->data,p->bytes);*bytes=p->bytes;*chunks=p->chunks;s->head=p->next;if(!s->head)s->tail=NULL;free(p->data);free(p);return 0;}
int titchy_stream_decoder_create(const titchy_config*c,size_t max,titchy_stream_decoder**out){if(!out)return TITCHY_INVALID;*out=NULL;if(!tt_config(c)||max>TT_MAX+255u)return TITCHY_INVALID;titchy_stream_decoder*s=calloc(1,sizeof(*s));if(!s)return TITCHY_MEMORY;s->c=*c;s->max_values=max;*out=s;return 0;}
void titchy_stream_decoder_free(titchy_stream_decoder*s){if(s){free(s->dictionary);free(s);}}
int titchy_stream_decoder_reset(titchy_stream_decoder*s){if(!s)return TITCHY_INVALID;s->samples=s->dict_count=0;s->lid=s->ld=0;s->parameters=s->failed=0;return 0;}
int titchy_stream_decode_packet(titchy_stream_decoder*s,const uint8_t*b,size_t bytes,size_t chunks,uint64_t*out,size_t cap,size_t*written){
 if(written)*written=0;if(!s||!written||s->failed)return TITCHY_INVALID;
 if(!b||!bytes||!chunks||chunks>s->c.chunks_per_split){s->failed=1;return TITCHY_STREAM;}
 size_t count=chunks*s->c.samples_per_chunk;if(count>cap||!out)return TITCHY_CAPACITY;if(count>s->max_values-s->samples){s->failed=1;return TITCHY_CAPACITY;}
 int params=(b[0]&128)!=0;size_t header=params?3:1;if(bytes<header){s->failed=1;return TITCHY_STREAM;}
 unsigned lid=params?b[1]:s->lid,ld=params?b[2]:s->ld;size_t nb=b[0]&127,cb=(unsigned)s->c.bits_per_sample*s->c.samples_per_chunk,bits=nb*cb+chunks*(lid+ld);
 if((!s->parameters&&!params)||lid>32||ld>cb||bytes-header!=(bits+7)/8||(bits%8&&(b[bytes-1]&((1u<<(8-bits%8))-1)))){s->failed=1;return TITCHY_STREAM;}
 size_t limit=tt_chunks(s->max_values,&s->c);if(nb>limit-s->dict_count){s->failed=1;return TITCHY_CAPACITY;}
 size_t bs=tt_base_bytes(&s->c),needed=s->dict_count+nb;
 if(needed>s->dict_capacity){size_t nc=s->dict_capacity?s->dict_capacity*2:8;if(nc<needed)nc=needed;if(nc>limit)nc=limit;uint8_t*p=realloc(s->dictionary,nc*bs);if(!p){s->failed=1;return TITCHY_MEMORY;}s->dictionary=p;s->dict_capacity=nc;}
 size_t pos=0;for(size_t j=0;j<nb;j++){uint8_t*base=s->dictionary+s->dict_count++*bs;memset(base,0,bs);size_t at=0;for(size_t k=0;k<cb;k++)tt_write(base,&at,tt_read(b+header,&pos,1),1);}
 for(size_t j=0;j<chunks;j++){
  size_t id=tt_read(b+header,&pos,lid);if(id>=s->dict_count){s->failed=1;return TITCHY_STREAM;}size_t at=0;uint64_t values[255];for(unsigned k=0;k<s->c.samples_per_chunk;k++)values[k]=tt_read(s->dictionary+id*bs,&at,s->c.bits_per_sample);
  unsigned q=ld/s->c.samples_per_chunk,r=ld%s->c.samples_per_chunk;for(unsigned level=0;level<s->c.bits_per_sample;level++)for(unsigned k=0;k<s->c.samples_per_chunk;k++)if(level<q+(r&&k>=(unsigned)s->c.samples_per_chunk-r)){uint64_t mask=UINT64_C(1)<<level;values[k]=(values[k]&~mask)|(tt_read(b+header,&pos,1)<<level);}
  memcpy(out+j*s->c.samples_per_chunk,values,s->c.samples_per_chunk*sizeof(*values));
 }
 s->lid=lid;s->ld=ld;s->parameters=1;s->samples+=count;*written=count;return 0;
}
