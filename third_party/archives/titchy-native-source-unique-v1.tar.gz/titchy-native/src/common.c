#include "internal.h"
size_t titchy_bound(size_t n, const titchy_config *c) {
  if (!tt_config(c) || n > TT_MAX)
    return 0;
  size_t chunks = tt_chunks(n, c),
         splits = (chunks + c->chunks_per_split - 1) / c->chunks_per_split;
  return 38 + 24 * splits + tt_base_bytes(c) * chunks + 8 * splits +
         (chunks * (32 + 255) + 7) / 8 + splits;
}
int tt_validate(const uint8_t *p, size_t size, size_t max_values, tt_view *v) {
  if (!p || size < 38 || memcmp(p, "TCHY", 4) || p[4] != 2)
    return TITCHY_STREAM;
  titchy_config c;
  c.bits_per_sample = p[5];
  c.samples_per_chunk = p[6];
  c.endian = p[7];
  c.chunks_per_split = (uint16_t)tt_get(p + 8, 2);
  c.threshold = tt_get(p + 10, 4) / 1000000.0;
  c.max_active_bytes = tt_get(p + 14, 8);
  if (!tt_config(&c))
    return TITCHY_STREAM;
  uint64_t total = tt_get(p + 22, 8);
  if (total > TT_MAX || total > max_values)
    return TITCHY_CAPACITY;
  size_t n = (size_t)total, chunks = tt_chunks(n, &c),
         splits = (size_t)tt_get(p + 34, 4), dict = (size_t)tt_get(p + 30, 4),
         bs = tt_base_bytes(&c);
  if (splits != (chunks + c.chunks_per_split - 1) / c.chunks_per_split ||
      dict > chunks || (!chunks && dict) || (chunks && !dict))
    return TITCHY_STREAM;
  size_t start = 38 + splits * 24;
  if (start > size || dict > (size - start) / bs)
    return TITCHY_STREAM;
  const uint8_t *dictionary = p + start;
  start += dict * bs;
  unsigned chunk_bits = (unsigned)c.bits_per_sample * c.samples_per_chunk;
  if (chunk_bits % 8)
    for (size_t i = 0; i < dict; i++)
      if (dictionary[(i + 1) * bs - 1] & ((1u << (8 - chunk_bits % 8)) - 1))
        return TITCHY_STREAM;
  size_t chunk_start = 0;
  for (size_t split = 0; split < splits; split++) {
    const uint8_t *ix = p + 38 + 24 * split;
    size_t nc = chunks - chunk_start;
    if (nc > c.chunks_per_split)
      nc = c.chunks_per_split;
    uint64_t offset = tt_get(ix + 12, 8);
    size_t length = (size_t)tt_get(ix + 20, 4);
    if (tt_get(ix, 8) != chunk_start || tt_get(ix + 8, 4) != nc ||
        offset != start || length < 8 || length > size - start)
      return TITCHY_STREAM;
    const uint8_t *r = p + start;
    unsigned lid = r[0], ld = r[1];
    size_t payload = (size_t)tt_get(r + 4, 4), bits = nc * (lid + ld);
    if (lid > 32 || ld > chunk_bits || tt_get(r + 2, 2) != nc ||
        payload != (bits + 7) / 8 || payload != length - 8)
      return TITCHY_STREAM;
    if (bits % 8 && payload &&
        (r[8 + payload - 1] & ((1u << (8 - bits % 8)) - 1)))
      return TITCHY_STREAM;
    size_t position = 0;
    for (size_t j = 0; j < nc; j++) {
      uint64_t id = tt_read(r + 8, &position, lid);
      if (id >= dict)
        return TITCHY_STREAM;
      position += ld;
    }
    start += length;
    chunk_start += nc;
  }
  if (start != size)
    return TITCHY_STREAM;
  v->config = c;
  v->samples = n;
  v->chunks = chunks;
  v->splits = splits;
  v->dict_count = dict;
  v->base_bytes = bs;
  v->wire = p;
  v->index = p + 38;
  v->dictionary = dictionary;
  return TITCHY_OK;
}
