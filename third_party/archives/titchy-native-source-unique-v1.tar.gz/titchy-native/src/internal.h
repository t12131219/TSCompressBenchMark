#ifndef TITCHY_INTERNAL_H
#define TITCHY_INTERNAL_H
#include "titchy.h"
#include <math.h>
#include <string.h>
#define TT_MAX 1000000u
#define TT_BASE 64
static inline int tt_config(const titchy_config *c) {
  return c && c->bits_per_sample && c->bits_per_sample <= 64 &&
         c->samples_per_chunk &&
         (unsigned)c->bits_per_sample * c->samples_per_chunk / 2 <= 255 &&
         c->chunks_per_split && c->endian <= 1 && isfinite(c->threshold) &&
         c->threshold >= 0 && c->threshold <= 1;
}
static inline uint64_t tt_get(const uint8_t *p, unsigned bytes) {
  uint64_t v = 0;
  for (unsigned i = 0; i < bytes; i++)
    v |= (uint64_t)p[i] << (8 * i);
  return v;
}
static inline void tt_put(uint8_t *p, uint64_t v, unsigned bytes) {
  for (unsigned i = 0; i < bytes; i++)
    p[i] = (uint8_t)(v >> (8 * i));
}
/* Bounded widths 0..64; byte-slice MSB-first avoids bit-at-a-time allocation.
 */
static inline void tt_write(uint8_t *p, size_t *position, uint64_t v,
                            unsigned width) {
  while (width) {
    unsigned offset = (unsigned)(*position & 7), n = 8 - offset;
    if (n > width)
      n = width;
    unsigned shift = width - n;
    p[*position / 8] |=
        (uint8_t)(((v >> shift) & ((1u << n) - 1)) << (8 - offset - n));
    *position += n;
    width -= n;
  }
}
static inline uint64_t tt_read(const uint8_t *p, size_t *position,
                               unsigned width) {
  uint64_t v = 0;
  while (width) {
    unsigned offset = (unsigned)(*position & 7), n = 8 - offset;
    if (n > width)
      n = width;
    v = (v << n) | ((p[*position / 8] >> (8 - offset - n)) & ((1u << n) - 1));
    *position += n;
    width -= n;
  }
  return v;
}
static inline unsigned tt_log(size_t n) {
  unsigned r = 0;
  for (size_t x = n ? n - 1 : 0; x; x >>= 1)
    r++;
  return r;
}
static inline size_t tt_chunks(size_t n, const titchy_config *c) {
  return (n + c->samples_per_chunk - 1) / c->samples_per_chunk;
}
static inline size_t tt_base_bytes(const titchy_config *c) {
  return ((size_t)c->bits_per_sample * c->samples_per_chunk + 7) / 8;
}
typedef struct {
  titchy_config config;
  size_t samples, chunks, splits, dict_count, base_bytes;
  const uint8_t *wire, *index, *dictionary;
} tt_view;
#ifdef __cplusplus
extern "C"
#endif
int tt_validate(const uint8_t *wire, size_t size, size_t max_values,
                tt_view *v);
static inline void tt_header(uint8_t *p, size_t n, const titchy_config *c,
                             size_t dict, size_t splits) {
  memcpy(p, "TCHY", 4);
  p[4] = 2;
  p[5] = c->bits_per_sample;
  p[6] = c->samples_per_chunk;
  p[7] = c->endian;
  tt_put(p + 8, c->chunks_per_split, 2);
  tt_put(p + 10, (uint32_t)round(c->threshold * 1000000.0), 4);
  tt_put(p + 14, c->max_active_bytes, 8);
  tt_put(p + 22, n, 8);
  tt_put(p + 30, dict, 4);
  tt_put(p + 34, splits, 4);
}
#endif
