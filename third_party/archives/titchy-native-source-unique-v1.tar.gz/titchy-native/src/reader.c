#include "internal.h"
#include <stdlib.h>
#include <stdio.h>
struct titchy_reader {titchy_read_at read;void*user;FILE*file;size_t size,n,dict,bs,splits,dict_offset;uint8_t*index;titchy_config c;};
static int rd(titchy_reader*r,size_t at,void*p,size_t n){return at>r->size||n>r->size-at||r->read(r->user,at,p,n)?TITCHY_STREAM:0;}
void titchy_reader_free(titchy_reader*r){if(r){if(r->file)fclose(r->file);free(r->index);free(r);}}
int titchy_reader_open(titchy_read_at read,void*user,size_t bytes,size_t max_values,titchy_reader**out){
 if(!out)return TITCHY_INVALID;*out=NULL;if(!read||bytes<38)return TITCHY_INVALID;
 titchy_reader*r=calloc(1,sizeof(*r));if(!r)return TITCHY_MEMORY;r->read=read;r->user=user;r->size=bytes;
 uint8_t h[38];int rc=rd(r,0,h,38);if(rc)goto fail;
 if(memcmp(h,"TCHY",4)||h[4]!=2){rc=TITCHY_STREAM;goto fail;}
 r->c=(titchy_config){h[5],h[6],(uint16_t)tt_get(h+8,2),h[7],tt_get(h+10,4)/1000000.,tt_get(h+14,8)};
 if(!tt_config(&r->c)){rc=TITCHY_STREAM;goto fail;}
 uint64_t n=tt_get(h+22,8);if(n>TT_MAX||n>max_values){rc=TITCHY_CAPACITY;goto fail;}r->n=(size_t)n;
 r->splits=tt_get(h+34,4);r->dict=tt_get(h+30,4);r->bs=tt_base_bytes(&r->c);
 size_t chunks=tt_chunks(r->n,&r->c);
 if(r->splits!=(chunks+r->c.chunks_per_split-1)/r->c.chunks_per_split||r->dict>chunks||(!chunks&&r->dict)||(chunks&&!r->dict)){rc=TITCHY_STREAM;goto fail;}
 r->dict_offset=38+24*r->splits;
 if(r->dict_offset>bytes||r->dict>(bytes-r->dict_offset)/r->bs){rc=TITCHY_STREAM;goto fail;}
 r->index=malloc(r->splits?r->splits*24:1);if(!r->index){rc=TITCHY_MEMORY;goto fail;}
 if((rc=rd(r,38,r->index,r->splits*24)))goto fail;
 size_t pos=r->dict_offset+r->dict*r->bs,chunk=0;
 for(size_t s=0;s<r->splits;s++){
  uint8_t*ix=r->index+24*s;size_t nc=chunks-chunk;if(nc>r->c.chunks_per_split)nc=r->c.chunks_per_split;
  size_t len=tt_get(ix+20,4);
  if(tt_get(ix,8)!=chunk||tt_get(ix+8,4)!=nc||tt_get(ix+12,8)!=pos||len<8||len>bytes-pos){rc=TITCHY_STREAM;goto fail;}
  pos+=len;chunk+=nc;
 }
 if(pos!=bytes){rc=TITCHY_STREAM;goto fail;}*out=r;return 0;
fail:titchy_reader_free(r);return rc;
}
static int file_read(void*u,uint64_t at,void*p,size_t n){FILE*f=u;if(at>INT64_MAX||fseeko(f,(off_t)at,SEEK_SET))return 1;return fread(p,1,n,f)!=n;}
int titchy_reader_open_file(const char*path,size_t max_values,titchy_reader**out){
 if(!out)return TITCHY_INVALID;*out=NULL;if(!path)return TITCHY_INVALID;
 FILE*f=fopen(path,"rb");if(!f)return TITCHY_INVALID;
 if(fseeko(f,0,SEEK_END)){fclose(f);return TITCHY_STREAM;}off_t len=ftello(f);
 if(len<0||(uint64_t)len>SIZE_MAX){fclose(f);return TITCHY_STREAM;}
 int rc=titchy_reader_open(file_read,f,(size_t)len,max_values,out);if(rc)fclose(f);else (*out)->file=f;return rc;
}
size_t titchy_reader_count(const titchy_reader*r){return r?r->n:0;}
/* Fetch one packed pair (<=287 bits), rather than the split payload. */
static int pair(titchy_reader*r,size_t chunk,uint8_t p[37],size_t*position,unsigned*lid,unsigned*ld){
 size_t split=chunk/r->c.chunks_per_split;const uint8_t*ix=r->index+24*split;
 size_t off=tt_get(ix+12,8),nc=tt_get(ix+8,4),local=chunk-tt_get(ix,8);uint8_t h[8];int rc=rd(r,off,h,8);if(rc)return rc;
 *lid=h[0];*ld=h[1];size_t bits=nc*(*lid+*ld),payload=(bits+7)/8;
 if(*lid>32||*ld>(unsigned)r->c.bits_per_sample*r->c.samples_per_chunk||tt_get(h+2,2)!=nc||tt_get(h+4,4)!=payload||payload!=tt_get(ix+20,4)-8)return TITCHY_STREAM;
 size_t start=local*(*lid+*ld);*position=start%8;size_t len=(*position+*lid+*ld+7)/8;
 return rd(r,off+8+start/8,p,len);
}
int titchy_reader_bit(titchy_reader*r,size_t bit_index,uint8_t*out){
 if(!r||!out||bit_index>=r->n*r->c.bits_per_sample)return TITCHY_INVALID;
 size_t sample=bit_index/r->c.bits_per_sample,bit=bit_index%r->c.bits_per_sample,chunk=sample/r->c.samples_per_chunk,a=sample%r->c.samples_per_chunk;
 uint8_t p[37]={0};size_t pos;unsigned lid,ld;int rc=pair(r,chunk,p,&pos,&lid,&ld);if(rc)return rc;
 uint64_t id=tt_read(p,&pos,lid);if(id>=r->dict)return TITCHY_STREAM;
 unsigned quota=ld/r->c.samples_per_chunk,extra=ld%r->c.samples_per_chunk,q=quota+(extra&&a>=r->c.samples_per_chunk-extra);
 unsigned low=r->c.bits_per_sample-1-(unsigned)bit;
 if(low<q){size_t offset=0;for(unsigned b=0;b<low;b++)for(unsigned k=0;k<r->c.samples_per_chunk;k++){unsigned z=quota+(extra&&k>=r->c.samples_per_chunk-extra);if(b<z)offset++;}
  for(unsigned k=0;k<a;k++){unsigned z=quota+(extra&&k>=r->c.samples_per_chunk-extra);if(low<z)offset++;}pos+=offset;*out=(uint8_t)tt_read(p,&pos,1);return 0;}
 size_t bp=a*r->c.bits_per_sample+bit;uint8_t byte;if((rc=rd(r,r->dict_offset+(size_t)id*r->bs+bp/8,&byte,1)))return rc;
 *out=(byte>>(7-bp%8))&1;return 0;
}
int titchy_reader_range(titchy_reader*r,size_t start,size_t n,uint64_t*out,size_t cap){
 if(!r||start>r->n||n>r->n-start)return TITCHY_INVALID;if(cap<n||(!out&&n))return TITCHY_CAPACITY;
 for(size_t chunk=start/r->c.samples_per_chunk;n&&chunk<=(start+n-1)/r->c.samples_per_chunk;chunk++){
  uint8_t p[37]={0},base[64];size_t pos;unsigned lid,ld;int rc=pair(r,chunk,p,&pos,&lid,&ld);if(rc)return rc;
  uint64_t id=tt_read(p,&pos,lid);if(id>=r->dict)return TITCHY_STREAM;
  if((rc=rd(r,r->dict_offset+(size_t)id*r->bs,base,r->bs)))return rc;
  uint64_t values[255];size_t bp=0;for(unsigned a=0;a<r->c.samples_per_chunk;a++)values[a]=tt_read(base,&bp,r->c.bits_per_sample);
  unsigned quota=ld/r->c.samples_per_chunk,extra=ld%r->c.samples_per_chunk;
  for(unsigned b=0;b<r->c.bits_per_sample;b++)for(unsigned a=0;a<r->c.samples_per_chunk;a++){unsigned q=quota+(extra&&a>=r->c.samples_per_chunk-extra);if(b<q){uint64_t mask=UINT64_C(1)<<b;values[a]=(values[a]&~mask)|(tt_read(p,&pos,1)<<b);}}
  size_t first=chunk*r->c.samples_per_chunk;for(unsigned a=0;a<r->c.samples_per_chunk;a++)if(first+a>=start&&first+a<start+n)out[first+a-start]=values[a];
 }return 0;
}
int titchy_reader_sample(titchy_reader*r,size_t index,uint64_t*out){return titchy_reader_range(r,index,1,out,1);}
