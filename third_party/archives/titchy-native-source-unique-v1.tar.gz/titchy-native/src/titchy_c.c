#include "internal.h"
#include <limits.h>
#include <stdlib.h>
/* Fixed-capacity active lookup; persisted base bytes are kept separately. */
typedef struct {
  uint32_t id, previous, next;
  uint64_t hash;
} slot;
typedef struct {
  slot *slots;
  uint32_t *table;
  size_t mask, used, limit;
  uint32_t head, tail;
  uint8_t *bases;
  size_t bytes;
} lookup;
#define NONE UINT32_MAX
static uint64_t hash_base(const uint8_t *p, size_t n) {
  uint64_t h = UINT64_C(1469598103934665603);
  for (size_t i = 0; i < n; i++)
    h = (h ^ p[i]) * UINT64_C(1099511628211);
  return h;
}
static void detach(lookup *d, uint32_t s) {
  slot *e = d->slots + s;
  if (e->previous != NONE)
    d->slots[e->previous].next = e->next;
  else
    d->head = e->next;
  if (e->next != NONE)
    d->slots[e->next].previous = e->previous;
  else
    d->tail = e->previous;
}
static void front(lookup *d, uint32_t s) {
  slot *e = d->slots + s;
  e->previous = NONE;
  e->next = d->head;
  if (d->head != NONE)
    d->slots[d->head].previous = s;
  else
    d->tail = s;
  d->head = s;
}
static void erase_slot(lookup *d, uint32_t s) {
  size_t i = (size_t)d->slots[s].hash & d->mask;
  while (d->table[i] != s + 1)
    i = (i + 1) & d->mask;
  size_t hole = i, j = (i + 1) & d->mask;
  while (d->table[j]) {
    size_t home = (size_t)d->slots[d->table[j] - 1].hash & d->mask;
    if (((j - home) & d->mask) >= ((j - hole) & d->mask)) {
      d->table[hole] = d->table[j];
      hole = j;
    }
    j = (j + 1) & d->mask;
  }
  d->table[hole] = 0;
}
static uint32_t find_base(lookup *d, const uint8_t *base, size_t dict,
                          int *is_new) {
  uint64_t hash = hash_base(base, d->bytes);
  size_t i = (size_t)hash & d->mask;
  if (d->limit)
    while (d->table[i]) {
      uint32_t s = d->table[i] - 1;
      slot *e = d->slots + s;
      if (e->hash == hash &&
          !memcmp(d->bases + (size_t)e->id * d->bytes, base, d->bytes)) {
        if (d->head != s) {
          detach(d, s);
          front(d, s);
        }
        *is_new = 0;
        return e->id;
      }
      i = (i + 1) & d->mask;
    }
  uint32_t id = (uint32_t)dict;
  memcpy(d->bases + dict * d->bytes, base, d->bytes);
  *is_new = 1;
  if (!d->limit)
    return id;
  uint32_t s;
  if (d->used == d->limit) {
    s = d->tail;
    erase_slot(d, s);
    detach(d, s);
  } else
    s = (uint32_t)d->used++;
  d->slots[s].id = id;
  d->slots[s].hash = hash;
  front(d, s);
  i = (size_t)hash & d->mask;
  while (d->table[i])
    i = (i + 1) & d->mask;
  d->table[i] = s + 1;
  return id;
}
int titchy_c_encode(const uint64_t *samples, size_t n, const titchy_config *c,
                    uint8_t *out, size_t capacity, size_t *written) {
  if (!written)
    return TITCHY_INVALID;
  *written = 0;
  size_t bound = titchy_bound(n, c);
  if (!bound || (!samples && n) || !out)
    return TITCHY_INVALID;
  if (capacity < bound)
    return TITCHY_CAPACITY;
  if (c->bits_per_sample < 64)
    for (size_t i = 0; i < n; i++)
      if (samples[i] >> c->bits_per_sample)
        return TITCHY_INVALID;
  size_t chunks = tt_chunks(n, c),
         ns = (chunks + c->chunks_per_split - 1) / c->chunks_per_split,
         bs = tt_base_bytes(c);
  size_t active = c->max_active_bytes == UINT64_MAX
                      ? chunks
                      : (size_t)(c->max_active_bytes / (bs + 4));
  if (active > chunks)
    active = chunks;
  size_t table_size = 2;
  while (table_size < active * 2)
    table_size *= 2;
  uint8_t *bases = (uint8_t *)malloc(chunks ? chunks * bs : 1),
          *records = (uint8_t *)calloc(bound, 1);
  slot *slots = (slot *)calloc(active ? active : 1, sizeof(slot));
  uint32_t *table = (uint32_t *)calloc(table_size, sizeof(uint32_t));
  size_t *starts = (size_t *)calloc(ns ? ns : 1, sizeof(size_t)),
         *lengths = (size_t *)calloc(ns ? ns : 1, sizeof(size_t));
  if (!bases || !records || !slots || !table || !starts || !lengths) {
    free(bases);
    free(records);
    free(slots);
    free(table);
    free(starts);
    free(lengths);
    return TITCHY_MEMORY;
  }
  lookup d = {slots, table, table_size - 1, 0, active, NONE, NONE, bases, bs};
  unsigned lid = tt_log(c->chunks_per_split),
           ld = (unsigned)c->bits_per_sample * c->samples_per_chunk / 2;
  size_t dict = 0, old = 0, record_size = 0, ci = 0;
  for (size_t split = 0; split < ns; split++) {
    if (split) {
      if (dict + c->chunks_per_split >= ((uint64_t)1 << lid))
        lid++;
      size_t added = dict - old;
      old = dict;
      if (!added) {
        if (ld)
          ld--;
      } else if ((double)added / c->chunks_per_split > c->threshold) {
        unsigned max = (unsigned)c->bits_per_sample * c->samples_per_chunk;
        if (max > 255)
          max = 255;
        if (ld < max)
          ld++;
      }
    }
    size_t count = chunks - ci;
    if (count > c->chunks_per_split)
      count = c->chunks_per_split;
    size_t payload = (count * (lid + ld) + 7) / 8;
    uint8_t *r = records + record_size;
    r[0] = (uint8_t)lid;
    r[1] = (uint8_t)ld;
    tt_put(r + 2, count, 2);
    tt_put(r + 4, payload, 4);
    starts[split] = record_size;
    lengths[split] = 8 + payload;
    size_t pos = 0;
    for (size_t j = 0; j < count; j++, ci++) {
      uint64_t values[255];
      uint8_t base[TT_BASE] = {0}, deviation[255];
      unsigned quota = ld / c->samples_per_chunk,
               extra = ld % c->samples_per_chunk, nb = 0;
      for (unsigned a = 0; a < c->samples_per_chunk; a++) {
        size_t at = ci * c->samples_per_chunk + a;
        values[a] = at < n ? samples[at] : 0;
      }
      for (unsigned bit = 0; bit < c->bits_per_sample; bit++)
        for (unsigned a = 0; a < c->samples_per_chunk; a++) {
          unsigned q =
              quota + (extra && a >= (unsigned)c->samples_per_chunk - extra);
          if (bit < q) {
            deviation[nb++] = (uint8_t)((values[a] >> bit) & 1);
            values[a] &= ~((uint64_t)1 << bit);
          }
        }
      size_t bp = 0;
      for (unsigned a = 0; a < c->samples_per_chunk; a++)
        tt_write(base, &bp, values[a], c->bits_per_sample);
      int is_new;
      uint32_t id = find_base(&d, base, dict, &is_new);
      dict += (unsigned)is_new;
      tt_write(r + 8, &pos, id, lid);
      for (unsigned bit = 0; bit < nb; bit++)
        tt_write(r + 8, &pos, deviation[bit], 1);
    }
    record_size += 8 + payload;
  }
  tt_header(out, n, c, dict, ns);
  size_t offset = 38 + 24 * ns + dict * bs, chunk_start = 0;
  for (size_t split = 0; split < ns; split++) {
    uint8_t *ix = out + 38 + split * 24;
    size_t count = tt_get(records + starts[split] + 2, 2);
    tt_put(ix, chunk_start, 8);
    tt_put(ix + 8, count, 4);
    tt_put(ix + 12, offset + starts[split], 8);
    tt_put(ix + 20, lengths[split], 4);
    chunk_start += count;
  }
  memcpy(out + 38 + 24 * ns, bases, dict * bs);
  memcpy(out + offset, records, record_size);
  *written = offset + record_size;
  free(bases);
  free(records);
  free(slots);
  free(table);
  free(starts);
  free(lengths);
  return TITCHY_OK;
}
/* Reconstruct requested chunks only; reads bounded by tt_validate. */
static int range_c(const tt_view *v, size_t start, size_t len, uint64_t *out) {
  if (!len)
    return TITCHY_OK;
  const titchy_config *c = &v->config;
  size_t end = start + len, first = start / c->samples_per_chunk,
         last = (end - 1) / c->samples_per_chunk;
  for (size_t split = first / c->chunks_per_split;
       split <= last / c->chunks_per_split; split++) {
    const uint8_t *ix = v->index + 24 * split,
                  *r = v->wire + tt_get(ix + 12, 8);
    unsigned lid = r[0], ld = r[1];
    size_t split_first = (size_t)tt_get(ix, 8), nc = (size_t)tt_get(ix + 8, 4);
    size_t left = first > split_first ? first - split_first : 0,
           right = last - split_first + 1;
    if (right > nc)
      right = nc;
    for (size_t j = left; j < right; j++) {
      size_t pos = j * (lid + ld);
      uint32_t id = (uint32_t)tt_read(r + 8, &pos, lid);
      const uint8_t *base = v->dictionary + (size_t)id * v->base_bytes;
      uint64_t values[255];
      size_t bp = 0;
      for (unsigned a = 0; a < c->samples_per_chunk; a++)
        values[a] = tt_read(base, &bp, c->bits_per_sample);
      unsigned quota = ld / c->samples_per_chunk,
               extra = ld % c->samples_per_chunk;
      for (unsigned bit = 0; bit < c->bits_per_sample; bit++)
        for (unsigned a = 0; a < c->samples_per_chunk; a++) {
          unsigned q =
              quota + (extra && a >= (unsigned)c->samples_per_chunk - extra);
          if (bit < q) {
            uint64_t mask = (uint64_t)1 << bit;
            values[a] = (values[a] & ~mask) | (tt_read(r + 8, &pos, 1) << bit);
          }
        }
      size_t global = (split_first + j) * c->samples_per_chunk;
      for (unsigned a = 0; a < c->samples_per_chunk; a++)
        if (global + a >= start && global + a < end)
          out[global + a - start] = values[a];
    }
  }
  return TITCHY_OK;
}
int titchy_c_range(const uint8_t *wire, size_t size, size_t start, size_t len,
                   uint64_t *out, size_t capacity, size_t max_values) {
  tt_view v;
  int rc = tt_validate(wire, size, max_values, &v);
  if (rc)
    return rc;
  if (start > v.samples || len > v.samples - start)
    return TITCHY_INVALID;
  if (capacity < len || (!out && len))
    return TITCHY_CAPACITY;
  return range_c(&v, start, len, out);
}
int titchy_c_decode(const uint8_t *wire, size_t size, uint64_t *out,
                    size_t capacity, size_t max_values, size_t *count) {
  if (!count)
    return TITCHY_INVALID;
  *count = 0;
  tt_view v;
  int rc = tt_validate(wire, size, max_values, &v);
  if (rc)
    return rc;
  if (capacity < v.samples || (!out && v.samples))
    return TITCHY_CAPACITY;
  rc = range_c(&v, 0, v.samples, out);
  if (!rc)
    *count = v.samples;
  return rc;
}
