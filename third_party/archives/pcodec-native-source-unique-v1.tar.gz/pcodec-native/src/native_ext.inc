/* Included in the existing C/C++ core to reuse bounded ANS/bit I/O. */
#include "pcodec_native_ext.h"
#include <stdio.h>
typedef struct {unsigned order,quant;int64_t bias,weight[32];} Conv;
typedef struct {int mode,delta,secondary;unsigned k,wl,sl;uint64_t base,*dict;size_t dict_n;Conv conv;Var var[3];} NativeMeta;
typedef struct {size_t n;Var var[3];} NativePage;
struct pcn_encoder {int type;NativeMeta meta;NativePage*pages;size_t page_n;};
struct pcn_decoder {int type,file,failed,active;size_t limit,total,page_n,pos;uint8_t*owned;Reader input,page;NativeMeta meta;};
static int nm_secondary(const NativeMeta*m){return m->mode>0&&m->mode<4;}
static int nm_has(const NativeMeta*m,unsigned j){return j==1||(j==0&&m->delta==2)||(j==2&&nm_secondary(m));}
static size_t nm_state(const NativeMeta*m,unsigned j){if(j==0||j==2&&!m->secondary)return 0;return m->delta==1?m->conv.order:m->delta==2?(size_t)1<<m->sl:m->delta==3?m->conv.order:0;}
static void nm_free(NativeMeta*m){free(m->dict);for(unsigned j=0;j<3;j++)var_free(m->var+j);memset(m,0,sizeof(*m));}
void pcn_buffer_free(uint8_t*p,size_t n){(void)n;free(p);}
static int emit_buffer(pcn_buffer*out,const void*p,size_t n){if(!out)return PC_INVALID;out->data=NULL;out->size=0;if(!n)return 0;out->data=(uint8_t*)malloc(n);if(!out->data)return PC_NOMEM;memcpy(out->data,p,n);out->size=n;return 0;}
pcn_config pcn_default_config(void){pcn_config c={8,-1,-1,0,0,0,0,1.,1u<<18};return c;}
static int pcn_valid(const pcn_config*c,int t){unsigned b=(unsigned)pc_type_size(t)*8;return c&&b&&t!=9&&c->level>=0&&c->level<=12&&c->mode>=-1&&c->mode<=4&&c->delta>=-1&&c->delta<=3&&c->max_page_n&&c->max_page_n<=MAX_ENTRIES&&(c->enable_8_bit==0||c->enable_8_bit==1)&&(b!=8||c->enable_8_bit)&&(c->mode!=1||(!isfloat(t)&&c->int_base&&c->int_base<=mask64(b)))&&(c->mode!=2||(isfloat(t)&&isfinite(c->float_base)&&c->float_base!=0&&isfinite(narrow(1/c->float_base,b))))&&(c->mode!=3||(isfloat(t)&&c->quant_k>0&&c->quant_k<=(b==32?23:52)))&&(c->delta!=1||(c->order>=0&&c->order<=7))&&(c->delta!=3||(c->order>=0&&c->order<=32&&(c->mode==4||b<=32)));}
static uint64_t nm_predict(const uint64_t*x,const Conv*c,unsigned b){
 // Metadata checks prove no signed overflow over the entire latent domain.
 int64_t s=c->bias;for(unsigned j=0;j<c->order;j++)s+=c->weight[j]*(int64_t)x[j];return s>0?((uint64_t)s>>c->quant)&mask64(b):0;
}
static int fit_conv(const Var*p,unsigned requested,Conv*c){
 unsigned order=requested?requested:6;if(order>p->n)order=(unsigned)p->n;if(!order||p->n<=order)return 0;
 // Centering and rolling covariance are equivalent to upstream ridge regression.
 // A median center avoids losing low residual bits on large ordered integers.
 uint64_t*sorted=(uint64_t*)malloc(p->n*8);double*v=(double*)malloc(p->n*sizeof(double));if(!sorted||!v){free(sorted);free(v);return -PC_NOMEM;}
 memcpy(sorted,p->v,p->n*8);qsort(sorted,p->n,8,cmpu64);double center=(double)sorted[p->n/2];free(sorted);
 for(size_t i=0;i<p->n;i++)v[i]=(double)p->v[i]-center;
 double a[33][33]={{0}},rhs[33]={0},beta[33]={0};unsigned h=order+1;
 for(size_t i=0;i<p->n-order;i++)for(unsigned j=0;j<h;j++){double x=j==order?1:v[i+j];rhs[j]+=x*v[i+order];for(unsigned k=0;k<=j;k++)a[j][k]+=x*(k==order?1:v[i+k]);}
 for(unsigned j=0;j<h;j++){a[j][j]+=.1;for(unsigned k=0;k<j;k++)a[k][j]=a[j][k];}
 for(unsigned j=0;j<h;j++)for(unsigned k=0;k<=j;k++){double s=a[j][k];for(unsigned z=0;z<k;z++)s=fma(-a[j][z],a[k][z],s);if(j==k){a[j][k]=sqrt(fmax(0,s));if(!a[j][k]){free(v);return 0;}}else a[j][k]=s/a[k][k];}
 for(unsigned j=0;j<h;j++){double s=rhs[j];for(unsigned k=0;k<j;k++)s-=a[j][k]*beta[k];beta[j]=s/a[j][j];}
 for(unsigned jj=h;jj>0;jj--){unsigned j=jj-1;double s=beta[j];for(unsigned k=j+1;k<h;k++)s-=a[k][j]*beta[k];beta[j]=s/a[j][j];}
 free(v);double sum=0,ab=0;for(unsigned j=0;j<order;j++){sum+=beta[j];ab+=fabs(beta[j]);}double bias=(1-sum)*center+beta[order];
 unsigned cb=p->b==8?16:p->b==16?32:64;
 double qd=floor(log2((ldexp(1.,cb-1)-1)/(ab*(double)mask64(p->b)+fabs(bias)+1)))-1;
 if(!isfinite(qd)||qd<0)return 0;unsigned q=(unsigned)MIN2(MIN2(qd,31),cb-1);double scale=ldexp(1.,q);
 c->order=order;c->quant=q;c->bias=(int64_t)(bias*scale);
 for(unsigned j=0;j<order;j++){double w=round(beta[j]*scale);if(w<INT32_MIN||w>INT32_MAX)return 0;c->weight[j]=(int64_t)w;}
 return 1;
}
static int apply_conv(Var*v,const Conv*c){
 size_t n=v->n;unsigned order=c->order;v->state_n=order;v->state=(uint64_t*)calloc(order,8);if(!v->state)return PC_NOMEM;
 for(unsigned j=0;j<order&&j<n;j++)v->state[j]=v->v[j];
 for(size_t i=n;i>order;i--){size_t at=i-1;uint64_t pred=nm_predict(v->v+at-order,c,v->b);v->v[at]=(v->v[at]-pred+(UINT64_C(1)<<(v->b-1)))&mask64(v->b);}memmove(v->v,v->v+MIN2(order,n),(n-MIN2(order,n))*8);
 v->n=n-MIN2(n,order);return 0;
}
typedef struct {uint64_t value;size_t count,index;} DictEntry;
static int dict_cmp(const void*a,const void*b){const DictEntry*x=(const DictEntry*)a,*y=(const DictEntry*)b;return x->count!=y->count?(x->count<y->count?1:-1):cmpu64(&x->value,&y->value);}
static int dict_build(Var*p,NativeMeta*m){
 uint64_t*sorted=(uint64_t*)malloc(p->n*8);DictEntry*entry=(DictEntry*)malloc(p->n*sizeof(*entry));size_t*map=(size_t*)malloc(p->n*sizeof(size_t));
 if(!sorted||!entry||!map){free(sorted);free(entry);free(map);return PC_NOMEM;}
 memcpy(sorted,p->v,p->n*8);qsort(sorted,p->n,8,cmpu64);size_t k=0;
 for(size_t i=0;i<p->n;i++){if(!k||sorted[i]!=entry[k-1].value){entry[k].value=sorted[i];entry[k].count=0;entry[k].index=k;k++;}entry[k-1].count++;}
 qsort(entry,k,sizeof(*entry),dict_cmp);m->dict=(uint64_t*)malloc(k*8);if(!m->dict){free(sorted);free(entry);free(map);return PC_NOMEM;}
 m->dict_n=k;for(size_t j=0;j<k;j++){m->dict[j]=entry[j].value;map[entry[j].index]=j;}
 // Sorted unique lookup, preserving the original temporal order.
 size_t unique=0;for(size_t i=0;i<p->n;i++)if(!i||sorted[i]!=sorted[i-1])sorted[unique++]=sorted[i];
 for(size_t i=0;i<p->n;i++){size_t lo=0,hi=k;while(lo<hi){size_t mid=lo+(hi-lo)/2;if(sorted[mid]<p->v[i])lo=mid+1;else hi=mid;}p->v[i]=map[lo];}
 p->b=32;free(sorted);free(entry);free(map);return 0;
}
static void nm_write(Writer*w,const NativeMeta*m,int t){
 unsigned b=(unsigned)pc_type_size(t)*8;put(w,m->mode,4);
 if(m->mode==1||m->mode==2)put(w,m->base,b);
 if(m->mode==3)put(w,m->k,8);
 if(m->mode==4){put(w,m->dict_n,25);walign(w);for(size_t j=0;j<m->dict_n;j++)put(w,m->dict[j],b);}
 put(w,m->delta,4);
 if(m->delta==1){put(w,m->conv.order,3);put(w,m->secondary,1);}
 if(m->delta==2){put(w,m->wl-1,5);put(w,m->sl,4);put(w,m->secondary,1);}
 if(m->delta==3){put(w,m->conv.quant,5);put(w,(uint64_t)m->conv.bias^(UINT64_C(1)<<63),64);put(w,m->conv.order-1,5);for(unsigned j=0;j<m->conv.order;j++)put(w,(uint32_t)m->conv.weight[j]^UINT32_C(0x80000000),32);}
 for(unsigned j=0;j<3;j++)if(nm_has(m,j))write_varmeta(w,(Var*)m->var+j);walign(w);
}
static int nm_read(Reader*r,int t,NativeMeta*m){
 nm_free(m);unsigned b=(unsigned)pc_type_size(t)*8;m->mode=(int)get(r,4);
 if(m->mode==1||m->mode==2)m->base=get(r,b);
 else if(m->mode==3)m->k=(unsigned)get(r,8);
 else if(m->mode==4){m->dict_n=(size_t)get(r,25);ralign(r);if(!m->dict_n||m->dict_n>MAX_ENTRIES||r->err)return r->err?r->err:PC_CORRUPT;if(m->dict_n>(r->size-r->bit/8)/(b/8))return PC_TRUNCATED;m->dict=(uint64_t*)malloc(m->dict_n*8);if(!m->dict)return PC_NOMEM;for(size_t j=0;j<m->dict_n;j++)m->dict[j]=get(r,b);}
 else if(m->mode!=0)return PC_UNSUPPORTED;
 if((m->mode==1&&(!m->base||isfloat(t)))||(m->mode==2&&(!isfloat(t)||!isfinite(asfloat(unorder(m->base,b),b))||asfloat(unorder(m->base,b),b)==0))||(m->mode==3&&(!isfloat(t)||!m->k||m->k>(b==32?23u:52u))))return PC_CORRUPT;
 m->delta=(int)get(r,4);
 if(m->delta==1){m->conv.order=(unsigned)get(r,3);m->secondary=(int)get(r,1);if(!m->conv.order)return PC_CORRUPT;}
 else if(m->delta==2){m->wl=1+(unsigned)get(r,5);m->sl=(unsigned)get(r,4);m->secondary=(int)get(r,1);if(m->wl>24||m->sl>m->wl)return PC_CORRUPT;}
 else if(m->delta==3){
  m->conv.quant=(unsigned)get(r,5);uint64_t raw=get(r,64)^(UINT64_C(1)<<63);memcpy(&m->conv.bias,&raw,8);m->conv.order=1+(unsigned)get(r,5);
  long double bound=fabsl((long double)m->conv.bias);unsigned primary=m->mode==4?32:b,cb=primary==8?16:primary==16?32:64;
  if(primary>32||m->conv.quant>=cb)return PC_CORRUPT;
  for(unsigned j=0;j<m->conv.order;j++){uint32_t u=(uint32_t)get(r,32)^UINT32_C(0x80000000);int32_t w;memcpy(&w,&u,4);m->conv.weight[j]=w;bound+=ldexpl(fabsl((long double)w),primary);}
  if(bound>=ldexpl(1,cb-1))return PC_CORRUPT;
 }else if(m->delta!=0)return PC_UNSUPPORTED;
 for(unsigned j=0;j<3;j++)if(nm_has(m,j)){int e=read_varmeta(r,m->var+j,j==0||m->mode==4?32:b);if(e)return e;}
 ralign(r);return r->err;
}
void pcn_chunk_destroy(pcn_encoder*e){if(e){if(e->pages)for(size_t i=0;i<e->page_n;i++)for(unsigned j=0;j<3;j++)var_free(e->pages[i].var+j);free(e->pages);nm_free(&e->meta);free(e);}}
int pcn_chunk_new(const void*src,size_t n,int t,const pcn_config*conf,const size_t*counts,size_t np,pcn_encoder**out){
 if(!out)return PC_INVALID;*out=NULL;pcn_config defaults=pcn_default_config();const pcn_config*c=conf?conf:&defaults;
 if(!src||!n||n>MAX_ENTRIES||!pcn_valid(c,t))return t==9?PC_UNSUPPORTED:PC_INVALID;
 pcn_encoder*e=(pcn_encoder*)calloc(1,sizeof(*e));if(!e)return PC_NOMEM;e->type=t;
 if(!counts)np=(n+c->max_page_n-1)/c->max_page_n;if(!np||np>n){pcn_chunk_destroy(e);return PC_INVALID;}
 e->page_n=np;e->pages=(NativePage*)calloc(np,sizeof(*e->pages));if(!e->pages){pcn_chunk_destroy(e);return PC_NOMEM;}
 size_t total=0;for(size_t i=0;i<np;i++){size_t cn=counts?counts[i]:n/np+(i<n%np);if(!cn||cn>n-total){pcn_chunk_destroy(e);return PC_INVALID;}e->pages[i].n=cn;total+=cn;}if(total!=n){pcn_chunk_destroy(e);return PC_INVALID;}
 NativeMeta*m=&e->meta;Choice choice={0,0,0,1,0};TrainWorkspace ws=PC_ZERO;Var p=PC_ZERO,s=PC_ZERO;int status=workspace_init(&ws,n,hist_log(c->level,n));if(status)goto fail;
 if(c->mode<0||c->delta<0){pc_config legacy={c->level,c->mode==4?0:c->mode,c->delta==1?c->order:c->delta==2?8:c->delta==3?0:c->delta,c->quant_k,c->float_base,c->max_page_n};status=choose(src,n,t,&legacy,&choice,&ws,c->int_base);if(status)goto fail;}
 m->mode=c->mode<0?choice.mode:c->mode;m->k=c->quant_k;m->base=c->mode==1?c->int_base:ordered(asbits(c->mode<0?choice.base:c->float_base,(unsigned)pc_type_size(t)*8),(unsigned)pc_type_size(t)*8);if(c->mode<0)m->k=choice.k;
 m->delta=c->delta<0?(choice.delta==8?2:choice.delta?1:0):c->delta;m->conv.order=c->delta<0?(unsigned)choice.delta:(unsigned)c->order;m->wl=8;m->sl=0;
 if(m->delta==1&&!m->conv.order)m->delta=0;
 status=split(src,n,t,m->mode==4?0:m->mode,m->k,asfloat(unorder(m->base,(unsigned)pc_type_size(t)*8),(unsigned)pc_type_size(t)*8),c->int_base,&p,&s);if(status)goto fail;
 if(m->mode==4){status=dict_build(&p,m);if(status)goto fail;}
 if(m->delta==3){int fitted=fit_conv(&p,(unsigned)c->order,&m->conv);if(fitted<0){status=-fitted;goto fail;}if(!fitted)m->delta=0;}
 {size_t start=0;
 for(size_t i=0;i<np;i++){
  NativePage*page=e->pages+i;
  for(unsigned j=1;j<3;j++)if(nm_has(m,j)){
   Var*var=page->var+j,*srcvar=j==1?&p:&s;status=alloc_var(var,page->n,srcvar->b);if(status)goto fail;memcpy(var->v,srcvar->v+start,page->n*8);
   if(j==1){if(m->delta==1)status=consecutive(var,m->conv.order);else if(m->delta==2)status=lookback(var,page->var,8);else if(m->delta==3)status=apply_conv(var,&m->conv);if(status)goto fail;}
  }
  start+=page->n;
 }
 for(unsigned j=0;j<3;j++)if(nm_has(m,j)){
  Var*model=m->var+j;size_t count=0;for(size_t i=0;i<np;i++)count+=e->pages[i].var[j].n;
  status=alloc_var(model,count,e->pages[0].var[j].b);if(status)goto fail;size_t at=0;
  for(size_t i=0;i<np;i++){Var*v=e->pages[i].var+j;memcpy(model->v+at,v->v,v->n*8);at+=v->n;}
  status=train(model,j==2?MIN2(hist_log(c->level,n),6):hist_log(c->level,n),&ws);if(status)goto fail;
  free(model->v);model->v=NULL;
  for(size_t i=0;i<np;i++){Var*v=e->pages[i].var+j;v->log=model->log;v->nb=model->nb;v->bins=(Bin*)malloc(MAX2(v->nb,1)*sizeof(Bin));if(!v->bins){status=PC_NOMEM;goto fail;}if(v->nb)memcpy(v->bins,model->bins,v->nb*sizeof(Bin));status=dissect(v);if(status)goto fail;}
 }
 }
 *out=e;
fail:
 var_free(&p);var_free(&s);free(ws.allocation);if(status)pcn_chunk_destroy(e);return status;
}
int pcn_chunk_header_meta(const pcn_encoder*e,pcn_buffer*out){if(!e||!out)return PC_INVALID;out->data=NULL;out->size=0;Writer w=PC_ZERO;put(&w,4,8);put(&w,1,8);nm_write(&w,&e->meta,e->type);if(w.err){free(w.p);return w.err;}out->data=w.p;out->size=w.bit/8;return 0;}
int pcn_chunk_page(pcn_encoder*e,size_t index,pcn_buffer*out){
 if(!out)return PC_INVALID;out->data=NULL;out->size=0;if(!e||index>=e->page_n)return PC_INVALID;
 NativePage*page=e->pages+index;Writer w=PC_ZERO;
 for(unsigned j=0;j<3;j++)if(nm_has(&e->meta,j)){Var*v=page->var+j;for(size_t k=0;k<v->state_n;k++)put(&w,v->state[k],v->b);for(unsigned k=0;k<4;k++)put(&w,v->final[k]-(1u<<v->log),v->log);}
 walign(&w);for(size_t start=0;start<page->n;start+=256)for(unsigned j=0;j<3;j++)if(nm_has(&e->meta,j))write_batch(&w,page->var+j,start);walign(&w);
 if(w.err){free(w.p);return w.err;}out->data=w.p;out->size=w.bit/8;return 0;
}
int pcn_chunk_page_counts(const pcn_encoder*e,pcn_buffer*out){if(!e||!out)return PC_INVALID;out->data=(uint8_t*)malloc(e->page_n*sizeof(size_t));out->size=0;if(!out->data)return PC_NOMEM;out->size=e->page_n*sizeof(size_t);for(size_t j=0;j<e->page_n;j++)memcpy(out->data+j*sizeof(size_t),&e->pages[j].n,sizeof(size_t));return 0;}
static int describe_native(const NativeMeta*m,pcn_buffer*out){char text[256];int n=snprintf(text,sizeof(text),"{\"backend\":\"native-c11\",\"auto_policy\":\"NativeAuto\",\"mode\":%d,\"delta\":%d,\"order\":%u,\"dictionary_entries\":%zu,\"quantization\":%u}",m->mode,m->delta,m->conv.order,m->dict_n,m->conv.quant);return emit_buffer(out,text,(size_t)n);}
int pcn_chunk_describe(const pcn_encoder*e,pcn_buffer*out){return e?describe_native(&e->meta,out):PC_INVALID;}
int pcn_decoder_describe(const pcn_decoder*d,pcn_buffer*out){return d?describe_native(&d->meta,out):PC_INVALID;}
static void page_clear(NativeMeta*m){for(unsigned j=0;j<3;j++){Var*v=m->var+j;free(v->v);free(v->state);free(v->history);v->v=v->state=NULL;v->history=NULL;v->state_n=v->n=v->history_window=v->history_pos=0;}}
static int page_start(pcn_decoder*d,Reader page,size_t n){
 page_clear(&d->meta);NativeMeta*m=&d->meta;
 for(unsigned j=0;j<3;j++)if(nm_has(m,j)){
  Var*v=m->var+j;v->state_n=nm_state(m,j);size_t offset=j==0?nm_state(m,1):v->state_n;v->n=n-MIN2(n,offset);
  v->v=(uint64_t*)calloc(256,8);v->state=(uint64_t*)calloc(MAX2(v->state_n,1),8);if(!v->v||!v->state)return PC_NOMEM;
  if(!v->nb&&v->n)return PC_CORRUPT;
  for(size_t k=0;k<v->state_n;k++)v->state[k]=get(&page,v->b);
  for(unsigned k=0;k<4;k++)v->final[k]=(uint32_t)get(&page,v->log);
  if(m->delta==2&&v->state_n){v->history_window=MIN2((size_t)1<<m->wl,n+v->state_n);v->history_pos=v->history_window;v->history=calloc(2*MAX2(v->history_window,256),8);if(!v->history)return PC_NOMEM;memcpy((uint64_t*)v->history+v->history_pos-v->state_n,v->state,v->state_n*8);}
 }
 ralign(&page);if(page.err)return page.err;d->page=page;d->page_n=n;d->pos=0;d->active=1;return 0;
}
static int restore_batch(pcn_decoder*d,size_t count,void*out){
 NativeMeta*m=&d->meta;Var*p=m->var+1,*s=m->var+2;Reader*r=&d->page;
 for(unsigned j=0;j<3;j++)if(nm_has(m,j)){Var*v=m->var+j;memset(v->v,0,256*8);read_batch(r,v,d->pos,v->v);}
 if(r->err)return r->err;
 for(unsigned j=1;j<3;j++)if(nm_has(m,j)){
  Var*v=m->var+j;if(!v->state_n)continue;
  if(m->delta==1)undo_consecutive_batch(v,count);
  else if(m->delta==2){size_t residuals=MIN2(256,v->n-MIN2(d->pos,v->n));int e;
   // uint64 ANS lags converted explicitly, never reinterpret a wide buffer.
   uint32_t lags[256];for(size_t k=0;k<residuals;k++){if(m->var[0].v[k]>UINT32_MAX)return PC_CORRUPT;lags[k]=(uint32_t)m->var[0].v[k];}
   e=undo_lookback_batch64(v,lags,d->pos,count,residuals,(size_t)1<<m->wl);if(e)return e;
  }else if(m->delta==3){
   size_t residuals=MIN2(256,v->n-MIN2(d->pos,v->n));uint64_t mid=UINT64_C(1)<<(v->b-1);
   for(size_t k=0;k<count;k++){uint64_t next=k<residuals?((v->v[k]^mid)+nm_predict(v->state,&m->conv,v->b))&mask64(v->b):0;v->v[k]=v->state[0];memmove(v->state,v->state+1,(v->state_n-1)*8);v->state[v->state_n-1]=next;}
  }
 }
 unsigned b=(unsigned)pc_type_size(d->type)*8;uint64_t mid=UINT64_C(1)<<(b-1);
 if(m->mode==4){for(size_t i=0;i<count;i++){if(p->v[i]>=m->dict_n)return PC_CORRUPT;uint64_t x=m->dict[p->v[i]],raw=isfloat(d->type)?unorder(x,b):issigned(d->type)?x^mid:x;storeraw(out,i,b,raw);}return 0;}
 if(d->type==PC_F32)return restore_f32(p,s,count,m->mode,m->k,m->mode==2?unorder(m->base,b):m->base,out);
 if(d->type==PC_F64)return restore_f64(p,s,count,m->mode,m->k,m->mode==2?unorder(m->base,b):m->base,out);
 for(size_t i=0;i<count;i++){uint64_t x=p->v[i];if(m->mode==1)x=(x*m->base+s->v[i])&mask64(b);if(issigned(d->type))x^=mid;storeraw(out,i,b,x);}return 0;
}
void pcn_decoder_destroy(pcn_decoder*d){if(d){free(d->owned);if(!d->file)free((void*)d->page.p);nm_free(&d->meta);free(d);}}
static pcn_decoder*decoder_alloc(int t){if(!pc_type_size(t)||t==9)return NULL;pcn_decoder*d=(pcn_decoder*)calloc(1,sizeof(*d));if(d)d->type=t;return d;}
int pcn_wrapped_open(const uint8_t*bytes,size_t n,int t,pcn_decoder**out){
 if(!out)return PC_INVALID;*out=NULL;if(!bytes||n<2||n>SIZE_MAX/8||!pc_type_size(t))return PC_INVALID;if(t==9)return PC_UNSUPPORTED;
 pcn_decoder*d=decoder_alloc(t);if(!d)return PC_NOMEM;Reader r={bytes,n,0,0};unsigned major=(unsigned)get(&r,8),minor=(unsigned)get(&r,8);int status=major==4&&minor<=1?nm_read(&r,t,&d->meta):PC_UNSUPPORTED;
 if(!status&&r.bit!=n*8)status=PC_CORRUPT;if(status){pcn_decoder_destroy(d);return status;}*out=d;return 0;
}
int pcn_wrapped_start_page(pcn_decoder*d,const uint8_t*bytes,size_t size,size_t n,size_t limit){
 if(!d||d->file||d->failed||d->active||(!bytes&&size)||size>SIZE_MAX/8||!n||n>MAX_ENTRIES)return PC_INVALID;
 if(n>limit||d->total>limit-n)return PC_LIMIT;
 free((void*)d->page.p);d->page.p=NULL;uint8_t*copy=(uint8_t*)malloc(MAX2(size,1));if(!copy)return PC_NOMEM;if(size)memcpy(copy,bytes,size);
 Reader page={copy,size,0,0};d->page=page;int status=page_start(d,page,n);if(status)d->failed=1;d->limit=limit;return status;
}
int pcn_file_open(const uint8_t*bytes,size_t n,int t,size_t limit,pcn_decoder**out){
 if(!out)return PC_INVALID;*out=NULL;if(!bytes||n>SIZE_MAX/8||!pc_type_size(t))return PC_INVALID;if(t==9)return PC_UNSUPPORTED;
 pcn_decoder*d=decoder_alloc(t);if(!d)return PC_NOMEM;d->file=1;d->limit=limit;d->owned=(uint8_t*)malloc(MAX2(n,1));if(!d->owned){pcn_decoder_destroy(d);return PC_NOMEM;}memcpy(d->owned,bytes,n);Reader input={d->owned,n,0,0};d->input=input;Reader*r=&d->input;
 int status=0;if(get(r,32)!=0x216f6370)status=PC_CORRUPT;else if(get(r,8)!=3)status=PC_UNSUPPORTED;
 unsigned uniform=(unsigned)get(r,8);if(uniform&&uniform!=(unsigned)t)status=PC_INVALID;unsigned power=1+(unsigned)get(r,6);get(r,power);ralign(r);unsigned major=(unsigned)get(r,8),minor=(unsigned)get(r,8);if(major!=4||minor>1)status=PC_UNSUPPORTED;if(r->err)status=r->err;
 if(status){pcn_decoder_destroy(d);return status;}*out=d;return 0;
}
int pcn_read(pcn_decoder*d,size_t capacity,pcn_buffer*out,size_t*n,int*finished){
 if(out){out->data=NULL;out->size=0;}if(n)*n=0;if(finished)*finished=0;
 if(!d||!out||!n||!finished||d->failed||!capacity||capacity%256||capacity>SIZE_MAX/pc_type_size(d->type))return PC_INVALID;
 size_t quota=d->file?d->limit-d->total:d->active?d->page_n-d->pos:0;
 size_t allocate=MIN2(capacity,quota);uint8_t*values=(uint8_t*)malloc(MAX2(allocate*pc_type_size(d->type),1));if(!values)return PC_NOMEM;size_t count=0;int status=0;
 while(count<capacity){
  if(!d->active){
   if(!d->file){*finished=1;break;}
   Reader*r=&d->input;unsigned t=(unsigned)get(r,8);if(r->err){status=r->err;break;}if(!t){if(r->bit!=r->size*8)status=PC_CORRUPT;else *finished=1;break;}
   if(t!=(unsigned)d->type){status=PC_INVALID;break;}size_t cn=1+(size_t)get(r,24);if(r->err){status=r->err;break;}
   if(cn>d->limit-d->total){status=PC_LIMIT;break;}
   status=nm_read(r,d->type,&d->meta);if(!status)status=page_start(d,*r,cn);if(status)break;
  }
  size_t batch=MIN2(256,d->page_n-d->pos);if(batch>capacity-count)break;if(batch>allocate-count){status=PC_LIMIT;break;}
  status=restore_batch(d,batch,values+count*pc_type_size(d->type));if(status)break;d->pos+=batch;d->total+=batch;count+=batch;
  if(d->pos==d->page_n){ralign(&d->page);if(d->page.err){status=d->page.err;break;}if(!d->file&&d->page.bit!=d->page.size*8){status=PC_CORRUPT;break;}if(d->file)d->input=d->page;d->active=0;if(!d->file){*finished=1;break;}}
 }
 if(status){free(values);d->failed=1;return status;}out->data=values;out->size=count*pc_type_size(d->type);*n=count;return 0;
}
int pcn_compress(const void*src,size_t n,int t,const pcn_config*conf,pcn_buffer*out){
 if(!out)return PC_INVALID;out->data=NULL;out->size=0;pcn_config defaults=pcn_default_config();const pcn_config*c=conf?conf:&defaults;
 if((!src&&n)||!pcn_valid(c,t)||n>SIZE_MAX/pc_type_size(t))return t==9?PC_UNSUPPORTED:PC_INVALID;
 Writer w=PC_ZERO;put(&w,0x216f6370,32);put(&w,3,8);put(&w,0,8);unsigned power=MAX2(bits64(n),1);put(&w,power-1,6);put(&w,n,power);walign(&w);put(&w,4,8);put(&w,1,8);
 size_t np=n/c->max_page_n+(n%c->max_page_n!=0),start=0;int status=0;
 for(size_t j=0;j<np;j++){
  size_t cn=n/np+(j<n%np);pcn_encoder*enc=NULL;status=pcn_chunk_new((const uint8_t*)src+start*pc_type_size(t),cn,t,c,&cn,1,&enc);if(status)break;
  pcn_buffer meta={NULL,0},page={NULL,0};status=pcn_chunk_header_meta(enc,&meta);if(!status)status=pcn_chunk_page(enc,0,&page);
  if(!status){put(&w,t,8);put(&w,cn-1,24);for(size_t k=2;k<meta.size;k++)put(&w,meta.data[k],8);for(size_t k=0;k<page.size;k++)put(&w,page.data[k],8);}
  pcn_buffer_free(meta.data,meta.size);pcn_buffer_free(page.data,page.size);pcn_chunk_destroy(enc);if(status)break;start+=cn;
 }
 put(&w,0,8);if(!status)status=w.err;if(status){free(w.p);return status;}out->data=w.p;out->size=w.bit/8;return 0;
}
int pcn_decompress(const uint8_t*src,size_t size,int t,size_t limit,pcn_buffer*out,size_t*n){
 if(out){out->data=NULL;out->size=0;}if(n)*n=0;if(!out||!n)return PC_INVALID;pcn_decoder*d=NULL;int status=pcn_file_open(src,size,t,limit,&d);if(status)return status;
 size_t capacity=0,total=0;uint8_t*result=NULL;int done=0;
 while(!done){pcn_buffer batch={NULL,0};size_t got=0;status=pcn_read(d,4096,&batch,&got,&done);if(status){free(batch.data);break;}
  if(batch.size>SIZE_MAX-total){free(batch.data);status=PC_LIMIT;break;}
  if(total+batch.size>capacity){size_t target=MAX2(total+batch.size,capacity>SIZE_MAX/2?SIZE_MAX:capacity*2);uint8_t*p=(uint8_t*)realloc(result,target);if(!p){free(batch.data);status=PC_NOMEM;break;}result=p;capacity=target;}
  if(batch.size)memcpy(result+total,batch.data,batch.size);total+=batch.size;free(batch.data);
 }
 pcn_decoder_destroy(d);if(status){free(result);return status;}out->data=result;out->size=total;*n=total/pc_type_size(t);return 0;
}
