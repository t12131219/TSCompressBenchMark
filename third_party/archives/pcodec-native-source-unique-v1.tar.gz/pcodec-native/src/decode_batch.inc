/* Instantiated for 32- and 64-bit cache-resident latent batches. */
static void PC_BATCH_NAME(Reader *r, Var *v, size_t offset, PC_BATCH_WORD *__restrict values) {
  const Node *__restrict nodes = v->nodes;
  const uint64_t *__restrict lowers = v->lowers;
  size_t start = 0, end = MIN2(256, v->n - MIN2(offset, v->n));
  if (start >= end || r->err)
    return;
  if (!v->nb) {
    r->err = PC_CORRUPT;
    return;
  }
  unsigned obs[256];
  uint64_t positions[256];
  size_t total = 0;
  if (v->nb == 1) {
    const Bin *bin = &v->bins[0];
    if (!bin->ob) {
      for (size_t i = start; i < end; i++)
        values[i] = bin->lo;
      return;
    }
    size_t total = (end - start) * bin->ob;
    if (r->bit > r->size * 8 || total > r->size * 8 - r->bit) {
      r->err = PC_TRUNCATED;
      return;
    }
#if defined(__BYTE_ORDER__) && __BYTE_ORDER__ == __ORDER_LITTLE_ENDIAN__
    size_t finalbit = r->bit + total;
    if (r->size - (finalbit >> 3) >= 8) {
      uint64_t offset_mask = mask64(bin->ob), value_mask = mask64(v->b);
      size_t i = start;
#if defined(__AVX2__)
      if (bin->ob <= 56) {
        __m256i at =
            _mm256_set_epi64x((long long)(r->bit + 3 * bin->ob), (long long)(r->bit + 2 * bin->ob),
                              (long long)(r->bit + bin->ob), (long long)r->bit);
        __m256i step = _mm256_set1_epi64x(4 * bin->ob), seven = _mm256_set1_epi64x(7);
        __m256i omask = _mm256_set1_epi64x((long long)offset_mask);
        __m256i vmask = _mm256_set1_epi64x((long long)value_mask);
        __m256i lower = _mm256_set1_epi64x((long long)bin->lo);
        for (; i + 4 <= end; i += 4) {
          __m256i packed =
              _mm256_i64gather_epi64((const long long *)r->p, _mm256_srli_epi64(at, 3), 1);
          __m256i offset =
              _mm256_and_si256(_mm256_srlv_epi64(packed, _mm256_and_si256(at, seven)), omask);
          PC_BATCH_STORE(values + i, _mm256_and_si256(_mm256_add_epi64(lower, offset), vmask));
          at = _mm256_add_epi64(at, step);
        }
        r->bit += (i - start) * bin->ob;
      }
#endif
      for (; i < end; i++) {
        size_t byte = r->bit >> 3;
        unsigned off = (unsigned)(r->bit & 7);
        uint64_t x;
        memcpy(&x, r->p + byte, 8);
        x >>= off;
        if (bin->ob + off > 64)
          x |= (uint64_t)r->p[byte + 8] << (64 - off);
        values[i] = (bin->lo + (x & offset_mask)) & value_mask;
        r->bit += bin->ob;
      }
      return;
    }
#endif
    for (size_t i = start; i < end; i++)
      values[i] = (bin->lo + get(r, bin->ob)) & mask64(v->b);
    return;
  } else {
    uint32_t s0 = v->final[0], s1 = v->final[1], s2 = v->final[2], s3 = v->final[3];
    size_t i = start;
#if defined(__BYTE_ORDER__) && __BYTE_ORDER__ == __ORDER_LITTLE_ENDIAN__
    /* Four renormalizations need at most 56 bits; with initial bit offset
       they fit a single bounded 64-bit load. Tail uses the checked reader. */
    for (; i + 4 <= end && r->size - (r->bit >> 3) >= 8; i += 4) {
      uint64_t packed;
      memcpy(&packed, r->p + (r->bit >> 3), 8);
      unsigned off = (unsigned)(r->bit & 7), bits = 0;
#define PC_READ_LANE(j, state)                                                                     \
  do {                                                                                             \
    const Node *node = &nodes[state];                                                              \
    uint32_t val = (uint32_t)((packed >> (off + bits)) & ((1u << node->nb) - 1));                  \
    values[i + (j)] = lowers[state];                                                               \
    positions[i + (j) - start] = total;                                                            \
    total += node->ob;                                                                             \
    obs[i + (j) - start] = node->ob;                                                               \
    bits += node->nb;                                                                              \
    state = node->next + val;                                                                      \
  } while (0)
      PC_READ_LANE(0, s0);
      PC_READ_LANE(1, s1);
      PC_READ_LANE(2, s2);
      PC_READ_LANE(3, s3);
#undef PC_READ_LANE
      r->bit += bits;
    }
#endif
    uint32_t states[4] = {s0, s1, s2, s3};
    for (; i < end; i++) {
      unsigned j = (unsigned)(i & 3);
      const Node *node = &nodes[states[j]];
      values[i] = lowers[states[j]];
      positions[i - start] = total;
      total += node->ob;
      obs[i - start] = node->ob;
      states[j] = node->next + (uint32_t)get(r, node->nb);
    }
    memcpy(v->final, states, sizeof(states));
  }
  /* On short tails the setup of bulk offset positions costs more than
     checked reads, and often no full word remains after the payload. */
  if (end - start < 64) {
    for (size_t i = start; i < end; i++)
      values[i] = (values[i] + get(r, obs[i - start])) & mask64(v->b);
    return;
  }
  unsigned maxob = v->max_ob;
  if (r->err || total > r->size * 8 - r->bit) {
    r->err = PC_TRUNCATED;
    return;
  }
#if defined(__BYTE_ORDER__) && __BYTE_ORDER__ == __ORDER_LITTLE_ENDIAN__
  if (!total)
    return;
  size_t finalbit = r->bit + total;
  if (r->size - (finalbit >> 3) >= 8) {
    for (size_t i = 0; i < end - start; i++)
      positions[i] += r->bit;
    uint64_t mask = mask64(v->b);
    if (maxob <= 56) {
      size_t i = 0;
#if defined(__AVX2__)
      const __m256i ones = _mm256_set1_epi64x(1), seven = _mm256_set1_epi64x(7);
      const __m256i value_mask = _mm256_set1_epi64x((long long)mask);
      for (; i + 4 <= end - start; i += 4) {
        __m256i at = _mm256_loadu_si256((const __m256i *)(positions + i));
        __m256i bytes = _mm256_srli_epi64(at, 3);
        __m256i packed = _mm256_i64gather_epi64((const long long *)r->p, bytes, 1);
        __m256i width = _mm256_cvtepu32_epi64(_mm_loadu_si128((const __m128i *)(obs + i)));
        __m256i lowmask = _mm256_sub_epi64(_mm256_sllv_epi64(ones, width), ones);
        __m256i offsets =
            _mm256_and_si256(_mm256_srlv_epi64(packed, _mm256_and_si256(at, seven)), lowmask);
        __m256i lower = PC_BATCH_LOAD(values + start + i);
        PC_BATCH_STORE(values + start + i,
                       _mm256_and_si256(_mm256_add_epi64(lower, offsets), value_mask));
      }
#endif
      for (; i < end - start; i++) {
        uint64_t x;
        memcpy(&x, r->p + (positions[i] >> 3), 8);
        values[start + i] =
            (values[start + i] + ((x >> (positions[i] & 7)) & mask64(obs[i]))) & mask;
      }
    } else {
      for (size_t i = 0; i < end - start; i++) {
        size_t byte = positions[i] >> 3;
        unsigned off = (unsigned)(positions[i] & 7);
        uint64_t x;
        memcpy(&x, r->p + byte, 8);
        x >>= off;
        if (obs[i] + off > 64)
          x |= (uint64_t)r->p[byte + 8] << (64 - off);
        values[start + i] = (values[start + i] + (x & mask64(obs[i]))) & mask;
      }
    }
    r->bit = finalbit;
    return;
  }
#endif
  for (size_t i = start; i < end; i++)
    values[i] = (values[i] + get(r, obs[i - start])) & mask64(v->b);
}
