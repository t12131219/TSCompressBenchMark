#ifdef PC_SOURCE_BACKEND
#include "pcodec_source.h"
#endif
/* Native implementation of the pco numerical codec, Apache-2.0.
 * Algorithms and wire format adapted from pco 1.0.4 (Martin Loncaric et al.).
 * See NOTICE and README for scope and intentional encoder differences.
 * This translation unit is valid C11 and C++17; both builds use this core.
 */
#include "pcodec.h"
#include <limits.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#if defined(__AVX2__) || defined(__LZCNT__)
#include <immintrin.h>
#endif

#define MIN2(a, b) ((a) < (b) ? (a) : (b))
#define MAX2(a, b) ((a) > (b) ? (a) : (b))
#ifdef __cplusplus
#define PC_ZERO                                                                                    \
  {}
#else
#define PC_ZERO {0}
#endif
#define MAX_BINS 4096
#define MAX_ENTRIES ((size_t)1 << 24)
typedef struct {
  uint8_t *p;
  size_t cap, bit;
  int err;
} Writer;
typedef struct {
  const uint8_t *p;
  size_t size, bit;
  int err;
} Reader;
static uint64_t mask64(unsigned b) {
  return b == 64 ? UINT64_MAX : (b ? ((UINT64_C(1) << b) - 1) : 0);
}
static unsigned bits64(uint64_t x) {
#if defined(__LZCNT__)
  return 64u - (unsigned)_lzcnt_u64(x);
#else
  return x ? 64u - (unsigned)__builtin_clzll(x) : 0;
#endif
}
static unsigned ceil_log(size_t n) {
  return n > 1 ? bits64(n - 1) : 0;
}
static int reserve(Writer *w, size_t bits) {
  if (w->err)
    return 0;
  if (bits > SIZE_MAX - w->bit - 7) {
    w->err = PC_NOMEM;
    return 0;
  }
  size_t want = (w->bit + bits + 7) / 8;
  if (want > w->cap) {
    size_t cap = MAX2(want, w->cap < 128 ? 128 : w->cap + w->cap / 2);
    uint8_t *p = (uint8_t *)realloc(w->p, cap);
    if (!p) {
      w->err = PC_NOMEM;
      return 0;
    }
    memset(p + w->cap, 0, cap - w->cap);
    w->p = p;
    w->cap = cap;
  }
  return 1;
}
static void put(Writer *w, uint64_t x, unsigned b) {
  if (!b || !reserve(w, b + 64))
    return;
  x &= mask64(b);
#if defined(__BYTE_ORDER__) && __BYTE_ORDER__ == __ORDER_LITTLE_ENDIAN__
  if (b <= 56) {
    size_t byte = w->bit >> 3;
    uint64_t packed;
    memcpy(&packed, w->p + byte, 8);
    packed |= x << (w->bit & 7);
    memcpy(w->p + byte, &packed, 8);
    w->bit += b;
    return;
  }
#endif
  while (b) {
    unsigned off = w->bit & 7, k = MIN2(b, 8 - off);
    w->p[w->bit >> 3] |= (uint8_t)((x & mask64(k)) << off);
    x >>= k;
    w->bit += k;
    b -= k;
  }
}
static void walign(Writer *w) {
  put(w, 0, (unsigned)((8 - (w->bit & 7)) & 7));
}
static uint64_t get(Reader *r, unsigned b) {
  if (r->err)
    return 0;
  if (b > 64 || r->bit > r->size * 8 || b > r->size * 8 - r->bit) {
    r->err = PC_TRUNCATED;
    return 0;
  }
#if defined(__BYTE_ORDER__) && __BYTE_ORDER__ == __ORDER_LITTLE_ENDIAN__
  if (b <= 56 && r->size - (r->bit >> 3) >= 8) {
    uint64_t packed;
    memcpy(&packed, r->p + (r->bit >> 3), 8);
    uint64_t res = (packed >> (r->bit & 7)) & mask64(b);
    r->bit += b;
    return res;
  }
#endif
  uint64_t x = 0;
  unsigned shift = 0;
  while (b) {
    unsigned off = r->bit & 7, k = MIN2(b, 8 - off);
    x |= ((uint64_t)(r->p[r->bit >> 3] >> off) & mask64(k)) << shift;
    shift += k;
    r->bit += k;
    b -= k;
  }
  return x;
}
static void ralign(Reader *r) {
  if (get(r, (unsigned)((8 - (r->bit & 7)) & 7)))
    r->err = PC_CORRUPT;
}
size_t pc_type_size(int t) {
  switch (t) {
  case 1:
  case 3:
  case 5:
    return 4;
  case 2:
  case 4:
  case 6:
    return 8;
  case 7:
  case 8:
  case 9:
    return 2;
  case 10:
  case 11:
    return 1;
  default:
    return 0;
  }
}
static int isfloat(int t) {
  return t == 5 || t == 6;
}
static int issigned(int t) {
  return t == 3 || t == 4 || t == 8 || t == 11;
}
static uint64_t loadraw(const void *p, size_t i, unsigned b) {
#if defined(__BYTE_ORDER__) && __BYTE_ORDER__ == __ORDER_LITTLE_ENDIAN__
  switch (b) {
  case 64: {
    uint64_t x;
    memcpy(&x, (const uint8_t *)p + i * 8, 8);
    return x;
  }
  case 32: {
    uint32_t x;
    memcpy(&x, (const uint8_t *)p + i * 4, 4);
    return x;
  }
  case 16: {
    uint16_t x;
    memcpy(&x, (const uint8_t *)p + i * 2, 2);
    return x;
  }
  case 8:
    return ((const uint8_t *)p)[i];
  }
#endif
  const uint8_t *q = (const uint8_t *)p + i * (b / 8);
  uint64_t x = 0;
  for (unsigned k = 0; k < b / 8; k++)
    x |= (uint64_t)q[k] << (8 * k);
  return x;
}
static void storeraw(void *p, size_t i, unsigned b, uint64_t x) {
#if defined(__BYTE_ORDER__) && __BYTE_ORDER__ == __ORDER_LITTLE_ENDIAN__
  switch (b) {
  case 64:
    memcpy((uint8_t *)p + i * 8, &x, 8);
    return;
  case 32: {
    uint32_t y = (uint32_t)x;
    memcpy((uint8_t *)p + i * 4, &y, 4);
    return;
  }
  case 16: {
    uint16_t y = (uint16_t)x;
    memcpy((uint8_t *)p + i * 2, &y, 2);
    return;
  }
  case 8:
    ((uint8_t *)p)[i] = (uint8_t)x;
    return;
  }
#endif
  uint8_t *q = (uint8_t *)p + i * (b / 8);
  for (unsigned k = 0; k < b / 8; k++)
    q[k] = (uint8_t)(x >> (8 * k));
}
static uint64_t ordered(uint64_t x, unsigned b) {
  uint64_t mid = UINT64_C(1) << (b - 1);
  return (x ^ ((x & mid) ? mask64(b) : mid)) & mask64(b);
}
static uint64_t unorder(uint64_t x, unsigned b) {
  uint64_t mid = UINT64_C(1) << (b - 1);
  return (x ^ ((x & mid) ? mid : mask64(b))) & mask64(b);
}
static double asfloat(uint64_t x, unsigned b) {
  if (b == 32) {
    uint32_t u = (uint32_t)x;
    float f;
    memcpy(&f, &u, 4);
    return f;
  }
  double d;
  memcpy(&d, &x, 8);
  return d;
}
static uint64_t asbits(double d, unsigned b) {
  if (b == 32) {
    float f = (float)d;
    uint32_t u;
    memcpy(&u, &f, 4);
    return u;
  }
  uint64_t u;
  memcpy(&u, &d, 8);
  return u;
}
static double narrow(double d, unsigned b) {
  return b == 32 ? (double)(float)d : d;
}
static uint64_t intfloat_encode(double x, unsigned b) {
  uint64_t mid = UINT64_C(1) << (b - 1), gpi = UINT64_C(1) << (b == 32 ? 24 : 53);
  double a = fabs(x);
  uint64_t ai;
  if (a < (double)gpi)
    ai = (uint64_t)(int64_t)a;
  else
    ai = gpi + (asbits(a, b) - asbits((double)gpi, b));
  return (signbit(x) ? mid - 1 - ai : mid + ai) & mask64(b);
}
static double intfloat_decode(uint64_t x, unsigned b) {
  uint64_t mid = UINT64_C(1) << (b - 1), gpi = UINT64_C(1) << (b == 32 ? 24 : 53);
  uint64_t raw = unorder(x, b), a = raw & (mid - 1), sign = raw & mid;
  /* Small magnitudes fit int64_t, avoiding the general uint64-to-float
     conversion while retaining negative zero through the sign bit. */
  raw = a < gpi ? asbits((double)(int64_t)a, b) : a + asbits((double)gpi, b) - gpi;
  return asfloat(raw | sign, b);
}

typedef struct {
  uint64_t lo, hi;
  uint32_t count, weight;
  unsigned ob;
} Bin;
typedef struct {
  uint16_t next;
  uint8_t nb, ob;
} Node;
typedef struct {
  unsigned b, log, nb, order, max_ob;
  size_t n, state_n;
  Bin *bins;
  uint64_t *v, *state;
  uint32_t final[4];
  uint16_t *syms, *av;
  uint8_t *ab;
  Node *nodes;
  uint64_t *lowers;
  void *history;
  size_t history_window, history_pos;
} Var;
static void var_free(Var *v) {
  free(v->bins);
  free(v->v);
  free(v->state);
  free(v->syms);
  free(v->av);
  free(v->ab);
  free(v->nodes);
  free(v->history);
  memset(v, 0, sizeof(*v));
}
/* One reusable training arena per compression call. Each region is aligned
 * for its element type; no process-global caches or externally prepared models. */
typedef struct {
  void *allocation;
  uint64_t *sorted;
  Bin *hist;
  float *best, *weights;
  uint32_t *counts;
  unsigned *prev;
} TrainWorkspace;
static int workspace_init(TrainWorkspace *ws, size_t n, unsigned hlog) {
  size_t h = (size_t)1 << hlog;
  if (n > (SIZE_MAX - h * (sizeof(Bin) + 4 * sizeof(uint32_t)) - 8) / 8)
    return PC_NOMEM;
  size_t size = n * 8 + h * sizeof(Bin) + (h + 1) * 2 * sizeof(uint32_t) + h * 2 * sizeof(uint32_t);
  uint8_t *p = (uint8_t *)malloc(size);
  if (!p)
    return PC_NOMEM;
  ws->allocation = p;
  ws->sorted = (uint64_t *)p;
  p += n * 8;
  ws->hist = (Bin *)p;
  p += h * sizeof(Bin);
  ws->best = (float *)p;
  p += (h + 1) * sizeof(float);
  ws->counts = (uint32_t *)p;
  p += (h + 1) * 4;
  ws->prev = (unsigned *)p;
  p += h * sizeof(unsigned);
  ws->weights = (float *)p;
  return 0;
}
static int cmpu64(const void *a, const void *b) {
  uint64_t x = *(const uint64_t *)a, y = *(const uint64_t *)b;
  return x > y ? 1 : x < y ? -1 : 0;
}
static float log_approx(float x) {
  const float z = 0.674f, B = 2.0f / z, C = -B / (6.0f * z), A = -B - C;
  uint32_t u, zu;
  memcpy(&u, &x, 4);
  memcpy(&zu, &z, 4);
  uint32_t s = u & 0x7fffff, high = s > (zu & 0x7fffff);
  int li = (int)(u >> 23) + (int)high - 127;
  u = ((0x7fu ^ high) << 23) | s;
  memcpy(&x, &u, 4);
  return (float)li + A + x * (B + C * x);
}
static float bin_cost(uint64_t lo, uint64_t hi, uint32_t count, float total, unsigned meta) {
  return (float)meta + (total - log_approx((float)count) + (float)bits64(hi - lo)) * (float)count;
}
/* Exact sorted analogue of upstream histogram builder. Uses full sorting
 * rather than upstream's partial quicksort. Constant runs never split. */
/* Partition only at histogram quantiles. Interiors need their extrema,
   not an ordering; each equal pivot run is kept whole, exactly as in the
   full-sort histogram. Thus bin bounds/counts and all encoder choices match. */
static void histogram_partition(uint64_t *x, size_t n, size_t origin, size_t total, unsigned log,
                                unsigned depth) {
  if (n <= 1)
    return;
  size_t target = (origin << log) / total;
  size_t boundary = (((target + 1) * total + ((size_t)1 << log) - 1) >> log) - 1;
  if (target + 1 == ((size_t)1 << log) || boundary >= origin + n) {
    size_t imin = 0, imax = 0;
    for (size_t i = 1; i < n; i++) {
      if (x[i] < x[imin])
        imin = i;
      if (x[i] > x[imax])
        imax = i;
    }
    uint64_t tmp = x[0];
    x[0] = x[imin];
    x[imin] = tmp;
    if (imax == 0)
      imax = imin;
    tmp = x[n - 1];
    x[n - 1] = x[imax];
    x[imax] = tmp;
    return;
  }
  if (n < 16) {
    for (size_t i = 1; i < n; i++) {
      uint64_t value = x[i];
      size_t j = i;
      while (j && x[j - 1] > value) {
        x[j] = x[j - 1];
        j--;
      }
      x[j] = value;
    }
    return;
  }
  if (!depth) {
    qsort(x, n, 8, cmpu64);
    return;
  }
  uint64_t a = x[n / 4], b = x[n / 2], c = x[(n * 3) / 4];
  uint64_t pivot = a < b ? (b < c ? b : MAX2(a, c)) : (a < c ? a : MAX2(b, c));
  size_t left = 0;
  for (size_t i = 0; i < n; i++) {
    uint64_t value = x[i];
    int lt = value < pivot;
    x[i] = x[left];
    x[left] = value;
    left += (size_t)lt;
  }
  size_t right = left;
  for (size_t i = left; i < n; i++) {
    uint64_t value = x[i];
    int eq = value == pivot;
    x[i] = x[right];
    x[right] = value;
    right += (size_t)eq;
  }
  histogram_partition(x, left, origin, total, log, depth - 1);
  histogram_partition(x + right, n - right, origin + right, total, log, depth - 1);
}
static unsigned histogram(uint64_t *x, size_t n, unsigned hlog, Bin *h) {
  size_t pos = 0;
  unsigned nb = 0, next = 0;
  int active = 0;
  Bin cur = {0, 0, 0, 0, 0};
  size_t target_bins = (size_t)1 << hlog;
  while (pos < n) {
    size_t target = (pos * target_bins) / n;
    size_t end = ((target + 1) * n + target_bins - 1) / target_bins;
    if (end >= n) {
      if (!active) {
        cur.lo = x[pos];
        cur.count = 0;
        active = 1;
      }
      cur.hi = x[n - 1];
      cur.count += (uint32_t)(n - pos);
      h[nb++] = cur;
      break;
    }
    size_t l = end - 1, r = end;
    uint64_t value = x[l];
    while (l > pos && x[l - 1] == value)
      --l;
    while (r < n && x[r] == value)
      ++r;
    if (l > pos) {
      if (!active) {
        cur.lo = x[pos];
        cur.count = 0;
        active = 1;
      }
      cur.hi = x[l - 1];
      cur.count += (uint32_t)(l - pos);
    }
    size_t mid = l + (r - l) / 2;
    unsigned idx = (unsigned)(mid * target_bins / n);
    if (idx > next) {
      unsigned spare = idx - 1;
      if (active) {
        h[nb++] = cur;
        active = 0;
        next = spare + 1;
      } else
        idx = spare;
    }
    if (!active) {
      cur.lo = value;
      cur.count = 0;
      active = 1;
    }
    cur.hi = value;
    cur.count += (uint32_t)(r - l);
    if (r >= ((size_t)(idx + 1) * n + target_bins - 1) / target_bins) {
      h[nb++] = cur;
      active = 0;
      next = idx + 1;
    }
    pos = r;
  }
  return nb;
}
static int quantize(Var *v, size_t total, unsigned maxlog, TrainWorkspace *ws) {
  if (v->nb <= 1) {
    v->log = 0;
    if (v->nb)
      v->bins[0].weight = 1;
    return 0;
  }
  unsigned log = MAX2(ceil_log(v->nb), maxlog);
  uint32_t sum = 1u << log;
  float *fw = ws->weights;
  float desired = 0, mult = (float)sum / (float)total;
  for (unsigned i = 0; i < v->nb; i++) {
    fw[i] = fmaxf((float)v->bins[i].count * mult - 1, 0);
    desired += fw[i];
  }
  float sm = desired == 0 ? 0 : (float)(sum - v->nb) / desired;
  uint32_t got = 0;
  for (unsigned i = 0; i < v->nb; i++) {
    fw[i] = 1 + fw[i] * sm;
    v->bins[i].weight = (uint32_t)roundf(fw[i]);
    got += v->bins[i].weight;
  }
  for (unsigned i = 0; got > sum && i < v->nb; i++)
    if (v->bins[i].weight > 1 && (float)v->bins[i].weight > fw[i]) {
      v->bins[i].weight--;
      got--;
    }
  for (unsigned i = 0; got < sum && i < v->nb; i++)
    if ((float)v->bins[i].weight < fw[i]) {
      v->bins[i].weight++;
      got++;
    }
  if (got != sum)
    return PC_CORRUPT;
  unsigned power = 32;
  for (unsigned i = 0; i < v->nb; i++)
    power = MIN2(power, (unsigned)__builtin_ctz(v->bins[i].weight));
  v->log = log - power;
  for (unsigned i = 0; i < v->nb; i++)
    v->bins[i].weight >>= power;
  return 0;
}
static int train(Var *v, unsigned hlog, TrainWorkspace *ws) {
  if (!v->n) {
    v->log = 0;
    v->nb = 0;
    return 0;
  }
  Bin *h = ws->hist;
  uint64_t *sorted = ws->sorted;
  memcpy(sorted, v->v, v->n * 8);
  histogram_partition(sorted, v->n, 0, v->n, hlog, 2 * ceil_log(v->n) + 1);
  unsigned nh = histogram(sorted, v->n, hlog, h);
  unsigned est = MIN2(MIN2(hlog + 2, 12), ceil_log(v->n));
  unsigned meta = est + v->b + bits64(v->b);
  float tl = log_approx((float)v->n);
  float *best = ws->best;
  uint32_t *cs = ws->counts;
  unsigned *prev = ws->prev;
  best[0] = 0;
  cs[0] = 0;
  for (unsigned i = 0; i < nh; i++)
    cs[i + 1] = cs[i] + h[i].count;
  for (unsigned i = 0; i < nh; i++) {
    float bc = INFINITY;
    unsigned bj = 0;
    for (unsigned jj = i + 1; jj > 0; jj--) {
      unsigned j = jj - 1;
      float cost = best[j] + bin_cost(h[j].lo, h[i].hi, cs[i + 1] - cs[j], tl, meta);
      if (cost < bc) {
        bc = cost;
        bj = j;
      }
    }
    best[i + 1] = bc;
    prev[i] = bj;
  }
  v->bins = (Bin *)malloc(nh * sizeof(Bin));
  if (!v->bins)
    return PC_NOMEM;
  float single = bin_cost(h[0].lo, h[nh - 1].hi, (uint32_t)v->n, tl, meta);
  int trivial = 1;
  float tc = 0;
  for (unsigned i = 0; i < nh; i++) {
    if (h[i].lo != h[i].hi)
      trivial = 0;
    tc += bin_cost(h[i].lo, h[i].hi, h[i].count, tl, meta);
  }
  if (single < best[nh] + 0.1f * (float)v->n) {
    v->nb = 1;
    v->bins[0] = h[0];
    v->bins[0].hi = h[nh - 1].hi;
    v->bins[0].count = (uint32_t)v->n;
  } else if (trivial && tc < best[nh] + 0.1f * (float)v->n) {
    v->nb = nh;
    memcpy(v->bins, h, nh * sizeof(Bin));
  } else {
    unsigned end = nh;
    v->nb = 0;
    while (end) {
      unsigned j = prev[end - 1];
      Bin bin = h[j];
      bin.hi = h[end - 1].hi;
      bin.count = cs[end] - cs[j];
      v->bins[v->nb++] = bin;
      end = j;
    }
    for (unsigned i = 0; i < v->nb / 2; i++) {
      Bin t = v->bins[i];
      v->bins[i] = v->bins[v->nb - 1 - i];
      v->bins[v->nb - 1 - i] = t;
    }
  }
  for (unsigned i = 0; i < v->nb; i++)
    v->bins[i].ob = bits64(v->bins[i].hi - v->bins[i].lo);
  return quantize(v, v->n, est, ws);
}
/* Search each balanced-tree level across independent values; padding makes
   the depth fixed, and AVX2 gather removes per-value branch dependencies. */
static void find_symbols(Var *v) {
  unsigned log = ceil_log(v->nb), count = 1u << log;
  uint64_t lower[MAX_BINS];
  for (unsigned i = 0; i < v->nb; i++)
    lower[i] = v->bins[i].lo;
  for (unsigned i = v->nb; i < count; i++)
    lower[i] = UINT64_MAX;
  for (size_t start = 0; start < v->n; start += 256) {
    size_t end = MIN2(start + 256, v->n), n = end - start;
    uint64_t indices[256] = {0};
    for (unsigned step = count / 2; step; step >>= 1) {
      for (size_t i = 0; i < n; i++) {
        size_t candidate = (size_t)indices[i] + step;
        indices[i] += (uint64_t)(v->v[start + i] >= lower[candidate]) * step;
      }
    }
    for (size_t i = 0; i < n; i++)
      v->syms[start + i] = (uint16_t)MIN2(indices[i], v->nb - 1);
  }
}
static int build_nodes(Var *v) {
  unsigned table = 1u << v->log, stride = (3 * table) / 5;
  if (!(stride & 1))
    stride++;
  if (v->nb <= 1)
    return v->nb == 0 && v->log != 0 ? PC_CORRUPT : PC_OK;
  v->nodes = (Node *)malloc(table * (sizeof(Node) + sizeof(uint64_t)));
  v->lowers = v->nodes ? (uint64_t *)(v->nodes + table) : NULL;
  if (!v->nodes)
    return PC_NOMEM;
  unsigned step = 0, total = 0;
  for (unsigned s = 0; s < v->nb; s++)
    total += v->bins[s].weight;
  if (total != table && !(v->nb == 0 && v->log == 0))
    return PC_CORRUPT;
  for (unsigned s = 0; s < v->nb; s++)
    for (unsigned k = 0; k < v->bins[s].weight; k++) {
      unsigned idx = (stride * step++) & (table - 1);
      v->lowers[idx] = v->bins[s].lo;
      v->nodes[idx].ob = (uint8_t)v->bins[s].ob;
      v->nodes[idx].next = (uint16_t)s;
    }
  unsigned xs[MAX_BINS];
  for (unsigned i = 0; i < v->nb; i++)
    xs[i] = v->bins[i].weight;
  for (unsigned i = 0; i < table; i++) {
    unsigned s = v->nodes[i].next;
    unsigned x = v->nb ? xs[s]++ : 1;
    unsigned nb = v->log - (bits64(x) - 1);
    v->nodes[i].next = (uint16_t)((x << nb) - table);
    v->nodes[i].nb = (uint8_t)nb;
  }
  return 0;
}
static int dissect(Var *v) {
  for (unsigned i = 0; i < v->nb; i++)
    v->max_ob = MAX2(v->max_ob, v->bins[i].ob);
  for (unsigned j = 0; j < 4; j++)
    v->final[j] = 1u << v->log;
  if (!v->n || v->nb == 1)
    return 0;
  v->syms = (uint16_t *)malloc(v->n * 2);
  v->av = (uint16_t *)malloc(v->n * 2);
  v->ab = (uint8_t *)malloc(v->n);
  if (!v->syms || !v->av || !v->ab)
    return PC_NOMEM;
  find_symbols(v);
  if (!v->log)
    return 0;
  unsigned table = 1u << v->log;
  uint32_t *next = (uint32_t *)malloc(table * 4);
  if (!next)
    return PC_NOMEM;
  unsigned starts[MAX_BINS], pos[MAX_BINS], minbits[MAX_BINS], cut[MAX_BINS], off = 0;
  for (unsigned i = 0; i < v->nb; i++) {
    unsigned w = v->bins[i].weight;
    starts[i] = pos[i] = off;
    off += w;
    minbits[i] = v->log - (bits64(2 * w - 1) - 1);
    cut[i] = 2 * w * (1u << minbits[i]);
  }
  unsigned step = 0, stride = (3 * table) / 5;
  if (!(stride & 1))
    stride++;
  uint16_t *symbols = (uint16_t *)malloc(table * 2);
  if (!symbols) {
    free(next);
    return PC_NOMEM;
  }
  for (unsigned s = 0; s < v->nb; s++)
    for (unsigned k = 0; k < v->bins[s].weight; k++)
      symbols[(stride * step++) & (table - 1)] = (uint16_t)s;
  for (unsigned i = 0; i < table; i++)
    next[pos[symbols[i]]++] = table + i;
  free(symbols);
  size_t ii = v->n;
  uint32_t state0 = v->final[0], state1 = v->final[1], state2 = v->final[2], state3 = v->final[3];
  while (ii & 3) {
    size_t i = --ii;
    unsigned j = (unsigned)(i & 3), symbol = v->syms[i], state = v->final[j];
    unsigned nb = minbits[symbol] + (state >= cut[symbol]);
    v->ab[i] = (uint8_t)nb;
    v->av[i] = (uint16_t)(state & mask64(nb));
    v->final[j] = next[starts[symbol] + (state >> nb) - v->bins[symbol].weight];
  }
  state0 = v->final[0];
  state1 = v->final[1];
  state2 = v->final[2];
  state3 = v->final[3];
  while (ii) {
    ii -= 4;
#define PC_ENCODE_LANE(lane, state)                                                                \
  do {                                                                                             \
    size_t i = ii + lane;                                                                          \
    unsigned symbol = v->syms[i];                                                                  \
    unsigned nb = minbits[symbol] + (state >= cut[symbol]);                                        \
    v->ab[i] = (uint8_t)nb;                                                                        \
    v->av[i] = (uint16_t)(state & mask64(nb));                                                     \
    state = next[starts[symbol] + (state >> nb) - v->bins[symbol].weight];                         \
  } while (0)
    PC_ENCODE_LANE(0, state0);
    PC_ENCODE_LANE(1, state1);
    PC_ENCODE_LANE(2, state2);
    PC_ENCODE_LANE(3, state3);
#undef PC_ENCODE_LANE
  }
  v->final[0] = state0;
  v->final[1] = state1;
  v->final[2] = state2;
  v->final[3] = state3;
  free(next);
  return 0;
}
static void write_varmeta(Writer *w, Var *v) {
  put(w, v->log, 4);
  put(w, v->nb, 15);
  for (unsigned i = 0; i < v->nb; i++) {
    put(w, v->bins[i].weight - 1, v->log);
    put(w, v->bins[i].lo, v->b);
    put(w, v->bins[i].ob, bits64(v->b));
  }
}
/* Capacity and zeroed overshoot bytes are established once per batch. */
static void put_payload(Writer *w, uint64_t x, unsigned b) {
  if (!b)
    return;
  x &= mask64(b);
#if defined(__BYTE_ORDER__) && __BYTE_ORDER__ == __ORDER_LITTLE_ENDIAN__
  size_t byte = w->bit >> 3;
  unsigned off = (unsigned)(w->bit & 7);
  uint64_t packed;
  memcpy(&packed, w->p + byte, 8);
  packed |= x << off;
  memcpy(w->p + byte, &packed, 8);
  if (b + off > 64)
    w->p[byte + 8] |= (uint8_t)(x >> (64 - off));
  w->bit += b;
#else
  put(w, x, b);
#endif
}
static void write_batch(Writer *w, Var *v, size_t start) {
  size_t end = MIN2(start + 256, v->n);
  if (start >= end)
    return;
  if (v->nb == 1 && !v->bins[0].ob)
    return;
  if (!reserve(w, (end - start) * (v->b + v->log) + 64))
    return;
  if (v->nb == 1) {
    const Bin *bin = &v->bins[0];
    for (size_t i = start; i < end; i++)
      put_payload(w, v->v[i] - bin->lo, bin->ob);
    return;
  }
  size_t i = start;
  /* Four ANS emissions have at most 4*14 bits and share one word write. */
  for (; i + 4 <= end; i += 4) {
    unsigned b0 = v->ab[i], b1 = v->ab[i + 1], b2 = v->ab[i + 2], b3 = v->ab[i + 3];
    uint64_t packed = v->av[i] | ((uint64_t)v->av[i + 1] << b0) |
                      ((uint64_t)v->av[i + 2] << (b0 + b1)) |
                      ((uint64_t)v->av[i + 3] << (b0 + b1 + b2));
    put_payload(w, packed, b0 + b1 + b2 + b3);
  }
  for (; i < end; i++)
    put_payload(w, v->av[i], v->ab[i]);
  i = start;
  if (!v->max_ob)
    return;
  if (v->max_ob <= 14) {
    for (; i + 4 <= end; i += 4) {
      const Bin *b0 = &v->bins[v->syms[i]], *b1 = &v->bins[v->syms[i + 1]],
                *b2 = &v->bins[v->syms[i + 2]], *b3 = &v->bins[v->syms[i + 3]];
      uint64_t packed = (v->v[i] - b0->lo) | ((v->v[i + 1] - b1->lo) << b0->ob) |
                        ((v->v[i + 2] - b2->lo) << (b0->ob + b1->ob)) |
                        ((v->v[i + 3] - b3->lo) << (b0->ob + b1->ob + b2->ob));
      put_payload(w, packed, b0->ob + b1->ob + b2->ob + b3->ob);
    }
  } else if (v->max_ob <= 28) {
    for (; i + 2 <= end; i += 2) {
      const Bin *b0 = &v->bins[v->syms[i]], *b1 = &v->bins[v->syms[i + 1]];
      uint64_t packed = (v->v[i] - b0->lo) | ((v->v[i + 1] - b1->lo) << b0->ob);
      put_payload(w, packed, b0->ob + b1->ob);
    }
  }
  for (; i < end; i++) {
    const Bin *bin = &v->bins[v->syms[i]];
    put_payload(w, v->v[i] - bin->lo, bin->ob);
  }
}
static int read_varmeta(Reader *r, Var *v, unsigned b) {
  v->b = b;
  v->log = (unsigned)get(r, 4);
  v->nb = (unsigned)get(r, 15);
  if (v->log > 14 || v->nb > MAX_BINS || (1u << v->log) < v->nb || (v->nb == 1 && v->log))
    return PC_CORRUPT;
  v->bins = (Bin *)calloc(MAX2(v->nb, 1), sizeof(Bin));
  if (!v->bins)
    return PC_NOMEM;
  for (unsigned i = 0; i < v->nb; i++) {
    v->bins[i].weight = (uint32_t)get(r, v->log) + 1;
    v->bins[i].lo = get(r, b);
    v->bins[i].ob = (unsigned)get(r, bits64(b));
    v->max_ob = MAX2(v->max_ob, v->bins[i].ob);
    if (v->bins[i].ob > b)
      return PC_CORRUPT;
  }
  return r->err ? r->err : build_nodes(v);
}
#if defined(__AVX2__)
static inline void store_four_u32(uint32_t *p, __m256i x) {
  __m256i perm = _mm256_permutevar8x32_epi32(x, _mm256_setr_epi32(0, 2, 4, 6, 0, 0, 0, 0));
  _mm_storeu_si128((__m128i *)p, _mm256_castsi256_si128(perm));
}
#endif
#define PC_BATCH_NAME read_batch
#define PC_BATCH_WORD uint64_t
#define PC_BATCH_STORE(p, x) _mm256_storeu_si256((__m256i *)(p), (x))
#define PC_BATCH_LOAD(p) _mm256_loadu_si256((const __m256i *)(p))
#include "decode_batch.inc"
#undef PC_BATCH_NAME
#undef PC_BATCH_WORD
#undef PC_BATCH_STORE
#undef PC_BATCH_LOAD
#define PC_BATCH_NAME read_batch32
#define PC_BATCH_WORD uint32_t
#define PC_BATCH_STORE(p, x) store_four_u32((p), (x))
#define PC_BATCH_LOAD(p) _mm256_cvtepu32_epi64(_mm_loadu_si128((const __m128i *)(p)))
#include "decode_batch.inc"
#undef PC_BATCH_NAME
#undef PC_BATCH_WORD
#undef PC_BATCH_STORE
#undef PC_BATCH_LOAD
static int alloc_var(Var *v, size_t n, unsigned b) {
  v->b = b;
  v->n = n;
  v->v = (uint64_t *)malloc(MAX2(n, 1) * 8);
  return v->v ? 0 : PC_NOMEM;
}
static int consecutive(Var *v, unsigned order) {
  v->order = order;
  v->state_n = order;
  if (!order)
    return 0;
  v->state = (uint64_t *)calloc(MAX2(order, 1), 8);
  if (!v->state)
    return PC_NOMEM;
  size_t n = v->n;
  uint64_t mask = mask64(v->b), mid = UINT64_C(1) << (v->b - 1);
  for (unsigned j = 0; j < order; j++) {
    v->state[j] = j < n ? v->v[j] : 0;
    for (size_t i = n; i > (size_t)j + 1; i--)
      v->v[i - 1] = (v->v[i - 1] - v->v[i - 2]) & mask;
  }
  size_t offset = MIN2(n, order);
  v->n = n - offset;
  memmove(v->v, v->v + offset, v->n * 8);
  if (order)
    for (size_t i = 0; i < v->n; i++)
      v->v[i] ^= mid;
  return 0;
}
/* Native lookback predictor: 16 recent values plus exact/coarse hashed last
 * occurrences, score balances small residuals and frequent distances. */
static int lookback(Var *p, Var *d, unsigned window_log) {
  size_t n = p->n, wn = (size_t)1 << window_log;
  int e = alloc_var(d, n ? n - 1 : 0, 32);
  if (e)
    return e;
  p->state_n = 1;
  p->state = (uint64_t *)calloc(1, 8);
  if (!p->state)
    return PC_NOMEM;
  if (n)
    p->state[0] = p->v[0];
  uint32_t counts[4096];
  uint8_t goodness[4096];
  /* Chunk length is capped at 2^24, so 32-bit history positions suffice. */
  uint32_t last[8192];
  memset(last, 0, sizeof(last));
  for (size_t k = 0; k < wn; k++) {
    counts[k] = 1;
    goodness[k] = 1;
  }
  uint64_t mask = mask64(p->b), mid = UINT64_C(1) << (p->b - 1);
  unsigned max_goodness = 1;
  for (size_t i = 1; i < n; i++) {
    uint64_t x = p->v[i], bestdelta = UINT64_MAX;
    unsigned best = 1, bestscore = 0;
    unsigned recent = (unsigned)MIN2(i, 16);
    uint64_t h = (x ^ (x >> 32)) * UINT64_C(11400714819323197441);
    unsigned ha = (unsigned)(h >> 32) & 4095;
    uint64_t y = x >> 8;
    h = (y ^ (y >> 32)) * UINT64_C(11400714819323197441);
    unsigned hb = (unsigned)(h >> 32) & 4095;
    size_t a_lag = i - last[ha], b_lag = i - last[4096 + hb];
    last[ha] = (uint32_t)i;
    last[4096 + hb] = (uint32_t)i;
#define PC_SCORE_LAG(lag)                                                                          \
  do {                                                                                             \
    size_t distance = (lag);                                                                       \
    uint64_t a = (x - p->v[i - distance]) & mask, b = (UINT64_C(0) - a) & mask;                    \
    uint64_t delta = MIN2(a, b);                                                                   \
    unsigned score = p->b - bits64(delta) + goodness[distance - 1];                                \
    int better = score > bestscore || (score == bestscore && delta < bestdelta);                   \
    best = better ? (unsigned)distance : best;                                                     \
    bestscore = better ? score : bestscore;                                                        \
    bestdelta = better ? delta : bestdelta;                                                        \
  } while (0)
    for (unsigned lb = 1; lb <= recent; lb++) {
      PC_SCORE_LAG(lb);
      if (bestscore == p->b + max_goodness)
        break;
    }
    if (bestscore < p->b + max_goodness) {
      if (a_lag > recent && a_lag <= wn)
        PC_SCORE_LAG(a_lag);
      if (b_lag > recent && b_lag <= wn && b_lag != a_lag)
        PC_SCORE_LAG(b_lag);
    }
#undef PC_SCORE_LAG
    d->v[i - 1] = best;
    uint32_t count = ++counts[best - 1];
    if (!(count & (count - 1))) {
      goodness[best - 1]++;
      max_goodness = MAX2(max_goodness, goodness[best - 1]);
    }
  }
  for (size_t i = n; i > 1; i--)
    p->v[i - 1] = ((p->v[i - 1] - p->v[i - 1 - d->v[i - 2]]) & mask) ^ mid;
  p->n = n ? n - 1 : 0;
  memmove(p->v, p->v + (n ? 1 : 0), p->n * 8);
  return 0;
}
static void undo_delta(Var *v, size_t n, int delta, const Var *d) {
  uint64_t mask = mask64(v->b), mid = UINT64_C(1) << (v->b - 1);
  if (delta == 8) {
    size_t real = MIN2(n, v->state_n);
    memmove(v->v + real, v->v, v->n * 8);
    memcpy(v->v, v->state + v->state_n - real, real * 8);
    for (size_t i = real; i < n; i++)
      v->v[i] = ((v->v[i] ^ mid) + v->v[i - (size_t)d->v[i - real]]) & mask;
  } else if (delta) {
    for (size_t i = 0; i < v->n; i++)
      v->v[i] ^= mid;
    for (size_t j = v->state_n; j > 0; j--) {
      uint64_t moment = v->state[j - 1];
      for (size_t i = 0; i < n; i++) {
        uint64_t tmp = v->v[i];
        v->v[i] = moment;
        moment = (moment + tmp) & mask;
      }
    }
  }
}
/* Restore one cache-resident batch and carry finite-difference moments. */
static void undo_consecutive_batch(Var *v, size_t n) {
  uint64_t mask = mask64(v->b), mid = UINT64_C(1) << (v->b - 1);
  for (size_t i = 0; i < n; i++)
    v->v[i] ^= mid;
  for (size_t j = v->state_n; j > 0; j--) {
    uint64_t moment = v->state[j - 1];
    for (size_t i = 0; i < n; i++) {
      uint64_t tmp = v->v[i];
      v->v[i] = moment;
      moment = (moment + tmp) & mask;
    }
    v->state[j - 1] = moment;
  }
}
static void undo_consecutive_batch32(Var *v, size_t n) {
  uint32_t *values = (uint32_t *)v->v;
  uint64_t mask = mask64(v->b), mid = UINT64_C(1) << (v->b - 1);
  for (size_t i = 0; i < n; i++)
    values[i] ^= mid;
  for (size_t j = v->state_n; j > 0; j--) {
    uint64_t moment = v->state[j - 1];
    for (size_t i = 0; i < n; i++) {
      uint64_t tmp = values[i];
      values[i] = moment;
      moment = (moment + tmp) & mask;
    }
    v->state[j - 1] = moment;
  }
}
/* Delayed output is the saved prefix plus the reconstructed residuals.
   A double window avoids a modulo operation on each dependent history load. */
#define PC_LOOKBACK_BATCH(NAME, WORD)                                                              \
  static int NAME(Var *v, const uint32_t *lags, size_t start, size_t count, size_t residuals,      \
                  size_t maxlag) {                                                                 \
    WORD *history = (WORD *)v->history, *values = (WORD *)v->v;                                    \
    size_t window = v->history_window, pos = v->history_pos;                                       \
    if (pos + count > 2 * MAX2(window, 256)) {                                                     \
      memmove(history, history + pos - window, window * sizeof(WORD));                             \
      pos = window;                                                                                \
    }                                                                                              \
    const WORD mid = (WORD)((uint64_t)1 << (v->b - 1));                                            \
    for (size_t i = 0; i < residuals; i++) {                                                       \
      size_t lag = lags[i];                                                                        \
      if (!lag || lag > maxlag || lag > start + i + v->state_n)                                    \
        return PC_CORRUPT;                                                                         \
      history[pos + i] = (WORD)(((values[i] ^ mid) + history[pos + i - lag]) & mask64(v->b));                       \
    }                                                                                              \
    memcpy(values, history + pos - v->state_n, count * sizeof(WORD));                              \
    v->history_pos = pos + count;                                                                  \
    return PC_OK;                                                                                  \
  }
PC_LOOKBACK_BATCH(undo_lookback_batch32, uint32_t)
PC_LOOKBACK_BATCH(undo_lookback_batch64, uint64_t)
#undef PC_LOOKBACK_BATCH
static int split(const void *src, size_t n, int t, int mode, int k, double base, uint64_t int_base, Var *p, Var *s) {
  unsigned b = (unsigned)pc_type_size(t) * 8;
  int e = alloc_var(p, n, b);
  if (e)
    return e;
  if (mode) {
    e = alloc_var(s, n, b);
    if (e)
      return e;
  }
  uint64_t mid = UINT64_C(1) << (b - 1), mask = mask64(b);
  double inv = narrow(1 / base, b);
  for (size_t i = 0; i < n; i++) {
    uint64_t raw = loadraw(src, i, b), ord = isfloat(t)    ? ordered(raw, b)
                                             : issigned(t) ? raw ^ mid
                                                           : raw;
    if (mode == 0)
      p->v[i] = ord;
    else if (mode == 1) {
      p->v[i] = ord / int_base;
      s->v[i] = ord % int_base;
    } else if (mode == 3) {
      p->v[i] = ord >> k;
      s->v[i] = (raw & mid) ? mask64((unsigned)k) - (ord & mask64((unsigned)k))
                            : ord & mask64((unsigned)k);
    } else if (mode == 2) {
      double num = asfloat(raw, b), mult = narrow(round(narrow(num * inv, b)), b),
             un = narrow(mult * base, b);
      p->v[i] = intfloat_encode(mult, b);
      s->v[i] = ((ord - ordered(asbits(un, b), b)) & mask) ^ mid;
    }
  }
  return 0;
}
static unsigned hist_log(int level, size_t n) {
  unsigned ln = bits64(n) - 1, fast = ln > 4 ? ln - 4 : 0;
  return (unsigned)level <= fast ? (unsigned)level : fast + ((unsigned)level - fast) / 2;
}
static double var_cost(const Var *v) {
  double cost =
      19 + (double)v->nb * (v->log + v->b + bits64(v->b)) + (double)v->state_n * v->b + 4 * v->log;
  for (unsigned i = 0; i < v->nb; i++)
    cost += (double)v->bins[i].count * (v->bins[i].ob + v->log - log2((double)v->bins[i].weight));
  return cost;
}
typedef struct {
  int mode, k, delta;
  double base, cost;
} Choice;
typedef struct {
  Var primary, secondary;
  double secondary_cost[13];
  unsigned ready;
  int initialized;
} SampleMode;
static int evaluate(const void *src, size_t n, int t, int mode, int k, double base, int delta,
                    int level, double *cost, SampleMode *cache, TrainWorkspace *ws, uint64_t int_base) {
  if (!cache->initialized) {
    int e = split(src, n, t, mode, k, base, int_base, &cache->primary, &cache->secondary);
    if (e)
      return e;
    cache->initialized = 1;
  }
  Var p = PC_ZERO, d = PC_ZERO;
  int e = alloc_var(&p, n, cache->primary.b);
  if (!e)
    memcpy(p.v, cache->primary.v, n * 8);
  if (!e)
    e = delta == 8 ? lookback(&p, &d, 8) : consecutive(&p, (unsigned)delta);
  unsigned hl = hist_log(level, n);
  if (!e)
    e = train(&p, hl, ws);
  if (!e && mode && !(cache->ready & (1u << hl))) {
    Var *secondary = &cache->secondary;
    free(secondary->bins);
    secondary->bins = NULL;
    e = train(secondary, MIN2(hl, 6), ws);
    if (!e) {
      cache->secondary_cost[hl] = var_cost(secondary);
      cache->ready |= 1u << hl;
    }
  }
  if (!e && delta == 8)
    e = train(&d, hl, ws);
  if (!e)
    *cost = var_cost(&p) + (mode ? cache->secondary_cost[hl] : 0) +
            (delta == 8 ? var_cost(&d) : 0) + 8 +
            ((mode == 1 || mode == 2) ? p.b
             : mode == 3 ? 8
                         : 0) +
            (delta == 8 ? 10
             : delta    ? 4
                        : 0);
  var_free(&p);
  var_free(&d);
  return e;
}
/* Prefix sampling keeps prediction contiguous. All encode decisions and full
 * training, including allocation, are inside the timed compression call. */
static int choose(const void *src, size_t n, int t, const pc_config *c, Choice *best,
                  TrainWorkspace *ws, uint64_t int_base) {
  size_t sn = MIN2(n, 512);
  int modes[24], ks[24], nc = 0;
  double bases[24];
  modes[nc] = 0;
  ks[nc] = 0;
  bases[nc++] = 1;
  unsigned b = (unsigned)pc_type_size(t) * 8;
  if (c->mode == -1 && isfloat(t)) {
    unsigned tz[64] = {0};
    int finite = 1;
    for (size_t i = 0; i < sn; i++) {
      uint64_t raw = loadraw(src, i, b);
      unsigned z = raw ? (unsigned)__builtin_ctzll(raw) : b;
      z = MIN2(z, b == 32 ? 23 : 52);
      tz[z]++;
      if (!isfinite(asfloat(raw, b)))
        finite = 0;
    }
    unsigned occ = 0;
    double bestgain = 0;
    int bk = 0;
    for (int k = (b == 32 ? 23 : 52); k > 0; k--) {
      occ += tz[k];
      double f = (double)occ / (double)sn,
             h = (f > 0 && f < 1) ? -f * log2(f) - (1 - f) * log2(1 - f) : 0;
      double gain = f * k - h;
      if (gain > bestgain) {
        bestgain = gain;
        bk = k;
      }
    }
    if (bk && bestgain > 1) {
      modes[nc] = 3;
      ks[nc] = bk;
      bases[nc++] = 1;
    }
    if (finite) {
      for (int exp = 0; exp >= -9; exp--) {
        modes[nc] = 2;
        ks[nc] = 0;
        bases[nc++] = narrow(pow(10, exp), b);
      }
    }
  }
  if (c->mode >= 0) {
    nc = 1;
    modes[0] = c->mode;
    ks[0] = c->quant_k;
    bases[0] = narrow(c->base, b);
  }
  SampleMode caches[24];
  memset(caches, 0, sizeof(caches));
  int error = 0;
  int shortlist[4] = {0, 0, 0, 0}, ns = 1;
  if (nc > 1) {
    double ranked[24];
    for (int m = 0; m < nc; m++) {
      double a = 0, best_score = INFINITY;
      for (int delta = 0; delta <= 1; delta++) {
        int e = evaluate(src, sn, t, modes[m], ks[m], bases[m], delta, MIN2(c->level, 4), &a,
                         &caches[m], ws, int_base);
        if (e) {
          error = e;
          goto cleanup;
        }
        if (a < best_score)
          best_score = a;
      }
      ranked[m] = best_score;
    }
    for (int r = 0; r < 2; r++) {
      int idx = -1;
      double low = INFINITY;
      for (int m = 1; m < nc; m++)
        if (ranked[m] < low) {
          idx = m;
          low = ranked[m];
        }
      if (idx >= 0) {
        shortlist[ns++] = idx;
        ranked[idx] = INFINITY;
      }
    }
  }
  best->cost = INFINITY;
  for (int si = 0; si < ns; si++) {
    int m = shortlist[si];
    int maxdelta = c->delta < 0 ? 8 : c->delta, first = c->delta < 0 ? 0 : c->delta;
    /* Try 0..3 and lookback in auto; explicit consecutive supports up to 7. */
    for (int delta = first; delta <= maxdelta; delta++) {
      if (c->delta < 0 && delta > 3 && delta < 8)
        continue;
      double cost = 0;
      int e = evaluate(src, sn, t, modes[m], ks[m], bases[m], delta, MIN2(c->level, 6), &cost,
                       &caches[m], ws, int_base);
      if (e) {
        error = e;
        goto cleanup;
      }
      if (cost < best->cost) {
        best->mode = modes[m];
        best->k = ks[m];
        best->base = bases[m];
        best->delta = delta;
        best->cost = cost;
      }
    }
  }
cleanup:
  for (int m = 0; m < nc; m++) {
    var_free(&caches[m].primary);
    var_free(&caches[m].secondary);
  }
  return error;
}
static int write_chunk(Writer *w, const void *src, size_t n, int t, const pc_config *c,
                       TrainWorkspace *ws, uint64_t int_base) {
  Choice ch = {0, 0, 0, 1, 0};
  int e;
  if (c->mode >= 0 && c->delta >= 0) {
    ch.mode = c->mode;
    ch.k = c->quant_k;
    ch.delta = c->delta;
    ch.base = narrow(c->base, (unsigned)pc_type_size(t) * 8);
  } else {
    e = choose(src, n, t, c, &ch, ws, int_base);
    if (e)
      return e;
  }
  Var p = PC_ZERO, s = PC_ZERO, d = PC_ZERO;
  e = split(src, n, t, ch.mode, ch.k, ch.base, int_base, &p, &s);
  if (!e)
    e = ch.delta == 8 ? lookback(&p, &d, 8) : consecutive(&p, (unsigned)ch.delta);
  unsigned hl = hist_log(c->level, n);
  if (!e)
    e = train(&p, hl, ws);
  if (!e && ch.mode)
    e = train(&s, MIN2(hl, 6), ws);
  if (!e && ch.delta == 8)
    e = train(&d, hl, ws);
  if (!e)
    e = dissect(&p);
  if (!e && ch.mode)
    e = dissect(&s);
  if (!e && ch.delta == 8)
    e = dissect(&d);
  if (e)
    goto end;
  put(w, (unsigned)t, 8);
  put(w, n - 1, 24);
  put(w, (unsigned)ch.mode, 4);
  if (ch.mode == 1)
    put(w, int_base, p.b);
  if (ch.mode == 2)
    put(w, ordered(asbits(ch.base, p.b), p.b), p.b);
  if (ch.mode == 3)
    put(w, (unsigned)ch.k, 8);
  put(w, ch.delta == 8 ? 2 : ch.delta ? 1 : 0, 4);
  if (ch.delta == 8) {
    put(w, 7, 5);
    put(w, 0, 4);
    put(w, 0, 1);
  } else if (ch.delta) {
    put(w, (unsigned)ch.delta, 3);
    put(w, 0, 1);
  }
  if (ch.delta == 8)
    write_varmeta(w, &d);
  write_varmeta(w, &p);
  if (ch.mode)
    write_varmeta(w, &s);
  walign(w);
  {
    Var *vars[3] = {&d, &p, &s};
    for (int j = 0; j < 3; j++) {
      if ((j == 0 && ch.delta != 8) || (j == 2 && !ch.mode))
        continue;
      Var *v = vars[j];
      for (size_t k = 0; k < v->state_n; k++)
        put(w, v->state[k], v->b);
      for (unsigned k = 0; k < 4; k++)
        put(w, v->final[k] - (1u << v->log), v->log);
    }
  }
  walign(w);
  for (size_t start = 0; start < n; start += 256) {
    if (ch.delta == 8)
      write_batch(w, &d, start);
    write_batch(w, &p, start);
    if (ch.mode)
      write_batch(w, &s, start);
  }
  walign(w);
  e = w->err;
end:
  var_free(&p);
  var_free(&s);
  var_free(&d);
  return e;
}
pc_config pc_default_config(void) {
  pc_config c = {8, -1, -1, 0, 1.0, (size_t)1 << 18};
  return c;
}
static int pc_compress_inner(const void *src, size_t n, int t, const pc_config *conf, uint64_t int_base, uint8_t **dst,
                size_t *sz) {
  if (!dst || !sz || (!src && n) || !pc_type_size(t))
    return PC_INVALID;
  *dst = NULL;
  *sz = 0;
  if (t == 9)
    return PC_UNSUPPORTED;
  if (n > SIZE_MAX / pc_type_size(t))
    return PC_INVALID;
  pc_config def = pc_default_config();
  const pc_config *c = conf ? conf : &def;
  if (c->level < 0 || c->level > 12 || c->delta < -1 || c->delta > 8 || c->chunk_n == 0 ||
      c->chunk_n > MAX_ENTRIES || (c->mode != -1 && c->mode != 0 && c->mode != 2 && c->mode != 3 && !(c->mode == 1 && int_base)) ||
      ((c->mode == 2 || c->mode == 3) && !isfloat(t)) ||
      (c->mode == 1 && (isfloat(t) || int_base > mask64((unsigned)pc_type_size(t)*8))) ||
      (c->mode == 3 && (c->quant_k <= 0 || c->quant_k > (t == 5 ? 23 : 52))) ||
      (c->mode == 2 && (!isfinite(c->base) || c->base == 0 ||
                        !isfinite(narrow(1 / c->base, (unsigned)pc_type_size(t) * 8)))))
    return PC_INVALID;
  Writer w = PC_ZERO;
  put(&w, 0x216f6370, 32);
  put(&w, 3, 8);
  put(&w, 0, 8);
  unsigned power = MAX2(bits64(n), 1);
  put(&w, power - 1, 6);
  put(&w, n, power);
  walign(&w);
  put(&w, 4, 8);
  put(&w, 1, 8);
  size_t chunks = n / c->chunk_n + (n % c->chunk_n != 0), start = 0;
  int e = 0;
  TrainWorkspace ws = PC_ZERO;
  if (chunks) {
    size_t maxn = n / chunks + (n % chunks != 0);
    e = workspace_init(&ws, maxn, hist_log(c->level, maxn));
  }
  for (size_t i = 0; i < chunks && !e; i++) {
    size_t cn = n / chunks + (i < n % chunks);
    e = write_chunk(&w, (const uint8_t *)src + start * pc_type_size(t), cn, t, c, &ws, int_base);
    start += cn;
  }
  put(&w, 0, 8);
  free(ws.allocation);
  if (!e)
    e = w.err;
  if (e) {
    free(w.p);
    return e;
  }
  *dst = w.p;
  *sz = w.bit / 8;
  return 0;
}
/* Existing entry retains the exact NativeAuto strategy and ABI. */
int pc_compress_native(const void *src, size_t n, int t, const pc_config *conf,
                uint8_t **dst, size_t *sz) {
  return pc_compress_inner(src,n,t,conf,0,dst,sz);
}
/* Source policy is the default full-capability build. NativeAuto remains an
 * explicit execution policy, never silently advertised as SourceAuto. */
#ifdef PC_SOURCE_BACKEND
static int source_compress(const void*src,size_t n,int t,const pc_config*conf,uint64_t int_base,uint8_t**dst,size_t*sz){
 if(dst)*dst=NULL;if(sz)*sz=0;if(!dst||!sz)return PC_INVALID;
 pc_config def=pc_default_config();const pc_config*c=conf?conf:&def;
 if(c->delta < -1 || c->delta>8)return PC_INVALID;
 pcs_config cfg=pcs_default_config();cfg.level=c->level;cfg.mode=int_base?1:c->mode;
 cfg.delta=c->delta==-1?-1:c->delta==0?0:c->delta==8?2:1;cfg.order=c->delta>0&&c->delta<8?c->delta:0;
 cfg.quant_k=c->quant_k;cfg.float_base=c->base;cfg.int_base=int_base;cfg.max_page_n=c->chunk_n;cfg.enable_8_bit=1;
 pcs_buffer out={NULL,0};int rc=pcs_compress(src,n,t,&cfg,&out);if(rc)return rc;
 void*p=malloc(out.size?out.size:1);if(!p){pcs_buffer_free(out.data,out.size);return PC_NOMEM;}
 if(out.size)memcpy(p,out.data,out.size);*dst=p;*sz=out.size;pcs_buffer_free(out.data,out.size);return 0;
}
#endif
int pc_source_backend_available(void){
#ifdef PC_SOURCE_BACKEND
 return 1;
#else
 return 0;
#endif
}
int pc_compress(const void*src,size_t n,int t,const pc_config*c,uint8_t**dst,size_t*sz){
#ifdef PC_SOURCE_BACKEND
 return source_compress(src,n,t,c,0,dst,sz);
#else
 return pc_compress_native(src,n,t,c,dst,sz);
#endif
}
int pc_compress_intmult(const void *src, size_t n, int t, uint64_t base,
                       int level, int delta, size_t chunk_n, uint8_t **dst, size_t *sz) {
  if (dst) *dst=NULL;
  if (sz) *sz=0;
  if (!base) return PC_INVALID;
  pc_config c={level,1,delta,0,1.,chunk_n};
  #ifdef PC_SOURCE_BACKEND
  return source_compress(src,n,t,&c,base,dst,sz);
#else
  return pc_compress_inner(src,n,t,&c,base,dst,sz);
#endif
}
#if defined(__AVX2__)
/* Full IEEE range: select numeric integer conversion below gpi and bit-space
   conversion above it. Sign operations are integer masks, retaining -0. */
static size_t restore_mult32_simd(const uint32_t *p, const uint32_t *s, size_t n, uint64_t baseraw,
                                  void *dst) {
  const __m256i mid = _mm256_set1_epi32(INT32_MIN);
  const __m256i abs_mask = _mm256_set1_epi32(INT32_MAX);
  const __m256i all = _mm256_set1_epi32(-1);
  const __m256 base = _mm256_set1_ps((float)asfloat(baseraw, 32));
  size_t i = 0;
  for (; i + 8 <= n; i += 8) {
    __m256i x = _mm256_loadu_si256((const __m256i *)(p + i));
    __m256i neg = _mm256_xor_si256(_mm256_srai_epi32(x, 31), all);
    __m256i mag = _mm256_and_si256(_mm256_xor_si256(x, neg), abs_mask);
    __m256i small = _mm256_cmpgt_epi32(_mm256_set1_epi32(1 << 24), mag);
    __m256i converted = _mm256_castps_si256(_mm256_cvtepi32_ps(mag));
    __m256i fallback = _mm256_add_epi32(mag, _mm256_set1_epi32(0x4a800000));
    __m256i bits =
        _mm256_or_si256(_mm256_blendv_epi8(fallback, converted, small), _mm256_and_si256(neg, mid));
    __m256i u = _mm256_castps_si256(_mm256_mul_ps(_mm256_castsi256_ps(bits), base));
    __m256i ord = _mm256_xor_si256(u, _mm256_or_si256(_mm256_srai_epi32(u, 31), mid));
    ord =
        _mm256_xor_si256(_mm256_add_epi32(ord, _mm256_loadu_si256((const __m256i *)(s + i))), mid);
    __m256i raw = _mm256_xor_si256(
        ord, _mm256_or_si256(_mm256_xor_si256(_mm256_srai_epi32(ord, 31), all), mid));
    _mm256_storeu_si256((__m256i *)((uint8_t *)dst + i * 4), raw);
  }
  return i;
}
static size_t restore_mult64_simd(const uint64_t *p, const uint64_t *s, size_t n, uint64_t baseraw,
                                  void *dst) {
  const __m256i mid = _mm256_set1_epi64x(INT64_MIN);
  const __m256i abs_mask = _mm256_set1_epi64x(INT64_MAX);
  const __m256i minus_one = _mm256_set1_epi64x(-1);
  const __m256i zero = _mm256_setzero_si256();
  const __m256i low52 = _mm256_set1_epi64x((UINT64_C(1) << 52) - 1);
  const __m256i magic = _mm256_set1_epi64x(UINT64_C(0x4330000000000000));
  const __m256d two52 = _mm256_set1_pd(4503599627370496.0);
  const __m256d base = _mm256_set1_pd(asfloat(baseraw, 64));
  size_t i = 0;
  for (; i + 4 <= n; i += 4) {
    __m256i x = _mm256_loadu_si256((const __m256i *)(p + i));
    __m256i neg = _mm256_cmpgt_epi64(x, minus_one);
    __m256i mag = _mm256_and_si256(_mm256_xor_si256(x, neg), abs_mask);
    __m256i small = _mm256_cmpgt_epi64(_mm256_set1_epi64x(UINT64_C(1) << 53), mag);
    __m256d converted = _mm256_sub_pd(
        _mm256_castsi256_pd(_mm256_or_si256(_mm256_and_si256(mag, low52), magic)), two52);
    converted =
        _mm256_add_pd(converted, _mm256_blendv_pd(_mm256_setzero_pd(), two52,
                                                  _mm256_castsi256_pd(_mm256_slli_epi64(mag, 11))));
    __m256i fallback = _mm256_add_epi64(mag, _mm256_set1_epi64x(UINT64_C(0x4320000000000000)));
    __m256i bits =
        _mm256_or_si256(_mm256_blendv_epi8(fallback, _mm256_castpd_si256(converted), small),
                        _mm256_and_si256(neg, mid));
    __m256i u = _mm256_castpd_si256(_mm256_mul_pd(_mm256_castsi256_pd(bits), base));
    __m256i ord = _mm256_xor_si256(u, _mm256_or_si256(_mm256_cmpgt_epi64(zero, u), mid));
    ord =
        _mm256_xor_si256(_mm256_add_epi64(ord, _mm256_loadu_si256((const __m256i *)(s + i))), mid);
    __m256i raw = _mm256_xor_si256(ord, _mm256_or_si256(_mm256_cmpgt_epi64(ord, minus_one), mid));
    _mm256_storeu_si256((__m256i *)((uint8_t *)dst + i * 8), raw);
  }
  return i;
}
#endif
static size_t restore_mult_simd(const void *p, const void *s, size_t n, unsigned b,
                                unsigned word_bytes, uint64_t base, void *dst) {
#if defined(__AVX2__)
  if (b == 32 && word_bytes == 4)
    return restore_mult32_simd((const uint32_t *)p, (const uint32_t *)s, n, base, dst);
  if (b == 64)
    return restore_mult64_simd((const uint64_t *)p, (const uint64_t *)s, n, base, dst);
#else
  (void)p;
  (void)s;
  (void)n;
  (void)b;
  (void)word_bytes;
  (void)base;
  (void)dst;
#endif
  return 0;
}
/* Dispatch type and mode outside the restoration loops. Widths here are
   compile-time constants, enabling packed integer operations without fast-math. */
#define PC_RESTORE_FLOAT(NAME, B, UINT, WORD)                                                      \
  static int NAME(const Var *p, const Var *s, size_t n, int mode, unsigned k, uint64_t baseraw,    \
                  void *dst) {                                                                     \
    const WORD *pv = (const WORD *)p->v, *sv = (const WORD *)s->v;                                 \
    const unsigned b = B;                                                                          \
    const uint64_t mid = UINT64_C(1) << (B - 1);                                                   \
    if (mode == 0) {                                                                               \
      for (size_t i = 0; i < n; i++)                                                               \
        storeraw(dst, i, b, unorder(pv[i], b));                                                    \
    } else if (mode == 3) {                                                                        \
      uint64_t lowmask = mask64(k), flip = mask64(b) ^ lowmask;                                    \
      uint64_t invalid = 0;                                                                        \
      for (size_t i = 0; i < n; i++) {                                                             \
        uint64_t x = pv[i], low = sv[i];                                                           \
        invalid |= low & ~lowmask;                                                                 \
        UINT raw = (UINT)((x << k) ^ low ^ (x < (mid >> k) ? flip : mid));                         \
        storeraw(dst, i, b, raw);                                                                  \
      }                                                                                            \
      if (invalid)                                                                                 \
        return PC_CORRUPT;                                                                         \
    } else {                                                                                       \
      double base = asfloat(baseraw, b);                                                           \
      size_t first = restore_mult_simd(pv, sv, n, b, sizeof(WORD), baseraw, dst);                  \
      for (size_t i = first; i < n; i++) {                                                         \
        double un = narrow(intfloat_decode(pv[i], b) * base, b);                                   \
        UINT ord = (UINT)(ordered(asbits(un, b), b) + sv[i]);                                      \
        storeraw(dst, i, b, unorder(ord ^ mid, b));                                                \
      }                                                                                            \
    }                                                                                              \
    return PC_OK;                                                                                  \
  }
PC_RESTORE_FLOAT(restore_f32, 32, uint32_t, uint64_t)
PC_RESTORE_FLOAT(restore_f32_narrow, 32, uint32_t, uint32_t)
PC_RESTORE_FLOAT(restore_f64, 64, uint64_t, uint64_t)
#undef PC_RESTORE_FLOAT
static int decode_chunk(Reader *r, size_t cn, int t, void *dst) {
  unsigned b = (unsigned)pc_type_size(t) * 8;
  int mode = (int)get(r, 4), delta, secondary = 0;
  unsigned k = 0, wl = 0, sl = 0;
  uint64_t baseraw = 0;
  if (mode == 1)
    baseraw = get(r, b);
  else if (mode == 2)
    baseraw = unorder(get(r, b), b);
  else if (mode == 3) {
    k = (unsigned)get(r, 8);
    if (!k || k > (b == 32 ? 23u : 52u) || !isfloat(t))
      return PC_CORRUPT;
  } else if (mode != 0)
    return PC_UNSUPPORTED;
  if ((mode == 1 && isfloat(t)) || (mode == 2 && !isfloat(t)))
    return PC_CORRUPT;
  if (mode == 1 && !baseraw)
    return PC_CORRUPT;
  if (mode == 2 && (!isfinite(asfloat(baseraw, b)) || asfloat(baseraw, b) == 0))
    return PC_CORRUPT;
  delta = (int)get(r, 4);
  size_t state_n = 0;
  if (delta == 1) {
    state_n = (size_t)get(r, 3);
    secondary = (int)get(r, 1);
    if (!state_n)
      return PC_CORRUPT;
  } else if (delta == 2) {
    wl = 1 + (unsigned)get(r, 5);
    sl = (unsigned)get(r, 4);
    secondary = (int)get(r, 1);
    if (wl > 24 || sl > wl)
      return PC_CORRUPT;
    state_n = (size_t)1 << sl;
  } else if (delta != 0)
    return PC_UNSUPPORTED;
  int batch_restore = isfloat(t) && cn >= 256 && (delta != 2 || state_n <= cn);
  Var p = PC_ZERO, s = PC_ZERO, d = PC_ZERO;
  Var *vars[3] = {&d, &p, &s};
  int e = 0;
  if (delta == 2)
    e = read_varmeta(r, &d, 32);
  if (!e)
    e = read_varmeta(r, &p, b);
  if (!e && mode)
    e = read_varmeta(r, &s, b);
  ralign(r);
  if (!e && r->err)
    e = r->err;
  if (e)
    goto end;
  for (int j = 0; j < 3; j++) {
    if ((j == 0 && delta != 2) || (j == 2 && !mode))
      continue;
    Var *v = vars[j];
    v->state_n = (j == 1 || (j == 2 && secondary)) ? state_n : 0;
    v->n = cn - MIN2(cn, (j == 0 ? state_n : v->state_n));
    v->state = (uint64_t *)calloc(MAX2(v->state_n, 1), 8);
    v->v = (uint64_t *)calloc(MAX2(batch_restore ? MIN2(cn, 256) : cn, 1),
                              batch_restore && b == 32 ? 4 : 8);
    if (!v->state || !v->v) {
      e = PC_NOMEM;
      goto end;
    }
    for (size_t x = 0; x < v->state_n; x++)
      v->state[x] = get(r, v->b);
    for (unsigned x = 0; x < 4; x++)
      v->final[x] = (uint32_t)get(r, v->log);
    if (batch_restore && delta == 2 && v->state_n) {
      v->history_window = MIN2((size_t)1 << wl, cn + v->state_n);
      v->history_pos = v->history_window;
      v->history = calloc(2 * MAX2(v->history_window, 256), b / 8);
      if (!v->history) {
        e = PC_NOMEM;
        goto end;
      }
      for (size_t i = 0; i < v->state_n; i++) {
        if (b == 32)
          ((uint32_t *)v->history)[v->history_pos - v->state_n + i] = (uint32_t)v->state[i];
        else
          ((uint64_t *)v->history)[v->history_pos - v->state_n + i] = v->state[i];
      }
    }
  }
  ralign(r);
  for (size_t start = 0; start < cn && !r->err; start += 256) {
    if (delta == 2) {
      if (batch_restore)
        read_batch32(r, &d, start, (uint32_t *)d.v);
      else
        read_batch(r, &d, start, d.v + start);
    }
    if (batch_restore && b == 32) {
      read_batch32(r, &p, start, (uint32_t *)p.v);
      if (mode)
        read_batch32(r, &s, start, (uint32_t *)s.v);
    } else {
      read_batch(r, &p, start, p.v + (batch_restore ? 0 : start));
      if (mode)
        read_batch(r, &s, start, s.v + (batch_restore ? 0 : start));
    }
    if (batch_restore && !r->err) {
      size_t count = MIN2(256, cn - start);
      if (delta == 2) {
        size_t residuals = MIN2(256, p.n - MIN2(start, p.n));
        if (b == 32) {
          e = undo_lookback_batch32(&p, (uint32_t *)d.v, start, count, residuals, (size_t)1 << wl);
          if (!e && mode && secondary)
            e = undo_lookback_batch32(&s, (uint32_t *)d.v, start, count, residuals,
                                      (size_t)1 << wl);
        } else {
          e = undo_lookback_batch64(&p, (uint32_t *)d.v, start, count, residuals, (size_t)1 << wl);
          if (!e && mode && secondary)
            e = undo_lookback_batch64(&s, (uint32_t *)d.v, start, count, residuals,
                                      (size_t)1 << wl);
        }
        if (e)
          goto end;
      } else if (b == 32) {
        if (delta)
          undo_consecutive_batch32(&p, count);
        if (delta && mode && secondary)
          undo_consecutive_batch32(&s, count);
      } else {
        if (delta)
          undo_consecutive_batch(&p, count);
        if (delta && mode && secondary)
          undo_consecutive_batch(&s, count);
      }
      e = t == PC_F32
              ? restore_f32_narrow(&p, &s, count, mode, k, baseraw, (uint8_t *)dst + start * 4)
              : restore_f64(&p, &s, count, mode, k, baseraw, (uint8_t *)dst + start * 8);
      if (e)
        goto end;
    }
  }
  ralign(r);
  if (r->err) {
    e = r->err;
    goto end;
  }
  if (batch_restore)
    goto end;
  if (delta == 2) {
    for (size_t i = 0; i < d.n; i++)
      if (!d.v[i] || d.v[i] > ((size_t)1 << wl) || d.v[i] > i + state_n) {
        e = PC_CORRUPT;
        goto end;
      }
  }
  undo_delta(&p, cn, delta == 2 ? 8 : delta, &d);
  if (secondary && mode)
    undo_delta(&s, cn, delta == 2 ? 8 : delta, &d);
  if (t == PC_F32) {
    e = restore_f32(&p, &s, cn, mode, k, baseraw, dst);
    goto end;
  }
  if (t == PC_F64) {
    e = restore_f64(&p, &s, cn, mode, k, baseraw, dst);
    goto end;
  }
  for (size_t i = 0; i < cn; i++) {
    uint64_t raw = 0, x = p.v[i], mid = UINT64_C(1) << (b - 1);
    if (mode == 0)
      raw = isfloat(t) ? unorder(x, b) : issigned(t) ? x ^ mid : x;
    else if (mode == 1) {
      raw = (x * baseraw + s.v[i]) & mask64(b);
      if (issigned(t))
        raw ^= mid;
    } else if (mode == 3) {
      if (s.v[i] > mask64(k)) {
        e = PC_CORRUPT;
        goto end;
      }
      raw = ((x << k) ^ s.v[i] ^ (x < (mid >> k) ? mask64(b) ^ mask64(k) : mid)) & mask64(b);
    } else {
      double un = narrow(intfloat_decode(x, b) * asfloat(baseraw, b), b);
      raw = unorder(((ordered(asbits(un, b), b) + s.v[i]) & mask64(b)) ^ mid, b);
    }
    storeraw(dst, i, b, raw);
  }
end:
  var_free(&p);
  var_free(&s);
  var_free(&d);
  return e;
}
static int pc_decompress_legacy(const uint8_t *src, size_t sz, int expected, size_t max_values, void **dst, size_t *n) {
  if (!dst || !n || (!src && sz) || !pc_type_size(expected))
    return PC_INVALID;
  *dst = NULL;
  *n = 0;
  if (sz > SIZE_MAX / 8)
    return PC_INVALID;
  if (expected == 9)
    return PC_UNSUPPORTED;
  Reader r = {src, sz, 0, 0};
  if (get(&r, 32) != 0x216f6370)
    return PC_CORRUPT;
  if (get(&r, 8) != 3)
    return PC_UNSUPPORTED;
  unsigned uniform = (unsigned)get(&r, 8);
  if (uniform && uniform != (unsigned)expected)
    return PC_INVALID;
  unsigned power = 1 + (unsigned)get(&r, 6);
  (void)get(&r, power);
  ralign(&r);
  unsigned major = (unsigned)get(&r, 8), minor = (unsigned)get(&r, 8);
  if (major != 4 || minor > 1)
    return PC_UNSUPPORTED;
  void *out = NULL;
  size_t total = 0, cap = 0;
  int e = 0;
  while (!r.err) {
    unsigned t = (unsigned)get(&r, 8);
    if (r.err)
      break;
    if (!t)
      break;
    if (t != (unsigned)expected) {
      e = PC_INVALID;
      break;
    }
    size_t cn = (size_t)get(&r, 24) + 1;
    if (r.err)
      break;
    /* A forged constant chunk can legitimately expand a great deal. Limit
       individual allocation to format MAX_ENTRIES and check arithmetic. */
    size_t width = pc_type_size(expected);
    if (cn > MAX_ENTRIES || total > SIZE_MAX / width - cn) {
      e = PC_NOMEM;
      break;
    }
    if (cn > max_values || total > max_values - cn) {
      e = PC_LIMIT;
      break;
    }
    size_t want = (total + cn) * width;
    if (want > cap) {
      void *p = realloc(out, want);
      if (!p) {
        e = PC_NOMEM;
        break;
      }
      out = p;
      cap = want;
    }
    e = decode_chunk(&r, cn, expected, (uint8_t *)out + total * width);
    if (e)
      break;
    total += cn;
  }
  if (!e)
    e = r.err;
  if (!e && r.bit != sz * 8)
    e = PC_CORRUPT;
  if (e) {
    free(out);
    return e;
  }
  if (!out)
    out = calloc(1, 1);
  if (!out)
    return PC_NOMEM;
  *dst = out;
  *n = total;
  return 0;
}
int pc_decompress(const uint8_t *src, size_t sz, int expected, void **dst, size_t *n) {
  return pc_decompress_bounded(src, sz, expected, SIZE_MAX, dst, n);
}
void pc_free(void *p) {
  free(p);
}
const char *pc_error(int e) {
  switch (e) {
  case 0:
    return "ok";
  case 1:
    return "invalid argument/type";
  case 2:
    return "out of memory/size overflow";
  case 3:
    return "truncated stream";
  case 4:
    return "corrupt stream";
  case 6:
    return "output value limit exceeded";
  case 5:
    return "unsupported format/mode/type";
  default:
    return "unknown error";
  }
}

#include "native_ext.inc"

int pc_decompress_bounded(const uint8_t*src,size_t sz,int expected,size_t limit,void**dst,size_t*n){
#ifdef PC_SOURCE_BACKEND
 if(dst)*dst=NULL;if(n)*n=0;if(!dst||!n)return PC_INVALID;
 pcs_buffer out={NULL,0};int rc=pcs_decompress(src,sz,expected,limit,&out,n);if(rc)return rc;
 void*p=malloc(out.size?out.size:1);if(!p){pcs_buffer_free(out.data,out.size);*n=0;return PC_NOMEM;}
 if(out.size)memcpy(p,out.data,out.size);*dst=p;pcs_buffer_free(out.data,out.size);return 0;
#else
 int e=pc_decompress_legacy(src,sz,expected,limit,dst,n);
 if(e==PC_UNSUPPORTED&&expected!=PC_F16&&dst&&n){pcn_buffer out={NULL,0};e=pcn_decompress(src,sz,expected,limit,&out,n);if(!e)*dst=out.data;}
 return e;
#endif
}
