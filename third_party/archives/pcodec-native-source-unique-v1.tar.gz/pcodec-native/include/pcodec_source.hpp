#pragma once
#include "pcodec_source.h"
#include "pcodec.hpp"
#include <utility>
namespace pcodec_source {
inline void check(int rc){if(rc)throw std::runtime_error(pcs_last_error());}
class buffer {
 pcs_buffer b_{};
public:
 buffer()=default; explicit buffer(pcs_buffer b):b_(b){}
 ~buffer(){pcs_buffer_free(b_.data,b_.size);}
 buffer(buffer const&)=delete;buffer&operator=(buffer const&)=delete;
 buffer(buffer&&x)noexcept:b_(x.b_){x.b_={};}
 buffer&operator=(buffer&&x)noexcept{if(this!=&x){pcs_buffer_free(b_.data,b_.size);b_=x.b_;x.b_={};}return *this;}
 const uint8_t* data()const{return b_.data;}size_t size()const{return b_.size;}
};
template<class T>buffer compress(const T*data,size_t n,const pcs_config&cfg=pcs_default_config()){pcs_buffer b{};check(pcs_compress(data,n,pcodec::type<T>(),&cfg,&b));return buffer(b);}
class encoder{
 struct destroy{void operator()(pcs_encoder*p)const{pcs_chunk_destroy(p);}};
 std::unique_ptr<pcs_encoder,destroy> p_;
public:
 template<class T>encoder(const T*data,size_t n,const pcs_config&cfg=pcs_default_config(),const std::vector<size_t>&pages={}){pcs_encoder*p=nullptr;check(pcs_chunk_new(data,n,pcodec::type<T>(),&cfg,pages.empty()?nullptr:pages.data(),pages.size(),&p));p_.reset(p);}
 buffer header_meta()const{pcs_buffer b{};check(pcs_chunk_header_meta(p_.get(),&b));return buffer(b);}
 buffer page(size_t i){pcs_buffer b{};check(pcs_chunk_page(p_.get(),i,&b));return buffer(b);}
 buffer describe()const{pcs_buffer b{};check(pcs_chunk_describe(p_.get(),&b));return buffer(b);}
};
class decoder{
 struct destroy{void operator()(pcs_decoder*p)const{pcs_decoder_destroy(p);}};
 std::unique_ptr<pcs_decoder,destroy> p_;
 explicit decoder(pcs_decoder*p):p_(p){}
public:
 struct batch{buffer values;size_t count;bool finished;};
 template<class T>static decoder file(const uint8_t*data,size_t n,size_t limit){pcs_decoder*p=nullptr;check(pcs_file_open(data,n,pcodec::type<T>(),limit,&p));return decoder(p);}
 template<class T>static decoder wrapped(const uint8_t*meta,size_t n){pcs_decoder*p=nullptr;check(pcs_wrapped_open(meta,n,pcodec::type<T>(),&p));return decoder(p);}
 void start_page(const uint8_t*data,size_t bytes,size_t n,size_t limit){check(pcs_wrapped_start_page(p_.get(),data,bytes,n,limit));}
 batch read(size_t capacity=256){pcs_buffer b{};size_t n=0;int done=0;check(pcs_read(p_.get(),capacity,&b,&n,&done));return {buffer(b),n,done!=0};}
 buffer describe()const{pcs_buffer b{};check(pcs_decoder_describe(p_.get(),&b));return buffer(b);}
};
}
