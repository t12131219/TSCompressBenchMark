#pragma once
#include "pcodec.h"
#include <cstring>
#include <memory>
#include <stdexcept>
#include <type_traits>
#include <vector>
namespace pcodec {
inline void check(int code) {
  if (code)
    throw std::runtime_error(pc_error(code));
}
template <class T> constexpr int type() {
  if constexpr (std::is_same_v<T, float>)
    return PC_F32;
  else if constexpr (std::is_same_v<T, double>)
    return PC_F64;
  else if constexpr (std::is_same_v<T, uint64_t>)
    return PC_U64;
  else if constexpr (std::is_same_v<T, int64_t>)
    return PC_I64;
  else if constexpr (std::is_same_v<T, uint32_t>)
    return PC_U32;
  else if constexpr (std::is_same_v<T, int32_t>)
    return PC_I32;
  else if constexpr (std::is_same_v<T, uint16_t>)
    return PC_U16;
  else if constexpr (std::is_same_v<T, int16_t>)
    return PC_I16;
  else if constexpr (std::is_same_v<T, uint8_t>)
    return PC_U8;
  else if constexpr (std::is_same_v<T, int8_t>)
    return PC_I8;
  else {
    static_assert(!sizeof(T), "Unsupported number type");
  }
}
struct free_buffer {
  void operator()(void *p) const noexcept {
    pc_free(p);
  }
};
/* Owns the engine's buffer without an additional timed copy. */
class buffer {
  std::unique_ptr<void, free_buffer> data_;
  size_t size_;

public:
  buffer(void *p, size_t n) : data_(p), size_(n) {}
  void *data() noexcept {
    return data_.get();
  }
  const void *data() const noexcept {
    return data_.get();
  }
  size_t size() const noexcept {
    return size_;
  }
};
template <class T>
buffer compress(const T *src, size_t n, const pc_config &cfg = pc_default_config()) {
  uint8_t *p = nullptr;
  size_t size = 0;
  check(pc_compress(src, n, type<T>(), &cfg, &p, &size));
  return buffer(p, size);
}
template <class T> buffer decompress(const uint8_t *src, size_t size) {
  void *p = nullptr;
  size_t n = 0;
  check(pc_decompress(src, size, type<T>(), &p, &n));
  return buffer(p, n * sizeof(T));
}
template <class T> buffer decompress_bounded(const uint8_t *src, size_t size, size_t max_values) {
  void *p = nullptr; size_t n = 0;
  check(pc_decompress_bounded(src, size, type<T>(), max_values, &p, &n));
  return buffer(p, n * sizeof(T));
}
} // namespace pcodec
