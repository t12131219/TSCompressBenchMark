#ifndef PCODEC_NATIVE_H
#define PCODEC_NATIVE_H
#include <stddef.h>
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
/* Values match pco 1.0.4 standalone type identifiers. */
enum pc_type {
  PC_U32 = 1,
  PC_U64,
  PC_I32,
  PC_I64,
  PC_F32,
  PC_F64,
  PC_U16,
  PC_I16,
  PC_F16,
  PC_U8,
  PC_I8
};
enum pc_status {
  PC_OK = 0,
  PC_INVALID = 1,
  PC_NOMEM = 2,
  PC_TRUNCATED = 3,
  PC_CORRUPT = 4,
  PC_UNSUPPORTED = 5,
  PC_LIMIT = 6
};
/* mode: -1 auto, 0 Classic, 2 FloatMult, 3 FloatQuant.
   delta: -1 auto, 0 none, 1..7 consecutive, 8 lookback.
   Default PC_SOURCE_BACKEND=ON uses frozen SourceAuto / Try* fallback.
   OFF is the explicitly reduced C11 NativeAuto build (no f16). */
typedef struct {
  int level, mode, delta, quant_k;
  double base;
  size_t chunk_n;
} pc_config;
pc_config pc_default_config(void);
int pc_source_backend_available(void);
/* Explicit legacy NativeAuto policy; f16 requires source policy. */
int pc_compress_native(const void*,size_t,int,const pc_config*,uint8_t**,size_t*);
size_t pc_type_size(int type);
int pc_compress(const void *src, size_t n, int type, const pc_config *config, uint8_t **dst,
                size_t *dst_size);
/* Additive pure C/C++ IntMult encoder. Exact uint64 base (not a double),
   integer types only, base in 1..type maximum. delta -1 NativeAuto or 0..8.
   Default full build uses Source TryIntMult; reduced build forces native IntMult. */
int pc_compress_intmult(const void *src, size_t n, int type, uint64_t base,
                       int level, int delta, size_t chunk_n, uint8_t **dst, size_t *dst_size);
/* Strict standalone v3 / wrapped 4.1 reader. Caller owns output via pc_free.
   Supports Classic/FloatMult/FloatQuant/IntMult and NoOp/Consecutive/Lookback.
   Default full build supports all Source modes/types, including f16;
   reduced C11 build supports Dict/Conv1 but excludes f16. */
int pc_decompress(const uint8_t *src, size_t size, int expected_type, void **dst, size_t *n);
/* Additive bounded reader. Rejects cumulative output > max_values before
   allocating the offending chunk. Bounds output values, not total scratch or CPU.
   Same format/semantics as pc_decompress; on limit dst=NULL, n=0. */
int pc_decompress_bounded(const uint8_t *src, size_t size, int expected_type,
                          size_t max_values, void **dst, size_t *n);
void pc_free(void *ptr);
const char *pc_error(int code);
#ifdef __cplusplus
}
#endif
#endif
