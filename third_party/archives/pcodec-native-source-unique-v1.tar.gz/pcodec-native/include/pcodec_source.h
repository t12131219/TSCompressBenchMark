#ifndef PCODEC_SOURCE_H
#define PCODEC_SOURCE_H
#include "pcodec.h"
#ifdef __cplusplus
extern "C" {
#endif
/* Additive source-rust backend using frozen pco1.0.4 + documented Dict/Conv1 fixes. Not pure C.
 * Full build pc_* defaults to Source policy; pc_compress_native explicitly selects NativeAuto.
 * Buffers use pcs_buffer_free(data,size), NOT pc_free. Handles own input.
 * Same handle is nonconcurrent; independent handles may run concurrently.
 * Discard decoder after decode error. Limits are output only, not all scratch. */
typedef struct {uint8_t *data; size_t size;} pcs_buffer;
typedef struct {int level,mode,delta,order,quant_k,enable_8_bit;uint64_t int_base;double float_base;size_t max_page_n;} pcs_config;
/* mode -1 SourceAuto,0 Classic,1 TryIntMult,2 TryFloatMult,3 TryFloatQuant,
 * 4 TryDict; source Try* fallback stays active. delta -1 SourceAuto,0 NoOp,
 * 1 Consecutive(order0..7),2 Lookback,3 Conv1(order0..32, <=32bit types).
 * max_page_n1..2^24; u8/i8 require enable_8_bit=1. f16 supported (raw IEEE binary16 bits). */
pcs_config pcs_default_config(void);
int pcs_compress(const void*,size_t,int,const pcs_config*,pcs_buffer*);
int pcs_decompress(const uint8_t*,size_t,int,size_t max_values,pcs_buffer*,size_t*);
/* Genuine wrapped header+metadata and pages. Store type/page counts/lengths
 * in a charged sidecar. NULL exact counts => EqualPagesUpTo; otherwise exact
 * positive partition summing to n. Chunk n1..2^24. Page output arbitrary order. */
typedef struct pcs_encoder pcs_encoder;
int pcs_chunk_new(const void*,size_t,int,const pcs_config*,const size_t*,size_t,pcs_encoder**);
int pcs_chunk_header_meta(const pcs_encoder*,pcs_buffer*);
int pcs_chunk_page(pcs_encoder*,size_t,pcs_buffer*);
int pcs_chunk_page_counts(const pcs_encoder*,pcs_buffer*); /* size_t array */
int pcs_chunk_describe(const pcs_encoder*,pcs_buffer*); /* UTF8 JSON */
void pcs_chunk_destroy(pcs_encoder*);
/* True native incremental output; input is complete compressed file/page,
 * not network push. Wrapped scratch persists across reads/pages. Capacity is
 * positive multiple of256, final tail returned. Standalone may need an empty
 * final read to consume footer. */
typedef struct pcs_decoder pcs_decoder;
int pcs_file_open(const uint8_t*,size_t,int,size_t max_values,pcs_decoder**);
int pcs_wrapped_open(const uint8_t*,size_t,int,pcs_decoder**);
int pcs_wrapped_start_page(pcs_decoder*,const uint8_t*,size_t,size_t n,size_t max_values);
int pcs_read(pcs_decoder*,size_t capacity,pcs_buffer*,size_t* n,int* finished);
int pcs_decoder_describe(const pcs_decoder*,pcs_buffer*);
void pcs_decoder_destroy(pcs_decoder*);
void pcs_buffer_free(uint8_t*,size_t);
const char *pcs_last_error(void);
int pcs_build_info(pcs_buffer*);
#ifdef __cplusplus
}
#endif
#endif
