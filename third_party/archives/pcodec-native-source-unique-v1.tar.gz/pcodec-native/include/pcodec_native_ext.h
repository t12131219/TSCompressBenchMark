#ifndef PCODEC_NATIVE_EXT_H
#define PCODEC_NATIVE_EXT_H
#include "pcodec.h"
#ifdef __cplusplus
extern "C" {
#endif
/* C11 pco 4.1 wrapped/page APIs. Types, mode and delta IDs match the source
 * extension, but automatic mode selection is explicitly NativeAuto (not Rust
 * SourceAuto). No runtime Rust dependency. f16 is not supported.
 * mode -1 NativeAuto,0 Classic,1 IntMult,2 FloatMult,3 FloatQuant,4 Dict.
 * delta -1 NativeAuto,0 NoOp,1 Consecutive(order0..7),2 Lookback,
 * 3 Conv1(order1..32, or 0 selecting native order6). Conv1 primary <=32bits.
 * Dictionary order is frequency descending, ties ordered by value.
 * Conv1 ridge regression/quantization is native, wire-compatible.
 * Allocated buffers belong to caller; pcn_buffer_free releases them.
 * Handles own their inputs and are nonconcurrent; separate handles independent.
 * max_values limits cumulative decoded output; metadata/window allocation has
 * explicit format bounds. Read capacity must be positive multiple of 256.
 */
typedef struct {uint8_t*data;size_t size;} pcn_buffer;
typedef struct {int level,mode,delta,order,quant_k,enable_8_bit;uint64_t int_base;double float_base;size_t max_page_n;} pcn_config;
typedef struct pcn_encoder pcn_encoder;
typedef struct pcn_decoder pcn_decoder;
pcn_config pcn_default_config(void);
int pcn_compress(const void*,size_t,int,const pcn_config*,pcn_buffer*);
int pcn_decompress(const uint8_t*,size_t,int,size_t max_values,pcn_buffer*,size_t*);
/* Metadata is genuinely shared across pages, trained on all page residuals.
 * Exact page counts positive/sum=n, NULL counts selects equal pages <=max_page_n.
 * Save type, page counts and lengths as charged external framing. */
int pcn_chunk_new(const void*,size_t,int,const pcn_config*,const size_t*,size_t,pcn_encoder**);
int pcn_chunk_header_meta(const pcn_encoder*,pcn_buffer*);
int pcn_chunk_page(pcn_encoder*,size_t,pcn_buffer*);
int pcn_chunk_page_counts(const pcn_encoder*,pcn_buffer*);
int pcn_chunk_describe(const pcn_encoder*,pcn_buffer*);
void pcn_chunk_destroy(pcn_encoder*);
int pcn_file_open(const uint8_t*,size_t,int,size_t max_values,pcn_decoder**);
int pcn_wrapped_open(const uint8_t*,size_t,int,pcn_decoder**);
int pcn_wrapped_start_page(pcn_decoder*,const uint8_t*,size_t,size_t n,size_t max_values);
int pcn_read(pcn_decoder*,size_t capacity,pcn_buffer*,size_t*n,int*finished);
int pcn_decoder_describe(const pcn_decoder*,pcn_buffer*);
void pcn_decoder_destroy(pcn_decoder*);
void pcn_buffer_free(uint8_t*,size_t);
#ifdef __cplusplus
}
#endif
#endif
