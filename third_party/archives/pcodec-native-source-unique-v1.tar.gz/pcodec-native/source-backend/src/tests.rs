use super::*;
fn empty() -> Buffer {
    Buffer {
        data: ptr::null_mut(),
        size: 0,
    }
}
#[test]
fn invalid_configuration_clears_outputs() {
    unsafe {
        let x = [1u32, 2, 3];
        let mut b = empty();
        let mut c = pcs_default_config();
        for (mode, delta, order) in [(99, 0, 0), (1, 3, 33), (0, 3, 6)] {
            c.mode = mode;
            c.delta = delta;
            c.order = order;
            let t = if delta == 3 && order == 6 { 2 } else { 1 };
            assert_eq!(
                pcs_compress(x.as_ptr() as *const c_void, 1, t, &c, &mut b),
                1
            );
            assert!(b.data.is_null());
            assert_eq!(b.size, 0);
        }
        c = pcs_default_config();
        assert_eq!(
            pcs_compress(x.as_ptr() as *const c_void, 1, 10, &c, &mut b),
            1
        );
        assert_eq!(
            pcs_compress(x.as_ptr() as *const c_void, 1, 9, &c, &mut b),
            5
        );
        c.mode = 1;
        c.int_base = 0;
        assert_eq!(
            pcs_compress(x.as_ptr() as *const c_void, 1, 1, &c, &mut b),
            1
        );
    }
}
#[test]
fn failed_reader_quarantined_and_partial_limit() {
    unsafe {
        let x = (0..1031u32).collect::<Vec<_>>();
        let mut c = pcs_default_config();
        c.mode = 0;
        c.delta = 0;
        c.max_page_n = 511;
        let mut b = empty();
        assert_eq!(
            pcs_compress(x.as_ptr() as *const c_void, x.len(), 1, &c, &mut b),
            0
        );
        let mut d = ptr::null_mut();
        assert_eq!(pcs_file_open(b.data, b.size, 1, 800, &mut d), 0);
        pcs_buffer_free(b.data, b.size);
        let mut total = 0;
        loop {
            let mut out = empty();
            let mut n = 99;
            let mut done = 99;
            let rc = pcs_read(d, 256, &mut out, &mut n, &mut done);
            if rc != 0 {
                assert_eq!(rc, 6);
                assert_eq!(n, 0);
                assert_eq!(done, 0);
                assert!(out.data.is_null());
                break;
            }
            assert_eq!(
                slice::from_raw_parts(out.data, out.size),
                raw(&x[total..total + n])
            );
            total += n;
            pcs_buffer_free(out.data, out.size);
        }
        assert!(total > 0 && total < 800);
        let mut out = empty();
        let mut n = 9;
        let mut done = 9;
        assert_eq!(pcs_read(d, 256, &mut out, &mut n, &mut done), 1);
        assert_eq!(n, 0);
        pcs_decoder_destroy(d);
    }
}
#[test]
fn decoder_truncation_and_early_drop() {
    unsafe {
        let x = (0..1031u32).collect::<Vec<_>>();
        let mut c = pcs_default_config();
        c.mode = 0;
        c.delta = 0;
        let mut b = empty();
        assert_eq!(
            pcs_compress(x.as_ptr() as *const c_void, x.len(), 1, &c, &mut b),
            0
        );
        for size in [0, 1, 2, b.size / 2, b.size - 1] {
            let mut out = empty();
            let mut n = 99;
            let rc = pcs_decompress(b.data, size, 1, x.len(), &mut out, &mut n);
            assert_ne!(rc, 0);
            assert!(out.data.is_null());
            assert_eq!(n, 0);
        }
        let mut d = ptr::null_mut();
        assert_eq!(pcs_file_open(b.data, b.size, 1, x.len(), &mut d), 0);
        let mut out = empty();
        let mut n = 0;
        let mut done = 0;
        assert_eq!(pcs_read(d, 256, &mut out, &mut n, &mut done), 0);
        pcs_buffer_free(out.data, out.size);
        pcs_decoder_destroy(d);
        pcs_buffer_free(b.data, b.size);
    }
}
