//! Thin C ABI for frozen Rust pco; never redirects old pc_* calls.
use better_io::BetterBufRead;
use pco::{
    data_types::Number,
    metadata::{ChunkMeta, DeltaEncoding, Mode},
    ChunkConfig, DeltaSpec, ModeSpec, PagingSpec,
};
use std::{
    cell::RefCell,
    ffi::{c_char, c_void, CString},
    mem,
    panic::{catch_unwind, AssertUnwindSafe},
    ptr, slice,
};
const MAX_N: usize = 1 << 24;
#[repr(C)]
pub struct Buffer {
    pub data: *mut u8,
    pub size: usize,
}
#[repr(C)]
#[derive(Clone, Copy)]
pub struct Config {
    pub level: i32,
    pub mode: i32,
    pub delta: i32,
    pub order: i32,
    pub quant_k: i32,
    pub enable_8_bit: i32,
    pub int_base: u64,
    pub float_base: f64,
    pub max_page_n: usize,
}
#[derive(Debug)]
struct Error(i32, String);
type Result<T> = std::result::Result<T, Error>;
impl From<pco::errors::PcoError> for Error {
    fn from(e: pco::errors::PcoError) -> Self {
        use pco::errors::ErrorKind::*;
        Self(
            match e.kind {
                InvalidArgument => 1,
                InsufficientData => 3,
                _ => 4,
            },
            e.to_string(),
        )
    }
}
fn invalid(s: &str) -> Error {
    Error(1, s.into())
}
thread_local! {static LAST:RefCell<CString>=RefCell::new(CString::new("").unwrap());}
fn entry(f: impl FnOnce() -> Result<()>) -> i32 {
    let err = match catch_unwind(AssertUnwindSafe(f)) {
        Ok(Ok(())) => return 0,
        Ok(Err(e)) => e,
        Err(_) => Error(4, "source panic contained; discard failed handle".into()),
    };
    LAST.with(|x| *x.borrow_mut() = CString::new(err.1.replace('\0', "?")).unwrap());
    err.0
}
unsafe fn bytes<'a>(p: *const u8, n: usize) -> Result<&'a [u8]> {
    if n > isize::MAX as usize || p.is_null() && n != 0 {
        return Err(invalid("invalid input bytes"));
    }
    Ok(if n == 0 {
        &[]
    } else {
        slice::from_raw_parts(p, n)
    })
}
unsafe fn clear(out: *mut Buffer) -> Result<()> {
    if out.is_null() {
        return Err(invalid("NULL output"));
    }
    *out = Buffer {
        data: ptr::null_mut(),
        size: 0,
    };
    Ok(())
}
unsafe fn emit(out: *mut Buffer, b: Vec<u8>) {
    if b.is_empty() {
        return;
    }
    let mut b = b.into_boxed_slice();
    *out = Buffer {
        data: b.as_mut_ptr(),
        size: b.len(),
    };
    mem::forget(b);
}
fn raw<T: Copy>(v: &[T]) -> Vec<u8> {
    unsafe { slice::from_raw_parts(v.as_ptr() as *const u8, mem::size_of_val(v)).to_vec() }
}
unsafe fn values<T: Number>(p: *const c_void, n: usize) -> Result<Vec<T>> {
    let len = n
        .checked_mul(mem::size_of::<T>())
        .ok_or_else(|| invalid("input overflow"))?;
    let b = bytes(p as *const u8, len)?;
    let mut v = vec![T::default(); n];
    ptr::copy_nonoverlapping(b.as_ptr(), v.as_mut_ptr() as *mut u8, len);
    Ok(v)
}
fn config(c: &Config, t: i32) -> Result<ChunkConfig> {
    if !(0..=12).contains(&c.level)
        || c.max_page_n == 0
        || c.max_page_n > MAX_N
        || !(0..=1).contains(&c.enable_8_bit)
    {
        return Err(invalid("level/page/enable8 range"));
    }
    let float = t == 5 || t == 6 || t == 9;
    let width = match t {
        1 | 3 | 5 => 32,
        2 | 4 | 6 => 64,
        7 | 8 | 9 => 16,
        10 | 11 => 8,
        _ => return Err(Error(5, "unsupported dtype".into())),
    };
    let mode = match c.mode {
        -1 => ModeSpec::Auto,
        0 => ModeSpec::Classic,
        1 => {
            if float || c.int_base == 0 || (width < 64 && c.int_base >= (1u64 << width)) {
                return Err(invalid("IntMult integer/base domain"));
            }
            ModeSpec::TryIntMult(c.int_base)
        }
        2 => {
            let b = if width == 16 { half::f16::from_f64(c.float_base).to_f64() } else if width == 32 {
                c.float_base as f32 as f64
            } else {
                c.float_base
            };
            if !float || !b.is_finite() || b == 0. || !(1. / b).is_finite() {
                return Err(invalid("FloatMult base/type"));
            }
            ModeSpec::TryFloatMult(c.float_base)
        }
        3 => {
            if !float || c.quant_k <= 0 || c.quant_k > if width == 16 { 10 } else if width == 32 { 23 } else { 52 } {
                return Err(invalid("FloatQuant k/type"));
            }
            ModeSpec::TryFloatQuant(c.quant_k as u32)
        }
        4 => ModeSpec::TryDict,
        _ => return Err(invalid("mode")),
    };
    let delta = match c.delta {
        -1 => DeltaSpec::Auto,
        0 => DeltaSpec::NoOp,
        1 if (0..=7).contains(&c.order) => DeltaSpec::TryConsecutive(c.order as usize),
        2 => DeltaSpec::TryLookback,
        3 if (0..=32).contains(&c.order) && width <= 32 => DeltaSpec::TryConv1(c.order as usize),
        _ => return Err(invalid("delta/order/type")),
    };
    Ok(ChunkConfig::default()
        .with_compression_level(c.level as usize)
        .with_mode_spec(mode)
        .with_delta_spec(delta)
        .with_enable_8_bit(c.enable_8_bit == 1)
        .with_paging_spec(PagingSpec::EqualPagesUpTo(c.max_page_n)))
}
macro_rules! dispatch{($t:expr,$f:ident $(,$x:expr)*)=>{match $t{1=>$f::<u32>($($x),*),2=>$f::<u64>($($x),*),3=>$f::<i32>($($x),*),4=>$f::<i64>($($x),*),5=>$f::<f32>($($x),*),6=>$f::<f64>($($x),*),7=>$f::<u16>($($x),*),8=>$f::<i16>($($x),*),9=>$f::<half::f16>($($x),*),10=>$f::<u8>($($x),*),11=>$f::<i8>($($x),*),_=>Err(Error(5,"unsupported dtype".into()))}}}
fn quote(s: &str) -> String {
    let mut o = String::from("\"");
    for c in s.chars() {
        match c {
            '"' => o.push_str("\\\""),
            '\\' => o.push_str("\\\\"),
            '\n' => o.push_str("\\n"),
            c if c.is_control() => o.push('?'),
            c => o.push(c),
        }
    }
    o.push('"');
    o
}
fn describe(m: &ChunkMeta) -> String {
    let mode = match m.mode {
        Mode::Classic => 0,
        Mode::IntMult(_) => 1,
        Mode::FloatMult(_) => 2,
        Mode::FloatQuant(_) => 3,
        Mode::Dict(_) => 4,
        _ => -99,
    };
    let delta = match m.delta_encoding {
        DeltaEncoding::NoOp => 0,
        DeltaEncoding::Consecutive { .. } => 1,
        DeltaEncoding::Lookback { .. } => 2,
        DeltaEncoding::Conv1(_) => 3,
        _ => -99,
    };
    format!("{{\"backend\":\"source-rust-repaired\",\"mode\":{mode},\"delta\":{delta},\"mode_detail\":{},\"delta_detail\":{}}}",quote(&format!("{:?}",m.mode)),quote(&format!("{:?}",m.delta_encoding)))
}
#[derive(Clone)]
struct OwnedRead {
    buf: Vec<u8>,
    pos: usize,
}
impl BetterBufRead for OwnedRead {
    fn fill_or_eof(&mut self, _: usize) -> std::io::Result<&[u8]> {
        Ok(&self.buf[self.pos..])
    }
    fn consume(&mut self, n: usize) {
        self.pos += n;
        assert!(self.pos <= self.buf.len());
    }
    fn capacity(&self) -> Option<usize> {
        None
    }
    fn resize_capacity(&mut self, _: usize) {}
}
trait Decode {
    fn read(&mut self, cap: usize) -> Result<(Vec<u8>, usize, bool)>;
    fn start(&mut self, _: Vec<u8>, _: usize, _: usize) -> Result<()> {
        Err(invalid("not wrapped"))
    }
    fn info(&self) -> String;
}
pub struct Decoder {
    inner: Box<dyn Decode>,
    failed: bool,
}
struct File<T: Number> {
    file: pco::standalone::FileDecompressor,
    src: Option<OwnedRead>,
    chunk: Option<pco::standalone::ChunkDecompressor<T, OwnedRead>>,
    remaining: usize,
    limit: usize,
    total: usize,
    finished: bool,
    infos: Vec<String>,
}
impl<T: Number> Decode for File<T> {
    fn read(&mut self, cap: usize) -> Result<(Vec<u8>, usize, bool)> {
        if self.finished {
            return Ok((vec![], 0, true));
        }
        if self.chunk.is_none() {
            use pco::standalone::DecompressorItem::*;
            match self.file.chunk_decompressor(self.src.take().unwrap())? {
                Chunk(c) => {
                    if c.n() > self.limit - self.total {
                        return Err(Error(
                            6,
                            "cumulative output limit before chunk allocation".into(),
                        ));
                    }
                    self.remaining = c.n();
                    self.total += c.n();
                    self.infos.push(describe(c.meta()));
                    self.chunk = Some(c)
                }
                EndOfData(rest) => {
                    if rest.pos != rest.buf.len() {
                        return Err(Error(4, "standalone trailing bytes".into()));
                    }
                    self.finished = true;
                    return Ok((vec![], 0, true));
                }
            }
        }
        let n = cap.min(self.remaining);
        let mut v = vec![T::default(); n];
        let progress = self.chunk.as_mut().unwrap().read(&mut v)?;
        if progress.n_processed != n {
            return Err(Error(4, "native short decode".into()));
        }
        self.remaining -= n;
        if progress.finished {
            self.src = Some(self.chunk.take().unwrap().into_src());
        }
        Ok((raw(&v), n, false))
    }
    fn info(&self) -> String {
        format!("{{\"backend\":\"source-rust-repaired\",\"kind\":\"standalone\",\"decoded_chunk_headers\":[{}]}}",self.infos.join(","))
    }
}
fn file_new<T: Number + 'static>(b: Vec<u8>, limit: usize) -> Result<Box<dyn Decode>> {
    let (file, src) = pco::standalone::FileDecompressor::new(OwnedRead { buf: b, pos: 0 })?;
    Ok(Box::new(File::<T> {
        file,
        src: Some(src),
        chunk: None,
        remaining: 0,
        limit,
        total: 0,
        finished: false,
        infos: vec![],
    }))
}
// Safe owning page-state adapter added in generated pco. It invokes the
// unchanged native state read routine and reuses the chunk scratch directly.
struct Wrapped<T: Number + 'static> {
    core: pco::wrapped::OwnedPageReader<T, OwnedRead>,
    remaining: usize,
    info: String,
    started: bool,
    active: bool,
}
impl<T: Number + 'static> Decode for Wrapped<T> {
    fn read(&mut self, cap: usize) -> Result<(Vec<u8>, usize, bool)> {
        if !self.started {
            return Err(invalid("no page started"));
        }
        if !self.active {
            return Ok((vec![], 0, true));
        }
        let n = cap.min(self.remaining);
        let mut v = vec![T::default(); n];
        let p = self.core.read(&mut v)?;
        if p.n_processed != n {
            return Err(Error(4, "native page short decode".into()));
        }
        self.remaining -= n;
        if p.finished {
            let rest = self.core.finish_page().unwrap();
            self.active = false;
            if rest.pos != rest.buf.len() {
                return Err(Error(4, "page trailing bytes".into()));
            }
        }
        Ok((raw(&v), n, p.finished))
    }
    fn start(&mut self, b: Vec<u8>, n: usize, limit: usize) -> Result<()> {
        if self.active {
            return Err(invalid("previous page unfinished"));
        }
        if n == 0 || n > MAX_N {
            return Err(invalid("page n domain"));
        }
        if n > limit {
            return Err(Error(6, "page output limit".into()));
        }
        self.core.start_page(OwnedRead { buf: b, pos: 0 }, n)?;
        self.remaining = n;
        self.started = true;
        self.active = true;
        Ok(())
    }
    fn info(&self) -> String {
        self.info.clone()
    }
}
fn wrapped_new<T: Number + 'static>(b: Vec<u8>) -> Result<Box<dyn Decode>> {
    let (fd, src) = pco::wrapped::FileDecompressor::new(b.as_slice())?;
    let (cd, rest) = fd.chunk_decompressor::<T, _>(src)?;
    if !rest.is_empty() {
        return Err(Error(
            4,
            "header+metadata must not contain pages/trailing bytes".into(),
        ));
    }
    let info = describe(cd.meta());
    Ok(Box::new(Wrapped::<T> {
        core: pco::wrapped::OwnedPageReader::new(cd),
        remaining: 0,
        info,
        started: false,
        active: false,
    }))
}
fn compress<T: Number>(p: *const c_void, n: usize, c: &ChunkConfig) -> Result<Vec<u8>> {
    let v = unsafe { values::<T>(p, n)? };
    Ok(pco::standalone::simple_compress(&v, c)?)
}
pub struct Encoder {
    core: pco::wrapped::ChunkCompressor,
    header_meta: Vec<u8>,
    counts: Vec<usize>,
    info: String,
}
fn chunk_new<T: Number>(p: *const c_void, n: usize, c: &ChunkConfig) -> Result<Encoder> {
    let v = unsafe { values::<T>(p, n)? };
    let fc = pco::wrapped::FileCompressor::default();
    let core = fc.chunk_compressor(&v, c)?;
    let mut header_meta = vec![];
    fc.write_header(&mut header_meta)?;
    core.write_meta(&mut header_meta)?;
    let counts = core.n_per_page();
    let info = describe(core.meta());
    Ok(Encoder {
        core,
        header_meta,
        counts,
        info,
    })
}
#[no_mangle]
pub extern "C" fn pcs_default_config() -> Config {
    Config {
        level: 8,
        mode: -1,
        delta: -1,
        order: 0,
        quant_k: 0,
        enable_8_bit: 0,
        int_base: 1,
        float_base: 1.,
        max_page_n: 1 << 18,
    }
}
#[no_mangle]
pub unsafe extern "C" fn pcs_compress(
    p: *const c_void,
    n: usize,
    t: i32,
    c: *const Config,
    out: *mut Buffer,
) -> i32 {
    entry(|| {
        clear(out)?;
        let c = if c.is_null() {
            pcs_default_config()
        } else {
            *c
        };
        let c = config(&c, t)?;
        emit(out, dispatch!(t, compress, p, n, &c)?);
        Ok(())
    })
}
#[no_mangle]
pub unsafe extern "C" fn pcs_chunk_new(
    p: *const c_void,
    n: usize,
    t: i32,
    c: *const Config,
    counts: *const usize,
    pages: usize,
    out: *mut *mut Encoder,
) -> i32 {
    entry(|| {
        if out.is_null() {
            return Err(invalid("NULL encoder output"));
        }
        *out = ptr::null_mut();
        if n == 0 || n > MAX_N {
            return Err(invalid("chunk n1..2^24"));
        }
        let c = if c.is_null() {
            pcs_default_config()
        } else {
            *c
        };
        let mut c = config(&c, t)?;
        if !counts.is_null() {
            if pages == 0 || pages > n {
                return Err(invalid("exact page count"));
            }
            let v = slice::from_raw_parts(counts, pages).to_vec();
            if v.contains(&0) || v.iter().try_fold(0usize, |a, &b| a.checked_add(b)) != Some(n) {
                return Err(invalid("exact page partition"));
            }
            c.paging_spec = PagingSpec::Exact(v);
        } else if pages != 0 {
            return Err(invalid("NULL exact counts"));
        }
        *out = Box::into_raw(Box::new(dispatch!(t, chunk_new, p, n, &c)?));
        Ok(())
    })
}
#[no_mangle]
pub unsafe extern "C" fn pcs_chunk_header_meta(p: *const Encoder, out: *mut Buffer) -> i32 {
    entry(|| {
        clear(out)?;
        let p = p.as_ref().ok_or_else(|| invalid("NULL encoder"))?;
        emit(out, p.header_meta.clone());
        Ok(())
    })
}
#[no_mangle]
pub unsafe extern "C" fn pcs_chunk_page_counts(p: *const Encoder, out: *mut Buffer) -> i32 {
    entry(|| {
        clear(out)?;
        let p = p.as_ref().ok_or_else(|| invalid("NULL encoder"))?;
        emit(out, raw(&p.counts));
        Ok(())
    })
}
#[no_mangle]
pub unsafe extern "C" fn pcs_chunk_describe(p: *const Encoder, out: *mut Buffer) -> i32 {
    entry(|| {
        clear(out)?;
        let p = p.as_ref().ok_or_else(|| invalid("NULL encoder"))?;
        emit(out, p.info.as_bytes().to_vec());
        Ok(())
    })
}
#[no_mangle]
pub unsafe extern "C" fn pcs_chunk_page(p: *mut Encoder, i: usize, out: *mut Buffer) -> i32 {
    entry(|| {
        clear(out)?;
        let p = p.as_mut().ok_or_else(|| invalid("NULL encoder"))?;
        if i >= p.counts.len() {
            return Err(invalid("page index"));
        }
        let mut v = vec![];
        p.core.write_page(i, &mut v)?;
        emit(out, v);
        Ok(())
    })
}
#[no_mangle]
pub unsafe extern "C" fn pcs_chunk_destroy(p: *mut Encoder) {
    if !p.is_null() {
        drop(Box::from_raw(p))
    }
}
#[no_mangle]
pub unsafe extern "C" fn pcs_file_open(
    p: *const u8,
    n: usize,
    t: i32,
    limit: usize,
    out: *mut *mut Decoder,
) -> i32 {
    entry(|| {
        if out.is_null() {
            return Err(invalid("NULL decoder output"));
        }
        *out = ptr::null_mut();
        let inner = dispatch!(t, file_new, bytes(p, n)?.to_vec(), limit)?;
        *out = Box::into_raw(Box::new(Decoder {
            inner,
            failed: false,
        }));
        Ok(())
    })
}
#[no_mangle]
pub unsafe extern "C" fn pcs_wrapped_open(
    p: *const u8,
    n: usize,
    t: i32,
    out: *mut *mut Decoder,
) -> i32 {
    entry(|| {
        if out.is_null() {
            return Err(invalid("NULL decoder output"));
        }
        *out = ptr::null_mut();
        let inner = dispatch!(t, wrapped_new, bytes(p, n)?.to_vec())?;
        *out = Box::into_raw(Box::new(Decoder {
            inner,
            failed: false,
        }));
        Ok(())
    })
}
#[no_mangle]
pub unsafe extern "C" fn pcs_wrapped_start_page(
    p: *mut Decoder,
    b: *const u8,
    n: usize,
    values: usize,
    limit: usize,
) -> i32 {
    entry(|| {
        let p = p.as_mut().ok_or_else(|| invalid("NULL decoder"))?;
        if p.failed {
            return Err(invalid("failed decoder; discard"));
        }
        let input = bytes(b, n)?.to_vec();
        p.failed = true;
        let r = p.inner.start(input, values, limit);
        p.failed = matches!(&r,Err(e) if e.0!=1&&e.0!=6);
        r
    })
}
#[no_mangle]
pub unsafe extern "C" fn pcs_read(
    p: *mut Decoder,
    cap: usize,
    out: *mut Buffer,
    n: *mut usize,
    done: *mut i32,
) -> i32 {
    entry(|| {
        clear(out)?;
        if !n.is_null() {
            *n = 0
        }
        if !done.is_null() {
            *done = 0
        }
        if n.is_null() || done.is_null() || cap == 0 || cap % 256 != 0 {
            return Err(invalid("read capacity: positive multiple of256"));
        }
        let p = p.as_mut().ok_or_else(|| invalid("NULL decoder"))?;
        if p.failed {
            return Err(invalid("failed decoder; discard"));
        }
        p.failed = true;
        match p.inner.read(cap) {
            Ok((v, k, end)) => {
                p.failed = false;
                emit(out, v);
                *n = k;
                *done = end as i32;
                Ok(())
            }
            Err(e) => {
                p.failed = true;
                Err(e)
            }
        }
    })
}
#[no_mangle]
pub unsafe extern "C" fn pcs_decoder_describe(p: *const Decoder, out: *mut Buffer) -> i32 {
    entry(|| {
        clear(out)?;
        let p = p.as_ref().ok_or_else(|| invalid("NULL decoder"))?;
        emit(out, p.inner.info().into_bytes());
        Ok(())
    })
}
#[no_mangle]
pub unsafe extern "C" fn pcs_decoder_destroy(p: *mut Decoder) {
    if !p.is_null() {
        drop(Box::from_raw(p))
    }
}
#[no_mangle]
pub unsafe extern "C" fn pcs_decompress(
    p: *const u8,
    len: usize,
    t: i32,
    limit: usize,
    out: *mut Buffer,
    n: *mut usize,
) -> i32 {
    entry(|| {
        clear(out)?;
        if n.is_null() {
            return Err(invalid("NULL count"));
        }
        *n = 0;
        let mut reader = dispatch!(t, file_new, bytes(p, len)?.to_vec(), limit)?;
        let mut v = vec![];
        let mut count = 0;
        loop {
            let (b, k, done) = reader.read(256)?;
            v.extend_from_slice(&b);
            count += k;
            if done {
                break;
            }
        }
        emit(out, v);
        *n = count;
        Ok(())
    })
}
#[no_mangle]
pub unsafe extern "C" fn pcs_buffer_free(p: *mut u8, len: usize) {
    if !p.is_null() {
        drop(Box::from_raw(ptr::slice_from_raw_parts_mut(p, len)))
    }
}
#[no_mangle]
pub extern "C" fn pcs_last_error() -> *const c_char {
    LAST.with(|x| x.borrow().as_ptr())
}
#[no_mangle]
pub unsafe extern "C" fn pcs_build_info(out: *mut Buffer) -> i32 {
    entry(|| {
        clear(out)?;
        emit(out,format!("{{\"backend\":\"source-rust-repaired\",\"pco\":\"1.0.4\",\"internal_threads\":1,\"avx2_compiled\":{},\"bmi2_compiled\":{},\"lzcnt_compiled\":{}}}",cfg!(target_feature="avx2"),cfg!(target_feature="bmi2"),cfg!(target_feature="lzcnt")).into_bytes());
        Ok(())
    })
}

#[cfg(test)]
mod tests;
