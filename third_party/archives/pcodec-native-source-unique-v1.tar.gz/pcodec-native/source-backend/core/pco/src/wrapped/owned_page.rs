//! Owning storage for the existing page state, without self-referential borrows.
//! The original PageDecompressor remains unchanged. No prediction/ANS logic here.
use better_io::BetterBufRead;
use crate::data_types::Number;
use crate::dyn_slices::DynNumberSliceMut;
use crate::errors::{PcoError,PcoResult};
use crate::progress::Progress;
use crate::wrapped::{ChunkDecompressor,PageDecompressorState};
pub struct OwnedPageReader<T:Number,R:BetterBufRead>{
 cd:ChunkDecompressor<T>,state:Option<PageDecompressorState<R>>,
}
impl<T:Number,R:BetterBufRead> OwnedPageReader<T,R>{
 pub fn new(cd:ChunkDecompressor<T>)->Self{Self{cd,state:None}}
 pub fn start_page(&mut self,src:R,n:usize)->PcoResult<()>{
  if self.state.is_some(){return Err(PcoError::invalid_argument("previous page active"))}
  self.state=Some(PageDecompressorState::new(src,&self.cd.inner,n)?);Ok(())
 }
 pub fn read(&mut self,dst:&mut[T])->PcoResult<Progress>{
  self.state.as_mut().ok_or_else(||PcoError::invalid_argument("no active page"))?
    .read(&mut self.cd.inner,DynNumberSliceMut::new(dst))
 }
 pub fn finish_page(&mut self)->Option<R>{self.state.take().map(|p|p.into_src())}
}
