<p align="center">
  <img alt="Pco logo: a pico-scale, compressed version of the Pyramid of Khafre in the palm of your hand" src="https://raw.githubusercontent.com/pcodec/pcodec/cac902e714077426d915f4fc397508b187c72380/images/logo.svg" width="160px">
</p>

Pco (Pcodec) losslessly compresses and decompresses numerical sequences with
high compression ratio and moderately fast speed.

For pcodec's uses, design, and benchmarks,
[see the main repo](https://github.com/pcodec/pcodec).

# Quick Start

```rust
use pco::ChunkConfig;
use pco::errors::PcoResult;
use pco::standalone::{simple_compress, simple_decompress};

fn main() -> PcoResult<()> {
  // your data
  let mut my_nums = Vec::new();
  for i in 0..100000 {
    my_nums.push(i as i64);
  }

  // compress
  let compressed: Vec<u8> = simple_compress(&my_nums, &ChunkConfig::default())?;
  println!("compressed down to {} bytes", compressed.len());

  // decompress
  let recovered: Vec<i64> = simple_decompress(&compressed)?;
  assert_eq!(recovered, my_nums);
  Ok(())
}
```

# Compilation Notes

**For best performance on x86_64, compile with `bmi1`, `bmi2`, `lzcnt`, and `avx2`**.
This improves compression speed slightly and decompression speed substantially!
Almost all hardware nowadays supports these instruction sets.
To make sure you're using these, you can:

* Add the following to your `~/.cargo/config.toml`:
```toml
[target.'cfg(target_arch = "x86_64")']
rustflags = ["-C", "target-feature=+bmi1,+bmi2,+lzcnt,+avx2"]
```
* OR compile with `RUSTFLAGS="-C target-feature=+bmi1,+bmi2,+lzcnt,+avx2" cargo build --release ...`

Note that setting `target-cpu=native` does not always have the same effect,
since LLVM compiles for the lowest common denominator of instructions for a
broad CPU family.
