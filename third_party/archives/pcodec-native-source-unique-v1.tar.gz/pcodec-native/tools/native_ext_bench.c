#define _POSIX_C_SOURCE 200809L
#include "pcodec_native_ext.h"
#include <errno.h>
#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

static void fail(const char *message) { fprintf(stderr, "%s\n", message); exit(2); }
static long integer(const char *s, long lo, long hi) {
  char *end; errno = 0; long v = strtol(s, &end, 10);
  if (errno || !*s || *end || v < lo || v > hi) fail("invalid integer argument");
  return v;
}
static uint64_t now(void) {
  struct timespec t; clock_gettime(CLOCK_MONOTONIC, &t);
  return (uint64_t)t.tv_sec*UINT64_C(1000000000)+(uint64_t)t.tv_nsec;
}
static void check(int status) { if (status) fail(pc_error(status)); }
int main(int argc, char **argv) {
  if (argc < 7 || argc > 11) fail(
    "usage: pcodec_native_ext INPUT TYPE_ID MODE DELTA ORDER REPEATS [PAGE [INT_BASE [FLOAT_BASE [QUANT_K]]]]");
  int type = (int)integer(argv[2], 1, 11);
  pcn_config c = pcn_default_config(); c.enable_8_bit = 1;
  c.mode = (int)integer(argv[3], -1, 4); c.delta = (int)integer(argv[4], -1, 3);
  c.order = (int)integer(argv[5], 0, 32); long repeats = integer(argv[6], 1, 10000);
  if (argc > 7) c.max_page_n = (size_t)integer(argv[7], 1, 1L<<24);
  if (argc > 8) {
    char *end; errno = 0; c.int_base = strtoull(argv[8], &end, 10);
    if (errno || !*argv[8] || *end || argv[8][0]=='-') fail("invalid int base");
  }
  if (argc > 9) { char *end; errno=0; c.float_base=strtod(argv[9],&end);
    if (errno || !*argv[9] || *end) fail("invalid float base"); }
  if (argc > 10) c.quant_k = (int)integer(argv[10], 0, 52);
  FILE *f = fopen(argv[1], "rb"); if (!f) fail("open input");
  if (fseek(f,0,SEEK_END)) fail("seek input"); long length=ftell(f);
  if (length<=0 || length>(1L<<30) || (size_t)length%pc_type_size(type)) fail("input size");
  rewind(f); size_t bytes=(size_t)length, n=bytes/pc_type_size(type);
  uint8_t *raw=malloc(bytes); if (!raw) fail("allocate input");
  if (fread(raw,1,bytes,f)!=bytes || fclose(f)) fail("read input");
  pcn_buffer wire={NULL,0}, decoded={NULL,0}; size_t count=0, compressed=0;
  uint64_t encode_ns=0, decode_ns=0;
  for (long i=0;i<repeats;i++) {
    uint64_t start=now(); check(pcn_compress(raw,n,type,&c,&wire)); encode_ns+=now()-start;
    compressed=wire.size; start=now();
    check(pcn_decompress(wire.data,wire.size,type,n,&decoded,&count)); decode_ns+=now()-start;
    if (count!=n || decoded.size!=bytes || memcmp(raw,decoded.data,bytes)) fail("roundtrip mismatch");
    pcn_buffer_free(wire.data,wire.size); pcn_buffer_free(decoded.data,decoded.size);
  }
  printf("{\"backend\":\"C11\",\"auto_policy\":\"NativeAuto\",\"values\":%zu,"
         "\"raw_bytes\":%zu,\"compressed_bytes\":%zu,\"repeats\":%ld,"
         "\"mean_encode_ns\":%.1f,\"mean_decode_ns\":%.1f,\"verified\":true}\n",
         n,bytes,compressed,repeats,(double)encode_ns/repeats,(double)decode_ns/repeats);
  free(raw); return 0;
}
