#define _POSIX_C_SOURCE 200809L
#include "pcodec.h"
#ifdef PC_CPP_DRIVER
#include "pcodec.hpp"
#endif
#include <inttypes.h>
#include <errno.h>
#include <limits.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#define MAX2(a, b) ((a) > (b) ? (a) : (b))
static uint64_t ns(void) {
  struct timespec t;
  clock_gettime(CLOCK_MONOTONIC, &t);
  return (uint64_t)t.tv_sec * 1000000000 + (uint64_t)t.tv_nsec;
}
static void fail(const char *msg) {
  fprintf(stderr, "%s\n", msg);
  exit(2);
}
static void ck(int e) {
  if (e)
    fail(pc_error(e));
}
static uint8_t *readfile(const char *path, size_t *n) {
  FILE *f = fopen(path, "rb");
  if (!f)
    fail("open input");
  if (fseek(f, 0, SEEK_END))
    fail("seek");
  long len = ftell(f);
  if (len < 0)
    fail("tell");
  rewind(f);
  *n = (size_t)len;
  uint8_t *p = (uint8_t *)malloc(*n + 1);
  if (!p)
    fail("alloc");
  if (fread(p, 1, *n, f) != *n)
    fail("read");
  fclose(f);
  return p;
}
static void writefile(const char *path, const void *p, size_t n) {
  FILE *f = fopen(path, "wb");
  if (!f)
    fail("open output");
  if (fwrite(p, 1, n, f) != n)
    fail("write");
  if (fclose(f)) fail("close output");
}
static int type(const char *s) {
  const char *names[] = {"",    "u32", "u64", "i32", "i64", "f32",
                         "f64", "u16", "i16", "f16", "u8",  "i8"};
  for (int i = 1; i <= 11; i++)
    if (!strcmp(s, names[i]))
      return i;
  fail("unknown type");
  return 0;
}
static pc_config config(const char *s) {
  pc_config c = pc_default_config();
  if (!strcmp(s, "auto"))
    return c;
  if (!strcmp(s, "classic")) {
    c.mode = 0;
    c.delta = 0;
    return c;
  }
  if (!strcmp(s, "classic-auto")) {
    c.mode = 0;
    return c;
  }
  int mode = 0, delta = 0, k = 0;
  double base = 1;
  int used = 0;
  if (sscanf(s, "fixed:%d:%d:%d:%lf%n", &mode, &delta, &k, &base, &used) != 4 || s[used] || !isfinite(base))
    fail("unknown profile");
  c.mode = mode;
  c.delta = delta;
  c.quant_k = k;
  c.base = base;
  return c;
}
static int encode(const void *raw, size_t n, int t, const pc_config *c, uint8_t **p, size_t *sz) {
#ifdef PC_CPP_DRIVER
  try {
    if (t == PC_F64) {
      auto b = pcodec::compress((const double *)raw, n, *c);
      *sz = b.size();
      *p = (uint8_t *)malloc(*sz);
      if (!*p)
        return PC_NOMEM;
      memcpy(*p, b.data(), *sz);
      return 0;
    }
  } catch (const std::exception &e) {
    fail(e.what());
  }
#endif
  return pc_compress(raw, n, t, c, p, sz);
}
/* Timed calls directly own the same engine allocations in both languages. */
static void timed_encode(const void *raw, size_t n, int t, const pc_config *c, size_t expected) {
#ifdef PC_CPP_DRIVER
  if (t == PC_F64) {
    auto b = pcodec::compress((const double *)raw, n, *c);
    if (b.size() != expected)
      fail("nondeterministic size");
    return;
  }
  if (t == PC_F32) {
    auto b = pcodec::compress((const float *)raw, n, *c);
    if (b.size() != expected)
      fail("nondeterministic size");
    return;
  }
#endif
  uint8_t *p = NULL;
  size_t sz = 0;
  ck(pc_compress(raw, n, t, c, &p, &sz));
  if (sz != expected)
    fail("nondeterministic size");
  pc_free(p);
}
static void timed_decode(const uint8_t *src, size_t sz, int t, size_t n) {
#ifdef PC_CPP_DRIVER
  if (t == PC_F64) {
    auto b = pcodec::decompress<double>(src, sz);
    if (b.size() != n * 8)
      fail("wrong size");
    return;
  }
  if (t == PC_F32) {
    auto b = pcodec::decompress<float>(src, sz);
    if (b.size() != n * 4)
      fail("wrong size");
    return;
  }
#endif
  void *p = NULL;
  size_t count = 0;
  ck(pc_decompress(src, sz, t, &p, &count));
  if (count != n)
    fail("wrong count");
  pc_free(p);
}
static int repeats(const char *s) {
  char *end; errno=0; long v=strtol(s,&end,10);
  if(errno || end==s || *end || v<1 || v>31)fail("repeats 1..31");
  return (int)v;
}
static double target_ms(const char *s) {
  char *end; errno=0; double v=strtod(s,&end);
  if(errno || end==s || *end || !isfinite(v) || v<=0)fail("invalid target time");
  return v;
}
int main(int argc, char **argv) {
  if (argc < 6)
    fail("usage: driver encode|decode|bench|bench-decode type profile input output|repeats "
         "[target_ms]");
  int t = type(argv[2]);
  pc_config c = config(argv[3]);
  size_t len = 0;
  uint8_t *raw = readfile(argv[4], &len);
  if (!strcmp(argv[1], "decode")) {
    void *p = NULL;
    size_t n = 0;
    ck(pc_decompress(raw, len, t, &p, &n));
    writefile(argv[5], p, n * pc_type_size(t));
    pc_free(p);
    free(raw);
    return 0;
  }
  if (!strcmp(argv[1], "bench-decode")) {
    void *out = NULL;
    size_t n = 0;
    ck(pc_decompress(raw, len, t, &out, &n));
    pc_free(out);
    int reps = repeats(argv[5]);
    if (reps < 1 || reps > 31)
      fail("repeats 1..31");
    double target = argc > 6 ? target_ms(argv[6]) : 30;
    uint64_t begin = ns();
    timed_decode(raw, len, t, n);
    uint64_t duration = ns() - begin;
    unsigned loops = (unsigned)fmin(2000, fmax(1, ceil(target * 1e6 / MAX2(duration, 1))));
    printf("{\"n\":%zu,\"compressed_bytes\":%zu,\"dec_loops\":%u,\"dec_ns\":[", n, len, loops);
    for (int rep = 0; rep < reps; rep++) {
      begin = ns();
      for (unsigned j = 0; j < loops; j++)
        timed_decode(raw, len, t, n);
      printf("%s%.3f", rep ? "," : "", (double)(ns() - begin) / loops);
    }
    puts("]}");
    free(raw);
    return 0;
  }
  if (len % pc_type_size(t))
    fail("bad raw size");
  size_t n = len / pc_type_size(t), sz = 0;
  uint8_t *p = NULL;
  ck(encode(raw, n, t, &c, &p, &sz));
  if (!strcmp(argv[1], "encode")) {
    writefile(argv[5], p, sz);
    pc_free(p);
    free(raw);
    return 0;
  }
  if (strcmp(argv[1], "bench"))
    fail("bad command");
  void *out = NULL;
  size_t got = 0;
  ck(pc_decompress(p, sz, t, &out, &got));
  if (got != n || memcmp(raw, out, len))
    fail("lossless verification failed");
  pc_free(out);
  int reps = repeats(argv[5]);
  if (reps < 1 || reps > 31)
    fail("repeats 1..31");
  double target = argc > 6 ? target_ms(argv[6]) : 30;
  uint64_t enc[31], dec[31];
  unsigned loops[2] = {1, 1};
  for (int op = 0; op < 2; op++) {
    uint64_t begin = ns();
    if (op)
      timed_decode(p, sz, t, n);
    else
      timed_encode(raw, n, t, &c, sz);
    uint64_t duration = ns() - begin;
    double want = target * 1000000.0 / (double)MAX2(duration, 1);
    loops[op] = (unsigned)fmin(2000, fmax(1, ceil(want)));
    for (int r = 0; r < reps; r++) {
      begin = ns();
      for (unsigned l = 0; l < loops[op]; l++) {
        if (op)
          timed_decode(p, sz, t, n);
        else
          timed_encode(raw, n, t, &c, sz);
      }
      uint64_t elapsed = ns() - begin;
      if (op)
        dec[r] = elapsed;
      else
        enc[r] = elapsed;
    }
  }
  printf("{\"n\":%zu,\"compressed_bytes\":%zu,\"enc_loops\":%u,\"dec_loops\":%u,\"enc_ns\":[", n,
         sz, loops[0], loops[1]);
  for (int r = 0; r < reps; r++)
    printf("%s%.3f", r ? "," : "", (double)enc[r] / loops[0]);
  printf("],\"dec_ns\":[");
  for (int r = 0; r < reps; r++)
    printf("%s%.3f", r ? "," : "", (double)dec[r] / loops[1]);
  puts("]}");
  pc_free(p);
  free(raw);
  return 0;
}
