# pcodec-native · unique-v1

本工程只交付一个主选实现 `pcodec_c`，覆盖 11 pcodec / pco。

## 构建

```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j4
```

支持Linux x86_64，GCC/G++、CMake≥3.22、make。ISA要求及运行约束见下表。工程自带所需源码依赖；构建输出不在发布包内。

PC_SOURCE_BACKEND=ON 启用显式Rust功能组件，需要离线Cargo；默认C11功能完整保留。

独立C/C++对照、历史版本、上游oracle及独立验证程序不交付。辅助库、共享格式代码、ISA加速和训练/流式等模块服务于同一主实现。`reference`、`fpc-original` 等历史target名称是CSV主选标识，不代表存在另一份并列实现。

## 11. pcodec / pco

| 属性 | 支持范围与限制 |
| --- | --- |
| 技术家族 | 数值变换+delta+ANS |
| 方法角色 | 完整数值codec |
| 编码流水线 | mode变换+delta+bin训练+ANS/bitpack |
| 原生类型 | pc_*/pcn_*：i32/u32/i64/u64/f32/f64；不支持f16 |
| 输入适配 | 原生类型模型，非字节通用压缩 |
| 数值域与特殊值 | 模式按类型/基数校验；Conv1直接主潜变量≤32bit，64bit原数据可先Dict生成32bit潜变量；不外推任意组合 |
| 形状与多变量 | 单变量1D |
| 时间轴或显式x | 不支持：仅隐式样本序号 |
| 布局与stride | 连续数组 |
| 缺失值语义 | 未声明原生mask；不隐式插补 |
| 恢复与质量合同 | 声明域内位级无损 |
| 核心参数 | 默认pc_*：NativeAuto level8/chunk262144；显式pcn_*支持Dict、Conv1、IntMult/FloatMult/FloatQuant、delta及pages；NativeAuto不自动搜索新增Dict/Conv1 |
| 批处理 | 支持：整输入调用 |
| 增量编码 | 条件支持：C11 pcn_chunk_*整chunk训练/共享meta后任意页生成顺序；不是逐值在线训练 |
| 增量解码 | 支持：C11 pcn_wrapped_open/start_page与pcn_read保留预测状态增量解码；capacity须为正256倍数；原pc_decompress_bounded可解Dict/Conv1 |
| 状态与复用 | C11 chunk元数据与page预测状态；wrapped decoder的max_values为累计限额 |
| 点范围与seek | 条件支持：C11 wrapped显式选页，调用方保存meta及页边界；非任意值O(1)访问 |
| 渐进恢复 | 不支持：所选核心无此公开入口 |
| 压缩域计算 | 不支持：所选核心无此公开入口 |
| 训练或在线学习 | C11 chunk统计/Dict建表；Conv1 ridge/Cholesky拟合、量化及预测；非SourceAuto等价搜索 |
| 字典码本复用 | 支持：C11 pcn_*显式Dict；共享chunk元数据多页；旧默认NativeAuto不自动选新增模式 |
| SIMD或ISA | 主选V4保留批次/SIMD解码及PC_NATIVE构建；新增C11 Dict/Conv1入口不额外宣称SIMD |
| 内部并行编码 | 不支持：所选调用路径串行 |
| 内部并行解码 | 不支持：所选调用路径串行 |
| GPU | 未确认：未对该冻结核心建立GPU入口证据 |
| 并发与所有权 | 独立handle并发，失败handle丢弃；不同free不可混用 |
| 格式与兼容 | C11 pco standalone及wrapped/pages；显式模式有双向参考互解证据，非全参数兼容声明 |
| 独立恢复依赖 | 完整流或wrapped头/meta/类型/页长度/计数/边界须计费；free函数按API匹配 |
| 运行与构建依赖 | 主选及新增能力C11；默认PC_SOURCE_BACKEND=OFF；pcodec_native_ext原生CLI；Rust仅显式扩展/验证依赖 |
| 长度尾部与资源 | pcn_read容量正256倍数、累计输出上限；f16不支持；Conv1潜变量位宽和类型组合显式校验 |
| 确定性条件 | 原生种子/配置固定下验证；不承诺与Rust Auto选模或Dict等频顺序逐字节一致 |
| 许可范围 | 源码许可声明及 fix_ReWrite/pcodec-native/licenses 中的冻结归属材料。 |
| 已知限制与身份 | SourceAuto尚未原生等价移植，Try体积兜底不承诺相同；296组双向配置参考为明确修复Dict尾批/Conv1短页的Rust生成副本，非全部未经修改上游 |
