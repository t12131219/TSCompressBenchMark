#define _POSIX_C_SOURCE 200809L
#include "gorilla.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <stdint.h>
#ifdef DIRECT_CPP
#include "gorilla.hpp"
#endif
static volatile uint64_t sink;
static void fail(const char *s) { fprintf(stderr,"%s\n",s); exit(1); }
static void raw_write(FILE *f,int64_t time,uint64_t value) {
    uint64_t u; unsigned j; memcpy(&u,&time,8);
    for(j=0;j<8;++j) fputc((int)((u>>(8*j))&255),f);
    for(j=0;j<8;++j) fputc((int)((value>>(8*j))&255),f);
}
static size_t encode(const g_sample *p,size_t n,g_buffer *capture) {
#ifdef DIRECT_CPP
    auto b=gorilla::compress(p,n); size_t size=b.size();
    if(capture) { capture->data=(uint8_t*)malloc(size); if(!capture->data) fail("oom"); memcpy(capture->data,b.data(),size); capture->size=size; }
    sink^=b.back(); return size;
#else
    g_buffer b={0}; if(g_compress(p,n,&b)!=G_OK) fail("encode error");
    size_t size=b.size; sink^=b.data[size-1]; if(capture) *capture=b; else g_free(b.data); return size;
#endif
}
static void decode(const g_buffer *b,FILE *f) {
#ifdef DIRECT_CPP
    auto values=gorilla::decompress(b->data,b->size); const g_sample *p=values.data(); size_t n=values.size();
#else
    g_array values={0}; if(g_decompress(b->data,b->size,65535,&values)!=G_OK) fail("decode error");
    const g_sample *p=values.data; size_t n=values.count;
#endif
    /* Observe every decoded pair, equally for Go/C/C++; writing is outside timing. */
    uint64_t checksum=0; size_t i;
    for(i=0;i<n;++i) { uint64_t t; memcpy(&t,&p[i].timestamp,8); checksum^=t+p[i].bits; if(f) raw_write(f,p[i].timestamp,p[i].bits); }
    sink^=checksum;
#ifndef DIRECT_CPP
    g_free(values.data);
#endif
}
static double now(void) { struct timespec t; clock_gettime(CLOCK_MONOTONIC,&t); return (double)t.tv_sec+(double)t.tv_nsec*1e-9; }
static int compare(const void *a,const void *b) { double x=*(const double*)a,y=*(const double*)b; return (x>y)-(x<y); }
static uint8_t *readfile(const char *path,size_t *size) {
    FILE *f=fopen(path,"rb"); if(!f) fail("cannot open input");
    if(fseek(f,0,SEEK_END)) fail("seek failed");
    long n=ftell(f); if(n<0) fail("size failed"); rewind(f);
    uint8_t *p=(uint8_t*)malloc((size_t)n+1); if(!p) fail("oom");
    if(fread(p,1,(size_t)n,f)!=(size_t)n) fail("read failed");
    fclose(f); *size=(size_t)n; return p;
}
static uint64_t little(const uint8_t *p) { uint64_t u=0; unsigned j; for(j=0;j<8;++j) u|=(uint64_t)p[j]<<(8*j); return u; }
int main(int argc,char **argv) {
    if(argc<3) fail("usage: runner encode RAW PACKED | decode PACKED RAW | bench RAW");
    size_t bytes; uint8_t *raw=readfile(argv[2],&bytes);
    if(!strcmp(argv[1],"decode")) {
        if(argc!=4) fail("output required");
        FILE *f=fopen(argv[3],"wb"); if(!f) fail("output open failed"); size_t pos=0;
        while(pos<bytes) {
            if(bytes-pos<8) fail("bad transport length");
            uint64_t size=0; unsigned j;
            for(j=0;j<8;++j) size=(size<<8)|raw[pos++];
            if(size>bytes-pos) fail("bad transport payload");
            g_buffer b={raw+pos,(size_t)size}; decode(&b,f); pos+=(size_t)size;
        }
        if(fclose(f)) fail("output write failed");
        free(raw); return 0;
    }
    if(bytes%16) fail("input must contain 16-byte LE timestamp/bits records");
    size_t count=bytes/16,i; g_sample *samples=(g_sample*)malloc((count+1)*sizeof(g_sample)); if(!samples) fail("oom");
    for(i=0;i<count;++i) { uint64_t u=little(raw+16*i); memcpy(&samples[i].timestamp,&u,8); samples[i].bits=little(raw+16*i+8); } free(raw);
    size_t blocks=(count+511)/512,compressed=0; g_buffer *chunks=(g_buffer*)calloc(blocks+1,sizeof(g_buffer)); if(!chunks) fail("oom");
    for(i=0;i<blocks;++i) { size_t n=count-i*512; if(n>512) n=512; compressed+=encode(samples+i*512,n,&chunks[i]); }
    if(!strcmp(argv[1],"encode")) {
        if(argc!=4) fail("output required");
        FILE *f=fopen(argv[3],"wb"); if(!f) fail("output open failed");
        for(i=0;i<blocks;++i) { unsigned j; for(j=0;j<8;++j) fputc((int)(((uint64_t)chunks[i].size>>(56-8*j))&255),f); if(fwrite(chunks[i].data,1,chunks[i].size,f)!=chunks[i].size) fail("write failed"); }
        if(fclose(f)) fail("output write failed");
    } else if(!strcmp(argv[1],"bench")) {
        if(!count) fail("empty benchmark");
        size_t loops=(100000+count-1)/count; if(loops>1000) loops=1000; double enc[7],dec[7]; size_t k,l;
        for(k=0;k<8;++k) {
            double start=now();
            for(l=0;l<loops;++l) for(i=0;i<blocks;++i) { size_t n=count-i*512; if(n>512) n=512; sink^=encode(samples+i*512,n,NULL); }
            double et=(now()-start)/(double)loops; start=now();
            for(l=0;l<loops;++l) for(i=0;i<blocks;++i) decode(&chunks[i],NULL);
            double dt=(now()-start)/(double)loops;
            if(k) { enc[k-1]=et; dec[k-1]=dt; }
        }
        qsort(enc,7,sizeof(double),compare); qsort(dec,7,sizeof(double),compare);
        printf("{\"count\":%zu,\"compressed_bytes\":%zu,\"blocks\":%zu,\"loops\":%zu,\"encode_seconds\":%.12g,\"decode_seconds\":%.12g,\"encode_runs\":[",count,compressed,blocks,loops,enc[3],dec[3]);
        for(i=0;i<7;++i) printf("%s%.12g",i?",":"",enc[i]);
        printf("],\"decode_runs\":[");
        for(i=0;i<7;++i) printf("%s%.12g",i?",":"",dec[i]);
        puts("]}");
    } else fail("unknown operation");
    for(i=0;i<blocks;++i) free(chunks[i].data);
    free(chunks); free(samples); return 0;
}
