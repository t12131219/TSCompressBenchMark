# gorilla-native · unique-v1

本工程只交付一个主选实现 `gorilla_c`，覆盖 7 Gorilla / XORChunk。

## 构建

```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j4
```

支持Linux x86_64，GCC/G++、CMake≥3.22、make。ISA要求及运行约束见下表。工程自带所需源码依赖；构建输出不在发布包内。

默认构建包含本工程主选功能组件。

独立C/C++对照、历史版本、上游oracle及独立验证程序不交付。辅助库、共享格式代码、ISA加速和训练/流式等模块服务于同一主实现。`reference`、`fpc-original` 等历史target名称是CSV主选标识，不代表存在另一份并列实现。

## 7. Gorilla / XORChunk

| 属性 | 支持范围与限制 |
| --- | --- |
| 技术家族 | 时间差分+浮点XOR |
| 方法角色 | 完整timestamp/value chunk codec |
| 编码流水线 | 时间delta-of-delta+XOR窗口 |
| 原生类型 | int64 timestamp + binary64 value |
| 输入适配 | 原生时间轴与浮点位型 |
| 数值域与特殊值 | 全部binary64位型；有符号64位时间按Go wraparound语义 |
| 形状与多变量 | 单value列+时间轴 |
| 时间轴或显式x | 原生signed毫秒timestamp；seek时间定位要求非递减轴 |
| 布局与stride | 连续数组 |
| 缺失值语义 | 未声明原生mask；不隐式插补 |
| 恢复与质量合同 | timestamp/value位级恢复 |
| 核心参数 | chunk大小、batch/online、resume位置、seek目标 |
| 批处理 | 支持：整输入调用 |
| 增量编码 | 支持：Appender/append立即编码 |
| 增量解码 | 支持：Iterator/next逐样本 |
| 状态与复用 | append/snapshot/finish/reset/resume；resume扫描与复制须计时 |
| 点范围与seek | 条件支持：仅forward seek，逐token扫描，非O(1)索引 |
| 渐进恢复 | 不支持：所选核心无此公开入口 |
| 压缩域计算 | 不支持：所选核心无此公开入口 |
| 训练或在线学习 | 时间/XOR窗口在线状态，无外部训练 |
| 字典码本复用 | 不支持：所选核心无此公开入口 |
| SIMD或ISA | 无所选核显式SIMD后端 |
| 内部并行编码 | 不支持：所选调用路径串行 |
| 内部并行解码 | 不支持：所选调用路径串行 |
| GPU | 未确认：未对该冻结核心建立GPU入口证据 |
| 并发与所有权 | 独立对象可并发，同对象独占；iterator借不可变chunk |
| 格式与兼容 | XORChunk原生2字节头；无CRC |
| 独立恢复依赖 | 类型/原生chunk grammar固定；多chunk需保存边界 |
| 运行与构建依赖 | 唯一C11主核；batch/append/resume/iterator/forward-seek。 |
| 长度尾部与资源 | 单chunk最多65535样本 |
| 确定性条件 | 未确认：未建立跨平台字节确定性保证 |
| 许可范围 | 源码许可声明及 fix_ReWrite/gorilla-native/licenses 中的冻结归属材料。 |
| 已知限制与身份 | 批量decoder初始XOR窗口修复，接受上游合法续写流；多chunk每块8字节长度计费 |
