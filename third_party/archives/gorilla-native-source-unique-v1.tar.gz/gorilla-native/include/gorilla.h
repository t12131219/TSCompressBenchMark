/* Gorilla/Prometheus XOR chunks, native C11. See LICENSE and NOTICE. */
#ifndef GORILLA_NATIVE_H
#define GORILLA_NATIVE_H
#include <stddef.h>
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
typedef enum { G_OK=0, G_INVALID, G_NOMEM, G_OVERFLOW, G_TRUNCATED, G_CORRUPT, G_LIMIT } g_status;
/* Timestamp: signed milliseconds. bits: raw IEEE binary64, all NaN payloads
 * supported. No floating arithmetic is performed by the codecs. */
typedef struct { int64_t timestamp; uint64_t bits; } g_sample;
typedef struct { uint8_t *data; size_t size; } g_buffer;
typedef struct { g_sample *data; size_t count; } g_array;
/* One original-format chunk, 0..65535 samples; caller splits longer series.
 * Outputs must be fresh/zeroed; free previous data before reuse. Input/output
 * must not overlap. Functions zero output structs on failure, and never free
 * caller-owned inputs. Result storage belongs to caller: release with g_free.
 * Reentrant, no mutable global state. Input arrays must be valid and aligned. */
g_status g_compress_bound(size_t count, size_t *bound);
g_status g_compress(const g_sample *values, size_t count, g_buffer *output);
/* Checks input/token bounds, count limit, exact chunk length and zero padding.
 * Original format has no CRC: structural checks cannot detect all damage.
 * max_values=0 permits empty chunks only. */
g_status g_decompress(const uint8_t *data, size_t bytes, size_t max_values, g_array *output);
/* Stateful codec extension shared by the two batch libraries. The C/C++ batch
 * kernels remain independent. One context must not be used concurrently.
 * create/reset retain compressed workspace only, bounded by max_values<=65535.
 * append encodes immediately; snapshot copies a complete original-format chunk
 * without closing it; finish closes (idempotent). No whole-column raw cache. */
typedef struct g_encoder g_encoder;
typedef struct g_iterator g_iterator;
g_status g_encoder_create(size_t max_values, g_encoder **out);
g_status g_encoder_append(g_encoder*, const g_sample*, size_t count);
g_status g_encoder_snapshot(const g_encoder*, g_buffer*);
g_status g_encoder_finish(g_encoder*, g_buffer*);
g_status g_encoder_reset(g_encoder*);
/* Resume an existing complete chunk: scan validates grammar/restores predictors,
 * copy retains original compressed bits. On failure discard/reset the context. */
g_status g_encoder_resume(g_encoder*, const uint8_t*, size_t bytes);
g_status g_encoder_progress(const g_encoder*, size_t *values, size_t *data_bits, size_t *workspace_bytes);
void g_encoder_destroy(g_encoder*);
/* Borrow complete immutable bytes; no sample array allocation. next/seek return
 * present=0 at EOF and persistent error on invalid grammar. Drain to validate
 * final byte/padding. Seek is forward-only, returns current when current.t>=t;
 * chronological first-at-or-after semantics require nondecreasing timestamps.
 * Reset reuses the iterator object and clears any failure. */
g_status g_iterator_create(const uint8_t*, size_t bytes, size_t max_values, g_iterator **out);
g_status g_iterator_reset(g_iterator*, const uint8_t*, size_t bytes, size_t max_values);
g_status g_iterator_next(g_iterator*, g_sample*, int *present);
g_status g_iterator_seek(g_iterator*, int64_t timestamp, g_sample*, int *present);
void g_iterator_destroy(g_iterator*);
void g_free(void *pointer);
const char *g_strerror(g_status status);
#ifdef __cplusplus
}
#endif
#endif
