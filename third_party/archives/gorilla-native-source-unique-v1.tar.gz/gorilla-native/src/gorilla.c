#include "gorilla.h"
#include <limits.h>
#include <stdlib.h>
#include <string.h>
_Static_assert(CHAR_BIT==8, "8 bit bytes required");
_Static_assert(sizeof(g_sample)==16, "16 byte sample layout required");

static unsigned leading(uint64_t x) {
#if defined(__GNUC__) || defined(__clang__)
    return x ? (unsigned)__builtin_clzll(x) : 64;
#else
    unsigned n=0; if(!x) return 64;
    for(;!(x&(UINT64_C(1)<<63));x<<=1) ++n; return n;
#endif
}
static unsigned trailing(uint64_t x) {
#if defined(__GNUC__) || defined(__clang__)
    return x ? (unsigned)__builtin_ctzll(x) : 64;
#else
    unsigned n=0; if(!x) return 64;
    for(;!(x&1);x>>=1) ++n; return n;
#endif
}
static uint64_t mask(unsigned n) { return n==64 ? UINT64_MAX : (UINT64_C(1)<<n)-1; }
static uint64_t time_bits(int64_t t) { uint64_t u; memcpy(&u,&t,8); return u; }
static int64_t signed_bits(uint64_t u) { int64_t t; memcpy(&t,&u,8); return t; }
static uint64_t be64(const uint8_t *p) {
#if defined(__BYTE_ORDER__) && __BYTE_ORDER__ == __ORDER_LITTLE_ENDIAN__ && (defined(__GNUC__) || defined(__clang__))
    uint64_t u; memcpy(&u,p,8); return __builtin_bswap64(u);
#else
    uint64_t u=0; unsigned j; for(j=0;j<8;++j) u=(u<<8)|p[j]; return u;
#endif
}
static void store_be64(uint8_t *p, uint64_t u) {
#if defined(__BYTE_ORDER__) && __BYTE_ORDER__ == __ORDER_LITTLE_ENDIAN__ && (defined(__GNUC__) || defined(__clang__))
    u=__builtin_bswap64(u); memcpy(p,&u,8);
#else
    unsigned j; for(j=0;j<8;++j) p[j]=(uint8_t)(u>>(56-8*j));
#endif
}
typedef struct { uint8_t *p; uint64_t acc; unsigned used; } writer;
static void put(writer *w,uint64_t value,unsigned n) {
    unsigned space=64-w->used;
    if(!n) return;
    value&=mask(n);
    if(n<space) { w->acc|=value<<(space-n); w->used+=n; }
    else {
        store_be64(w->p,w->acc|(value>>(n-space))); w->p+=8;
        n-=space; w->used=n; w->acc=n?value<<(64-n):0;
    }
}
static void uvarint(writer *w,uint64_t x) {
    while(x>=128) { put(w,(x&127)|128,8); x>>=7; }
    put(w,x,8);
}
/* Prometheus small signed buckets have the asymmetric range
 * [-(2^(b-1)-1), +2^(b-1)], unlike conventional sign extension. */
static int fits(uint64_t u,unsigned b) {
    int64_t v=signed_bits(u),half=INT64_C(1)<<(b-1);
    return v>=-half+1 && v<=half;
}
#ifndef G_STREAM_ONLY
g_status g_compress_bound(size_t n,size_t *bound) {
    if(!bound) return G_INVALID;
    *bound=0; if(n>65535) return G_LIMIT;
    /* The second timestamp is a uint64 varint (up to 80 bits), whereas
     * subsequent timestamps need at most 68 bits. Account for that short
     * two-sample worst case explicitly. */
    *bound=2+((n?144U:0U)+(n>1?157U:0U)+(n>2?(n-2)*145U:0U)+7U)/8;
    return G_OK;
}
g_status g_compress(const g_sample *values,size_t n,g_buffer *out) {
    size_t bound,i; uint64_t prev_t=0,prev_v=0,prev_delta=0;
    unsigned lz=255,tz=0; uint8_t *p; writer w; g_status status;
    if(!out) return G_INVALID;
    memset(out,0,sizeof(*out));
    if(!values && n) return G_INVALID;
    status=g_compress_bound(n,&bound); if(status!=G_OK) return status;
    p=(uint8_t*)malloc(bound); if(!p) return G_NOMEM;
    p[0]=(uint8_t)(n>>8); p[1]=(uint8_t)n;
    w.p=p+2; w.acc=0; w.used=0;
    for(i=0;i<n;++i) {
        uint64_t t=time_bits(values[i].timestamp),value=values[i].bits,delta=0;
        if(!i) {
            uint64_t zig=(t<<1)^((t>>63)?UINT64_MAX:0);
            uvarint(&w,zig); put(&w,value,64);
        } else {
            uint64_t x=prev_v^value;
            delta=t-prev_t;
            if(i==1) uvarint(&w,delta);
            else {
                uint64_t dod=delta-prev_delta;
                if(!dod) put(&w,0,1);
                else if(fits(dod,14)) { put(&w,2,2); put(&w,dod,14); }
                else if(fits(dod,17)) { put(&w,6,3); put(&w,dod,17); }
                else if(fits(dod,20)) { put(&w,14,4); put(&w,dod,20); }
                else { put(&w,15,4); put(&w,dod,64); }
            }
            if(!x) put(&w,0,1);
            else {
                unsigned a=leading(x),b=trailing(x);
                if(a>31) a=31;
                if(lz!=255 && a>=lz && b>=tz) {
                    put(&w,2,2); put(&w,x>>tz,64-lz-tz);
                } else {
                    unsigned significant=64-a-b;
                    put(&w,3,2); put(&w,a,5); put(&w,significant,6);
                    put(&w,x>>b,significant); lz=a; tz=b;
                }
            }
        }
        prev_t=t; prev_v=value; prev_delta=delta;
    }
    while(w.used) {
        *w.p++=(uint8_t)(w.acc>>56); w.acc<<=8;
        w.used=w.used>8?w.used-8:0;
    }
    out->data=p; out->size=(size_t)(w.p-p); return G_OK;
}
#endif
typedef struct { const uint8_t *p; size_t bytes,remaining; uint64_t acc; unsigned avail; int bad; } reader;
static uint64_t get(reader *r,unsigned n) {
    uint64_t result=0;
    if(n>64 || n>r->remaining) { r->bad=1; return 0; }
    r->remaining-=n;
    while(n) {
        unsigned take;
        if(!r->avail) {
            unsigned j,bytes=r->bytes>=8?8:(unsigned)r->bytes;
            if(bytes==8) { r->acc=be64(r->p); r->p+=8; }
            else { r->acc=0; for(j=0;j<bytes;++j) r->acc=(r->acc<<8)|*r->p++; }
            r->bytes-=bytes; r->avail=bytes*8;
        }
        take=n<r->avail?n:r->avail;
        if(take==64) result=r->acc;
        else result=(result<<take)|((r->acc>>(r->avail-take))&mask(take));
        r->avail-=take; n-=take;
    }
    return result;
}
static uint64_t get_uvarint(reader *r) {
    uint64_t value=0; unsigned j;
    for(j=0;j<10;++j) {
        uint64_t b=get(r,8);
        if(r->bad || (j==9 && b>1)) { r->bad=1; return 0; }
        value|=(b&127)<<(7*j);
        if(b<128) return value;
    }
    r->bad=1; return 0;
}
#ifndef G_STREAM_ONLY
g_status g_decompress(const uint8_t *p,size_t bytes,size_t max_values,g_array *out) {
    size_t count,i; g_sample *values=NULL;
    uint64_t time=0,value=0,delta=0; unsigned lz=0,tz=0; reader r;
    if(!out) return G_INVALID;
    memset(out,0,sizeof(*out));
    if(!p && bytes) return G_INVALID;
    if(bytes<2) return G_TRUNCATED;
    count=((size_t)p[0]<<8)|p[1];
    if(count>max_values) return G_LIMIT;
    if(bytes-2>SIZE_MAX/8) return G_OVERFLOW;
    /* Every sample after the first needs at least two bits. */
    if(count && ((bytes-2)*8<72 || count-1>((bytes-2)*8-72)/2)) return G_TRUNCATED;
    if(count) { values=(g_sample*)malloc(count*sizeof(*values)); if(!values) return G_NOMEM; }
    r.p=p+2; r.bytes=bytes-2; r.remaining=(bytes-2)*8; r.acc=0; r.avail=0; r.bad=0;
    for(i=0;i<count;++i) {
        if(!i) {
            uint64_t zig=get_uvarint(&r);
            time=(zig>>1)^((zig&1)?UINT64_MAX:0); value=get(&r,64);
        } else {
            if(i==1) delta=get_uvarint(&r);
            else {
                unsigned ones=0,bits=0; uint64_t dod=0;
                while(ones<4 && get(&r,1)) ++ones;
                if(ones) {
                    bits=ones==1?14:ones==2?17:ones==3?20:64;
                    dod=get(&r,bits);
                    if(bits!=64 && dod>(UINT64_C(1)<<(bits-1))) dod-=UINT64_C(1)<<bits;
                    delta+=dod;
                }
            }
            time+=delta;
            if(get(&r,1)) {
                uint64_t x; unsigned sig;
                if(get(&r,1)) {
                    lz=(unsigned)get(&r,5); sig=(unsigned)get(&r,6);
                    if(!sig) sig=64;
                    if(lz+sig>64) goto corrupt;
                    tz=64-lz-sig;
                } else { if(lz==255) goto corrupt; sig=64-lz-tz; }
                x=get(&r,sig);
                if(!x) goto corrupt;
                value^=x<<tz;
            }
        }
        if(r.bad) goto corrupt;
        values[i].timestamp=signed_bits(time); values[i].bits=value;
    }
    if(r.remaining>=8 || get(&r,(unsigned)r.remaining) || r.bad) goto corrupt;
    out->data=values; out->count=count; return G_OK;
corrupt:
    free(values); return G_CORRUPT;
}
void g_free(void *p) { free(p); }
const char *g_strerror(g_status s) {
    switch(s) {
        case G_OK:return "success"; case G_INVALID:return "invalid argument";
        case G_NOMEM:return "allocation failed"; case G_OVERFLOW:return "size overflow";
        case G_TRUNCATED:return "truncated chunk"; case G_CORRUPT:return "corrupt chunk";
        case G_LIMIT:return "sample count exceeds limit"; default:return "unknown status";
    }
}

#endif /* G_STREAM_ONLY */
