/* Incremental extension derived from the selected C token loop. See NOTICE.
 * Reuse private bit/varint helpers without exporting the independent batch API. */
#define G_STREAM_ONLY 1
#include "gorilla.c"
struct g_encoder {
    uint8_t *storage; size_t capacity,limit,count;
    writer w; uint64_t time,value,delta; unsigned lz,tz; int closed;
};
struct g_iterator {
    const uint8_t *data; size_t bytes,count,index,data_bits;
    reader r; uint64_t time,value,delta; unsigned lz,tz;
    g_status error; int validated;
};
static size_t stream_bound(size_t n) {
    return 2+((n?144U:0U)+(n>1?157U:0U)+(n>2?(n-2)*145U:0U)+7U)/8;
}
g_status g_encoder_reset(g_encoder *e) {
    if(!e) return G_INVALID;
    e->count=0; e->time=e->value=e->delta=0; e->lz=255; e->tz=0; e->closed=0;
    e->storage[0]=e->storage[1]=0;
    e->w.p=e->storage+2; e->w.acc=0; e->w.used=0; return G_OK;
}
g_status g_encoder_create(size_t limit,g_encoder **out) {
    g_encoder *e;
    if(!out) return G_INVALID;
    *out=NULL; if(limit>65535) return G_LIMIT;
    e=(g_encoder*)calloc(1,sizeof(*e)); if(!e) return G_NOMEM;
    e->capacity=stream_bound(limit); e->limit=limit;
    e->storage=(uint8_t*)malloc(e->capacity); if(!e->storage) {free(e);return G_NOMEM;}
    g_encoder_reset(e); *out=e;return G_OK;
}
g_status g_encoder_append(g_encoder *e,const g_sample *samples,size_t count) {
    size_t i;
    if(!e || (!samples && count) || e->closed) return G_INVALID;
    if(count>e->limit-e->count) return G_LIMIT; /* reject before state changes */
    for(i=0;i<count;++i) {
        uint64_t t=time_bits(samples[i].timestamp),v=samples[i].bits,d=t-e->time;
        if(!e->count) {uvarint(&e->w,(t<<1)^((t>>63)?UINT64_MAX:0));put(&e->w,v,64);}
        else {
            uint64_t x=e->value^v;
            if(e->count==1) uvarint(&e->w,d);
            else {
                uint64_t dod=d-e->delta;
                if(!dod) put(&e->w,0,1);
                else if(fits(dod,14)) {put(&e->w,2,2);put(&e->w,dod,14);}
                else if(fits(dod,17)) {put(&e->w,6,3);put(&e->w,dod,17);}
                else if(fits(dod,20)) {put(&e->w,14,4);put(&e->w,dod,20);}
                else {put(&e->w,15,4);put(&e->w,dod,64);}
            }
            if(!x) put(&e->w,0,1);
            else {
                unsigned a=leading(x),b=trailing(x);if(a>31)a=31;
                if(e->lz!=255 && a>=e->lz && b>=e->tz) {put(&e->w,2,2);put(&e->w,x>>e->tz,64-e->lz-e->tz);}
                else {unsigned sig=64-a-b;put(&e->w,3,2);put(&e->w,a,5);put(&e->w,sig,6);put(&e->w,x>>b,sig);e->lz=a;e->tz=b;}
            }
        }
        e->time=t;e->value=v;e->delta=e->count?d:0;++e->count;
    }
    return G_OK;
}
g_status g_encoder_progress(const g_encoder *e,size_t *n,size_t *bits,size_t *workspace) {
    if(!e || !n || !bits || !workspace) return G_INVALID;
    *n=e->count;*bits=16+(size_t)(e->w.p-e->storage-2)*8+e->w.used;*workspace=e->capacity;return G_OK;
}
g_status g_encoder_snapshot(const g_encoder *e,g_buffer *out) {
    size_t n,bits,workspace,size,offset;uint8_t *p;uint64_t acc;unsigned used;
    if(!out)return G_INVALID;
    memset(out,0,sizeof(*out));if(!e)return G_INVALID;
    g_encoder_progress(e,&n,&bits,&workspace);size=(bits+7)/8;
    p=(uint8_t*)malloc(size);if(!p)return G_NOMEM;
    offset=(size_t)(e->w.p-e->storage);memcpy(p,e->storage,offset);
    p[0]=(uint8_t)(n>>8);p[1]=(uint8_t)n;acc=e->w.acc;used=e->w.used;
    while(used) {p[offset++]=(uint8_t)(acc>>56);acc<<=8;used=used>8?used-8:0;}
    out->data=p;out->size=size;return G_OK;
}
g_status g_encoder_finish(g_encoder *e,g_buffer *out) {
    g_status s=g_encoder_snapshot(e,out);if(s==G_OK)e->closed=1;return s;
}
void g_encoder_destroy(g_encoder *e) {if(e){free(e->storage);free(e);}}
g_status g_iterator_reset(g_iterator *it,const uint8_t *p,size_t bytes,size_t limit) {
    size_t count;
    if(!it)return G_INVALID;
    memset(it,0,sizeof(*it));it->error=G_INVALID;
    if(!p && bytes)return G_INVALID;
    if(bytes<2)return it->error=G_TRUNCATED;
    if(bytes-2>SIZE_MAX/8)return it->error=G_OVERFLOW;
    count=((size_t)p[0]<<8)|p[1];if(count>limit)return it->error=G_LIMIT;
    if(count && ((bytes-2)*8<72 || count-1>((bytes-2)*8-72)/2))return it->error=G_TRUNCATED;
    it->data=p;it->bytes=bytes;it->count=count;it->lz=0;
    it->r.p=p+2;it->r.bytes=bytes-2;it->r.remaining=(bytes-2)*8;
    it->error=G_OK;return G_OK;
}
g_status g_iterator_create(const uint8_t *p,size_t bytes,size_t limit,g_iterator **out) {
    g_iterator *it;g_status s;
    if(!out)return G_INVALID;
    *out=NULL;it=(g_iterator*)malloc(sizeof(*it));if(!it)return G_NOMEM;
    s=g_iterator_reset(it,p,bytes,limit);if(s!=G_OK){free(it);return s;}*out=it;return G_OK;
}
g_status g_iterator_next(g_iterator *it,g_sample *out,int *present) {
    if(!present)return G_INVALID;
    *present=0;if(!it || !out)return G_INVALID;
    if(it->error!=G_OK)return it->error;
    if(it->index==it->count) {
        if(!it->validated) {
            if(it->r.remaining>=8 || get(&it->r,(unsigned)it->r.remaining) || it->r.bad)return it->error=G_CORRUPT;
            it->validated=1;
        }
        return G_OK;
    }
    if(!it->index) {uint64_t zig=get_uvarint(&it->r);it->time=(zig>>1)^((zig&1)?UINT64_MAX:0);it->value=get(&it->r,64);}
    else {
        if(it->index==1)it->delta=get_uvarint(&it->r);
        else {
            unsigned ones=0,bits;uint64_t dod;
            while(ones<4 && get(&it->r,1))++ones;
            if(ones) {bits=ones==1?14:ones==2?17:ones==3?20:64;dod=get(&it->r,bits);if(bits!=64 && dod>(UINT64_C(1)<<(bits-1)))dod-=UINT64_C(1)<<bits;it->delta+=dod;}
        }
        it->time+=it->delta;
        if(get(&it->r,1)) {
            unsigned sig;uint64_t x;
            if(get(&it->r,1)) {it->lz=(unsigned)get(&it->r,5);sig=(unsigned)get(&it->r,6);if(!sig)sig=64;if(it->lz+sig>64)return it->error=G_CORRUPT;it->tz=64-it->lz-sig;}
            else {if(it->lz==255)return it->error=G_CORRUPT;sig=64-it->lz-it->tz;}
            x=get(&it->r,sig);if(!x)return it->error=G_CORRUPT;it->value^=x<<it->tz;
        }
    }
    if(it->r.bad)return it->error=G_CORRUPT;
    ++it->index;it->data_bits=(it->bytes-2)*8-it->r.remaining;
    out->timestamp=signed_bits(it->time);out->bits=it->value;*present=1;return G_OK;
}
g_status g_iterator_seek(g_iterator *it,int64_t timestamp,g_sample *out,int *present) {
    g_status s;
    if(!present)return G_INVALID;
    *present=0;if(!it || !out)return G_INVALID;
    if(it->error!=G_OK)return it->error;
    while(!it->index || timestamp>signed_bits(it->time)) {s=g_iterator_next(it,out,present);if(s!=G_OK || !*present)return s;}
    out->timestamp=signed_bits(it->time);out->bits=it->value;*present=1;return G_OK;
}
void g_iterator_destroy(g_iterator *it) {free(it);}
g_status g_encoder_resume(g_encoder *e,const uint8_t *p,size_t bytes) {
    g_iterator it;g_status s;g_sample value;int present;size_t whole,j,tail;
    if(!e)return G_INVALID;
    s=g_iterator_reset(&it,p,bytes,e->limit);if(s!=G_OK)return s;
    do {s=g_iterator_next(&it,&value,&present);}while(s==G_OK && present);
    if(s!=G_OK)return s;
    if(bytes>e->capacity)return G_LIMIT;
    if(!it.count)return g_encoder_reset(e); /* upstream empty-chunk Appender is fresh */
    /* Complete 64-bit words precede the pending reservoir; padding is discarded. */
    whole=it.data_bits/64;tail=it.data_bits%64;
    g_encoder_reset(e);memcpy(e->storage,p,bytes);e->w.p=e->storage+2+whole*8;e->w.used=(unsigned)tail;e->w.acc=0;
    for(j=0;j<(tail+7)/8;++j)e->w.acc|=(uint64_t)p[2+whole*8+j]<<(56-8*j);
    if(tail)e->w.acc&=UINT64_MAX<<(64-tail);
    e->count=it.count;e->time=it.time;e->value=it.value;e->delta=it.delta;e->lz=it.lz;e->tz=it.tz;return G_OK;
}
