#define _POSIX_C_SOURCE 200809L
#include "selfstar.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <errno.h>
#include <limits.h>
#ifdef CPP_BACKEND
#define CTX sf_cpp
#define CREATE sf_cpp_create
#define DESTROY sf_cpp_destroy
#define ENCODE sf_cpp_encode
#define DECODE sf_cpp_decode
#else
#define CTX sf_c
#define CREATE sf_c_create
#define DESTROY sf_c_destroy
#define ENCODE sf_c_encode
#define DECODE sf_c_decode
#endif
static void check(int yes){if(!yes){fprintf(stderr,"benchmark/check failed\n");exit(2);}}
static int number(const char*s){char*end;long n;check(s&&*s);for(const char*p=s;*p;++p)check(*p>='0'&&*p<='9');errno=0;n=strtol(s,&end,10);check(!errno&&!*end&&n<=INT_MAX);return (int)n;}
static double now(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return t.tv_sec+t.tv_nsec*1e-9;}
static void u32(FILE*f,size_t v){for(int i=0;i<4;++i)fputc((int)(v>>(8*i))&255,f);}
int main(int argc,char**argv){
 if(argc!=6){fprintf(stderr,"usage: bench ALGORITHM_ID WIDTH INPUT DUMP REPEATS\n");return 2;}
 int a=number(argv[1]),w=number(argv[2]),reps=number(argv[5]);check(a>=0&&a<4&&(w==32||w==64)&&reps>0);
 FILE*f=fopen(argv[3],"rb");check(f!=NULL);check(fseek(f,0,SEEK_END)==0);long sz=ftell(f);rewind(f);check(sz>0&&sz%(w/8)==0);size_t count=(size_t)sz/(w/8),blocks=(count+511)/512;
 unsigned char*data=malloc((size_t)sz),*decoded=malloc(1000*8),*frames=malloc(blocks*25000);size_t*bits=calloc(blocks,sizeof(size_t));check(data&&decoded&&frames&&bits);check(fread(data,1,(size_t)sz,f)==(size_t)sz);fclose(f);
 size_t bytes=0,totalbits=0;CTX*e=CREATE((sf_algorithm)a,(sf_dtype)w),*d=CREATE((sf_algorithm)a,(sf_dtype)w);check(e&&d);
 f=fopen(argv[4],"wb");check(f!=NULL);
 for(size_t i=0;i<blocks;++i){size_t off=i*512,n=count-off<512?count-off:512;unsigned char*p=frames+i*25000;
  check(ENCODE(e,data+off*(w/8),n,p,25000,&bits[i])==SF_OK);size_t len=(bits[i]+7)/8;bytes+=len;totalbits+=bits[i];
  check(DECODE(d,p,len,bits[i],decoded,n)==SF_OK);check(memcmp(decoded,data+off*(w/8),n*(w/8))==0);
  u32(f,n);u32(f,bits[i]);check(fwrite(p,1,len,f)==len);
 }check(fclose(f)==0);DESTROY(e);DESTROY(d);
 double et=0,dt=0;
 for(int r=-1;r<reps;++r){double start=now();e=CREATE((sf_algorithm)a,(sf_dtype)w);check(e!=NULL);
  for(size_t i=0;i<blocks;++i){size_t off=i*512,n=count-off<512?count-off:512,b;check(ENCODE(e,data+off*(w/8),n,frames+i*25000,25000,&b)==SF_OK);check(b==bits[i]);}DESTROY(e);double duration=now()-start;if(r>=0)et+=duration;
  start=now();d=CREATE((sf_algorithm)a,(sf_dtype)w);check(d!=NULL);for(size_t i=0;i<blocks;++i){size_t off=i*512,n=count-off<512?count-off:512;check(DECODE(d,frames+i*25000,(bits[i]+7)/8,bits[i],decoded,n)==SF_OK);}DESTROY(d);duration=now()-start;if(r>=0)dt+=duration;
 }
 printf("{\"count\":%zu,\"raw_bytes\":%ld,\"compressed_bytes\":%zu,\"payload_bits\":%zu,\"blocks\":%zu,\"encode_seconds\":%.12g,\"decode_seconds\":%.12g}\n",count,sz,bytes,totalbits,blocks,et/reps,dt/reps);
 free(data);free(decoded);free(frames);free(bits);return 0;
}
