#ifndef SELFSTAR_H
#define SELFSTAR_H
#include <stddef.h>
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
/* Exactly four algorithm IDs. Precision is an independent property. */
typedef enum { SF_ELF=0, SF_ELF_PLUS=1, SF_ELF_STAR=2, SF_SELF_STAR=3 } sf_algorithm;
typedef enum { SF_F32=32, SF_F64=64 } sf_dtype;
typedef enum { SF_OK=0, SF_INVALID=1, SF_CAPACITY=2, SF_CORRUPT=3, SF_MEMORY=4, SF_STATE=5 } sf_status;
/* Contexts are directional: use separate instances for encoding and decoding.
   Successive blocks retain SElf* models. reset starts an independent stream.
   Counts 1..1000; NaN input is rejected (upstream reserves NaN as terminator).
   Input/output arrays contain float for SF_F32, double for SF_F64.
   Buffer overlap is unsupported. On error reset before reuse; output may change.
   No header is inserted: caller supplies dtype, algorithm, count and bit length. */
typedef struct sf_c sf_c;
#define SF_DECLARE(P,T) \
 T *P##_create(sf_algorithm algorithm, sf_dtype dtype); \
 void P##_destroy(T *ctx); \
 sf_status P##_reset(T *ctx); \
 sf_status P##_encode(T *ctx,const void *values,size_t count,uint8_t *out,size_t capacity,size_t *bits); \
 sf_status P##_decode(T *ctx,const uint8_t *input,size_t bytes,size_t bits,void *values,size_t count)
SF_DECLARE(sf_c,sf_c);
#undef SF_DECLARE
/* Incremental block lifecycle on the same directional contexts.
 * begin binds caller output until finish; add immediately encodes except Elf*,
 * whose source algorithm needs a full block of transformed words/betas.
 * finish closes a nonempty 1..1000-value block and advances SElf* learning.
 * read_begin borrows a complete immutable block; next outputs one typed value.
 * Drain through has_value=0 to consume sentinel and commit next-block state.
 * reset starts a new independent stream; failure requires reset/destruction.
 * Legacy batch and incremental calls may alternate only at block boundaries. */
typedef struct {
 size_t count, bits, deferred_values;
 int phase; /* 0 completed/idle, 1 encoding, 2 reading */
} sf_progress;
#define SF_LIVE_DECLARE(P,T) \
 sf_status P##_begin(T*,uint8_t *out,size_t capacity); \
 sf_status P##_add(T*,const void *values,size_t count); \
 sf_status P##_finish(T*,size_t *bits); \
 sf_status P##_read_begin(T*,const uint8_t*,size_t bytes,size_t bits,size_t count); \
 sf_status P##_next(T*,void *value,int *has_value); \
 sf_status P##_progress(T*,sf_progress*)
SF_LIVE_DECLARE(sf_c,sf_c);
#undef SF_LIVE_DECLARE
static inline const char *sf_status_string(sf_status status) {
 switch(status) {
 case SF_OK: return "ok";
 case SF_INVALID: return "invalid argument/input";
 case SF_CAPACITY: return "output capacity";
 case SF_CORRUPT: return "corrupt/truncated stream";
 case SF_MEMORY: return "allocation failed";
 case SF_STATE: return "invalid/failed context state";
 default: return "unknown";
 }
}
#ifdef __cplusplus
}
#endif
#endif
