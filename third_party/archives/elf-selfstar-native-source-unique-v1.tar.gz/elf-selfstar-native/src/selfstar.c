/* Independent C11 implementation of the SElfStar four-codec family. */
#include "selfstar.h"
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <setjmp.h>
#include "powers.h"
#define MAX_BLOCK 1000
#define BAD 1000000

typedef struct { uint32_t code; int len; } Code;
typedef struct { int p[32],n,bits,round[64],rep[64]; } Positions;
typedef struct { uint8_t *out; const uint8_t *in; size_t pos,limit; jmp_buf fail; int error; } IO;
typedef struct {
 uint64_t values[MAX_BLOCK];int beta[MAX_BLOCK],freq[17],ld[64],td[64];
 int erase_last,put_last,ended;size_t count,expected;
} Live;
struct sf_c {
 Live *live;int active;
 int algorithm,width,raw,direction,bad,blocks,sl,st,write_positions;
 uint64_t prev;
 double ratio;
 Positions lead,trail;
 Code codes[17];
 IO io;
};
static void fail(IO *b,int status){b->error=status;longjmp(b->fail,1);}
static void put(IO*b,uint64_t v,int n){
 if(n<0||n>64||b->pos>b->limit||(size_t)n>b->limit-b->pos)fail(b,SF_CAPACITY);
 while(n){int off=(int)(b->pos&7),k=8-off;if(k>n)k=n;
  unsigned mask=(1u<<k)-1;unsigned shift=(unsigned)(8-off-k);
  uint8_t*dest=&b->out[b->pos/8];*dest=(uint8_t)((*dest&~(mask<<shift))|(((v>>(n-k))&mask)<<shift));
  b->pos+=(size_t)k;n-=k;
 }
}
static uint64_t get(IO*b,int n){
 if(n<0||n>64||b->pos>b->limit||(size_t)n>b->limit-b->pos)fail(b,SF_CORRUPT);
 uint64_t v=0;while(n){int off=(int)(b->pos&7),k=8-off;if(k>n)k=n;
  v=(v<<k)|((b->in[b->pos/8]>>(8-off-k))&((1u<<k)-1));b->pos+=(size_t)k;n-=k;
 }return v;
}
static int clog2(int n){int b=0;for(--n;n>0;n>>=1)++b;return b;}
static int clz(uint64_t v,int w){return v?(w==32?__builtin_clz((uint32_t)v):__builtin_clzll(v)):w;}
static int ctz(uint64_t v,int w){return v?(w==32?__builtin_ctz((uint32_t)v):__builtin_ctzll(v)):w;}
static uint64_t from_number(double d,int w){uint64_t v=0;if(w==32){float f=(float)d;uint32_t u;memcpy(&u,&f,4);v=u;}else memcpy(&v,&d,8);return v;}
static double number(uint64_t u,int w){if(w==32){uint32_t v=(uint32_t)u;float f;memcpy(&f,&v,4);return f;}double d;memcpy(&d,&u,8);return d;}
static uint64_t end_sign(int w){return w==32?UINT64_C(0x7fc00000):UINT64_C(0x7ff8000000000000);}
static double quant(double v,int w){return w==32?(double)(float)v:v;}
static double power(int i,int neg,int w){if(i<0)return NAN;if(w==32)return i<64?(neg?p32n[i]:p32p[i]):(neg?0:INFINITY);return i<325?(neg?p64n[i]:p64p[i]):(neg?0:INFINITY);}
static int sp_flag(double v,int w,int*flag){
 *flag=0;
 if(v>=1){for(int i=0;i<9;++i)if(v<power(i+1,0,w))return i;}
 else for(int i=1;i<11;++i)if(v>=power(i,1,w)){*flag=v==power(i,1,w);return -i;}
 double l=log10(v);*flag=l==floor(l);return (int)floor(l);
}
static int get_sp(double v,int w){int flag;return sp_flag(v,w,&flag);}
static int significant(double v,int sp,int last,int simple,int w){
 int fallback=w==32?8:17,maxpow=w==32?38:308;
 int i;
 if(simple)i=sp>=0?1:-sp;
 else if(last!=INT_MAX&&last!=0)i=last-sp-1>1?last-sp-1:1;
 else if(w==64&&last==INT_MAX)i=17-sp;
 else i=sp>=0?1:-sp;
 if(i<0||i>maxpow)return fallback;
 double tmp=quant(v*power(i,0,w),w);int64_t integer;
 for(;;){
  if(!isfinite(tmp)||tmp>=(w==32?(double)(float)INT_MAX:(double)INT64_MAX))return fallback;
  integer=(int64_t)tmp;
  if(quant((double)integer,w)==tmp)break;
  if(++i>maxpow)return fallback;
  tmp=quant(v*power(i,0,w),w);
 }
 if(quant(tmp/power(i,0,w),w)!=v)return fallback;
 if(!simple)while(i>0&&integer%10==0){--i;integer/=10;}
 return sp+i+1;
}
static double restore(double v,int beta,int w){
 double mag=fabs(v);if(!(mag>0)||!isfinite(mag))return NAN;
 int sp=get_sp(mag,w);
 if(beta==0){int i=-sp-1;if(i<0||i>324)return NAN;return copysign(power(i,1,w),v);}
 int alpha=beta-sp-1;if(alpha<0||alpha>(w==32?38:308))return NAN;
 double scale=power(alpha,0,w),prod=quant(v*scale,w);
 return quant((v<0?floor(prod):ceil(prod))/scale,w);
}
static int erase(sf_c*c,uint64_t raw,int last,uint64_t*out){
 int w=c->width,rawsym=c->raw;double original=number(raw,w),v=fabs(original);*out=raw;
 if(v==0||!isfinite(v))return rawsym;
 int simple=c->algorithm==SF_ELF,flag=0,sp;
 if(simple&&w==64){double l=log10(v);sp=(int)floor(l);flag=v<1&&sp==l;}
 else sp=sp_flag(v,w,&flag);
 int beta=significant(v,sp,last,simple,w),alpha=beta-sp-1,b=flag?0:beta;
 if(alpha<0||beta<0||beta>=rawsym)return rawsym;
 static const int f[]={0,4,7,10,14,17,20,24,27,30,34,37,40,44,47,50,54,57,60,64,67};
 int fa=alpha<21?f[alpha]:(int)ceil(alpha*(log(10.0)/log(2.0)));
 int mant=w==32?23:52,bias=w==32?127:1023;
 int exponent=(int)((raw>>mant)&(w==32?255:2047));
 int eb=mant-(fa+exponent-bias);
 if(eb<=(w==32?3:4)||eb>=w)return rawsym;
 uint64_t mask=UINT64_MAX<<eb,trunc=raw&mask;
 if(trunc==raw)return rawsym;
 double tv=number(trunc,w);
 if(!(fabs(tv)>0)||!isfinite(tv))return rawsym;
 int tsp=get_sp(fabs(tv),w);if(tsp!=(int)floor(log10(fabs(tv))))return rawsym;
 double recovered=restore(tv,b,w);
 if(from_number(recovered,w)!=raw)return rawsym;
 *out=trunc;return b;
}
/* Exact Java PriorityQueue tie order: frequency then height, no symbol key. */
typedef struct {int freq,height,symbol,left,right;} HNode;
static int compare(const HNode*n,int a,int b){return n[a].freq!=n[b].freq?n[a].freq-n[b].freq:n[a].height-n[b].height;}
static void offer(int*h,int*size,HNode*n,int x){int k=(*size)++;while(k){int p=(k-1)/2;if(compare(n,x,h[p])>=0)break;h[k]=h[p];k=p;}h[k]=x;}
static int poll(int*h,int*size,HNode*n){int ret=h[0],x=h[--*size],k=0,half=*size/2;while(k<half){int ch=k*2+1,r=ch+1;if(r<*size&&compare(n,h[ch],h[r])>0)ch=r;if(compare(n,x,h[ch])<=0)break;h[k]=h[ch];k=ch;}if(*size)h[k]=x;return ret;}
static void visit(HNode*n,int p,uint32_t code,int len,Code*out){if(n[p].symbol>=0){out[n[p].symbol]=(Code){code,len};return;}visit(n,n[p].left,code<<1,len+1,out);visit(n,n[p].right,(code<<1)|1,len+1,out);}
static void huffman(const int*freq,int count,Code*out){HNode n[33];int heap[17]={0},size=0,used=0;for(int i=0;i<count;++i){n[used]=(HNode){freq[i],0,i,-1,-1};offer(heap,&size,n,used++);}while(size>1){int l=poll(heap,&size,n),r=poll(heap,&size,n);n[used]=(HNode){n[l].freq+n[r].freq,(n[l].height>n[r].height?n[l].height:n[r].height)+1,-1,l,r};offer(heap,&size,n,used++);}visit(n,heap[0],0,0,out);}
static void write_codes(IO*io,Code*c,int n){int max=0;for(int i=0;i<n;++i)if(c[i].len>max)max=c[i].len;int bits=clog2(max);put(io,(unsigned)bits,3);for(int i=0;i<n;++i){put(io,(unsigned)c[i].len-1,bits);put(io,c[i].code,c[i].len);}}
static void read_codes(IO*io,Code*c,int n){int b=(int)get(io,3);if(b>4)fail(io,SF_CORRUPT);for(int i=0;i<n;++i){int len=(int)get(io,b)+1;if(len>16)fail(io,SF_CORRUPT);c[i]=(Code){(uint32_t)get(io,len),len};for(int j=0;j<i;++j){int shorter=len<c[j].len?len:c[j].len;if((c[i].code>>(len-shorter))==(c[j].code>>(c[j].len-shorter)))fail(io,SF_CORRUPT);}}}
static int read_symbol(IO*io,const Code*c,int n){uint32_t code=0;for(int len=1;len<=16;++len){code=(code<<1)|(uint32_t)get(io,1);for(int i=0;i<n;++i)if(c[i].len==len&&c[i].code==code)return i;}fail(io,SF_CORRUPT);return 0;}
static void positions_init(Positions*p,int w,const int*pos,int n){memset(p,0,sizeof(*p));p->n=n;p->bits=clog2(n);memcpy(p->p,pos,(size_t)n*sizeof(int));int index=0;for(int i=0;i<w;++i){if(index+1<n&&i==pos[index+1])++index;p->round[i]=pos[index];p->rep[i]=index;}}
/* PostOffice DP with prefix-sum interval costs; preserves source tie ordering. */
static int interval(const int*count,const int*weight,int k,int end){return weight[end]-weight[k+1]-k*(count[end]-count[k+1]);}
static void optimize_positions(Positions*out,const int*a,int w){
 int before[64],after[64],count[65]={0},weight[65]={0},nonzeros=w,total=0;
 before[0]=1;for(int i=0;i<w;++i){total+=a[i];count[i+1]=total;weight[i+1]=weight[i]+a[i]*i;if(i){nonzeros-=a[i]==0;before[i]=before[i-1]+(a[i]!=0);}}
 for(int i=0;i<w;++i)after[i]=nonzeros-before[i];
 int best=INT_MAX,bestpos[32]={0},bestn=1,maxz=clog2(nonzeros);if(maxz>(w==32?4:5))maxz=w==32?4:5;
 for(int z=0;z<=maxz;++z){
  int present=total*z;if(present>=best)break;
  int original=1<<z,num=original<nonzeros?original:nonzeros;
  int dp[64][32]={{0}},pre[64][32]={{0}};pre[0][0]=-1;
  for(int i=1;i<w;++i){if(a[i]==0)continue;int start=num+i-w>1?num+i-w:1;
   for(int j=start;j<=i&&j<num;++j){
    if(i>1&&j==1){dp[i][j]=interval(count,weight,0,i);pre[i][j]=0;}
    else{if(before[i]<j+1||after[i]<num-1-j)continue;int cost=INT_MAX,previous=0;
     for(int k=j-1;k<i;++k){if((a[k]==0&&k>0)||before[k]<j||after[k]<num-j)continue;int sum=dp[k][j-1]+interval(count,weight,k,i);if(cost>sum){cost=sum;previous=k;if(sum==0)break;}}
     if(cost!=INT_MAX){dp[i][j]=cost;pre[i][j]=previous;}
    }
   }
  }
  int cost=INT_MAX,last=-1;
  for(int i=num-1;i<w;++i){if(num==1&&i>0)break;if((a[i]==0&&i>0)||before[i]<num)continue;int sum=dp[i][num-1]+interval(count,weight,i,w);if(cost>sum){cost=sum;last=i;}}
  int pos[32]={0},idx=num-1;while(last!=-1&&idx>=0){pos[idx]=last;last=pre[last][idx];--idx;}
  if(cost+present<best){best=cost+present;bestn=original;if(original>num){int j=0,k=0;while(j<original&&k<num){if(j-k<original-num&&j<pos[k]){bestpos[j]=j;++j;}else bestpos[j++]=pos[k++];}}else memcpy(bestpos,pos,(size_t)num*sizeof(int));}
 }
 positions_init(out,w,bestpos,bestn);
}
static void write_positions(IO*io,const Positions*p,int w){put(io,(unsigned)p->n,w==32?4:5);for(int i=0;i<p->n;++i)put(io,(unsigned)p->p[i],w==32?5:6);}
static void read_positions(IO*io,Positions*p,int w){int n=(int)get(io,w==32?4:5);if(!n)n=w/2;int pos[32];for(int i=0;i<n;++i){pos[i]=(int)get(io,w==32?5:6);if((i==0&&pos[i]!=0)||(i&&pos[i]<=pos[i-1]))fail(io,SF_CORRUPT);}positions_init(p,w,pos,n);}
static void init(sf_c*c,int a,int w){memset(c,0,sizeof(*c));c->algorithm=a;c->width=w;c->raw=w==32?8:16;c->sl=c->st=BAD;
 static const int l64[]={0,8,12,16,18,20,22,24},l32[]={0,6,10,12,14,16,18,20};
 static const int t64[]={0,22,28,32,36,40,42,46},sl32[]={0,8,12,16},st32[]={0,16};
 positions_init(&c->lead,w,w==32?(a==SF_SELF_STAR?sl32:l32):l64,w==32&&a==SF_SELF_STAR?4:8);
 positions_init(&c->trail,w,w==32?st32:t64,w==32?2:8);
}
static void xor_put(sf_c*c,uint64_t v,int first,int*ld,int*td){IO*b=&c->io;int w=c->width,star=c->algorithm>=SF_ELF_STAR;
 if(first){
  if(c->algorithm==SF_ELF_STAR){write_positions(b,&c->lead,w);write_positions(b,&c->trail,w);}
  else if(c->algorithm==SF_SELF_STAR){put(b,(unsigned)c->write_positions,1);if(c->write_positions){write_positions(b,&c->lead,w);write_positions(b,&c->trail,w);}}
  c->prev=v;int tz=ctz(v,w);put(b,(unsigned)tz,w==32?6:7);
  if(tz<w){if(star)put(b,v>>(tz+1==64?63:tz+1),w-1-tz);else put(b,v>>tz,w-tz);}return;
 }
 uint64_t x=c->prev^v;if(!x){put(b,1,2);return;}
 int lz=clz(x,w),tz=ctz(x,w),l=c->lead.round[lz],t=star?c->trail.round[tz]:tz;
 if(c->algorithm==SF_SELF_STAR){++ld[lz];++td[tz];}
 if(star){
  if(l>=c->sl&&t>=c->st&&(l-c->sl)+(t-c->st)<1+c->lead.bits+c->trail.bits){put(b,1,1);put(b,x>>c->st,w-c->sl-c->st);}
  else{c->sl=l;c->st=t;put(b,0,2);put(b,(unsigned)c->lead.rep[l],c->lead.bits);put(b,(unsigned)c->trail.rep[t],c->trail.bits);put(b,x>>t,w-l-t);}
 }else{
  if(l==c->sl&&t>=c->st){put(b,0,2);put(b,x>>c->st,w-c->sl-c->st);}
  else{c->sl=l;c->st=t;int center=w-l-t,small=center<=(w==32?8:16);put(b,small?2:3,2);put(b,(unsigned)c->lead.rep[l],3);put(b,(unsigned)center,small?(w==32?3:4):(w==32?5:6));put(b,x>>t,center);}
 }c->prev=v;
}
static uint64_t xor_get(sf_c*c,int first){IO*b=&c->io;int w=c->width,star=c->algorithm>=SF_ELF_STAR;
 if(first){if(c->algorithm==SF_ELF_STAR||(c->algorithm==SF_SELF_STAR&&get(b,1))){read_positions(b,&c->lead,w);read_positions(b,&c->trail,w);}
  int tz=(int)get(b,w==32?6:7);if(tz>w)fail(b,SF_CORRUPT);if(tz==w)c->prev=0;else if(star)c->prev=((get(b,w-1-tz)<<1)|1)<<tz;else c->prev=get(b,w-tz)<<tz;return c->prev;
 }
 if(star){if(get(b,1)==0){if(get(b,1))return c->prev;int l=(int)get(b,c->lead.bits),t=(int)get(b,c->trail.bits);if(l>=c->lead.n||t>=c->trail.n)fail(b,SF_CORRUPT);c->sl=c->lead.p[l];c->st=c->trail.p[t];}}
 else{int code=(int)get(b,2);if(code==1)return c->prev;if(code>=2){int rep=(int)get(b,3);c->sl=c->lead.p[rep];int n=code==2?(w==32?3:4):(w==32?5:6);int center=(int)get(b,n);if(!center)center=1<<n;c->st=w-c->sl-center;}}
 int center=w-c->sl-c->st;if(center<1||center>w||c->sl<0||c->st<0)fail(b,SF_CORRUPT);uint64_t x=get(b,center)<<c->st;c->prev^=x;return c->prev;
}
static void beta_put(sf_c*c,int beta,int*last){IO*b=&c->io;int bp=c->width==32?3:4;
 if(c->algorithm==SF_ELF){if(beta==c->raw)put(b,0,1);else{put(b,1,1);put(b,(unsigned)beta,bp);}}
 else if(c->algorithm==SF_ELF_STAR||(c->algorithm==SF_SELF_STAR&&c->blocks)){put(b,c->codes[beta].code,c->codes[beta].len);}
 else if(beta==c->raw)put(b,2,2);
 else if(beta==*last)put(b,0,1);
 else{put(b,3,2);put(b,(unsigned)beta,bp);*last=beta;}
}
static int beta_get(sf_c*c,int*last){IO*b=&c->io;int bp=c->width==32?3:4;
 if(c->algorithm==SF_ELF)return get(b,1)?(int)get(b,bp):c->raw;
 if(c->algorithm==SF_ELF_STAR||(c->algorithm==SF_SELF_STAR&&c->blocks))return read_symbol(b,c->codes,c->raw+1);
 if(!get(b,1)){if(*last==INT_MAX)fail(b,SF_CORRUPT);return *last;}
 if(!get(b,1))return c->raw;
 return *last=(int)get(b,bp);
}
sf_c*sf_c_create(sf_algorithm a,sf_dtype w){if(a<SF_ELF||a>SF_SELF_STAR||(w!=SF_F32&&w!=SF_F64))return NULL;sf_c*c=malloc(sizeof(*c));if(c)init(c,a,w);return c;}
void sf_c_destroy(sf_c*c){if(c)free(c->live);free(c);}
sf_status sf_c_reset(sf_c*c){if(!c)return SF_INVALID;int a=c->algorithm,w=c->width;Live*l=c->live;init(c,a,w);c->live=l;if(l)memset(l,0,sizeof(*l));return SF_OK;}
sf_status sf_c_encode(sf_c*c,const void*values,size_t n,uint8_t*out,size_t cap,size_t*bits){
 if(!c||!values||!out||!bits||n<1||n>MAX_BLOCK||cap>SIZE_MAX/8)return SF_INVALID;if(c->bad||c->active)return SF_STATE;if(c->direction==2)return SF_STATE;
 for(size_t i=0;i<n;++i)if(isnan(c->width==32?((const float*)values)[i]:((const double*)values)[i]))return SF_INVALID;
 c->direction=1;IO*b=&c->io;b->out=out;b->pos=0;b->limit=cap*8;b->error=0;if(setjmp(b->fail)){c->bad=1;return (sf_status)b->error;}
 uint64_t v[MAX_BLOCK];int beta[MAX_BLOCK],freq[17]={0},ld[64]={0},td[64]={0},last=INT_MAX;
 if(c->algorithm!=SF_SELF_STAR)c->sl=c->st=BAD;
 for(size_t i=0;i<n;++i){double d=c->width==32?((const float*)values)[i]:((const double*)values)[i];beta[i]=erase(c,from_number(d,c->width),last,&v[i]);++freq[beta[i]];if(beta[i]!=c->raw)last=beta[i];}
 if(c->algorithm==SF_ELF_STAR){for(size_t i=1;i<n;++i){uint64_t x=v[i-1]^v[i];if(x){++ld[clz(x,c->width)];++td[ctz(x,c->width)];}}huffman(freq,c->raw+1,c->codes);write_codes(b,c->codes,c->raw+1);optimize_positions(&c->lead,ld,c->width);optimize_positions(&c->trail,td,c->width);}
 last=INT_MAX;for(size_t i=0;i<n;++i){beta_put(c,beta[i],&last);xor_put(c,v[i],i==0,ld,td);}
 int update=0;if(c->algorithm==SF_SELF_STAR){double ratio=(double)b->pos/(n*c->width);update=c->ratio<ratio;c->ratio=ratio;}
 beta_put(c,c->raw,&last);xor_put(c,end_sign(c->width),0,ld,td);
 if(c->algorithm==SF_SELF_STAR){huffman(freq,c->raw+1,c->codes);if(update){optimize_positions(&c->lead,ld,c->width);optimize_positions(&c->trail,td,c->width);}c->write_positions=update;}
 *bits=b->pos;if(b->pos%8)out[b->pos/8]&=(uint8_t)(0xffu<<(8-b->pos%8));++c->blocks;return SF_OK;
}
sf_status sf_c_decode(sf_c*c,const uint8_t*in,size_t bytes,size_t bits,void*out,size_t n){
 if(!c||!in||!out||n<1||n>MAX_BLOCK||!bits||bits>200000||bytes!=(bits+7)/8)return SF_INVALID;if(c->bad||c->active)return SF_STATE;if(c->direction==1)return SF_STATE;if(bits%8&&(in[bytes-1]&((1u<<(8-bits%8))-1)))return SF_CORRUPT;
 c->direction=2;IO*b=&c->io;b->in=in;b->pos=0;b->limit=bits;b->error=0;if(setjmp(b->fail)){c->bad=1;return (sf_status)b->error;}
 if(c->algorithm!=SF_SELF_STAR)c->sl=c->st=BAD;
 if(c->algorithm==SF_ELF_STAR)read_codes(b,c->codes,c->raw+1);
 int last=INT_MAX,freq[17]={0};
 for(size_t i=0;i<=n;++i){int beta=beta_get(c,&last);uint64_t v=xor_get(c,i==0);if(i==n){if(beta!=c->raw||v!=end_sign(c->width)||b->pos!=bits)fail(b,SF_CORRUPT);break;}if(v==end_sign(c->width))fail(b,SF_CORRUPT);
  ++freq[beta];double d=number(v,c->width);if(beta!=c->raw){d=restore(d,beta,c->width);if(!isfinite(d))fail(b,SF_CORRUPT);}else if(isnan(d))fail(b,SF_CORRUPT);
  if(c->width==32)((float*)out)[i]=(float)d;else ((double*)out)[i]=d;
 }
 if(c->algorithm==SF_SELF_STAR)huffman(freq,c->raw+1,c->codes);++c->blocks;return SF_OK;
}

static int live_prepare(sf_c*c){
 if(!c->live)c->live=calloc(1,sizeof(*c->live));
 if(!c->live)return 0;
 memset(c->live,0,sizeof(*c->live));c->live->erase_last=c->live->put_last=INT_MAX;return 1;
}
sf_status sf_c_begin(sf_c*c,uint8_t*out,size_t cap){
 if(!c||!out||cap>SIZE_MAX/8)return SF_INVALID;
 if(c->bad||c->active||c->direction==2)return SF_STATE;
 if(!live_prepare(c))return SF_MEMORY;
 c->direction=1;c->active=1;c->io.out=out;c->io.pos=0;c->io.limit=cap*8;c->io.error=0;
 if(c->algorithm!=SF_SELF_STAR)c->sl=c->st=BAD;
 return SF_OK;
}
sf_status sf_c_add(sf_c*c,const void*values,size_t n){
 if(!c||(!values&&n))return SF_INVALID;
 if(c->bad||c->active!=1)return SF_STATE;
 Live*l=c->live;if(n>MAX_BLOCK-l->count)return SF_INVALID;
 for(size_t i=0;i<n;++i)if(isnan(c->width==32?((const float*)values)[i]:((const double*)values)[i]))return SF_INVALID;
 IO*b=&c->io;if(setjmp(b->fail)){c->bad=1;return (sf_status)b->error;}
 for(size_t i=0;i<n;++i){
  double d=c->width==32?((const float*)values)[i]:((const double*)values)[i];uint64_t v;
  int beta=erase(c,from_number(d,c->width),l->erase_last,&v);++l->freq[beta];if(beta!=c->raw)l->erase_last=beta;
  if(c->algorithm==SF_ELF_STAR){l->values[l->count]=v;l->beta[l->count]=beta;}
  else{beta_put(c,beta,&l->put_last);xor_put(c,v,l->count==0,l->ld,l->td);}
  ++l->count;
 }
 return SF_OK;
}
sf_status sf_c_finish(sf_c*c,size_t*bits){
 if(!c||!bits)return SF_INVALID;*bits=0;
 if(c->bad||c->active!=1)return SF_STATE;
 Live*l=c->live;if(!l->count)return SF_INVALID;
 IO*b=&c->io;if(setjmp(b->fail)){c->bad=1;return (sf_status)b->error;}
 if(c->algorithm==SF_ELF_STAR){
  for(size_t i=1;i<l->count;++i){uint64_t x=l->values[i-1]^l->values[i];if(x){++l->ld[clz(x,c->width)];++l->td[ctz(x,c->width)];}}
  huffman(l->freq,c->raw+1,c->codes);write_codes(b,c->codes,c->raw+1);
  optimize_positions(&c->lead,l->ld,c->width);optimize_positions(&c->trail,l->td,c->width);
  for(size_t i=0;i<l->count;++i){beta_put(c,l->beta[i],&l->put_last);xor_put(c,l->values[i],i==0,l->ld,l->td);}
 }
 int update=0;if(c->algorithm==SF_SELF_STAR){double ratio=(double)b->pos/(l->count*c->width);update=c->ratio<ratio;c->ratio=ratio;}
 beta_put(c,c->raw,&l->put_last);xor_put(c,end_sign(c->width),0,l->ld,l->td);
 if(c->algorithm==SF_SELF_STAR){huffman(l->freq,c->raw+1,c->codes);if(update){optimize_positions(&c->lead,l->ld,c->width);optimize_positions(&c->trail,l->td,c->width);}c->write_positions=update;}
 *bits=b->pos;if(b->pos%8)b->out[b->pos/8]&=(uint8_t)(0xffu<<(8-b->pos%8));
 ++c->blocks;c->active=0;return SF_OK;
}
sf_status sf_c_read_begin(sf_c*c,const uint8_t*in,size_t bytes,size_t bits,size_t n){
 if(!c||!in||n<1||n>MAX_BLOCK||!bits||bits>200000||bytes!=(bits+7)/8)return SF_INVALID;
 if(c->bad||c->active||c->direction==1)return SF_STATE;
 if(bits%8&&(in[bytes-1]&((1u<<(8-bits%8))-1)))return SF_CORRUPT;
 if(!live_prepare(c))return SF_MEMORY;
 c->direction=2;c->active=2;c->live->expected=n;
 IO*b=&c->io;b->in=in;b->pos=0;b->limit=bits;b->error=0;
 if(setjmp(b->fail)){c->bad=1;return (sf_status)b->error;}
 if(c->algorithm!=SF_SELF_STAR)c->sl=c->st=BAD;
 if(c->algorithm==SF_ELF_STAR)read_codes(b,c->codes,c->raw+1);
 return SF_OK;
}
sf_status sf_c_next(sf_c*c,void*out,int*has){
 if(has)*has=0;if(!c||!out||!has)return SF_INVALID;
 if(c->bad)return SF_STATE;
 if(c->active!=2)return c->live&&c->live->ended&&c->direction==2?SF_OK:SF_STATE;
 Live*l=c->live;IO*b=&c->io;if(setjmp(b->fail)){c->bad=1;return (sf_status)b->error;}
 int beta=beta_get(c,&l->put_last);uint64_t v=xor_get(c,l->count==0);
 if(l->count==l->expected){
  if(beta!=c->raw||v!=end_sign(c->width)||b->pos!=b->limit)fail(b,SF_CORRUPT);
  if(c->algorithm==SF_SELF_STAR)huffman(l->freq,c->raw+1,c->codes);
  ++c->blocks;c->active=0;l->ended=1;return SF_OK;
 }
 if(v==end_sign(c->width))fail(b,SF_CORRUPT);
 ++l->freq[beta];double d=number(v,c->width);
 if(beta!=c->raw){d=restore(d,beta,c->width);if(!isfinite(d))fail(b,SF_CORRUPT);}else if(isnan(d))fail(b,SF_CORRUPT);
 if(c->width==32)*(float*)out=(float)d;else *(double*)out=d;
 ++l->count;*has=1;return SF_OK;
}
sf_status sf_c_progress(sf_c*c,sf_progress*p){
 if(!c||!p)return SF_INVALID;
 if(c->bad)return SF_STATE;
 p->phase=c->active;p->count=c->live?c->live->count:0;p->bits=c->io.pos;
 p->deferred_values=c->active==1&&c->algorithm==SF_ELF_STAR?c->live->count:0;return SF_OK;
}
