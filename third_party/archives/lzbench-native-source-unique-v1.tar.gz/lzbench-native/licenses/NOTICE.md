# 来源与许可

lzbench fa871e66b3543a70fd4d060f7c12719343ff4ac3（https://github.com/inikep/lzbench），离线干净原件。bench 的原包装按 GPL v2 或 v3；完整许可见 LICENSE-GPL-2/3 与 upstream/LICENSE。本项目新适配/工具同样采用 GPL v2 或 v3，保留各算法自身许可，不声称核心原创。

|链接组件|版本|许可原件|
|---|---|---|
|Brotli C|1.2.0|upstream/lz/brotli/LICENSE (MIT)|
|bzip2 C|1.0.8|upstream/bwt/bzip2/LICENSE（bzip2 特有许可）|
|libdeflate C|1.25|upstream/lz/libdeflate/COPYING (MIT)|
|LZ4 C|1.10.0|upstream/lz/lz4/lib/LICENSE (BSD-2-Clause)|
|LZSSE2/8 C++|2019-04-18|upstream/lz/lzsse/LICENSE (BSD-2-Clause)|
|Snappy C++|1.2.2|upstream/lz/snappy/COPYING (BSD-3-Clause)|
|XZ liblzma C|5.8.3|upstream/lz/xz/COPYING.0BSD；其他保留文件另见 COPYING|
|Zstandard C/ASM|1.5.7|upstream/lz/zstd/LICENSE (BSD-3-Clause)，也提供 GPLv2 选项|

仅链接 docs/build-closure.json（排除 lzsse4）的 codec 源文件；不链接 XZ 的 getopt/命令行、测试或其它工具。保留组件子目录中的其余构建/文档许可文本。系统依赖 libstdc++、libgcc、libc、libm、pthread；没有动态链接系统压缩库。C 接口仍需 C++ 链接运行库，因为 LZSSE 和 Snappy 核心是 C++。

候选修改：LZSSE 对齐/别名显式扩展与 malloc 失败/空长度分配防护；源码在 build/generated/candidate 生成，补丁由 tools/prepare.py 重放并记录。参考性能包装只为 libdeflate decoder 增加 free；未修原包装另构建 exact_worker。两者均不改变有效流的编解码决策。具体限制和检查见 contract.md、results/REPORT.md。
