#include "lzbench_extended.hpp"
#include <mutex>
#include <set>
#include <thread>
namespace {
std::mutex guard;
std::set<std::thread::id> workers;
std::thread::id caller;
std::uint64_t jobs=0,caller_jobs=0;
}
extern "C" void lnx_trace_job(void) {
 std::lock_guard<std::mutex> lock(guard);++jobs;
 if(std::this_thread::get_id()==caller)++caller_jobs;
 else workers.insert(std::this_thread::get_id());
}
namespace lzbench_native {
void reset_worker_stats(){std::lock_guard<std::mutex> lock(guard);workers.clear();jobs=caller_jobs=0;caller=std::this_thread::get_id();}
worker_stats get_worker_stats(){std::lock_guard<std::mutex> lock(guard);return {jobs,workers.size(),caller_jobs};}
}
