// Thin native backend integration, retaining the legacy api.cpp and profiles.
#include "lzbench_extended.hpp"
#define ZSTD_STATIC_LINKING_ONLY
#define LZ4F_STATIC_LINKING_ONLY
#include "lzbench_backends.h"
#include <algorithm>
#include <climits>
#include <cstring>
#include <set>
#include <stdexcept>
#include <utility>
extern "C" int64_t lnx_brotli_parameter(const void*,int);
namespace lzbench_native {
namespace {
void require(bool good,const std::string& message){if(!good)throw std::runtime_error(message);}
void zcheck(size_t v){require(!ZSTD_isError(v),ZSTD_getErrorName(v));}
void fcheck(size_t v){require(!LZ4F_isError(v),LZ4F_getErrorName(v));}
const unsigned char empty_byte=0;
int parameter_id(const std::string& key){size_t pos=0;int id=std::stoi(key.substr(6),&pos);require(pos==key.size()-6&&id>=0,"native parameter id");return id;}
bool overlap(const void* a,size_t n,const void* b,size_t m){if(!n||!m)return false;auto x=(uintptr_t)a,y=(uintptr_t)b;return x<y?y-x<n:x-y<m;}
}
struct session::impl {
 configuration c;std::set<std::string> used;std::map<std::string,std::int64_t> effective;
 BrotliEncoderState *be=nullptr;BrotliDecoderState *bd=nullptr;BrotliEncoderPreparedDictionary *bp=nullptr;
 bz_stream bz[2]{};bool binit[2]{};
 lzma_stream xs[2]{LZMA_STREAM_INIT,LZMA_STREAM_INIT};
 lzma_options_lzma lzopt{};lzma_options_delta delta[3]{};lzma_options_bcj bcj[3]{};lzma_filter filters[5]{};lzma_mt mt{};
 ZSTD_CCtx *zc=nullptr;ZSTD_DCtx *zd=nullptr;
 LZ4_stream_t *ls=nullptr;LZ4_streamHC_t *hc=nullptr;LZ4F_cctx *fc=nullptr;LZ4F_dctx *fd=nullptr;LZ4F_preferences_t fp{};
 LZSSE2_OptimalParseState *s2=nullptr;LZSSE8_OptimalParseState *s8=nullptr;LZSSE8_FastParseState *sfast=nullptr;size_t parse_capacity=0;
 libdeflate_compressor *dc=nullptr;libdeflate_decompressor *dd=nullptr;
 bytes history[2],pending;size_t pending_pos=0;bool fbegun=false,fended=false;
 bool initialized[2]{},done[2]{},failed[2]{};bool stream=false,continuing=false;
 int value(const std::string& key,int fallback){auto v=number(key,fallback);require(v>=INT_MIN&&v<=INT_MAX,"parameter outside int: "+key);return (int)v;}
 uint32_t unsigned32(const std::string& key,uint32_t fallback){auto v=number(key,fallback);require(v>=0&&v<=UINT32_MAX,"parameter outside uint32: "+key);return (uint32_t)v;}
 uint64_t unsigned64(const std::string& key,uint64_t fallback){auto v=number(key,(int64_t)fallback);require(v>=0,"negative parameter: "+key);return (uint64_t)v;}
 std::int64_t number(const std::string& key,std::int64_t fallback){used.insert(key);auto it=c.parameters.find(key);auto v=it==c.parameters.end()?fallback:it->second;effective[key]=v;return v;}
 void unknown(){for(auto& kv:c.parameters)require(used.count(kv.first),"unsupported parameter: "+kv.first);}
 explicit impl(configuration cfg):c(std::move(cfg)) {
  require(c.codec>=LN_BROTLI&&c.codec<LN_CODEC_COUNT,"codec");require(c.dictionary.size()<=(size_t)INT_MAX,"dictionary length");
  if(c.mode.empty())c.mode=(c.codec==LN_LZSSE2||c.codec==LN_LZSSE8)?"optimal":(c.codec==LN_LZ4||c.codec==LN_SNAPPY||c.codec==LN_DEFLATE)?"raw":"frame";
  if(c.level==INT_MIN)c.level=(c.mode=="fast"?0:((c.mode=="hc"||c.mode=="continue-hc")?LZ4HC_CLEVEL_DEFAULT:ln_default_level(c.codec)));
  stream=c.codec==LN_BROTLI||c.codec==LN_BZIP2||c.codec==LN_XZ||c.codec==LN_ZSTD||(c.codec==LN_LZ4&&c.mode=="frame");
  continuing=c.codec==LN_LZ4&&(c.mode=="continue"||c.mode=="continue-hc");
  require(c.dictionary.empty()||c.codec==LN_BROTLI||c.codec==LN_LZ4||c.codec==LN_ZSTD,"backend has no external dictionary in selected format");
  if(c.codec==LN_BROTLI){require(c.mode=="frame"&&c.level>=0&&c.level<=11,"Brotli mode/quality");value("window",22);require(value("mode",0)>=0&&value("mode",0)<=2,"Brotli mode");value("lgblock",0);require(value("dictionary_type",0)>=0&&value("dictionary_type",0)<=1,"Brotli dictionary type");
   for(auto& kv:c.parameters)if(kv.first.rfind("param.",0)==0){require(kv.second>=0&&kv.second<=UINT32_MAX,"Brotli native uint32 parameter");parameter_id(kv.first);used.insert(kv.first);effective[kv.first]=kv.second;}
  }else if(c.codec==LN_BZIP2){require(c.mode=="frame"&&c.level>=1&&c.level<=9,"bzip2 level/mode");int work=value("work_factor",30),small=value("small",0);require(work>=0&&work<=250&&(small==0||small==1),"bzip2 parameters");}
  else if(c.codec==LN_DEFLATE){require(c.mode=="raw"&&c.level>=0&&c.level<=12,"libdeflate mode/level");}
  else if(c.codec==LN_LZ4){
   require(c.mode=="raw"||c.mode=="hc"||c.mode=="continue"||c.mode=="continue-hc"||c.mode=="frame","LZ4 mode");
   if(c.mode=="frame"){
    require(c.level>=-65536&&c.level<=LZ4HC_CLEVEL_MAX,"LZ4 frame level");fp.compressionLevel=c.level;
    int bs=value("block_size_id",LZ4F_max64KB),bm=value("block_mode",LZ4F_blockLinked),cs=value("checksum",1),bc=value("block_checksum",0);
    require(bs>=4&&bs<=7&&bm>=0&&bm<=1&&cs>=0&&cs<=1&&bc>=0&&bc<=1,"LZ4 frame enum parameters");
    fp.frameInfo.blockSizeID=(LZ4F_blockSizeID_t)bs;fp.frameInfo.blockMode=(LZ4F_blockMode_t)bm;fp.frameInfo.contentChecksumFlag=(LZ4F_contentChecksum_t)cs;fp.frameInfo.blockChecksumFlag=(LZ4F_blockChecksum_t)bc;
    fp.frameInfo.contentSize=unsigned64("content_size",0);fp.frameInfo.dictID=unsigned32("dictionary_id",0);fp.autoFlush=(unsigned)value("auto_flush",0);fp.favorDecSpeed=(unsigned)value("favor_decode_speed",0);
    require(fp.frameInfo.blockSizeID>=LZ4F_max64KB&&fp.frameInfo.blockSizeID<=LZ4F_max4MB,"LZ4 frame block size");require((int)fp.frameInfo.blockMode>=0&&fp.frameInfo.blockMode<=LZ4F_blockIndependent&&(int)fp.frameInfo.contentChecksumFlag>=0&&fp.frameInfo.contentChecksumFlag<=LZ4F_contentChecksumEnabled&&(int)fp.frameInfo.blockChecksumFlag>=0&&fp.frameInfo.blockChecksumFlag<=LZ4F_blockChecksumEnabled&&fp.autoFlush<=1&&fp.favorDecSpeed<=1,"LZ4 frame parameters");
   }else if(c.mode=="hc"||c.mode=="continue-hc"){require(c.level>=LZ4HC_CLEVEL_MIN&&c.level<=LZ4HC_CLEVEL_MAX,"LZ4 HC level");}
   else{require(c.level==0,"LZ4 fast level N/A; use acceleration");require(value("acceleration",1)>0,"LZ4 acceleration");}
  }else if(c.codec==LN_LZSSE2||c.codec==LN_LZSSE8){require(__builtin_cpu_supports("sse4.1"),"SSE4.1 required");require(c.mode=="optimal"||(c.codec==LN_LZSSE8&&c.mode=="fast"),"selected LZSSE mode");require(c.level>=0&&c.level<=17&&(c.mode!="fast"||c.level==0),"LZSSE level");}
  else if(c.codec==LN_SNAPPY){require(c.mode=="raw"&&c.level==0,"Snappy has no level/stream/dictionary");}
  else if(c.codec==LN_XZ){
   require(c.mode=="frame"&&c.level>=0&&c.level<=9,"XZ mode/preset");auto preset=unsigned32("preset",(uint32_t)c.level);require(!lzma_lzma_preset(&lzopt,preset),"XZ preset");
   lzopt.dict_size=unsigned32("dict_size",lzopt.dict_size);lzopt.lc=unsigned32("lc",lzopt.lc);lzopt.lp=unsigned32("lp",lzopt.lp);lzopt.pb=unsigned32("pb",lzopt.pb);auto lm=value("lzma_mode",(int)lzopt.mode);require(lm==1||lm==2,"XZ mode");lzopt.mode=(lzma_mode)lm;lzopt.nice_len=unsigned32("nice_len",lzopt.nice_len);auto mf=value("match_finder",(int)lzopt.mf);require(mf==3||mf==4||mf==18||mf==19||mf==20,"XZ match finder");lzopt.mf=(lzma_match_finder)mf;lzopt.depth=unsigned32("depth",lzopt.depth);
   size_t f=0;for(unsigned i=0;i<3;++i){std::string key="filter"+std::to_string(i);auto id=number(key,0);if(!id)continue;filters[f].id=(lzma_vli)id;
    if(id==LZMA_FILTER_DELTA){delta[i].type=LZMA_DELTA_TYPE_BYTE;delta[i].dist=unsigned32(key+"_distance",1);filters[f].options=&delta[i];}
    else{require(id==LZMA_FILTER_X86||id==LZMA_FILTER_POWERPC||id==LZMA_FILTER_IA64||id==LZMA_FILTER_ARM||id==LZMA_FILTER_ARMTHUMB||id==LZMA_FILTER_ARM64||id==LZMA_FILTER_SPARC||id==LZMA_FILTER_RISCV,"XZ BCJ filter id");bcj[i].start_offset=unsigned32(key+"_offset",0);filters[f].options=&bcj[i];}++f;
   }filters[f++]={LZMA_FILTER_LZMA2,&lzopt};filters[f]={LZMA_VLI_UNKNOWN,nullptr};mt.filters=filters;
   mt.threads=unsigned32("threads",1);mt.block_size=unsigned64("block_size",0);auto check=value("check",LZMA_CHECK_CRC64);require(check==0||check==1||check==4||check==10,"XZ check");mt.check=(lzma_check)check;mt.timeout=unsigned32("timeout_ms",0);
   require(mt.threads>=1&&mt.threads<=64&&lzma_check_is_supported(mt.check),"XZ threads/check");
   auto mem=number("memory_limit",INT64_C(2147483648));require(mem>0,"XZ memory limit");mt.memlimit_stop=(uint64_t)mem;mt.memlimit_threading=(uint64_t)mem;
   auto usage=lzma_stream_encoder_mt_memusage(&mt);require(usage!=UINT64_MAX&&usage<=(uint64_t)mem,"XZ encoder memory/configuration limit");effective["encoder_memory_bytes"]=(std::int64_t)usage;
  }else if(c.codec==LN_ZSTD){
   require(c.mode=="frame"&&c.level>=ZSTD_minCLevel()&&c.level<=ZSTD_maxCLevel(),"Zstd mode/level");
   require(value("workers",0)>=0&&value("workers",0)<=64,"Zstd workers range");value("window_log",0);value("strategy",0);value("job_size",0);value("checksum",0);value("content_size",1);number("pledged_size",-1);
   for(auto& kv:c.parameters)if(kv.first.rfind("param.",0)==0){parameter_id(kv.first);used.insert(kv.first);effective[kv.first]=kv.second;}
  }
  unknown();
 }
 ~impl(){close(0);close(1);BrotliEncoderDestroyPreparedDictionary(bp);ZSTD_freeCCtx(zc);ZSTD_freeDCtx(zd);LZ4_freeStream(ls);LZ4_freeStreamHC(hc);LZ4F_freeCompressionContext(fc);LZ4F_freeDecompressionContext(fd);if(s2)LZSSE2_FreeOptimalParseState(s2);if(s8)LZSSE8_FreeOptimalParseState(s8);LZSSE8_FreeFastParseState(sfast);libdeflate_free_compressor(dc);libdeflate_free_decompressor(dd);}
 void close(unsigned d){if(d==0){BrotliEncoderDestroyInstance(be);be=nullptr;}else{BrotliDecoderDestroyInstance(bd);bd=nullptr;}if(binit[d]){if(!d)BZ2_bzCompressEnd(&bz[d]);else BZ2_bzDecompressEnd(&bz[d]);binit[d]=false;}lzma_end(&xs[d]);xs[d]=LZMA_STREAM_INIT;initialized[d]=done[d]=failed[d]=false;}
 void reset(unsigned d){
  close(d);history[d]=c.dictionary;if(history[d].size()>65536)history[d].erase(history[d].begin(),history[d].end()-65536);
  if(!d){pending.clear();pending_pos=0;fbegun=fended=false;}
  if(c.codec==LN_BROTLI){
   if(!d){be=BrotliEncoderCreateInstance(nullptr,nullptr,nullptr);require(be,"Brotli allocation");require(BrotliEncoderSetParameter(be,BROTLI_PARAM_QUALITY,(uint32_t)c.level)&&BrotliEncoderSetParameter(be,BROTLI_PARAM_LGWIN,(uint32_t)value("window",22))&&BrotliEncoderSetParameter(be,BROTLI_PARAM_MODE,(uint32_t)value("mode",0))&&BrotliEncoderSetParameter(be,BROTLI_PARAM_LGBLOCK,(uint32_t)value("lgblock",0)),"Brotli parameters");
    for(auto& kv:c.parameters)if(kv.first.rfind("param.",0)==0){auto id=parameter_id(kv.first);if(id==0)require(kv.second>=0&&kv.second<=2,"Brotli mode");require(kv.second>=0&&kv.second<=UINT32_MAX&&BrotliEncoderSetParameter(be,(BrotliEncoderParameter)id,(uint32_t)kv.second),"Brotli native parameter");}
    if(!c.dictionary.empty()){if(!bp)bp=BrotliEncoderPrepareDictionary((BrotliSharedDictionaryType)value("dictionary_type",0),c.dictionary.size(),c.dictionary.data(),11,nullptr,nullptr,nullptr);require(bp&&BrotliEncoderAttachPreparedDictionary(be,bp),"Brotli prepared dictionary");}
   }else{bd=BrotliDecoderCreateInstance(nullptr,nullptr,nullptr);require(bd,"Brotli decoder allocation");require(BrotliDecoderSetParameter(bd,BROTLI_DECODER_PARAM_LARGE_WINDOW,1),"Brotli large window");if(!c.dictionary.empty())require(BrotliDecoderAttachDictionary(bd,(BrotliSharedDictionaryType)value("dictionary_type",0),c.dictionary.size(),c.dictionary.data()),"Brotli decoder dictionary");}
  }else if(c.codec==LN_BZIP2){bz[d]={};int r=!d?BZ2_bzCompressInit(&bz[d],c.level,0,value("work_factor",30)):BZ2_bzDecompressInit(&bz[d],0,value("small",0));require(r==BZ_OK,"bzip2 init");binit[d]=true;}
  else if(c.codec==LN_XZ){lzma_ret r=!d?lzma_stream_encoder_mt(&xs[d],&mt):lzma_stream_decoder_mt(&xs[d],&mt);require(r==LZMA_OK,"XZ init: "+std::to_string(r));}
  else if(c.codec==LN_ZSTD){
   if(!d){if(!zc)zc=ZSTD_createCCtx();require(zc,"Zstd allocation");zcheck(ZSTD_CCtx_reset(zc,ZSTD_reset_session_and_parameters));
    for(auto kv:std::vector<std::pair<ZSTD_cParameter,int>>{{ZSTD_c_compressionLevel,c.level},{ZSTD_c_nbWorkers,value("workers",0)},{ZSTD_c_windowLog,value("window_log",0)},{ZSTD_c_strategy,value("strategy",0)},{ZSTD_c_jobSize,value("job_size",0)},{ZSTD_c_checksumFlag,value("checksum",0)},{ZSTD_c_contentSizeFlag,value("content_size",1)}})zcheck(ZSTD_CCtx_setParameter(zc,kv.first,kv.second));
    for(auto& kv:c.parameters)if(kv.first.rfind("param.",0)==0){auto id=parameter_id(kv.first);require(kv.second>=INT_MIN&&kv.second<=INT_MAX,"Zstd parameter int");zcheck(ZSTD_CCtx_setParameter(zc,(ZSTD_cParameter)id,(int)kv.second));int v;zcheck(ZSTD_CCtx_getParameter(zc,(ZSTD_cParameter)id,&v));effective[kv.first]=v;}
    zcheck(ZSTD_CCtx_loadDictionary(zc,c.dictionary.data(),c.dictionary.size()));auto pledge=number("pledged_size",-1);require(pledge>=-1,"pledged size");if(pledge>=0)zcheck(ZSTD_CCtx_setPledgedSrcSize(zc,(unsigned long long)pledge));
    for(auto key:std::vector<std::pair<const char*,ZSTD_cParameter>>{{"workers",ZSTD_c_nbWorkers},{"window_log",ZSTD_c_windowLog},{"strategy",ZSTD_c_strategy},{"job_size",ZSTD_c_jobSize}}){int v;zcheck(ZSTD_CCtx_getParameter(zc,key.second,&v));effective[key.first]=v;}
   }else{if(!zd)zd=ZSTD_createDCtx();require(zd,"Zstd decoder allocation");zcheck(ZSTD_DCtx_reset(zd,ZSTD_reset_session_and_parameters));zcheck(ZSTD_DCtx_loadDictionary(zd,c.dictionary.data(),c.dictionary.size()));}
  }else if(c.codec==LN_LZ4){
   if(c.mode=="frame"){if(!d){if(!fc)fcheck(LZ4F_createCompressionContext(&fc,LZ4F_VERSION));}else{if(!fd)fcheck(LZ4F_createDecompressionContext(&fd,LZ4F_VERSION));LZ4F_resetDecompressionContext(fd);}}
   else if(!d){if(c.mode=="hc"||c.mode=="continue-hc"){if(!hc)hc=LZ4_createStreamHC();require(hc,"LZ4 HC allocation");LZ4_resetStreamHC_fast(hc,c.level);LZ4_loadDictHC(hc,(const char*)c.dictionary.data(),(int)c.dictionary.size());}else{if(!ls)ls=LZ4_createStream();require(ls,"LZ4 allocation");LZ4_resetStream_fast(ls);LZ4_loadDict(ls,(const char*)c.dictionary.data(),(int)c.dictionary.size());}}
  }else if(c.codec==LN_DEFLATE){if(!d&&!dc)dc=libdeflate_alloc_compressor(c.level);if(d&&!dd)dd=libdeflate_alloc_decompressor();require(!d?dc!=nullptr:dd!=nullptr,"libdeflate allocation");}
  initialized[d]=true;
 }
 void retain(unsigned d,const void *data,size_t n){const auto *p=(const unsigned char*)data;if(n>=65536)history[d].assign(p+n-65536,p+n);else{if(history[d].size()+n>65536)history[d].erase(history[d].begin(),history[d].begin()+(history[d].size()+n-65536));history[d].insert(history[d].end(),p,p+n);}}
};
session::session(configuration c):p(new impl(std::move(c))){}
session::~session()=default;session::session(session&&) noexcept=default;session& session::operator=(session&&) noexcept=default;
const configuration& session::configured()const{return p->c;}
std::map<std::string,std::int64_t> session::effective_parameters()const{
 auto out=p->effective;
 if(p->c.codec==LN_BROTLI&&p->be){for(auto k:std::vector<std::pair<const char*,int>>{{"mode",0},{"quality",1},{"window",2},{"lgblock",3}})out[k.first]=lnx_brotli_parameter(p->be,k.second);for(auto& kv:out)if(kv.first.rfind("param.",0)==0)kv.second=lnx_brotli_parameter(p->be,parameter_id(kv.first));}
 if(p->c.codec==LN_ZSTD&&p->zc){int value;zcheck(ZSTD_CCtx_getParameter(p->zc,ZSTD_c_compressionLevel,&value));out["level"]=value;}
 return out;
}
bool session::streaming()const{return p->stream;}
void session::reset(bool encode){p->reset(encode?0:1);}
progress session::process(bool encode,const void *input,size_t n,void *output,size_t cap,bool finish){
 unsigned d=encode?0:1;require(p->stream,"batch-only backend/mode has no incremental API");require((input||!n)&&(output||!cap)&&cap&&!overlap(input,n,output,cap),"stream spans/capacity/overlap");require(!p->failed[d],"reset required after failure");require(!p->done[d],"reset required after stream end");
 if(!input)input=&empty_byte;
 try{
  if(!p->initialized[d])p->reset(d);size_t used=0,made=0;bool end=false;
  switch(p->c.codec){
   case LN_BROTLI:{size_t in=n,out=cap;auto ip=(const uint8_t*)input;auto op=(uint8_t*)output;
    if(encode){require(BrotliEncoderCompressStream(p->be,finish?BROTLI_OPERATION_FINISH:BROTLI_OPERATION_PROCESS,&in,&ip,&out,&op,nullptr),"Brotli encode");end=BrotliEncoderIsFinished(p->be)!=0;}
    else{auto r=BrotliDecoderDecompressStream(p->bd,&in,&ip,&out,&op,nullptr);require(r!=BROTLI_DECODER_RESULT_ERROR,"Brotli decode");end=r==BROTLI_DECODER_RESULT_SUCCESS;}
    used=n-in;made=cap-out;break;}
   case LN_BZIP2:{require(n<=UINT_MAX,"bzip2 input span exceeds UINT_MAX");auto& s=p->bz[d];size_t ni=std::min(n,(size_t)UINT_MAX),no=std::min(cap,(size_t)UINT_MAX);s.next_in=(char*)input;s.avail_in=(unsigned)ni;s.next_out=(char*)output;s.avail_out=(unsigned)no;
    auto r=encode?BZ2_bzCompress(&s,finish?BZ_FINISH:BZ_RUN):BZ2_bzDecompress(&s);require(r>=0,"bzip2 code");used=ni-s.avail_in;made=no-s.avail_out;end=r==BZ_STREAM_END;break;}
   case LN_XZ:{auto& s=p->xs[d];s.next_in=(const uint8_t*)input;s.avail_in=n;s.next_out=(uint8_t*)output;s.avail_out=cap;auto r=lzma_code(&s,finish?LZMA_FINISH:LZMA_RUN);require(r==LZMA_OK||r==LZMA_STREAM_END,"XZ code: "+std::to_string(r));used=n-s.avail_in;made=cap-s.avail_out;end=r==LZMA_STREAM_END;break;}
   case LN_ZSTD:{ZSTD_inBuffer in{input,n,0};ZSTD_outBuffer out{output,cap,0};auto r=encode?ZSTD_compressStream2(p->zc,&out,&in,finish?ZSTD_e_end:ZSTD_e_continue):ZSTD_decompressStream(p->zd,&out,&in);zcheck(r);used=in.pos;made=out.pos;end=encode?(finish&&r==0):r==0;break;}
   case LN_LZ4:{if(!encode){size_t in=n,out=cap;auto r=LZ4F_decompress_usingDict(p->fd,output,&out,input,&in,p->c.dictionary.data(),p->c.dictionary.size(),nullptr);fcheck(r);used=in;made=out;end=r==0;}
    else{
     if(p->pending_pos==p->pending.size()){
      p->pending.clear();p->pending_pos=0;
      if(!p->fbegun){p->pending.resize(LZ4F_HEADER_SIZE_MAX);auto r=LZ4F_compressBegin_usingDict(p->fc,p->pending.data(),p->pending.size(),p->c.dictionary.data(),p->c.dictionary.size(),&p->fp);fcheck(r);p->pending.resize(r);p->fbegun=true;}
      else if(n){used=std::min(n,(size_t)65536);p->pending.resize(LZ4F_compressBound(used,&p->fp));auto r=LZ4F_compressUpdate(p->fc,p->pending.data(),p->pending.size(),input,used,nullptr);fcheck(r);p->pending.resize(r);}
      else if(finish&&!p->fended){p->pending.resize(LZ4F_compressBound(0,&p->fp));auto r=LZ4F_compressEnd(p->fc,p->pending.data(),p->pending.size(),nullptr);fcheck(r);p->pending.resize(r);p->fended=true;}
     }
     made=std::min(cap,p->pending.size()-p->pending_pos);if(made)std::memcpy(output,p->pending.data()+p->pending_pos,made);p->pending_pos+=made;end=p->fended&&p->pending_pos==p->pending.size();
    }break;}
   default:throw std::runtime_error("no incremental backend");
  }
  if(!encode&&finish&&!used&&!made&&!end)throw std::runtime_error("truncated stream");
  p->done[d]=end;return {used,made,end};
 }catch(...){p->failed[d]=true;throw;}
}
bytes session::compress_block(const void *input,size_t n){
 require(!p->stream,"use process for native stream/frame");require(n<=(size_t)INT_MAX&&(input||!n),"native block length");if(!input)input=&empty_byte;
 if(!p->initialized[0]||!p->continuing)p->reset(0);
 size_t cap=std::min<size_t>(INT_MAX,2*n+1024);bytes out(cap);size_t used=0;
 switch(p->c.codec){
 case LN_DEFLATE:used=libdeflate_deflate_compress(p->dc,input,n,out.data(),cap);require(used>0,"DEFLATE compression");break;
 case LN_SNAPPY:used=cap;require(snappy_compress((const char*)input,n,(char*)out.data(),&used)==SNAPPY_OK,"Snappy compress");break;
 case LN_LZ4:{int k;if(p->c.mode=="hc"||p->c.mode=="continue-hc")k=LZ4_compress_HC_continue(p->hc,(const char*)input,(char*)out.data(),(int)n,(int)cap);else k=LZ4_compress_fast_continue(p->ls,(const char*)input,(char*)out.data(),(int)n,(int)cap,p->value("acceleration",1));require(k>0,"LZ4 compress");used=(size_t)k;
  if(p->continuing){bytes saved(65536);int count=p->hc?LZ4_saveDictHC(p->hc,(char*)saved.data(),65536):LZ4_saveDict(p->ls,(char*)saved.data(),65536);saved.resize((size_t)count);p->history[0].swap(saved);}break;}
 case LN_LZSSE2:case LN_LZSSE8:{require(n<=SIZE_MAX/2,"LZSSE size");if(p->c.mode=="fast"){if(!p->sfast)p->sfast=LZSSE8_MakeFastParseState();require(p->sfast,"LZSSE8 fast allocation");used=LZSSE8_CompressFast(p->sfast,input,n,out.data(),cap);}
  else{if(p->parse_capacity<n||(!p->s2&&!p->s8)){
   if(p->c.codec==LN_LZSSE2){auto *state=LZSSE2_MakeOptimalParseState(std::max<size_t>(1,n));require(state,"LZSSE2 allocation");if(p->s2)LZSSE2_FreeOptimalParseState(p->s2);p->s2=state;}
   else{auto *state=LZSSE8_MakeOptimalParseState(std::max<size_t>(1,n));require(state,"LZSSE8 allocation");if(p->s8)LZSSE8_FreeOptimalParseState(p->s8);p->s8=state;}p->parse_capacity=n;}
   used=p->c.codec==LN_LZSSE2?LZSSE2_CompressOptimalParse(p->s2,input,n,out.data(),cap,(unsigned)p->c.level):LZSSE8_CompressOptimalParse(p->s8,input,n,out.data(),cap,(unsigned)p->c.level);
  }require(used||!n,"LZSSE compress");break;}
 default:throw std::runtime_error("batch mode");
 }
 require(used<=cap,"native output capacity");out.resize(used);return out;
}
bytes session::decompress_block(const void *input,size_t n,size_t expected){
 require(!p->stream,"use process for stream/frame");require(n<=(size_t)INT_MAX&&expected<=(size_t)INT_MAX&&(input||!n),"native block lengths");if(!input)input=&empty_byte;
 if(!p->initialized[1]||!p->continuing)p->reset(1);bytes out(std::max<size_t>(expected,1));size_t used=0;
 switch(p->c.codec){
 case LN_DEFLATE:require(libdeflate_deflate_decompress(p->dd,input,n,out.data(),expected,&used)==LIBDEFLATE_SUCCESS,"DEFLATE decode");break;
 case LN_SNAPPY:used=expected;require(snappy_uncompress((const char*)input,n,(char*)out.data(),&used)==SNAPPY_OK,"Snappy decode");break;
 case LN_LZ4:{int k=LZ4_decompress_safe_usingDict((const char*)input,(char*)out.data(),(int)n,(int)expected,(const char*)p->history[1].data(),(int)p->history[1].size());require(k>=0,"LZ4 decode");used=(size_t)k;if(p->continuing)p->retain(1,out.data(),used);break;}
 case LN_LZSSE2:case LN_LZSSE8:require(n==expected||(n>=32&&expected>=32),"LZSSE short compressed block");used=p->c.codec==LN_LZSSE2?LZSSE2_Decompress(input,n,out.data(),expected):LZSSE8_Decompress(input,n,out.data(),expected);break;
 default:throw std::runtime_error("batch mode");
 }require(used==expected,"native decoded length");out.resize(used);return out;
}
bytes train_zstd_dictionary(const std::vector<bytes>& samples,size_t capacity){
 require(capacity>=256&&capacity<=(size_t)INT_MAX&&samples.size()<=UINT_MAX,"dictionary training size");bytes data;std::vector<size_t> sizes;for(auto& sample:samples){sizes.push_back(sample.size());data.insert(data.end(),sample.begin(),sample.end());}
 bytes dict(capacity);auto used=ZDICT_trainFromBuffer(dict.data(),dict.size(),data.data(),sizes.data(),(unsigned)sizes.size());require(!ZDICT_isError(used),ZDICT_getErrorName(used));dict.resize(used);return dict;
}
}
