// Native integration; see NOTICE.md. New adapter GPL-2.0-or-3.0.
#include "lzbench_native.h"
#include <algorithm>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <new>
#include "brotli/encode.h"
#include "brotli/decode.h"
#include "bwt/bzip2/bzlib.h"
#include "lz/libdeflate/libdeflate.h"
#include "lz/lz4/lib/lz4.h"
#include "lzsse/lzsse2/lzsse2.h"
#include "lzsse/lzsse8/lzsse8.h"
#include "snappy/snappy.h"
#include "lz/xz/src/liblzma/api/lzma.h"
#include "zstd/lib/zstd.h"
struct ln_context {ln_codec kind;int level;void *state=nullptr;ZSTD_CCtx *zc=nullptr;ZSTD_DCtx *zd=nullptr;};
static bool valid(ln_codec c){return c>=LN_BROTLI&&c<LN_CODEC_COUNT;}
static bool overlaps(const void *a,size_t n,const void *b,size_t m){if(!n||!m)return false;auto x=(uintptr_t)a,y=(uintptr_t)b;return x<y?y-x<n:x-y<m;}
extern "C" const char *ln_codec_name(ln_codec c){static const char* names[]={"brotli","bzip2","deflate","lz4","lzsse2","lzsse8","snappy","xz","zstd"};return valid(c)?names[c]:"invalid";}
extern "C" int ln_default_level(ln_codec c){static const int levels[]={5,6,6,0,5,5,0,6,3};return valid(c)?levels[c]:-1;}
extern "C" void ln_destroy(ln_context *c){if(!c)return;if(c->kind==LN_LZSSE2&&c->state)LZSSE2_FreeOptimalParseState((LZSSE2_OptimalParseState*)c->state);if(c->kind==LN_LZSSE8&&c->state)LZSSE8_FreeOptimalParseState((LZSSE8_OptimalParseState*)c->state);ZSTD_freeCCtx(c->zc);ZSTD_freeDCtx(c->zd);delete c;}
extern "C" ln_status ln_create(ln_codec kind,int level,ln_context **out){
    if(!out)return LN_INVALID;*out=nullptr;
    const int lo[]={0,1,1,0,0,0,0,0,1},hi[]={11,9,12,0,17,17,0,9,22};
    if(!valid(kind)||level<lo[kind]||level>hi[kind])return LN_INVALID;
    if((kind==LN_LZSSE2||kind==LN_LZSSE8)&&!__builtin_cpu_supports("sse4.1"))return LN_UNSUPPORTED;
    try {auto *c=new ln_context{kind,level};
        if(kind==LN_LZSSE2)c->state=LZSSE2_MakeOptimalParseState(LN_MAX_BLOCK);
        if(kind==LN_LZSSE8)c->state=LZSSE8_MakeOptimalParseState(LN_MAX_BLOCK);
        if(kind==LN_ZSTD){c->zc=ZSTD_createCCtx();c->zd=ZSTD_createDCtx();}
        if(((kind==LN_LZSSE2||kind==LN_LZSSE8)&&!c->state)||(kind==LN_ZSTD&&(!c->zc||!c->zd))){ln_destroy(c);return LN_NOMEM;}
        *out=c;return LN_OK;
    }catch(...){return LN_NOMEM;}
}
extern "C" size_t ln_compress_bound(ln_codec kind,size_t n){
    if(!valid(kind)||n>LN_MAX_BLOCK)return 0;
    switch(kind){case LN_BROTLI:return BrotliEncoderMaxCompressedSize(n);case LN_BZIP2:return n+n/100+601;case LN_DEFLATE:return libdeflate_deflate_compress_bound(nullptr,n);case LN_LZ4:return LZ4_compressBound((int)n);case LN_LZSSE2:case LN_LZSSE8:return std::max<size_t>(1,n);case LN_SNAPPY:return snappy::MaxCompressedLength(n);case LN_XZ:return lzma_block_buffer_bound(n)+1024;case LN_ZSTD:return ZSTD_compressBound(n);default:return 0;}
}
static int64_t xz(bool enc,int level,const void *in,size_t n,void *out,size_t cap){
    lzma_stream s=LZMA_STREAM_INIT;lzma_mt opt={};opt.threads=1;lzma_ret ret;
    if(enc){opt.preset=(uint32_t)level;opt.check=LZMA_CHECK_NONE;ret=lzma_stream_encoder_mt(&s,&opt);}
    else{opt.memlimit_stop=256ULL<<20;opt.flags=LZMA_CONCATENATED|LZMA_IGNORE_CHECK;ret=lzma_stream_decoder_mt(&s,&opt);}
    if(ret!=LZMA_OK){lzma_end(&s);return -1;}
    s.next_in=(const uint8_t*)in;s.avail_in=n;s.next_out=(uint8_t*)out;s.avail_out=cap;
    ret=lzma_code(&s,LZMA_FINISH);int64_t used=ret==LZMA_STREAM_END?(int64_t)s.total_out:-1;lzma_end(&s);return used;
}
extern "C" ln_status ln_compress(ln_context *c,const void *in,size_t n,void *out,size_t cap,size_t *produced){
    if(!produced)return LN_INVALID;*produced=0;
    if(!c||n>LN_MAX_BLOCK||(!in&&n)||(!out&&cap)||overlaps(in,n,out,cap))return LN_INVALID;
    size_t bound=ln_compress_bound(c->kind,n);if(cap<bound)return LN_CAPACITY;
    unsigned char dummy=0;if(!in)in=&dummy;if(!out)out=&dummy;
    try{size_t z=0;
        switch(c->kind){
        case LN_BROTLI:z=cap;if(!BrotliEncoderCompress(c->level,BROTLI_DEFAULT_WINDOW,BROTLI_DEFAULT_MODE,n,(const uint8_t*)in,&z,(uint8_t*)out))return LN_CODEC_ERROR;break;
        case LN_BZIP2:{unsigned int k=(unsigned int)cap;if(BZ2_bzBuffToBuffCompress((char*)out,&k,(char*)in,(unsigned)n,c->level,0,0)!=BZ_OK)return LN_CODEC_ERROR;z=k;break;}
        case LN_DEFLATE:{auto *s=libdeflate_alloc_compressor(c->level);if(!s)return LN_NOMEM;z=libdeflate_deflate_compress(s,in,n,out,cap);libdeflate_free_compressor(s);if(!z)return LN_CODEC_ERROR;break;}
        case LN_LZ4:{int r=LZ4_compress_default((const char*)in,(char*)out,(int)n,(int)std::min(cap,(size_t)INT32_MAX));if(r<=0)return LN_CODEC_ERROR;z=r;break;}
        case LN_LZSSE2:z=LZSSE2_CompressOptimalParse((LZSSE2_OptimalParseState*)c->state,in,n,out,cap,c->level);if(!z&&n)return LN_CODEC_ERROR;break;
        case LN_LZSSE8:z=LZSSE8_CompressOptimalParse((LZSSE8_OptimalParseState*)c->state,in,n,out,cap,c->level);if(!z&&n)return LN_CODEC_ERROR;break;
        case LN_SNAPPY:snappy::RawCompress((const char*)in,n,(char*)out,&z);break;
        case LN_XZ:{int64_t r=xz(true,c->level,in,n,out,cap);if(r<0)return LN_CODEC_ERROR;z=(size_t)r;break;}
        case LN_ZSTD:if(ZSTD_isError(ZSTD_CCtx_setParameter(c->zc,ZSTD_c_compressionLevel,c->level))||ZSTD_isError(ZSTD_CCtx_setParameter(c->zc,ZSTD_c_contentSizeFlag,1)))return LN_CODEC_ERROR;z=ZSTD_compress2(c->zc,out,cap,in,n);if(ZSTD_isError(z))return LN_CODEC_ERROR;break;
        default:return LN_INVALID;}
        if(z>cap)return LN_CODEC_ERROR;*produced=z;return LN_OK;
    }catch(const std::bad_alloc&){return LN_NOMEM;}catch(...){return LN_CODEC_ERROR;}
}
extern "C" ln_status ln_decompress(ln_context *c,const void *in,size_t n,void *out,size_t cap,size_t expected,size_t *produced){
    if(!produced)return LN_INVALID;*produced=0;
    if(!c||expected>LN_MAX_BLOCK||n>ln_compress_bound(c->kind,LN_MAX_BLOCK)||(!in&&n)||(!out&&cap)||overlaps(in,n,out,cap))return LN_INVALID;
    if(cap<expected)return LN_CAPACITY;
    unsigned char dummy=0;if(!in)in=&dummy;if(!out)out=&dummy;
    try{size_t z=0;
        switch(c->kind){
        case LN_BROTLI:z=expected;if(BrotliDecoderDecompress(n,(const uint8_t*)in,&z,(uint8_t*)out)!=BROTLI_DECODER_RESULT_SUCCESS)return LN_CODEC_ERROR;break;
        case LN_BZIP2:{unsigned k=(unsigned)expected;if(BZ2_bzBuffToBuffDecompress((char*)out,&k,(char*)in,(unsigned)n,0,0)!=BZ_OK)return LN_CODEC_ERROR;z=k;break;}
        case LN_DEFLATE:{auto *s=libdeflate_alloc_decompressor();if(!s)return LN_NOMEM;auto r=libdeflate_deflate_decompress(s,in,n,out,expected,&z);libdeflate_free_decompressor(s);if(r!=LIBDEFLATE_SUCCESS)return LN_CODEC_ERROR;break;}
        case LN_LZ4:{int r=LZ4_decompress_safe((const char*)in,(char*)out,(int)n,(int)expected);if(r<0)return LN_CODEC_ERROR;z=r;break;}
        case LN_LZSSE2:if(n!=expected&&(n<32||expected<32))return LN_CODEC_ERROR;z=LZSSE2_Decompress(in,n,out,expected);break;
        case LN_LZSSE8:if(n!=expected&&(n<32||expected<32))return LN_CODEC_ERROR;z=LZSSE8_Decompress(in,n,out,expected);break;
        case LN_SNAPPY:{size_t length=0;if(!snappy::GetUncompressedLength((const char*)in,n,&length)||length!=expected||!snappy::RawUncompress((const char*)in,n,(char*)out))return LN_CODEC_ERROR;z=length;break;}
        case LN_XZ:{int64_t r=xz(false,c->level,in,n,out,expected);if(r<0)return LN_CODEC_ERROR;z=(size_t)r;break;}
        case LN_ZSTD:z=ZSTD_decompressDCtx(c->zd,out,expected,in,n);if(ZSTD_isError(z))return LN_CODEC_ERROR;break;
        default:return LN_INVALID;}
        if(z!=expected)return LN_CODEC_ERROR;*produced=z;return LN_OK;
    }catch(const std::bad_alloc&){return LN_NOMEM;}catch(...){return LN_CODEC_ERROR;}
}
