#pragma once
#include "lzbench_native.h"
#include <cstdint>
#include <limits>
#include <map>
#include <memory>
#include <string>
#include <vector>
namespace lzbench_native {
using bytes=std::vector<unsigned char>;
struct configuration {
 ln_codec codec=LN_ZSTD;
 std::string mode; // default native frame/stream, raw, or optimal as applicable
 int level=std::numeric_limits<int>::min(); // automatic; negative Zstd levels remain selectable
 std::map<std::string,std::int64_t> parameters;
 bytes dictionary; // owned copy; full transfer bytes must be charged
};
struct progress {std::size_t consumed,produced;bool finished;};
struct worker_stats {std::uint64_t jobs,worker_threads,caller_jobs;};
/* Process-wide diagnostics, not context-local accounting. Reset only while all
 * codecs are idle. Hook sites are actual frozen XZ/Zstd native job functions. */
void reset_worker_stats();
worker_stats get_worker_stats();
class session {
 struct impl;std::unique_ptr<impl> p;
public:
 explicit session(configuration);
 ~session();
 session(session&&) noexcept;
 session& operator=(session&&) noexcept;
 session(const session&)=delete;
 session& operator=(const session&)=delete;
 const configuration& configured() const;
 std::map<std::string,std::int64_t> effective_parameters() const;
 bool streaming() const;
 /* encode=true and false have separate native states. reset starts independent
  * frames, retaining reusable state where the native library supports it.
  * process receives only caller's current spans, never caches the full message.
  * finish must be repeated with unchanged remaining input until finished=true.
  * Native processing errors invalidate that direction until reset; input/output cannot overlap. */
 void reset(bool encode);
 progress process(bool encode,const void*,std::size_t,void*,std::size_t,bool finish);
 /* Batch-only native blocks. LZ4 continue mode retains the last64KiB history
  * in owned buffers, so previous caller input/output need not outlive the call. */
 bytes compress_block(const void*,std::size_t);
 bytes decompress_block(const void*,std::size_t,std::size_t expected);
};
/* Frozen Zstd trainer. Input samples are separate byte strings; returns the
 * actual dictionary bytes. Training cost and input identity belong in reports. */
bytes train_zstd_dictionary(const std::vector<bytes>& samples,std::size_t capacity);
}
