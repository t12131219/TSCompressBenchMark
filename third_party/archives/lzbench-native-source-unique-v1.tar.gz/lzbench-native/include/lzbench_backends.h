/* Native frozen backend APIs, with the selected extended build closure.
 * These are actual upstream APIs: unsupported combinations are not unified into
 * a fake dictionary/stream/thread API. See FUNCTIONAL_REPORT.md. */
#ifndef LZBENCH_BACKENDS_H
#define LZBENCH_BACKENDS_H
#include <stddef.h>
#include "brotli/encode.h"
#include "brotli/decode.h"
#include "bwt/bzip2/bzlib.h"
#include "lz/libdeflate/libdeflate.h"
#include "lz/lz4/lib/lz4.h"
#include "lz/lz4/lib/lz4hc.h"
#include "lz/lz4/lib/lz4frame.h"
#include "lzsse/lzsse2/lzsse2.h"
#include "lzsse/lzsse8/lzsse8.h"
#include "snappy/snappy-c.h"
#include "lz/xz/src/liblzma/api/lzma.h"
#include "zstd/lib/zstd.h"
#include "zstd/lib/zdict.h"
#endif
