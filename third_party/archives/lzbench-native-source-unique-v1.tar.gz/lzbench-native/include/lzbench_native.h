#ifndef LZBENCH_NATIVE_H
#define LZBENCH_NATIVE_H
#include <stddef.h>
#ifdef __cplusplus
extern "C" {
#endif
#define LN_MAX_BLOCK ((size_t)65536)
typedef enum { LN_BROTLI,LN_BZIP2,LN_DEFLATE,LN_LZ4,LN_LZSSE2,LN_LZSSE8,LN_SNAPPY,LN_XZ,LN_ZSTD,LN_CODEC_COUNT } ln_codec;
typedef enum { LN_OK=0,LN_INVALID=1,LN_CAPACITY=2,LN_NOMEM=3,LN_CODEC_ERROR=4,LN_UNSUPPORTED=5 } ln_status;
typedef struct ln_context ln_context;
const char *ln_codec_name(ln_codec codec);
int ln_default_level(ln_codec codec);
/* Creates reusable state; caller must destroy. Single context is not concurrent. */
ln_status ln_create(ln_codec codec,int level,ln_context **context);
void ln_destroy(ln_context *context);
/* Zero indicates invalid codec/oversize input. Returns actual required worst-case capacity. */
size_t ln_compress_bound(ln_codec codec,size_t input_size);
/* Nonoverlapping buffers. input/output may be null only for zero length/capacity.
 * Errors set produced=0; destination may be modified. encode requires bound capacity.
 * decode is for TRUSTED codec streams with the precise external original length.
 * All lengths are bytes; maximum block size is LN_MAX_BLOCK. No added frame. */
ln_status ln_compress(ln_context *,const void *input,size_t input_size,void *output,size_t capacity,size_t *produced);
ln_status ln_decompress(ln_context *,const void *input,size_t input_size,void *output,size_t capacity,size_t expected_size,size_t *produced);
#ifdef __cplusplus
}
#endif
#endif
