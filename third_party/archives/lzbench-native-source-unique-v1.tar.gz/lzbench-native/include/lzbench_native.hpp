#ifndef LZBENCH_NATIVE_HPP
#define LZBENCH_NATIVE_HPP
#include "lzbench_native.h"
#include <stdexcept>
#include <utility>
#include <vector>
namespace lzbench_native {
class codec {
    ln_context *ctx_=nullptr;
    ln_codec kind_;
    static void check(ln_status s) { if(s!=LN_OK) throw std::runtime_error("lzbench-native status "+std::to_string(int(s))); }
public:
    explicit codec(ln_codec kind,int level=-1):kind_(kind) {check(ln_create(kind,level<0?ln_default_level(kind):level,&ctx_));}
    ~codec(){ln_destroy(ctx_);}
    codec(const codec&)=delete;
    codec& operator=(const codec&)=delete;
    codec(codec&& other) noexcept:ctx_(std::exchange(other.ctx_,nullptr)),kind_(other.kind_){}
    codec& operator=(codec&& other) noexcept {if(this!=&other){ln_destroy(ctx_);ctx_=std::exchange(other.ctx_,nullptr);kind_=other.kind_;}return *this;}
    std::vector<unsigned char> compress(const void *p,size_t n){auto b=ln_compress_bound(kind_,n);if(!b) throw std::invalid_argument("invalid block");std::vector<unsigned char> out(b);size_t used=0;check(ln_compress(ctx_,p,n,out.data(),out.size(),&used));out.resize(used);return out;}
    std::vector<unsigned char> decompress(const void *p,size_t n,size_t expected){if(expected>LN_MAX_BLOCK)throw std::invalid_argument("invalid length");std::vector<unsigned char> out(expected);size_t used=0;check(ln_decompress(ctx_,p,n,out.data(),out.size(),expected,&used));return out;}
};
}
#endif
