# lzbench-native · unique-v1

本工程只交付一个主选实现 `lzbench_native`，覆盖 32 Brotli、33 Bzip2、34 DEFLATE（libdeflate raw）、35 LZ4、36 LZSSE2、37 LZSSE8、38 Snappy、39 XZ / LZMA2、40 Zstandard。

## 构建

```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j4
```

支持Linux x86_64，GCC/G++、CMake≥3.22、make。ISA要求及运行约束见下表。工程自带所需源码依赖；构建输出不在发布包内。

默认构建包含本工程主选功能组件。

独立C/C++对照、历史版本、上游oracle及独立验证程序不交付。辅助库、共享格式代码、ISA加速和训练/流式等模块服务于同一主实现。`reference`、`fpc-original` 等历史target名称是CSV主选标识，不代表存在另一份并列实现。

## 32. Brotli

| 属性 | 支持范围与限制 |
| --- | --- |
| 技术家族 | Brotli |
| 方法角色 | 完整字节codec（raw或frame依变体） |
| 编码流水线 | LZ77+上下文/Huffman |
| 原生类型 | byte |
| 输入适配 | 数值只按字节输入，不建模dtype/时间轴 |
| 数值域与特殊值 | 任意字节；原生长度/容量前提 |
| 形状与多变量 | 字节序列 |
| 时间轴或显式x | 不支持：仅隐式样本序号 |
| 布局与stride | 连续数组 |
| 缺失值语义 | 未声明原生mask；不隐式插补 |
| 恢复与质量合同 | 字节无损 |
| 核心参数 | quality0..11、window/mode/lgblock、shared dictionary |
| 批处理 | 支持：整输入调用 |
| 增量编码 | 条件支持：选择原生stream/frame或continue入口；raw默认块不等于stream |
| 增量解码 | 条件支持：对应原生stream/frame增量；raw默认为整块 |
| 状态与复用 | C++session绑定各原生生命周期；ln_*旧ABI仍独立64KiB块 |
| 点范围与seek | 不支持：所选核心无此公开入口 |
| 渐进恢复 | 不支持：所选核心无此公开入口 |
| 压缩域计算 | 不支持：所选核心无此公开入口 |
| 训练或在线学习 | 无需外部训练 |
| 字典码本复用 | raw prefix/serialized shared dictionary；静态字典内置 |
| SIMD或ISA | 未确认：不以编译器自动向量化宣称显式SIMD |
| 内部并行编码 | 不支持：所选调用路径串行 |
| 内部并行解码 | 不支持：所选调用路径串行 |
| GPU | 未确认：未对该冻结核心建立GPU入口证据 |
| 并发与所有权 | 独立session可并发；单session独占；worker诊断为进程级 |
| 格式与兼容 | 原生frame |
| 独立恢复依赖 | payload+schema+外部dictionary完整计费；不混raw/frame |
| 运行与构建依赖 | 冻结C/C++原生库；非九套独立重写 |
| 长度尾部与资源 | 旧ln_*≤64KiB；扩展不再人为限64KiB，按各native域 |
| 确定性条件 | 未确认：未建立跨平台字节确定性保证 |
| 许可范围 | 源码许可声明及 fix_ReWrite/lzbench-native/licenses 中的冻结归属材料。 |
| 已知限制与身份 | session/原生后端为显式扩展，不表示CSV默认开启stream/MT/dict |
## 33. Bzip2

| 属性 | 支持范围与限制 |
| --- | --- |
| 技术家族 | Bzip2 |
| 方法角色 | 完整字节codec（raw或frame依变体） |
| 编码流水线 | BWT+MTF/RLE+Huffman |
| 原生类型 | byte |
| 输入适配 | 数值只按字节输入，不建模dtype/时间轴 |
| 数值域与特殊值 | 任意字节；原生长度/容量前提 |
| 形状与多变量 | 字节序列 |
| 时间轴或显式x | 不支持：仅隐式样本序号 |
| 布局与stride | 连续数组 |
| 缺失值语义 | 未声明原生mask；不隐式插补 |
| 恢复与质量合同 | 字节无损 |
| 核心参数 | level1..9、work_factor0..250、small解码 |
| 批处理 | 支持：整输入调用 |
| 增量编码 | 条件支持：选择原生stream/frame或continue入口；raw默认块不等于stream |
| 增量解码 | 条件支持：对应原生stream/frame增量；raw默认为整块 |
| 状态与复用 | C++session绑定各原生生命周期；ln_*旧ABI仍独立64KiB块 |
| 点范围与seek | 不支持：所选核心无此公开入口 |
| 渐进恢复 | 不支持：所选核心无此公开入口 |
| 压缩域计算 | 不支持：所选核心无此公开入口 |
| 训练或在线学习 | 无需外部训练 |
| 字典码本复用 | 不支持：所选核心无此公开入口 |
| SIMD或ISA | 未确认：不以编译器自动向量化宣称显式SIMD |
| 内部并行编码 | 不支持：所选调用路径串行 |
| 内部并行解码 | 不支持：所选调用路径串行 |
| GPU | 未确认：未对该冻结核心建立GPU入口证据 |
| 并发与所有权 | 独立session可并发；单session独占；worker诊断为进程级 |
| 格式与兼容 | bzip2 frame |
| 独立恢复依赖 | payload+schema+外部dictionary完整计费；不混raw/frame |
| 运行与构建依赖 | 冻结C/C++原生库；非九套独立重写 |
| 长度尾部与资源 | 旧ln_*≤64KiB；扩展不再人为限64KiB，按各native域 |
| 确定性条件 | 未确认：未建立跨平台字节确定性保证 |
| 许可范围 | 源码许可声明及 fix_ReWrite/lzbench-native/licenses 中的冻结归属材料。 |
| 已知限制与身份 | session/原生后端为显式扩展，不表示CSV默认开启stream/MT/dict |
## 34. DEFLATE（libdeflate raw）

| 属性 | 支持范围与限制 |
| --- | --- |
| 技术家族 | libdeflate |
| 方法角色 | 完整字节codec（raw或frame依变体） |
| 编码流水线 | DEFLATE LZ77+Huffman |
| 原生类型 | byte |
| 输入适配 | 数值只按字节输入，不建模dtype/时间轴 |
| 数值域与特殊值 | 任意字节；原生长度/容量前提 |
| 形状与多变量 | 字节序列 |
| 时间轴或显式x | 不支持：仅隐式样本序号 |
| 布局与stride | 连续数组 |
| 缺失值语义 | 未声明原生mask；不隐式插补 |
| 恢复与质量合同 | 字节无损 |
| 核心参数 | raw level0..12；所选不是zlib/gzip |
| 批处理 | 支持：整输入调用 |
| 增量编码 | 不支持：所选raw核为整块 |
| 增量解码 | 整块恢复 |
| 状态与复用 | C++session绑定各原生生命周期；ln_*旧ABI仍独立64KiB块 |
| 点范围与seek | 不支持：所选核心无此公开入口 |
| 渐进恢复 | 不支持：所选核心无此公开入口 |
| 压缩域计算 | 不支持：所选核心无此公开入口 |
| 训练或在线学习 | 无需外部训练 |
| 字典码本复用 | 不支持：所选核心无此公开入口 |
| SIMD或ISA | 未确认：不以编译器自动向量化宣称显式SIMD |
| 内部并行编码 | 不支持：所选调用路径串行 |
| 内部并行解码 | 不支持：所选调用路径串行 |
| GPU | 未确认：未对该冻结核心建立GPU入口证据 |
| 并发与所有权 | 独立session可并发；单session独占；worker诊断为进程级 |
| 格式与兼容 | raw DEFLATE |
| 独立恢复依赖 | payload+schema+外部dictionary完整计费；不混raw/frame |
| 运行与构建依赖 | 冻结C/C++原生库；非九套独立重写 |
| 长度尾部与资源 | 旧ln_*≤64KiB；扩展不再人为限64KiB，按各native域 |
| 确定性条件 | 未确认：未建立跨平台字节确定性保证 |
| 许可范围 | 源码许可声明及 fix_ReWrite/lzbench-native/licenses 中的冻结归属材料。 |
| 已知限制与身份 | session/原生后端为显式扩展，不表示CSV默认开启stream/MT/dict |
## 35. LZ4

| 属性 | 支持范围与限制 |
| --- | --- |
| 技术家族 | LZ4 |
| 方法角色 | 完整字节codec（raw或frame依变体） |
| 编码流水线 | LZ77字节匹配 |
| 原生类型 | byte |
| 输入适配 | 数值只按字节输入，不建模dtype/时间轴 |
| 数值域与特殊值 | 任意字节；原生长度/容量前提 |
| 形状与多变量 | 字节序列 |
| 时间轴或显式x | 不支持：仅隐式样本序号 |
| 布局与stride | 连续数组 |
| 缺失值语义 | 未声明原生mask；不隐式插补 |
| 恢复与质量合同 | 字节无损 |
| 核心参数 | raw fast acceleration/HC3..12；frame/continue为可选模式 |
| 批处理 | 支持：整输入调用 |
| 增量编码 | 条件支持：选择原生stream/frame或continue入口；raw默认块不等于stream |
| 增量解码 | 条件支持：对应原生stream/frame增量；raw默认为整块 |
| 状态与复用 | C++session绑定各原生生命周期；ln_*旧ABI仍独立64KiB块 |
| 点范围与seek | 不支持：所选核心无此公开入口 |
| 渐进恢复 | 不支持：所选核心无此公开入口 |
| 压缩域计算 | 不支持：所选核心无此公开入口 |
| 训练或在线学习 | 无需外部训练 |
| 字典码本复用 | 外部字典、continue/continue-hc；须保存字典身份/字节 |
| SIMD或ISA | 未确认：不以编译器自动向量化宣称显式SIMD |
| 内部并行编码 | 不支持：所选调用路径串行 |
| 内部并行解码 | 不支持：所选调用路径串行 |
| GPU | 未确认：未对该冻结核心建立GPU入口证据 |
| 并发与所有权 | 独立session可并发；单session独占；worker诊断为进程级 |
| 格式与兼容 | 主选raw；扩展LZ4 frame |
| 独立恢复依赖 | payload+schema+外部dictionary完整计费；不混raw/frame |
| 运行与构建依赖 | 冻结C/C++原生库；非九套独立重写 |
| 长度尾部与资源 | 旧ln_*≤64KiB；扩展不再人为限64KiB，按各native域 |
| 确定性条件 | 未确认：未建立跨平台字节确定性保证 |
| 许可范围 | 源码许可声明及 fix_ReWrite/lzbench-native/licenses 中的冻结归属材料。 |
| 已知限制与身份 | session/原生后端为显式扩展，不表示CSV默认开启stream/MT/dict |
## 36. LZSSE2

| 属性 | 支持范围与限制 |
| --- | --- |
| 技术家族 | LZSSE2 |
| 方法角色 | 完整字节codec（raw或frame依变体） |
| 编码流水线 | SIMD LZ字节匹配 |
| 原生类型 | byte |
| 输入适配 | 数值只按字节输入，不建模dtype/时间轴 |
| 数值域与特殊值 | 任意字节；原生长度/容量前提 |
| 形状与多变量 | 字节序列 |
| 时间轴或显式x | 不支持：仅隐式样本序号 |
| 布局与stride | 连续数组 |
| 缺失值语义 | 未声明原生mask；不隐式插补 |
| 恢复与质量合同 | 字节无损 |
| 核心参数 | optimal level0..17；本核无Fast API |
| 批处理 | 支持：整输入调用 |
| 增量编码 | 不支持：所选raw核为整块 |
| 增量解码 | 整块恢复 |
| 状态与复用 | C++session绑定各原生生命周期；ln_*旧ABI仍独立64KiB块 |
| 点范围与seek | 不支持：所选核心无此公开入口 |
| 渐进恢复 | 不支持：所选核心无此公开入口 |
| 压缩域计算 | 不支持：所选核心无此公开入口 |
| 训练或在线学习 | 无需外部训练 |
| 字典码本复用 | 不支持：所选核心无此公开入口 |
| SIMD或ISA | SSE4.1为强前提，无已声明portable fallback |
| 内部并行编码 | 不支持：所选调用路径串行 |
| 内部并行解码 | 不支持：所选调用路径串行 |
| GPU | 未确认：未对该冻结核心建立GPU入口证据 |
| 并发与所有权 | 独立session可并发；单session独占；worker诊断为进程级 |
| 格式与兼容 | LZSSE2 raw |
| 独立恢复依赖 | payload+schema+外部dictionary完整计费；不混raw/frame |
| 运行与构建依赖 | 冻结C/C++原生库；非九套独立重写 |
| 长度尾部与资源 | 旧ln_*≤64KiB；扩展不再人为限64KiB，按各native域 |
| 确定性条件 | 未确认：未建立跨平台字节确定性保证 |
| 许可范围 | 源码许可声明及 fix_ReWrite/lzbench-native/licenses 中的冻结归属材料。 |
| 已知限制与身份 | 保留unaligned/OOM修复；显式检测SSE4.1；optimal level0..17；本核无Fast API |
## 37. LZSSE8

| 属性 | 支持范围与限制 |
| --- | --- |
| 技术家族 | LZSSE8 |
| 方法角色 | 完整字节codec（raw或frame依变体） |
| 编码流水线 | SIMD LZ字节匹配 |
| 原生类型 | byte |
| 输入适配 | 数值只按字节输入，不建模dtype/时间轴 |
| 数值域与特殊值 | 任意字节；原生长度/容量前提 |
| 形状与多变量 | 字节序列 |
| 时间轴或显式x | 不支持：仅隐式样本序号 |
| 布局与stride | 连续数组 |
| 缺失值语义 | 未声明原生mask；不隐式插补 |
| 恢复与质量合同 | 字节无损 |
| 核心参数 | optimal level0..17；Fast模式不使用level |
| 批处理 | 支持：整输入调用 |
| 增量编码 | 不支持：所选raw核为整块 |
| 增量解码 | 整块恢复 |
| 状态与复用 | C++session绑定各原生生命周期；ln_*旧ABI仍独立64KiB块 |
| 点范围与seek | 不支持：所选核心无此公开入口 |
| 渐进恢复 | 不支持：所选核心无此公开入口 |
| 压缩域计算 | 不支持：所选核心无此公开入口 |
| 训练或在线学习 | 无需外部训练 |
| 字典码本复用 | 不支持：所选核心无此公开入口 |
| SIMD或ISA | SSE4.1为强前提，无已声明portable fallback |
| 内部并行编码 | 不支持：所选调用路径串行 |
| 内部并行解码 | 不支持：所选调用路径串行 |
| GPU | 未确认：未对该冻结核心建立GPU入口证据 |
| 并发与所有权 | 独立session可并发；单session独占；worker诊断为进程级 |
| 格式与兼容 | LZSSE8 raw |
| 独立恢复依赖 | payload+schema+外部dictionary完整计费；不混raw/frame |
| 运行与构建依赖 | 冻结C/C++原生库；非九套独立重写 |
| 长度尾部与资源 | 旧ln_*≤64KiB；扩展不再人为限64KiB，按各native域 |
| 确定性条件 | 未确认：未建立跨平台字节确定性保证 |
| 许可范围 | 源码许可声明及 fix_ReWrite/lzbench-native/licenses 中的冻结归属材料。 |
| 已知限制与身份 | 保留unaligned/OOM修复；显式检测SSE4.1；optimal level0..17；Fast模式不使用level |
## 38. Snappy

| 属性 | 支持范围与限制 |
| --- | --- |
| 技术家族 | Snappy |
| 方法角色 | 完整字节codec（raw或frame依变体） |
| 编码流水线 | LZ字节匹配 |
| 原生类型 | byte |
| 输入适配 | 数值只按字节输入，不建模dtype/时间轴 |
| 数值域与特殊值 | 任意字节；原生长度/容量前提 |
| 形状与多变量 | 字节序列 |
| 时间轴或显式x | 不支持：仅隐式样本序号 |
| 布局与stride | 连续数组 |
| 缺失值语义 | 未声明原生mask；不隐式插补 |
| 恢复与质量合同 | 字节无损 |
| 核心参数 | raw块，无level/dict/internal MT |
| 批处理 | 支持：整输入调用 |
| 增量编码 | 不支持：所选raw核为整块 |
| 增量解码 | 整块恢复 |
| 状态与复用 | C++session绑定各原生生命周期；ln_*旧ABI仍独立64KiB块 |
| 点范围与seek | 不支持：所选核心无此公开入口 |
| 渐进恢复 | 不支持：所选核心无此公开入口 |
| 压缩域计算 | 不支持：所选核心无此公开入口 |
| 训练或在线学习 | 无需外部训练 |
| 字典码本复用 | 不支持：所选核心无此公开入口 |
| SIMD或ISA | 未确认：不以编译器自动向量化宣称显式SIMD |
| 内部并行编码 | 不支持：所选调用路径串行 |
| 内部并行解码 | 不支持：所选调用路径串行 |
| GPU | 未确认：未对该冻结核心建立GPU入口证据 |
| 并发与所有权 | 独立session可并发；单session独占；worker诊断为进程级 |
| 格式与兼容 | Snappy raw |
| 独立恢复依赖 | payload+schema+外部dictionary完整计费；不混raw/frame |
| 运行与构建依赖 | 冻结C/C++原生库；非九套独立重写 |
| 长度尾部与资源 | 旧ln_*≤64KiB；扩展不再人为限64KiB，按各native域 |
| 确定性条件 | 未确认：未建立跨平台字节确定性保证 |
| 许可范围 | 源码许可声明及 fix_ReWrite/lzbench-native/licenses 中的冻结归属材料。 |
| 已知限制与身份 | session/原生后端为显式扩展，不表示CSV默认开启stream/MT/dict |
## 39. XZ / LZMA2

| 属性 | 支持范围与限制 |
| --- | --- |
| 技术家族 | XZ/LZMA2 |
| 方法角色 | 完整字节codec（raw或frame依变体） |
| 编码流水线 | 过滤器+LZMA2范围编码 |
| 原生类型 | byte |
| 输入适配 | 数值只按字节输入，不建模dtype/时间轴 |
| 数值域与特殊值 | 任意字节；原生长度/容量前提 |
| 形状与多变量 | 字节序列 |
| 时间轴或显式x | 不支持：仅隐式样本序号 |
| 布局与stride | 连续数组 |
| 缺失值语义 | 未声明原生mask；不隐式插补 |
| 恢复与质量合同 | 字节无损 |
| 核心参数 | preset/EXTREME、LZMA2参数、delta/BCJ、check、MT/block/memory |
| 批处理 | 支持：整输入调用 |
| 增量编码 | 条件支持：选择原生stream/frame或continue入口；raw默认块不等于stream |
| 增量解码 | 条件支持：对应原生stream/frame增量；raw默认为整块 |
| 状态与复用 | C++session绑定各原生生命周期；ln_*旧ABI仍独立64KiB块 |
| 点范围与seek | 不支持：所选核心无此公开入口 |
| 渐进恢复 | 不支持：所选核心无此公开入口 |
| 压缩域计算 | 不支持：所选核心无此公开入口 |
| 训练或在线学习 | 无需外部训练 |
| 字典码本复用 | LZMA2内部滑动字典；当前所选不是外置训练字典 |
| SIMD或ISA | 未确认：不以编译器自动向量化宣称显式SIMD |
| 内部并行编码 | 支持：原生XZ MT encoder，需合适block/长度/线程构建 |
| 内部并行解码 | 支持：原生XZ MT decoder；当前1/2worker已有验证记录 |
| GPU | 未确认：未对该冻结核心建立GPU入口证据 |
| 并发与所有权 | 独立session可并发；单session独占；worker诊断为进程级 |
| 格式与兼容 | XZ frame |
| 独立恢复依赖 | payload+schema+外部dictionary完整计费；不混raw/frame |
| 运行与构建依赖 | 冻结C/C++原生库；非九套独立重写 |
| 长度尾部与资源 | 旧ln_*≤64KiB；扩展不再人为限64KiB，按各native域 |
| 确定性条件 | 未确认：未建立跨平台字节确定性保证 |
| 许可范围 | 源码许可声明及 fix_ReWrite/lzbench-native/licenses 中的冻结归属材料。 |
| 已知限制与身份 | session/原生后端为显式扩展，不表示CSV默认开启stream/MT/dict |
## 40. Zstandard

| 属性 | 支持范围与限制 |
| --- | --- |
| 技术家族 | Zstd |
| 方法角色 | 完整字节codec（raw或frame依变体） |
| 编码流水线 | LZ匹配+FSE/Huffman |
| 原生类型 | byte |
| 输入适配 | 数值只按字节输入，不建模dtype/时间轴 |
| 数值域与特殊值 | 任意字节；原生长度/容量前提 |
| 形状与多变量 | 字节序列 |
| 时间轴或显式x | 不支持：仅隐式样本序号 |
| 布局与stride | 连续数组 |
| 缺失值语义 | 未声明原生mask；不隐式插补 |
| 恢复与质量合同 | 字节无损 |
| 核心参数 | level含负级别、window/strategy、workers/job_size、checksum等 |
| 批处理 | 支持：整输入调用 |
| 增量编码 | 条件支持：选择原生stream/frame或continue入口；raw默认块不等于stream |
| 增量解码 | 条件支持：对应原生stream/frame增量；raw默认为整块 |
| 状态与复用 | C++session绑定各原生生命周期；ln_*旧ABI仍独立64KiB块 |
| 点范围与seek | 不支持：所选核心无此公开入口 |
| 渐进恢复 | 不支持：所选核心无此公开入口 |
| 压缩域计算 | 不支持：所选核心无此公开入口 |
| 训练或在线学习 | 可显式ZDICT离线训练 |
| 字典码本复用 | 外部字典、ZDICT训练、CCtx/DCtx复用 |
| SIMD或ISA | 未确认：不以编译器自动向量化宣称显式SIMD |
| 内部并行编码 | 条件支持：原生Zstd workers编码；须MT构建及足够输入 |
| 内部并行解码 | 无内部MT decoder |
| GPU | 未确认：未对该冻结核心建立GPU入口证据 |
| 并发与所有权 | 独立session可并发；单session独占；worker诊断为进程级 |
| 格式与兼容 | Zstd frame |
| 独立恢复依赖 | payload+schema+外部dictionary完整计费；不混raw/frame |
| 运行与构建依赖 | 冻结C/C++原生库；非九套独立重写 |
| 长度尾部与资源 | 旧ln_*≤64KiB；扩展不再人为限64KiB，按各native域 |
| 确定性条件 | 未确认：未建立跨平台字节确定性保证 |
| 许可范围 | 源码许可声明及 fix_ReWrite/lzbench-native/licenses 中的冻结归属材料。 |
| 已知限制与身份 | session/原生后端为显式扩展，不表示CSV默认开启stream/MT/dict |
