#include "feature_io.hpp"
#include <chrono>
#include <fstream>
#include <iostream>
#include <limits>
#include <sstream>
using namespace lzbench_native;
using clock_type=std::chrono::steady_clock;
static bytes read(const std::string& name){std::ifstream f(name,std::ios::binary);if(!f)throw std::runtime_error("open input: "+name);bytes b((std::istreambuf_iterator<char>(f)),{});if(f.bad())throw std::runtime_error("read input");return b;}
static void write(const std::string& name,const bytes& b){std::ofstream f(name,std::ios::binary);f.write((const char*)b.data(),(std::streamsize)b.size());f.close();if(!f)throw std::runtime_error("write output");}
static int64_t integer(const std::string& s){size_t n=0;auto v=std::stoll(s,&n);if(n!=s.size())throw std::runtime_error("invalid integer");return v;}
static size_t positive(const std::string& s){auto n=integer(s);if(n<=0)throw std::runtime_error("positive size required");return (size_t)n;}
static configuration cfg(char** v,int start,int argc){configuration c;bool found=false;for(int i=0;i<LN_CODEC_COUNT;++i)if(v[2]==std::string(ln_codec_name((ln_codec)i))){c.codec=(ln_codec)i;found=true;}if(!found)throw std::runtime_error("unknown codec");c.mode=v[3];auto level=std::string(v[4]);if(level!="auto"){auto n=integer(level);if(n<=INT32_MIN||n>INT32_MAX)throw std::runtime_error("level range");c.level=(int)n;}for(int i=start;i<argc;++i){std::string text=v[i];auto eq=text.find('=');if(eq==text.npos||!c.parameters.emplace(text.substr(0,eq),integer(text.substr(eq+1))).second)throw std::runtime_error("invalid or duplicate parameter");}return c;}
int main(int argc,char** argv){try{
 if(argc>=5&&std::string(argv[1])=="train"){size_t cap=positive(argv[2]);std::vector<bytes> samples;for(int i=4;i<argc;++i)samples.push_back(read(argv[i]));auto a=clock_type::now();auto dict=train_zstd_dictionary(samples,cap);auto b=clock_type::now();write(argv[3],dict);std::cout<<"{\"dictionary_bytes\":"<<dict.size()<<",\"training_ns\":"<<std::chrono::duration_cast<std::chrono::nanoseconds>(b-a).count()<<"}\n";return 0;}
 if(argc<15)throw std::runtime_error("usage: roundtrip|decode codec mode level input_chunk output_chunk block cold|reuse repeats dictionary|- source encoded decoded expected [key=value...]; train capacity output samples...");
 std::string op=argv[1],life=argv[8];feature_io::check(op=="roundtrip"||op=="decode","operation");feature_io::check(life=="cold"||life=="reuse","lifecycle");auto c=cfg(argv,15,argc);auto in=positive(argv[5]),out=positive(argv[6]),block=positive(argv[7]),repeats=positive(argv[9]);if(std::string(argv[10])!="-")c.dictionary=read(argv[10]);
 auto input=read(argv[11]);auto expected_i=integer(argv[14]);feature_io::check(expected_i>=0,"negative expected size");size_t expected=op=="roundtrip"?input.size():(size_t)expected_i;std::unique_ptr<session> reusable;if(life=="reuse")reusable=std::make_unique<session>(c);
 bytes encoded,decoded;uint64_t enc_ns=0,dec_ns=0;worker_stats es{},ds{};std::map<std::string,int64_t> effective;
 for(size_t r=0;r<repeats;++r){reset_worker_stats();auto a=clock_type::now();if(op=="roundtrip"){
  if(life=="cold"){session s(c);encoded=feature_io::encode(s,input,in,out,block);effective=s.effective_parameters();}else{encoded=feature_io::encode(*reusable,input,in,out,block);effective=reusable->effective_parameters();}
 }else encoded=input;auto b=clock_type::now();es=get_worker_stats();reset_worker_stats();
 if(life=="cold"){session s(c);decoded=feature_io::decode(s,encoded,in,out,expected);}else decoded=feature_io::decode(*reusable,encoded,in,out,expected);
 auto z=clock_type::now();ds=get_worker_stats();enc_ns+=(uint64_t)std::chrono::duration_cast<std::chrono::nanoseconds>(b-a).count();dec_ns+=(uint64_t)std::chrono::duration_cast<std::chrono::nanoseconds>(z-b).count();if(op=="roundtrip")feature_io::check(decoded==input,"roundtrip mismatch");
 }
 write(argv[12],encoded);write(argv[13],decoded);session identity(c);
 auto stats=[](worker_stats s){std::cout<<"{\"jobs\":"<<s.jobs<<",\"worker_threads\":"<<s.worker_threads<<",\"caller_jobs\":"<<s.caller_jobs<<"}";};
 std::cout<<"{\"codec\":\""<<ln_codec_name(c.codec)<<"\",\"mode\":\""<<identity.configured().mode<<"\",\"level\":"<<identity.configured().level<<",\"native_stream\":"<<(identity.streaming()?"true":"false")<<",\"input_bytes\":"<<expected<<",\"encoded_bytes\":"<<encoded.size()<<",\"repeats\":"<<repeats<<",\"encode_ns\":"<<enc_ns<<",\"decode_ns\":"<<dec_ns<<",\"encode_jobs\":";stats(es);std::cout<<",\"decode_jobs\":";stats(ds);std::cout<<",\"effective_parameters\":{";bool comma=false;for(auto& kv:effective){if(comma)std::cout<<',';comma=true;std::cout<<'"'<<kv.first<<"\":"<<kv.second;}std::cout<<"}}\n";
 return 0;
 }catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 2;}}
