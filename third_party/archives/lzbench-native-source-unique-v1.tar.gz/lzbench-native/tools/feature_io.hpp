#pragma once
#include "lzbench_extended.hpp"
#include <algorithm>
#include <stdexcept>
namespace feature_io {
using namespace lzbench_native;
inline void check(bool ok,const char* text){if(!ok)throw std::runtime_error(text);}
inline void put64(bytes& b,uint64_t v){for(int i=0;i<8;++i){b.push_back((unsigned char)v);v>>=8;}}
inline uint64_t get64(const bytes& b,size_t& pos){check(pos<=b.size()&&b.size()-pos>=8,"truncated block table");uint64_t v=0;for(int i=0;i<8;++i)v|=(uint64_t)b[pos++]<<(8*i);return v;}
inline bytes stream(session& s,bool enc,const bytes& input,size_t inchunk,size_t outchunk,size_t limit){
 check(inchunk&&outchunk,"zero chunk");bytes result,buf(outchunk);size_t pos=0,end=std::min(inchunk,input.size()),idle=0;
 for(;;){auto p=s.process(enc,(input.empty()?(const unsigned char*)"":input.data()+pos),end-pos,buf.data(),buf.size(),end==input.size());
  check(p.consumed<=end-pos&&p.produced<=buf.size(),"invalid progress");pos+=p.consumed;
  check(p.produced<=limit&&result.size()<=limit-p.produced,"output quota exceeded");result.insert(result.end(),buf.begin(),buf.begin()+p.produced);
  if(p.finished){check(pos==input.size(),"trailing bytes after native frame");return result;}
  if(!p.consumed&&!p.produced){check(++idle<10000,"stream stalled");}else idle=0;
  if(pos==end&&end<input.size())end+=std::min(inchunk,input.size()-end);
 }
}
inline bytes encode(session& s,const bytes& input,size_t inchunk,size_t outchunk,size_t block){
 s.reset(true);if(s.streaming())return stream(s,true,input,inchunk,outchunk,input.size()*4+1048576);
 check(block>0,"zero block");bytes result{'L','N','B','L','K','2',0,0};size_t pos=0;
 do{size_t n=std::min(block,input.size()-pos);auto out=s.compress_block((input.empty()?(const unsigned char*)"":input.data()+pos),n);put64(result,n);put64(result,out.size());result.insert(result.end(),out.begin(),out.end());pos+=n;}while(pos<input.size());return result;
}
inline bytes decode(session& s,const bytes& input,size_t inchunk,size_t outchunk,size_t expected){
 s.reset(false);if(s.streaming()){auto out=stream(s,false,input,inchunk,outchunk,expected);check(out.size()==expected,"decoded size");return out;}
 check(input.size()>=8&&bytes(input.begin(),input.begin()+8)==bytes({'L','N','B','L','K','2',0,0}),"block schema");size_t pos=8;bytes result;
 while(pos<input.size()){auto n=get64(input,pos),len=get64(input,pos);check(n<=expected&&result.size()<=expected-n&&len<=input.size()-pos,"block lengths/quota");auto out=s.decompress_block((input.empty()?(const unsigned char*)"":input.data()+pos),(size_t)len,(size_t)n);result.insert(result.end(),out.begin(),out.end());pos+=(size_t)len;}
 check(result.size()==expected,"decoded size");return result;
}
}
