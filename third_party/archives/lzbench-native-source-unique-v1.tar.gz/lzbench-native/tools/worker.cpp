// Common measurement/IO harness. Codec calls are separate source implementations.
#include "lzbench_native.h"
#include <algorithm>
#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>
#include <cmath>
using Bytes=std::vector<unsigned char>;
static const char* names[]={"brotli","bzip2","deflate","lz4","lzsse2","lzsse8","snappy","xz","zstd"};
static int codec_id(const std::string& name){for(int i=0;i<9;++i)if(name==names[i])return i;throw std::runtime_error("unknown codec");}
class Codec {
    ln_context* ctx=nullptr;
public:
    Codec(int id,int level){
        if(ln_create((ln_codec)id,level,&ctx)!=LN_OK)throw std::runtime_error("candidate init failed");
    }
    ~Codec(){
        ln_destroy(ctx);
    }
    size_t compress(const Bytes& in,Bytes& out){unsigned char dummy=0;auto p=in.empty()?&dummy:in.data();
        size_t z=0;auto s=ln_compress(ctx,p,in.size(),out.data(),out.size(),&z);if(s!=LN_OK)throw std::runtime_error("candidate encode status "+std::to_string(s));return z;
    }
    void decompress(const Bytes& in,size_t size,Bytes& out){unsigned char dummy=0;auto p=in.empty()?&dummy:in.data();auto q=out.empty()?&dummy:out.data();
        size_t z=0;auto s=ln_decompress(ctx,p,size,q,out.size(),out.size(),&z);if(s!=LN_OK||z!=out.size())throw std::runtime_error("candidate decode status "+std::to_string(s));
    }
};
static Bytes read(const std::string& file){std::ifstream f(file,std::ios::binary);if(!f)throw std::runtime_error("cannot open "+file);return Bytes(std::istreambuf_iterator<char>(f),{});}
static int integer(const char* s){std::size_t used;int n=std::stoi(s,&used);if(used!=std::string(s).size())throw std::runtime_error("invalid integer");return n;}
static double real(const char* s){std::size_t used;double n=std::stod(s,&used);if(used!=std::string(s).size()||!std::isfinite(n))throw std::runtime_error("invalid number");return n;}
static void write(const std::string& file,const Bytes& b){std::ofstream f(file,std::ios::binary);f.write((const char*)b.data(),b.size());f.close();if(!f)throw std::runtime_error("write error");}
static void put64(Bytes& b,uint64_t x){for(int i=0;i<8;++i)b.push_back((unsigned char)(x>>(8*i)));}
static uint64_t get64(const Bytes& b,size_t& p){if(b.size()-p<8)throw std::runtime_error("short schema");uint64_t x=0;for(int i=0;i<8;++i)x|=(uint64_t)b[p++]<<(8*i);return x;}
struct Block{Bytes raw,compressed,decoded;size_t size=0;};
static std::vector<Block> blocks(const Bytes& raw){std::vector<Block> result;for(size_t p=0;p<raw.size()||(!p&&raw.empty());p+=LN_MAX_BLOCK){Block b;b.raw.assign(raw.begin()+p,raw.begin()+std::min(p+LN_MAX_BLOCK,raw.size()));b.compressed.resize(2*LN_MAX_BLOCK+4096);b.decoded.resize(b.raw.size());result.push_back(std::move(b));if(raw.empty())break;}return result;}
static Bytes pack(const std::vector<Block>& bs){Bytes b;for(const auto& v:bs){put64(b,v.raw.size());put64(b,v.size);b.insert(b.end(),v.compressed.begin(),v.compressed.begin()+v.size);}return b;}
volatile size_t sink=0;
using Clock=std::chrono::steady_clock;
template<class F> static void measure(F f,int rounds,double minimum){
    std::cout<<"[";for(int r=0;r<rounds;++r){size_t count=1;double seconds=0;
        for(;;){auto start=Clock::now();for(size_t j=0;j<count;++j)f();seconds=std::chrono::duration<double>(Clock::now()-start).count();if(seconds>=minimum||count>=(1u<<20))break;count*=2;}
        if(r)std::cout<<",";std::cout<<"{\"iterations\":"<<count<<",\"batch_seconds\":"<<seconds<<",\"seconds_per_column\":"<<seconds/count<<"}";
    }std::cout<<"]";
}
int main(int argc,char **argv){try{
    if(argc<6)throw std::runtime_error("usage: worker pack|unpack|bench CODEC LEVEL INPUT OUTPUT [rounds=7] [minimum_seconds=.005]");
    const std::string mode=argv[1];int id=codec_id(argv[2]),level=integer(argv[3]);Codec codec(id,level);auto input=read(argv[4]);
    if(mode=="unpack"){size_t p=0;Bytes output;while(p<input.size()){size_t n=get64(input,p),z=get64(input,p);if(n>LN_MAX_BLOCK||z>2*LN_MAX_BLOCK+4096||z>input.size()-p)throw std::runtime_error("invalid test schema");Bytes compressed(input.begin()+p,input.begin()+p+z),decoded(n);codec.decompress(compressed,z,decoded);output.insert(output.end(),decoded.begin(),decoded.end());p+=z;}write(argv[5],output);return 0;}
    auto bs=blocks(input);for(auto& b:bs){b.size=codec.compress(b.raw,b.compressed);codec.decompress(b.compressed,b.size,b.decoded);if(b.decoded!=b.raw)throw std::runtime_error("roundtrip mismatch");}
    if(mode=="bench"){
        int rounds=argc>6?integer(argv[6]):7;double minimum=argc>7?real(argv[7]):.005;if(rounds<1||rounds>31||minimum<0||minimum>1)throw std::runtime_error("invalid timing options");
        std::cout.precision(17);std::cout<<"{\"raw_bytes\":"<<input.size()<<",\"block_sizes\":[";
        size_t total=0;for(size_t i=0;i<bs.size();++i){if(i)std::cout<<",";std::cout<<bs[i].size;total+=bs[i].size;}std::cout<<"],\"compressed_bytes\":"<<total<<",\"encode_trials\":";
        measure([&](){for(auto& b:bs){auto z=codec.compress(b.raw,b.compressed);if(z!=b.size)throw std::runtime_error("nondeterministic size");sink+=z;}},rounds,minimum);
        std::cout<<",\"decode_trials\":";measure([&](){for(auto& b:bs){codec.decompress(b.compressed,b.size,b.decoded);sink+=b.decoded.empty()?0:b.decoded.back();}},rounds,minimum);std::cout<<"}\n";
        for(auto& b:bs)if(b.decoded!=b.raw)throw std::runtime_error("post timing mismatch");
    }else if(mode!="pack")throw std::runtime_error("invalid mode");
    write(argv[5],pack(bs));return 0;
}catch(const std::exception& e){std::cerr<<e.what()<<"\n";return 2;}}
