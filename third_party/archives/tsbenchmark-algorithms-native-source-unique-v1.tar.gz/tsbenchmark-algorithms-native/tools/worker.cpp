#include "tba.h"
#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstring>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <cctype>
#include <stdexcept>
#include <string>
#include <vector>
using Clock=std::chrono::steady_clock;
struct Owned {
    tba_buffer value{};
    ~Owned(){tba_free(&value);}
    Owned()=default;
    Owned(const Owned&)=delete;
    Owned& operator=(const Owned&)=delete;
};
std::vector<uint8_t> read(const std::string& p) {
    std::ifstream f(p,std::ios::binary|std::ios::ate);
    if(!f) throw std::runtime_error("cannot open input");
    auto n=f.tellg(); if(n<0 || n>std::streamoff(128000000)) throw std::runtime_error("input too large");
    std::vector<uint8_t> b(static_cast<size_t>(n)); f.seekg(0);
    if(n && !f.read(reinterpret_cast<char*>(b.data()),n)) throw std::runtime_error("input read failed");
    return b;
}
void write(const std::string& p,const tba_buffer& b) {
    std::ofstream f(p,std::ios::binary);
    if(!f || (b.bytes && !f.write(static_cast<const char*>(b.data),b.bytes))) throw std::runtime_error("output write failed");
    f.close(); if(!f) throw std::runtime_error("output close failed");
}
size_t number(const char* text,size_t maximum) {
    std::string s(text);
    if(s.empty() || !std::all_of(s.begin(),s.end(),[](unsigned char c){return c>='0' && c<='9';}))
        throw std::runtime_error("invalid unsigned integer");
    size_t used=0; const auto n=std::stoull(s,&used);
    if(used!=s.size() || n>maximum) throw std::runtime_error("integer limit");
    return static_cast<size_t>(n);
}
void check(int rc,const char* e) { if(rc) throw std::runtime_error(e); }
template<class F> void trials(F fn) {
    std::cout<<"[";
    for(int trial=0;trial<5;++trial) {
        double total=0; size_t calls=0;
        do {
            Owned out;
            const auto t=Clock::now(); fn(out.value);
            total+=std::chrono::duration<double>(Clock::now()-t).count(); ++calls;
        } while(total<0.01);
        if(trial) std::cout<<",";
        std::cout<<"{\"calls\":"<<calls<<",\"total_seconds\":"<<total
                 <<",\"seconds_per_call\":"<<total/calls<<"}";
    }
    std::cout<<"]";
}
int main(int argc,char** argv) {
    try {
        uint32_t endian=1;
        if(*reinterpret_cast<uint8_t*>(&endian)!=1 || sizeof(double)!=8 || sizeof(float)!=4)
            throw std::runtime_error("requires little-endian IEEE platform");
        if(argc<6 || argc>7) throw std::runtime_error("bench kind input prefix count | decode kind stream output max_count [layers]");
        const std::string mode=argv[1],name=argv[2];
        const int32_t kind=name=="kangaroo"?TBA_KANGAROO:name=="pbepla_rr"?TBA_PBEPLA_RR:name=="actsd"?TBA_ACTSD:-1;
        if(kind!=TBA_KANGAROO && kind!=TBA_PBEPLA_RR && kind!=TBA_ACTSD) throw std::runtime_error("unknown algorithm");
        auto b=read(argv[3]); std::string prefix=argv[4]; size_t n=number(argv[5],16000000);
        if(n>16000000) throw std::runtime_error("value limit");
        char error[1024]; Owned encoded,decoded;
        const unsigned layers=argc>6?static_cast<unsigned>(number(argv[6],16)):3;
        if(mode=="decode") {
            check(tba_decode(kind,b.data(),b.size(),layers,n,&decoded.value,error,sizeof(error)),error);
            write(prefix,decoded.value); return 0;
        }
        if(mode!="bench" || argc!=6 || b.size()!=n*8) throw std::runtime_error("invalid mode or input size");
        // Typed, aligned storage; no pointer casts from byte-vector storage.
        std::vector<double> values;
        std::vector<uint32_t> x,y;
        std::vector<double> eps;
        if(kind==TBA_ACTSD) {
            x.resize(n); y.resize(n);
            if(n) {std::memcpy(x.data(),b.data(),n*4); std::memcpy(y.data(),b.data()+n*4,n*4);}
        } else {
            values.resize(n); if(n) std::memcpy(values.data(),b.data(),n*8);
            for(double v:values) if(!std::isfinite(v)) throw std::runtime_error("benchmark finite inputs only");
            double low=0,high=0;
            if(n) {auto bounds=std::minmax_element(values.begin(),values.end()); low=*bounds.first;high=*bounds.second;}
            double span=high-low; if(!(span>0)) span=std::max(std::fabs(high),1.0);
            eps={0.05*span,0.01*span,0.005*span};
        }
        auto enc=[&](tba_buffer& out) {
            if(kind==TBA_KANGAROO) check(tba_kangaroo_encode(values.data(),n,&out,error,sizeof(error)),error);
            else if(kind==TBA_PBEPLA_RR) check(tba_pbepla_encode(values.data(),n,eps.data(),eps.size(),&out,error,sizeof(error)),error);
            else check(tba_actsd_encode(x.data(),y.data(),n,&out,error,sizeof(error)),error);
        };
        auto dec=[&](tba_buffer& out) {check(tba_decode(kind,encoded.value.data,encoded.value.bytes,3,n,&out,error,sizeof(error)),error);};
        enc(encoded.value); dec(decoded.value); // one complete warmup
        if(decoded.value.count!=n) throw std::runtime_error("decoded count mismatch");
        std::cout<<std::setprecision(17)<<"{\"compressed_bytes\":"<<encoded.value.bytes<<",\"count\":"<<n<<",\"encode_trials\":";
        trials(enc); std::cout<<",\"decode_trials\":"; trials(dec); std::cout<<"}\n";
        write(prefix+".stream",encoded.value); write(prefix+".decoded",decoded.value);
        if(kind==TBA_PBEPLA_RR) {
            for(unsigned layer=1;layer<=2;++layer) {
                Owned d; check(tba_decode(kind,encoded.value.data,encoded.value.bytes,layer,n,&d.value,error,sizeof(error)),error);
                write(prefix+".layer"+std::to_string(layer),d.value);
            }
        }
        return 0;
    } catch(const std::exception& e) {std::cerr<<e.what()<<"\n";return 1;}
}
