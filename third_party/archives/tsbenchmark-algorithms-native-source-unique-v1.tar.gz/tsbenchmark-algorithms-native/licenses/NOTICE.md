# 来源和许可

算法来源为用户提供 TSBenchmarkAlgorithms-main 本地档案，对应指定URL https://github.com/WenSanCoder/TSBenchmarkAlgorithms 。没有Git元数据，未联网重新取得提交。source-manifest.json 登记来源全部文件SHA256；upstream/仅保存构建/测试/说明闭包（algorithms、common、docs、experiments、third_party、根CMake/README），不复制论文PDF和历史results，不称作完整仓库档案。

该快照未发现算法项目的LICENSE文件，不自行赋予MIT等许可，不以Zstd许可替代算法许可。保留作者说明、文件及论文映射原状。

Zstd 1.5.7 来自本地 TSDataCompressBenchMark/adapters/zstd_frame/vendor/zstd 已有冻结副本，采用BSD-3-Clause，全文保留于 third_party/zstd-1.5.7/LICENSE，并保留COPYING。dependency-manifest.json登记文件身份。根CMake编译common/compress/decompress C源码，禁用ASM，不定义ZSTD_MULTITHREAD；双方benchmark不链接系统Zstd。与上游Windows的1.5.7 DLL构建不作逐字节承诺。

上游ACTSD独立Python oracle在Linux通过ctypes调用系统libzstd（本机1.4.8），只用于测试，不参与benchmark编码或压缩字节计费。这提供熵流互操作证据，不能称作独立Zstd实现。

新写内容：CMake集成、C ABI、接口测试、worker、CSV/计时适配、独立PBEP parser/decoder、报告及打包脚本。算法核心与KANG/PBEP/ACTS格式未修改。
