#pragma once

#include <cstdint>

namespace kangaroo::detail {

// Wire prefixes are written by the stream encoder: 0, 10 and 111 respectively.
enum class ErasureTag : std::uint8_t {
    Erased = 0,
    Flipped = 1,
    Verbatim = 2
};

struct ErasureResult {
    std::uint64_t value;
    ErasureTag tag;
};

// Decimal places in the shortest round-trip decimal representation; -1 for
// non-finite values. The lexical precision of the input CSV is not retained.
int decimal_places(std::uint64_t value);

// Implements Section 5, with a corrected inverse of Theorem 5's interval.
// A transformation is emitted only after independent bit-exact reconstruction.
// Values outside the proven domain are carried verbatim, preserving all bits.
ErasureResult erase_value(std::uint64_t value);

// Does not depend on encoder state. Invalid transformed values throw
// std::invalid_argument; Verbatim preserves arbitrary IEEE 754 bit patterns.
std::uint64_t recover_value(std::uint64_t value, ErasureTag tag);

} // namespace kangaroo::detail
