#pragma once

#include <cstddef>
#include <cstdint>
#include <limits>
#include <stdexcept>
#include <vector>

namespace kangaroo::detail {

// Contains encoded values (one entry per VL-RLE run), not the restored doubles.
// Sequence numbers are absolute; public distances are measured backwards from
// the newest entry, so distance zero always denotes the immediate predecessor.
class HistoryWindow {
public:
    explicit HistoryWindow(std::size_t capacity = 32)
        : values_(checked_capacity(capacity)) {}

    std::size_t size() const noexcept { return size_; }
    std::size_t capacity() const noexcept { return values_.size(); }
    bool empty() const noexcept { return size_ == 0; }
    std::uint64_t next_sequence() const noexcept { return next_sequence_; }

    bool contains_sequence(std::uint64_t sequence) const noexcept {
        return sequence < next_sequence_ && next_sequence_ - sequence <= size_;
    }

    std::uint64_t sequence_at_distance(std::size_t distance) const {
        if (distance >= size_) {
            throw std::out_of_range("Kangaroo history distance is outside the window");
        }
        return next_sequence_ - 1 - distance;
    }

    std::size_t distance_of_sequence(std::uint64_t sequence) const {
        if (!contains_sequence(sequence)) {
            throw std::out_of_range("Kangaroo history sequence has expired");
        }
        return static_cast<std::size_t>(next_sequence_ - 1 - sequence);
    }

    std::uint64_t at_sequence(std::uint64_t sequence) const {
        if (!contains_sequence(sequence)) {
            throw std::out_of_range("Kangaroo history sequence has expired");
        }
        return values_[static_cast<std::size_t>(sequence % values_.size())];
    }

    std::uint64_t at_distance(std::size_t distance) const {
        return at_sequence(sequence_at_distance(distance));
    }

    std::uint64_t newest() const { return at_distance(0); }

    void push(std::uint64_t bits) {
        // Reserve UINT64_MAX as an invalid sequence in the reference index.
        if (next_sequence_ == std::numeric_limits<std::uint64_t>::max()) {
            throw std::overflow_error("Kangaroo history sequence overflow");
        }
        values_[static_cast<std::size_t>(next_sequence_ % values_.size())] = bits;
        ++next_sequence_;
        if (size_ < values_.size()) {
            ++size_;
        }
    }

private:
    static std::size_t checked_capacity(std::size_t capacity) {
        if (capacity == 0) {
            throw std::invalid_argument("Kangaroo history window must be positive");
        }
        return capacity;
    }

    std::vector<std::uint64_t> values_;
    std::size_t size_ = 0;
    std::uint64_t next_sequence_ = 0;
};

} // namespace kangaroo::detail
