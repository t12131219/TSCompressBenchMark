#include "reference_search.h"

#include <stdexcept>

namespace kangaroo::detail {
namespace {

unsigned leading_zeros(std::uint64_t bits) noexcept {
    if (bits == 0) {
        return 64;
    }
    unsigned count = 0;
    for (std::uint64_t mask = std::uint64_t{1} << 63; (bits & mask) == 0;
         mask >>= 1) {
        ++count;
    }
    return count;
}

unsigned trailing_zeros(std::uint64_t bits) noexcept {
    if (bits == 0) {
        return 64;
    }
    unsigned count = 0;
    while ((bits & 1) == 0) {
        bits >>= 1;
        ++count;
    }
    return count;
}

} // namespace

ReferenceSearch::ReferenceSearch(std::size_t window_size)
    : history_(window_size), links_(window_size) {}

ReferenceChoice ReferenceSearch::result(std::uint64_t current,
                                        std::uint64_t sequence,
                                        bool matching) const {
    const auto value = history_.at_sequence(sequence);
    return {matching, history_.distance_of_sequence(sequence), value,
            leading_zeros(value ^ current)};
}

ReferenceChoice ReferenceSearch::choose(std::uint64_t current,
                                        SearchMode mode) const {
    if (history_.empty()) {
        throw std::logic_error("Kangaroo reference search requires prior history");
    }
    const auto& group = groups_[trailing_zeros(current)];
    if (!history_.contains_sequence(group.latest)) {
        return result(current, history_.next_sequence() - 1, false);
    }

    auto best = group.latest;
    auto max_lead = leading_zeros(history_.at_sequence(best) ^ current);
    if (mode == SearchMode::Fast) {
        const auto candidate = group.lookup[max_lead];
        if (history_.contains_sequence(candidate)) {
            // Prefix cancellation guarantees a strict improvement. Checking it
            // explicitly also makes this invariant visible in debug/review.
            if (leading_zeros(history_.at_sequence(candidate) ^ current) > max_lead) {
                best = candidate;
            }
        }
        return result(current, best, true);
    }

    // Algorithm 1: traverse only the same-trailing-zero predecessor chain.
    // Each edge caches Eq. (11); only complete-hop boundaries need XOR work.
    auto sequence = group.latest;
    auto min_lead = max_lead;
    while (true) {
        const auto& link = links_[static_cast<std::size_t>(sequence % links_.size())];
        if (!history_.contains_sequence(link.previous)) {
            break;
        }
        sequence = link.previous;
        if (link.leading_zeros < min_lead) {
            min_lead = link.leading_zeros;
        } else if (link.leading_zeros == min_lead) {
            min_lead = leading_zeros(history_.at_sequence(sequence) ^ current);
            if (min_lead > max_lead) {
                best = sequence;
                max_lead = min_lead;
            }
        }
    }
    return result(current, best, true);
}

void ReferenceSearch::push(std::uint64_t encoded_bits) {
    auto& group = groups_[trailing_zeros(encoded_bits)];
    const auto sequence = history_.next_sequence();
    Link link;
    if (history_.contains_sequence(group.latest)) {
        link.previous = group.latest;
        link.leading_zeros = leading_zeros(history_.at_sequence(group.latest) ^ encoded_bits);
        // Updating one same-trail adjacency edge changes its prefix frontier:
        // l < edge: unchanged; l == edge: old latest is the new boundary;
        // l > edge: the former boundary is separated by a shorter-prefix hop.
        group.lookup[link.leading_zeros] = group.latest;
        for (unsigned lead = link.leading_zeros + 1; lead <= 64; ++lead) {
            group.lookup[lead] = invalid_sequence;
        }
    } else {
        group.lookup.fill(invalid_sequence);
    }

    // Push can evict the oldest record. Absolute sequences in all indices are
    // checked on lookup, so stale entries cannot refer to a reused ring slot.
    history_.push(encoded_bits);
    links_[static_cast<std::size_t>(sequence % links_.size())] = link;
    group.latest = sequence;
}

} // namespace kangaroo::detail
