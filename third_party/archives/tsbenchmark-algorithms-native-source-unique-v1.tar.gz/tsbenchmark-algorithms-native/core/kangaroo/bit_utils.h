#pragma once

#include <array>
#include <cstdint>
#include <cstring>
#include <limits>
#include <stdexcept>

namespace kangaroo {
namespace detail {

static_assert(sizeof(double) == sizeof(std::uint64_t) &&
                  std::numeric_limits<double>::is_iec559,
              "Kangaroo requires IEEE 754 binary64 doubles");

inline std::uint64_t double_to_bits(double value) noexcept {
    std::uint64_t bits;
    std::memcpy(&bits, &value, sizeof(bits));
    return bits;
}

inline double bits_to_double(std::uint64_t bits) noexcept {
    double value;
    std::memcpy(&value, &bits, sizeof(value));
    return value;
}

inline unsigned count_leading_zeros(std::uint64_t value) noexcept {
    if (value == 0) {
        return 64;
    }
#if defined(__GNUC__) || defined(__clang__)
    return static_cast<unsigned>(__builtin_clzll(value));
#else
    unsigned count = 0;
    for (std::uint64_t mask = UINT64_C(1) << 63; (value & mask) == 0;
         mask >>= 1) {
        ++count;
    }
    return count;
#endif
}

inline unsigned count_trailing_zeros(std::uint64_t value) noexcept {
    if (value == 0) {
        return 64;
    }
#if defined(__GNUC__) || defined(__clang__)
    return static_cast<unsigned>(__builtin_ctzll(value));
#else
    unsigned count = 0;
    while ((value & 1) == 0) {
        ++count;
        value >>= 1;
    }
    return count;
#endif
}

// Chimp's 3-bit leading-zero representation, adopted by Kangaroo Section 3.3.2.
inline constexpr std::array<unsigned, 8> kLeadingBuckets{{0, 8, 12, 16, 18, 20, 22, 24}};

inline unsigned quantize_leading_zeros(unsigned count) {
    if (count > 64) {
        throw std::invalid_argument("leading-zero count exceeds 64");
    }
    unsigned bucket = 0;
    for (unsigned candidate : kLeadingBuckets) {
        if (candidate > count) {
            break;
        }
        bucket = candidate;
    }
    return bucket;
}

inline unsigned leading_code(unsigned bucket) {
    for (unsigned i = 0; i < kLeadingBuckets.size(); ++i) {
        if (kLeadingBuckets[i] == bucket) {
            return i;
        }
    }
    throw std::invalid_argument("invalid leading-zero bucket");
}

inline unsigned leading_from_code(unsigned code) {
    if (code >= kLeadingBuckets.size()) {
        throw std::invalid_argument("invalid leading-zero code");
    }
    return kLeadingBuckets[code];
}

} // namespace detail
} // namespace kangaroo
