#pragma once

#include <cstddef>
#include <cstdint>
#include <vector>

namespace kangaroo {

enum class ReferenceMode { Fast, Compact };

struct CompressParams {
    std::size_t history_window = 32;
    bool use_erasure = true;
    ReferenceMode reference_mode = ReferenceMode::Fast;
};

struct CodecStats {
    std::size_t distinct_values = 0;
    std::size_t repeated_values = 0;
    std::size_t first_values = 0;
    std::size_t literal_escapes = 0;
    std::size_t xor_equal = 0;
    std::size_t xor_same_trail = 0;
    std::size_t xor_different_trail = 0;
    std::size_t erased = 0;
    std::size_t flipped = 0;
    std::size_t verbatim = 0;
};

struct CompressionResult {
    std::vector<std::uint8_t> compressed_data;
    std::size_t original_bytes = 0;
    std::size_t compressed_bytes = 0;
    double compression_ratio = 0; // Original binary64 bytes / full container bytes.
    double encode_time_ms = 0;
    CodecStats stats;
};

struct DecodeLimits {
    // Explicit protection against unintended expansion of an untrusted stream.
    std::size_t max_output_values = 16000000;
};

struct DecompressionResult {
    std::vector<double> data;
    double decode_time_ms = 0;
    bool checksum_verified = false; // Integrity, not a comparison with unknown input.
};

CompressionResult compress(const double* data, std::size_t len,
                           const CompressParams& params = {});
// Window, mode and erasure flags are read from the self-contained stream.
DecompressionResult decompress(const std::uint8_t* data, std::size_t len,
                               const DecodeLimits& limits = {});
bool verify_bit_exact(const double* original, const double* recovered, std::size_t len);

} // namespace kangaroo
