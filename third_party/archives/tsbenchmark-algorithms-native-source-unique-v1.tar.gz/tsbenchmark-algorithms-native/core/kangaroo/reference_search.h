#pragma once

#include "history_window.h"

#include <array>
#include <cstddef>
#include <cstdint>
#include <limits>
#include <vector>

namespace kangaroo::detail {

enum class SearchMode { Fast, Compact };

struct ReferenceChoice {
    // False means no matching-trail candidate exists and value is the immediate
    // predecessor. True includes the newest matching-trail candidate itself.
    bool matching_candidate = false;
    std::size_t distance = 0;
    std::uint64_t value = 0;
    unsigned leading_zeros = 0;
};

class ReferenceSearch {
public:
    explicit ReferenceSearch(std::size_t window_size = 32);

    // Requires at least one prior encoded value. Neither operation uses the
    // original, restored doubles: search and history operate on erased bits.
    ReferenceChoice choose(std::uint64_t current,
                           SearchMode mode = SearchMode::Fast) const;
    void push(std::uint64_t encoded_bits);

    const HistoryWindow& history() const noexcept { return history_; }

private:
    static constexpr std::uint64_t invalid_sequence =
        std::numeric_limits<std::uint64_t>::max();

    struct Group {
        Group() { lookup.fill(invalid_sequence); }
        std::uint64_t latest = invalid_sequence;
        // lookup[l] is the most recent eligible complete-hop boundary for l
        // relative to latest. Invalidated entries are never used after expiry.
        std::array<std::uint64_t, 65> lookup;
    };

    struct Link {
        std::uint64_t previous = invalid_sequence;
        unsigned leading_zeros = 64;
    };

    ReferenceChoice result(std::uint64_t current, std::uint64_t sequence,
                           bool matching) const;

    HistoryWindow history_;
    std::vector<Link> links_;
    std::array<Group, 65> groups_;
};

} // namespace kangaroo::detail
