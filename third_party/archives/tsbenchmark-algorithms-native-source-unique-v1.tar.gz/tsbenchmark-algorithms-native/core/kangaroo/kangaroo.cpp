#include "kangaroo.h"

#include "bit_stream.h"
#include "bit_utils.h"
#include "erasure.h"
#include "history_window.h"
#include "reference_search.h"

#include <algorithm>
#include <array>
#include <chrono>
#include <cstring>
#include <limits>
#include <stdexcept>

namespace kangaroo {
namespace {

using detail::BitReader;
using detail::BitWriter;
using detail::ErasureTag;
constexpr std::size_t header_size = 40;
constexpr std::size_t max_window = 65536;

class Crc32 {
public:
    void byte(std::uint8_t value) {
        state_ = table()[(state_ ^ value) & 255] ^ (state_ >> 8);
    }
    void word(std::uint64_t value) {
        for (unsigned i = 0; i < 8; ++i) {
            byte(static_cast<std::uint8_t>(value >> (8 * i)));
        }
    }
    std::uint32_t finish() const { return state_ ^ UINT32_C(0xffffffff); }
private:
    static const std::array<std::uint32_t, 256>& table() {
        static const auto values = [] {
            std::array<std::uint32_t, 256> result{};
            for (std::uint32_t i = 0; i < 256; ++i) {
                auto c = i;
                for (unsigned j = 0; j < 8; ++j) {
                    c = (c >> 1) ^ ((c & 1) ? UINT32_C(0xedb88320) : 0);
                }
                result[i] = c;
            }
            return result;
        }();
        return values;
    }
    std::uint32_t state_ = UINT32_C(0xffffffff);
};

std::uint32_t crc_bytes(const std::uint8_t* data, std::size_t len) {
    Crc32 crc;
    for (std::size_t i = 0; i < len; ++i) {
        crc.byte(data[i]);
    }
    return crc.finish();
}

void put_le(std::vector<std::uint8_t>& out, std::size_t offset,
            std::uint64_t value, unsigned bytes) {
    for (unsigned i = 0; i < bytes; ++i) {
        out[offset + i] = static_cast<std::uint8_t>(value >> (8 * i));
    }
}

std::uint64_t get_le(const std::uint8_t* data, std::size_t offset, unsigned bytes) {
    std::uint64_t value = 0;
    for (unsigned i = 0; i < bytes; ++i) {
        value |= static_cast<std::uint64_t>(data[offset + i]) << (8 * i);
    }
    return value;
}

unsigned index_width(std::size_t window) {
    unsigned width = 0;
    for (auto value = window - 1; value != 0; value >>= 1) {
        ++width;
    }
    return width;
}

std::uint64_t input_bits(const double* data, std::size_t index) {
    std::uint64_t bits;
    std::memcpy(&bits, data + index, sizeof(bits));
    return bits;
}

void write_varuint(BitWriter& writer, std::uint64_t value) {
    do {
        const auto low = value & 127;
        value >>= 7;
        writer.write(low | (value != 0 ? 128 : 0), 8);
    } while (value != 0);
}

std::uint64_t read_varuint(BitReader& reader) {
    std::uint64_t value = 0;
    for (unsigned i = 0; i < 10; ++i) {
        const auto b = reader.read(8);
        if (i == 9 && b > 1) {
            throw std::runtime_error("Kangaroo: RLE integer overflow");
        }
        value |= (b & 127) << (7 * i);
        if ((b & 128) == 0) {
            if (i != 0 && b == 0) {
                throw std::runtime_error("Kangaroo: noncanonical RLE integer");
            }
            return value;
        }
    }
    throw std::runtime_error("Kangaroo: unterminated RLE integer");
}

void write_tag(BitWriter& writer, ErasureTag tag, CodecStats& stats) {
    if (tag == ErasureTag::Erased) {
        writer.write(0, 1);
        ++stats.erased;
    } else if (tag == ErasureTag::Flipped) {
        writer.write(2, 2);
        ++stats.flipped;
    } else {
        writer.write(7, 3);
        ++stats.verbatim;
    }
}

void write_center(BitWriter& writer, std::uint64_t current,
                  std::uint64_t reference, unsigned trail) {
    // The omitted low bit belongs to CURRENT, not to its XOR with reference.
    const auto diff = current ^ reference;
    const auto lead = detail::quantize_leading_zeros(
        std::min(detail::count_leading_zeros(diff), 63U - trail));
    const unsigned width = 63 - trail - lead;
    writer.write(detail::leading_code(lead), 3);
    writer.write(trail == 63 ? 0 : diff >> (trail + 1), width);
}

std::uint64_t read_center(BitReader& reader, std::uint64_t reference,
                          unsigned trail) {
    const auto lead = detail::leading_from_code(static_cast<unsigned>(reader.read(3)));
    if (trail > 63 || lead > 63 - trail) {
        throw std::runtime_error("Kangaroo: invalid center width");
    }
    const unsigned width = 63 - trail - lead;
    const auto center = reader.read(width);
    const auto high = trail == 63 ? 0 : center << (trail + 1);
    const auto mask = trail == 63 ? 0 : UINT64_MAX << (trail + 1);
    return ((reference ^ high) & mask) | (UINT64_C(1) << trail);
}

double elapsed_ms(std::chrono::steady_clock::time_point start) {
    return std::chrono::duration<double, std::milli>(
        std::chrono::steady_clock::now() - start).count();
}

} // namespace

CompressionResult compress(const double* data, std::size_t len,
                           const CompressParams& params) {
    const auto start = std::chrono::steady_clock::now();
    if (data == nullptr && len != 0) {
        throw std::invalid_argument("Kangaroo: null input");
    }
    if (len > std::numeric_limits<std::size_t>::max() / sizeof(double)) {
        throw std::length_error("Kangaroo: input length overflow");
    }
    if (params.history_window == 0 || params.history_window > max_window) {
        throw std::invalid_argument("Kangaroo: window must be in 1..65536");
    }
    if (params.reference_mode != ReferenceMode::Fast &&
        params.reference_mode != ReferenceMode::Compact) {
        throw std::invalid_argument("Kangaroo: invalid reference mode");
    }
    CompressionResult result;
    BitWriter writer;
    detail::ReferenceSearch search(params.history_window);
    const unsigned iw = index_width(params.history_window);
    const auto mode = params.reference_mode == ReferenceMode::Fast
        ? detail::SearchMode::Fast : detail::SearchMode::Compact;
    Crc32 original_crc;

    for (std::size_t i = 0; i < len;) {
        const auto original = input_bits(data, i);
        std::size_t end = i + 1;
        while (end < len && input_bits(data, end) == original) {
            ++end;
        }
        for (std::size_t j = i; j < end; ++j) {
            original_crc.word(original);
        }
        const auto transformed = params.use_erasure ? detail::erase_value(original)
            : detail::ErasureResult{original, ErasureTag::Verbatim};
        const auto current = transformed.value;
        if (search.history().empty()) {
            write_tag(writer, transformed.tag, result.stats);
            writer.write(current, 64);
            ++result.stats.first_values;
        } else {
            const auto reference = search.choose(current, mode);
            if (current == 0 && !reference.matching_candidate) {
                // ctz(+0)=64 cannot fit the paper's six-bit trail field.
                writer.write(6, 3);
                write_varuint(writer, 0);
                writer.write(original, 64);
                ++result.stats.literal_escapes;
                ++result.stats.verbatim;
            } else {
                write_tag(writer, transformed.tag, result.stats);
                const auto diff = current ^ reference.value;
                if (diff == 0) {
                    writer.write(0, 2);
                    writer.write(reference.distance, iw);
                    ++result.stats.xor_equal;
                } else if (reference.matching_candidate) {
                    writer.write(1, 1);
                    writer.write(reference.distance, iw);
                    write_center(writer, current, reference.value,
                                 detail::count_trailing_zeros(current));
                    ++result.stats.xor_same_trail;
                } else {
                    writer.write(1, 2); // 01: predecessor with different trail.
                    const auto trail = detail::count_trailing_zeros(current);
                    writer.write(trail, 6);
                    write_center(writer, current, reference.value, trail);
                    ++result.stats.xor_different_trail;
                }
            }
        }
        search.push(current);
        ++result.stats.distinct_values;
        const auto repeats = end - i - 1;
        if (repeats != 0) {
            writer.write(6, 3);
            write_varuint(writer, repeats);
            result.stats.repeated_values += repeats;
        }
        i = end;
    }

    auto& out = result.compressed_data;
    if (writer.bytes().size() > out.max_size() - header_size) {
        throw std::length_error("Kangaroo: output length overflow");
    }
    out.assign(header_size, 0);
    out[0] = 'K'; out[1] = 'A'; out[2] = 'N'; out[3] = 'G';
    out[4] = 1;
    out[5] = static_cast<std::uint8_t>((params.use_erasure ? 1 : 0) |
        (params.reference_mode == ReferenceMode::Compact ? 2 : 0));
    put_le(out, 6, header_size, 2);
    put_le(out, 8, params.history_window, 4);
    put_le(out, 12, len, 8);
    put_le(out, 20, writer.bit_size(), 8);
    put_le(out, 28, original_crc.finish(), 4);
    put_le(out, 32, crc_bytes(writer.bytes().data(), writer.bytes().size()), 4);
    put_le(out, 36, crc_bytes(out.data(), 36), 4);
    out.insert(out.end(), writer.bytes().begin(), writer.bytes().end());
    result.original_bytes = len * sizeof(double);
    result.compressed_bytes = out.size();
    result.compression_ratio = static_cast<double>(result.original_bytes) /
                               static_cast<double>(result.compressed_bytes);
    result.encode_time_ms = elapsed_ms(start);
    return result;
}

DecompressionResult decompress(const std::uint8_t* data, std::size_t len,
                               const DecodeLimits& limits) {
    const auto start = std::chrono::steady_clock::now();
    if (data == nullptr || len < header_size) {
        throw std::runtime_error("Kangaroo: truncated header");
    }
    if (data[0] != 'K' || data[1] != 'A' || data[2] != 'N' || data[3] != 'G' ||
        data[4] != 1 || (data[5] & ~3U) != 0 || get_le(data, 6, 2) != header_size) {
        throw std::runtime_error("Kangaroo: invalid container header");
    }
    if (get_le(data, 36, 4) != crc_bytes(data, 36)) {
        throw std::runtime_error("Kangaroo: header checksum mismatch");
    }
    const auto window = get_le(data, 8, 4);
    const auto count = get_le(data, 12, 8);
    const auto bits64 = get_le(data, 20, 8);
    if (window == 0 || window > max_window) {
        throw std::runtime_error("Kangaroo: invalid window");
    }
    if (count > limits.max_output_values ||
        count > std::numeric_limits<std::size_t>::max() / sizeof(double)) {
        throw std::length_error("Kangaroo: output exceeds configured limit");
    }
    if (bits64 > std::numeric_limits<std::size_t>::max()) {
        throw std::runtime_error("Kangaroo: payload bit length overflow");
    }
    const auto bits = static_cast<std::size_t>(bits64);
    const auto bytes = bits / 8 + (bits % 8 != 0);
    if (bytes != len - header_size) {
        throw std::runtime_error("Kangaroo: payload length mismatch");
    }
    const auto* payload = data + header_size;
    if (get_le(data, 32, 4) != crc_bytes(payload, bytes)) {
        throw std::runtime_error("Kangaroo: payload checksum mismatch");
    }
    if (bits % 8 != 0 &&
        (payload[bytes - 1] & ((1U << (8 - bits % 8)) - 1)) != 0) {
        throw std::runtime_error("Kangaroo: nonzero padding");
    }

    DecompressionResult result;
    result.data.resize(static_cast<std::size_t>(count));
    detail::HistoryWindow history(static_cast<std::size_t>(window));
    BitReader reader(payload, bytes, bits);
    const unsigned iw = index_width(static_cast<std::size_t>(window));
    Crc32 original_crc;
    std::size_t emitted = 0;
    std::uint64_t previous_original = 0;
    const auto emit = [&](std::uint64_t original) {
        std::memcpy(result.data.data() + emitted, &original, sizeof(original));
        ++emitted;
        original_crc.word(original);
    };

    while (emitted < count) {
        ErasureTag tag;
        if (reader.read(1) == 0) {
            tag = ErasureTag::Erased;
        } else if (reader.read(1) == 0) {
            tag = ErasureTag::Flipped;
        } else if (reader.read(1) == 0) {
            const auto repeat = read_varuint(reader);
            if (repeat == 0) {
                previous_original = reader.read(64);
                history.push(previous_original);
                emit(previous_original);
                continue;
            }
            if (emitted == 0 || repeat > count - emitted) {
                throw std::runtime_error("Kangaroo: invalid repeat count");
            }
            for (std::uint64_t i = 0; i < repeat; ++i) {
                emit(previous_original);
            }
            continue;
        } else {
            tag = ErasureTag::Verbatim;
        }
        if ((data[5] & 1) == 0 && tag != ErasureTag::Verbatim) {
            throw std::runtime_error("Kangaroo: erasure disabled by header");
        }

        std::uint64_t current;
        if (history.empty()) {
            current = reader.read(64);
        } else if (reader.read(1) != 0) {
            const auto distance = static_cast<std::size_t>(reader.read(iw));
            if (distance >= history.size()) {
                throw std::runtime_error("Kangaroo: invalid reference distance");
            }
            const auto reference = history.at_distance(distance);
            const auto trail = detail::count_trailing_zeros(reference);
            current = read_center(reader, reference, trail);
            if (current == reference) {
                throw std::runtime_error("Kangaroo: zero XOR in nonzero branch");
            }
        } else if (reader.read(1) == 0) {
            const auto distance = static_cast<std::size_t>(reader.read(iw));
            if (distance >= history.size()) {
                throw std::runtime_error("Kangaroo: invalid reference distance");
            }
            current = history.at_distance(distance);
        } else {
            const auto trail = static_cast<unsigned>(reader.read(6));
            const auto reference = history.newest();
            if (trail == detail::count_trailing_zeros(reference)) {
                throw std::runtime_error("Kangaroo: matching trail in predecessor branch");
            }
            current = read_center(reader, reference, trail);
        }
        previous_original = detail::recover_value(current, tag);
        history.push(current);
        emit(previous_original);
    }
    if (reader.remaining() != 0) {
        throw std::runtime_error("Kangaroo: unconsumed payload bits");
    }
    if (get_le(data, 28, 4) != original_crc.finish()) {
        throw std::runtime_error("Kangaroo: restored data checksum mismatch");
    }
    result.checksum_verified = true;
    result.decode_time_ms = elapsed_ms(start);
    return result;
}

bool verify_bit_exact(const double* original, const double* recovered, std::size_t len) {
    if (len == 0) {
        return true;
    }
    if (original == nullptr || recovered == nullptr ||
        len > std::numeric_limits<std::size_t>::max() / sizeof(double)) {
        return false;
    }
    return std::memcmp(original, recovered, len * sizeof(double)) == 0;
}

} // namespace kangaroo
