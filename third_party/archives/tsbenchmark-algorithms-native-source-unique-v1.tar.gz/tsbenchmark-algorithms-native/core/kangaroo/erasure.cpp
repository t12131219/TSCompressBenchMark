#include "erasure.h"

#include <array>
#include <charconv>
#include <cmath>
#include <cstring>
#include <stdexcept>
#include <string>
#include <system_error>

namespace kangaroo::detail {
namespace {

constexpr std::uint64_t sign_mask = UINT64_C(0x8000000000000000);
constexpr std::uint64_t exponent_mask = UINT64_C(0x7ff0000000000000);
constexpr long double log2_10 = 3.3219280948873623478703194294893901759L;
constexpr long double log10_2 = 0.3010299956639811952137388947244930268L;

double as_double(std::uint64_t value) {
    double result;
    std::memcpy(&result, &value, sizeof(result));
    return result;
}

std::uint64_t as_bits(double value) {
    std::uint64_t result;
    std::memcpy(&result, &value, sizeof(result));
    return result;
}

int trailing_zeros(std::uint64_t value) {
    if (value == 0) {
        return 64;
    }
    int count = 0;
    while ((value & 1) == 0) {
        ++count;
        value >>= 1;
    }
    return count;
}

int exponent(std::uint64_t value) {
    return static_cast<int>((value >> 52) & 0x7ff) - 1023;
}

int erase_length(int binary_exponent, int precision) {
    const int length = 52 - binary_exponent -
        static_cast<int>(std::ceil(static_cast<long double>(precision) * log2_10));
    return length > 0 ? length : 0;
}

int recover_precision(std::uint64_t value) {
    // Inverting L_alpha <= trail < L_(alpha-1) gives this expression.
    // The printed Eq. 22 omits the adjustment and fails the paper's Fig. 9(c).
    const int term = 51 - exponent(value) - trailing_zeros(value);
    return static_cast<int>(std::floor(static_cast<long double>(term) * log10_2)) + 1;
}

void increment_decimal(std::string& text) {
    for (std::size_t i = text.size(); i > 0; --i) {
        char& digit = text[i - 1];
        if (digit == '.') {
            continue;
        }
        if (digit != '9') {
            ++digit;
            return;
        }
        digit = '0';
    }
    text.insert(text.begin(), '1');
}

double parse_decimal(const std::string& text) {
    double result = 0;
    const auto parsed = std::from_chars(text.data(), text.data() + text.size(),
                                        result, std::chars_format::fixed);
    if (parsed.ec != std::errc{} || parsed.ptr != text.data() + text.size() ||
        !std::isfinite(result)) {
        throw std::invalid_argument("Kangaroo: erasure decimal reconstruction failed");
    }
    return result;
}

std::uint64_t round_up_decimal(std::uint64_t value, int precision) {
    // Avoid ceil(value * pow(10, precision)): that multiplication can overflow,
    // underflow, or round across an integer boundary. Formatting and parsing
    // the decimal grid also gives correctly rounded binary64 reconstruction.
    if (precision < 0 || precision > 324) {
        throw std::invalid_argument("Kangaroo: invalid recovered decimal precision");
    }
    const double magnitude = as_double(value & ~sign_mask);
    std::array<char, 1024> buffer{};
    const auto formatted = std::to_chars(buffer.data(), buffer.data() + buffer.size(),
                                          magnitude, std::chars_format::fixed, precision);
    if (formatted.ec != std::errc{}) {
        throw std::invalid_argument("Kangaroo: erasure decimal formatting failed");
    }
    std::string decimal(buffer.data(), formatted.ptr);
    double rounded = parse_decimal(decimal);
    if (rounded <= magnitude) {
        increment_decimal(decimal);
        rounded = parse_decimal(decimal);
    }
    return as_bits(rounded) | (value & sign_mask);
}

} // namespace

int decimal_places(std::uint64_t value) {
    if ((value & exponent_mask) == exponent_mask) {
        return -1;
    }
    std::array<char, 64> buffer{};
    const auto converted = std::to_chars(buffer.data(), buffer.data() + buffer.size(),
                                          as_double(value), std::chars_format::general);
    if (converted.ec != std::errc{}) {
        return -1;
    }
    const char* exponent_start = converted.ptr;
    const char* point = nullptr;
    for (const char* p = buffer.data(); p != converted.ptr; ++p) {
        if (*p == '.') {
            point = p;
        } else if (*p == 'e' || *p == 'E') {
            exponent_start = p;
            break;
        }
    }
    int decimal_exponent = 0;
    if (exponent_start != converted.ptr) {
        const char* start = exponent_start + 1;
        // from_chars(int) deliberately does not accept a leading '+'.
        if (start != converted.ptr && *start == '+') {
            ++start;
        }
        const auto parsed = std::from_chars(start, converted.ptr, decimal_exponent);
        if (parsed.ec != std::errc{} || parsed.ptr != converted.ptr) {
            return -1;
        }
    }
    const int fractional_digits = point == nullptr ? 0 :
        static_cast<int>(exponent_start - point - 1);
    const int precision = fractional_digits - decimal_exponent;
    return precision > 0 ? precision : 0;
}

ErasureResult erase_value(std::uint64_t value) {
    const ErasureResult unchanged{value, ErasureTag::Verbatim};
    const std::uint64_t exponent_bits = value & exponent_mask;
    // Signed zero, subnormals, infinities and NaNs use the exact raw path.
    if (exponent_bits == 0 || exponent_bits == exponent_mask) {
        return unchanged;
    }
    const int precision = decimal_places(value);
    if (precision <= 0) {
        return unchanged;
    }
    const int binary_exponent = exponent(value);
    const int length = erase_length(binary_exponent, precision);
    if (length <= 0 || length > 52) {
        return unchanged;
    }
    const std::uint64_t erased = value & ~((UINT64_C(1) << length) - 1);
    const int trail = trailing_zeros(erased);
    if (trail <= trailing_zeros(value)) {
        return unchanged;
    }
    ErasureResult transformed{erased, ErasureTag::Erased};
    const int preceding_length = erase_length(binary_exponent, precision - 1);
    if (trail >= preceding_length) {
        const int flip_position = preceding_length - 1;
        if (flip_position < 0 || flip_position >= 52) {
            return unchanged;
        }
        transformed.value |= UINT64_C(1) << flip_position;
        transformed.tag = ErasureTag::Flipped;
    }
    // The paper does not specify DP computation or decimal recovery. Keep the
    // output lossless even when a platform's decimal conversion differs.
    try {
        if (recover_value(transformed.value, transformed.tag) != value) {
            return unchanged;
        }
    } catch (const std::invalid_argument&) {
        return unchanged;
    }
    return transformed;
}

std::uint64_t recover_value(std::uint64_t value, ErasureTag tag) {
    if (tag == ErasureTag::Verbatim) {
        return value;
    }
    if (tag != ErasureTag::Erased && tag != ErasureTag::Flipped) {
        throw std::invalid_argument("Kangaroo: invalid erasure tag");
    }
    const std::uint64_t exponent_bits = value & exponent_mask;
    if (exponent_bits == 0 || exponent_bits == exponent_mask) {
        throw std::invalid_argument("Kangaroo: invalid erased IEEE 754 value");
    }
    const int precision = recover_precision(value);
    if (precision <= 0 || precision > 324) {
        throw std::invalid_argument("Kangaroo: invalid erased precision");
    }
    if (tag == ErasureTag::Flipped) {
        const int position = trailing_zeros(value);
        if (position >= 52 ||
            position != erase_length(exponent(value), precision - 1) - 1) {
            throw std::invalid_argument("Kangaroo: invalid erasure flip position");
        }
        value &= ~(UINT64_C(1) << position);
    }
    return round_up_decimal(value, precision);
}

} // namespace kangaroo::detail
