#pragma once
#include "actsd.h"
namespace actsd {
struct SegmentView {
    std::uint64_t first;
    std::size_t offset, bytes, count;
    SegType type;
    const std::uint8_t* payload; // borrows input bytes; keep input alive
};
struct ContainerView { std::vector<SegmentView> segments; std::size_t count = 0, overhead = 0; };
Bytes build_container(const std::uint64_t* v, std::size_t n,
    const std::vector<std::size_t>& starts, Profile profile, int theta,
    const std::vector<SegType>& forced_types = {});
ContainerView parse_container(const std::uint8_t* p, std::size_t size,
    std::size_t max_records = std::size_t(1) << 32);
std::vector<std::uint64_t> decode_segment(const ContainerView& c, std::size_t index);
std::vector<std::uint64_t> decode_container(const ContainerView& c);
void add_stats(EncodeStats& stats, const Bytes& container);
}
