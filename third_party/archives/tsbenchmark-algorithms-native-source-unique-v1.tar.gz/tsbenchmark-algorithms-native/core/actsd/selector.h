#pragma once
#include "actsd.h"
namespace actsd {
SegType select(const std::uint64_t* v, std::size_t n, Profile profile, int theta);
}
