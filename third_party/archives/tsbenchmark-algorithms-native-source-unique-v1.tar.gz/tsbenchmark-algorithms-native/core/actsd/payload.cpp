#include "payload.h"
#include "varint.h"
#include "zstd_codec.h"
namespace actsd {
bool valid_type(SegType t) { return t == SegType::Const || t == SegType::DeltaConst || t == SegType::Rle || t == SegType::DeltaZstd || t == SegType::Zstd; }
Bytes encode_payload(const std::uint64_t* v, std::size_t n, SegType t) {
    if (!n || !v || !valid_type(t)) throw std::invalid_argument("invalid payload input");
    Bytes b;
    switch (t) {
    case SegType::Const:
        for (std::size_t i = 1; i < n; ++i) if (v[i] != v[0]) throw std::invalid_argument("Const input varies");
        break;
    case SegType::DeltaConst: {
        if (n < 2) throw std::invalid_argument("DeltaConst needs two records");
        const auto d = v[1] - v[0];
        for (std::size_t i = 2; i < n; ++i) if (v[i] - v[i-1] != d) throw std::invalid_argument("DeltaConst input varies");
        put_varint(b, d); break;
    }
    case SegType::Rle: {
        std::size_t k = 1;
        for (std::size_t i = 1; i < n; ++i) k += v[i] != v[i-1];
        if (k > std::size_t(INT64_MAX) / 2) throw std::length_error("RLE run count overflow");
        put_varint(b, 2 * k);
        for (std::size_t i = 0; i < n;) {
            auto end = i + 1; while (end < n && v[end] == v[i]) ++end;
            put_varint(b, v[i]); put_varint(b, end - i); i = end;
        }
        break;
    }
    case SegType::DeltaZstd:
        for (std::size_t i = 1; i < n; ++i) put_varint(b, v[i] - v[i-1]);
        b = zstd_compress(b, n); break;
    case SegType::Zstd:
        for (std::size_t i = 0; i < n; ++i) put_varint(b, v[i]);
        b = zstd_compress(b, n); break;
    }
    return b;
}
std::vector<std::uint64_t> decode_payload(const std::uint8_t* p, std::size_t bytes,
    SegType t, std::uint64_t first, std::size_t count, std::size_t max_records) {
    require(valid_type(t), ErrorCode::Type, "unknown segment type");
    require(count != 0, ErrorCode::Count, "zero segment count");
    checked_size(count, max_records);
    Bytes inflated;
    if (t == SegType::Zstd || t == SegType::DeltaZstd) {
        inflated = zstd_decompress(p, bytes, times10(count)); p = inflated.data(); bytes = inflated.size();
    }
    Reader r(p, bytes);
    std::vector<std::uint64_t> v;
    switch (t) {
    case SegType::Const:
        r.end(); v.assign(count, first); break;
    case SegType::DeltaConst: {
        require(count >= 2, ErrorCode::Count, "DeltaConst requires count >= 2");
        const auto d = r.varint(); r.end();
        v.resize(count); v[0] = first;
        for (std::size_t i = 1; i < count; ++i) v[i] = v[i-1] + d;
        break;
    }
    case SegType::Rle: {
        const auto pairs = r.varint();
        require(pairs > 0 && pairs <= INT64_MAX && pairs % 2 == 0 && pairs / 2 <= count && pairs <= r.remaining(),
                ErrorCode::Payload, "invalid RLE pair count");
        for (std::uint64_t i = 0; i < pairs / 2; ++i) {
            const auto a = r.varint(), run = r.varint();
            require(run > 0 && run <= INT64_MAX && run <= count - v.size(), ErrorCode::Count, "invalid RLE run length");
            v.insert(v.end(), static_cast<std::size_t>(run), a);
        }
        require(v.size() == count, ErrorCode::Count, "RLE count mismatch");
        r.end(); break;
    }
    case SegType::DeltaZstd:
    case SegType::Zstd: {
        const auto skip = t == SegType::DeltaZstd ? 1U : 0U;
        require(count - skip <= bytes, ErrorCode::Count, "too few encoded integers");
        v.reserve(count);
        if (skip) v.push_back(first);
        for (std::size_t i = skip; i < count; ++i) {
            auto u = r.varint(); if (skip) u += v.back(); v.push_back(u);
        }
        r.end(); break;
    }
    }
    require(v.front() == first, ErrorCode::Payload, "first value disagrees with segment header");
    return v;
}
}
