#pragma once
#include "container.h"
namespace actsd {
struct FrameView {
    Sfc sfc;
    bool has_timestamps;
    std::size_t records;
    std::vector<ContainerView> containers;
    const std::uint8_t* timestamps = nullptr;
    std::size_t timestamp_bytes = 0;
};
Bytes build_frame(const std::vector<Bytes>& containers, std::size_t n, Sfc sfc,
                  const Bytes* timestamps = nullptr);
FrameView parse_frame(const std::uint8_t* p, std::size_t bytes,
    std::size_t max_records = std::size_t(1) << 32);
}
