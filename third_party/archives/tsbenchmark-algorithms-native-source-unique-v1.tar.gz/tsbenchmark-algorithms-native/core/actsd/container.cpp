#include "container.h"
#include "payload.h"
#include "selector.h"
#include "varint.h"
namespace actsd {
Bytes build_container(const std::uint64_t* v, std::size_t n, const std::vector<std::size_t>& starts,
                      Profile profile, int theta, const std::vector<SegType>& forced) {
    if (!n || !v || starts.empty() || starts[0] != 0 || starts.size() > n ||
        (!forced.empty() && forced.size() != starts.size())) throw std::invalid_argument("invalid segment starts");
    if (starts.size() > (SIZE_MAX - 8) / 8) throw std::length_error("container header overflow");
    Bytes out, body;
    put_varuint(out, 8 + starts.size() * 8); // E6: LEB128 length, not fixed u8
    tsbits::put_le(out, starts.size(), 8);
    for (std::size_t k = 0; k < starts.size(); ++k) {
        const auto begin = starts[k], end = k+1 < starts.size() ? starts[k+1] : n;
        if (begin >= end || end > n) throw std::invalid_argument("non-increasing segment starts");
        const auto t = forced.empty() ? select(v + begin, end - begin, profile, theta) : forced[k];
        const auto payload = encode_payload(v + begin, end - begin, t);
        tsbits::put_le(out, body.size(), 8); // E8: relative to seg_0
        tsbits::put_le(body, v[begin], 8);
        tsbits::put_le(body, payload.size(), 8);
        body.push_back(static_cast<std::uint8_t>(t));
        tsbits::put_le(body, end - begin, 8); // E7: explicit count, 25-byte header
        body.insert(body.end(), payload.begin(), payload.end());
    }
    out.insert(out.end(), body.begin(), body.end()); return out;
}
ContainerView parse_container(const std::uint8_t* p, std::size_t size, std::size_t max_records) {
    Reader r(p, size);
    const auto len64 = r.varuint();
    const auto len = checked_size(len64, r.remaining());
    Reader h(r.take(len), len);
    const auto m64 = h.le();
    require(m64 > 0 && m64 <= max_records && m64 == h.remaining() / 8 && h.remaining() % 8 == 0,
            ErrorCode::Header, "invalid segment count/header length");
    const auto m = static_cast<std::size_t>(m64);
    require(m <= r.remaining() / 25, ErrorCode::Truncated, "missing segment headers");
    std::vector<std::size_t> offsets;
    for (std::size_t k = 0; k < m; ++k) offsets.push_back(checked_size(h.le(), r.remaining()));
    h.end();
    ContainerView c;
    c.overhead = r.position() + 25 * m;
    const auto base = r.position();
    for (std::size_t k = 0; k < m; ++k) {
        require(offsets[k] == r.position() - base, ErrorCode::Offset, "offset violates Eq.3");
        const auto first = r.le(), bytes64 = r.le();
        const auto type = static_cast<SegType>(r.le(1));
        require(valid_type(type), ErrorCode::Type, "unknown segment type");
        const auto count = checked_size(r.le(), max_records - c.count);
        require(count > 0, ErrorCode::Count, "zero segment count");
        const auto bytes = checked_size(bytes64, r.remaining());
        const auto* payload = r.take(bytes);
        c.segments.push_back({first, offsets[k], bytes, count, type, payload}); c.count += count;
    }
    r.end(); return c;
}
std::vector<std::uint64_t> decode_segment(const ContainerView& c, std::size_t index) {
    if (index >= c.segments.size()) throw std::out_of_range("segment index");
    const auto& s = c.segments[index];
    return decode_payload(s.payload, s.bytes, s.type, s.first, s.count, c.count);
}
std::vector<std::uint64_t> decode_container(const ContainerView& c) {
    std::vector<std::uint64_t> v;
    for (std::size_t i = 0; i < c.segments.size(); ++i) {
        const auto part = decode_segment(c, i); v.insert(v.end(), part.begin(), part.end());
    }
    return v;
}
void add_stats(EncodeStats& stats, const Bytes& bytes) {
    const auto c = parse_container(bytes.data(), bytes.size());
    ++stats.containers; stats.segments += c.segments.size(); stats.container_bytes += bytes.size();
    stats.overhead_impl += c.overhead;
    stats.overhead_paper += 25 * c.segments.size() + 9;
    for (const auto& s : c.segments) ++stats.type_hits[static_cast<unsigned>(s.type)];
}
}
