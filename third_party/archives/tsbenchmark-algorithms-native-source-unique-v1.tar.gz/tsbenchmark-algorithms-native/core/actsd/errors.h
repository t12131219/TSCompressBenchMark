#pragma once
#include <stdexcept>
#include <string>
namespace actsd {
enum class ErrorCode { Truncated, Varint, Header, Offset, Type, Count, Payload, Zstd, Crc, Limit, Trailing };
inline const char* error_name(ErrorCode e) {
    switch (e) {
    case ErrorCode::Truncated: return "truncated";
    case ErrorCode::Varint: return "varint";
    case ErrorCode::Header: return "header";
    case ErrorCode::Offset: return "offset";
    case ErrorCode::Type: return "type";
    case ErrorCode::Count: return "count";
    case ErrorCode::Payload: return "payload";
    case ErrorCode::Zstd: return "zstd";
    case ErrorCode::Crc: return "crc";
    case ErrorCode::Limit: return "limit";
    case ErrorCode::Trailing: return "trailing";
    }
    return "unknown";
}
struct FormatError : std::runtime_error {
    ErrorCode code;
    FormatError(ErrorCode c, const std::string& message) : std::runtime_error(message), code(c) {}
};
inline void require(bool ok, ErrorCode c, const char* message) {
    if (!ok) throw FormatError(c, message);
}
} // namespace actsd
