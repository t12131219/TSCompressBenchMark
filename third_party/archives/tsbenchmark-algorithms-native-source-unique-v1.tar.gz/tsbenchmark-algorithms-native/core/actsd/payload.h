#pragma once
#include "actsd.h"
namespace actsd {
bool valid_type(SegType type);
Bytes encode_payload(const std::uint64_t* v, std::size_t n, SegType type);
std::vector<std::uint64_t> decode_payload(const std::uint8_t* p, std::size_t bytes,
    SegType type, std::uint64_t first, std::size_t count, std::size_t max_records = std::size_t(1) << 32);
}
