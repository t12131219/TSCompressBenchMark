#include "zstd_codec.h"
#include "errors.h"
#include <zstd.h>
namespace actsd {
int compression_level(std::size_t n) { return n <= 64 ? 1 : n <= 256 ? 2 : n <= 1024 ? 3 : n <= 4096 ? 4 : 5; }
unsigned zstd_version() { return ZSTD_versionNumber(); }
Bytes zstd_compress(const Bytes& in, std::size_t rows) {
    Bytes out(ZSTD_compressBound(in.size()));
    const auto n = ZSTD_compress(out.data(), out.size(), in.data(), in.size(), compression_level(rows));
    require(!ZSTD_isError(n), ErrorCode::Zstd, "Zstd compression failed");
    out.resize(n); return out;
}
Bytes zstd_decompress(const std::uint8_t* data, std::size_t size, std::size_t limit) {
    const auto frame = ZSTD_findFrameCompressedSize(data, size);
    require(!ZSTD_isError(frame) && frame == size, ErrorCode::Zstd, "invalid, concatenated or trailing Zstd frame");
    const auto n = ZSTD_getFrameContentSize(data, size);
    require(n != ZSTD_CONTENTSIZE_ERROR, ErrorCode::Zstd, "invalid Zstd frame");
    require(n == ZSTD_CONTENTSIZE_UNKNOWN || n <= limit, ErrorCode::Limit, "Zstd output exceeds count * 10");
    Bytes out(n == ZSTD_CONTENTSIZE_UNKNOWN ? limit : static_cast<std::size_t>(n));
    const auto actual = ZSTD_decompress(out.data(), out.size(), data, size);
    require(!ZSTD_isError(actual), ErrorCode::Zstd, "Zstd decompression failed");
    require(actual <= limit, ErrorCode::Limit, "Zstd output exceeds limit");
    out.resize(actual); return out;
}
}
