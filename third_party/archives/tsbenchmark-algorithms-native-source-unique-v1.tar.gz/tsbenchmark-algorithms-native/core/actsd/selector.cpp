#include "selector.h"
#include "attributes.h"
#include <stdexcept>
namespace actsd {
SegType select(const std::uint64_t* v, std::size_t n, Profile profile, int theta) {
    if (unsigned(profile) > 1 || theta < 0 || theta > 65 || (!v && n))
        throw std::invalid_argument("invalid selector parameters");
    if (n <= 1) return SegType::Const;
    bool delta_const = true;
    const auto d = v[1] - v[0];
    std::size_t same = 0;
    long double sum = 0;
    for (std::size_t i = 1; i < n; ++i) {
        delta_const &= v[i] - v[i-1] == d;
        same += v[i] == v[i-1];
        sum += popcount(v[i] ^ v[i-1]);
    }
    const auto average = sum / n; // E4: includes zero XORs, denominator L
    if (profile == Profile::Paper) {
        if (delta_const) return SegType::DeltaConst;
        if (same == n - 1) return SegType::Rle; // E5: unreachable after DeltaConst
        return average < theta ? SegType::DeltaZstd : SegType::Zstd;
    }
    if (n <= 2) return SegType::DeltaConst;
    if (sum == 0) return SegType::Const;
    if (static_cast<long double>(same) > 0.9L * n) return SegType::Rle;
    return average < 25 ? SegType::DeltaZstd : SegType::Zstd;
}
}
