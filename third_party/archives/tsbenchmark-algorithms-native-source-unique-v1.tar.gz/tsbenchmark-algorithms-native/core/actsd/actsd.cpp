#include "actsd.h"
#include "frame.h"
#include "grid_search.h"
#include "sfc.h"
#include "timestamps.h"
#include <cstring>
#include <limits>
#include <stdexcept>
namespace actsd {
static_assert(sizeof(float) == 4 && std::numeric_limits<float>::is_iec559, "ACTSD requires IEEE binary32");
void validate(const Params& p) {
    if (unsigned(p.sfc) > 2 || unsigned(p.rule) > 1 || unsigned(p.profile) > 1)
        throw std::invalid_argument("invalid SFC/rule/profile");
    if ((p.phi == -1) != (p.theta == -1) || p.phi < -1 || p.phi > 65 || p.theta < -1 || p.theta > 65)
        throw std::invalid_argument("phi/theta must both be automatic or in [0,65]");
}
Bytes encode(const std::uint32_t* x, const std::uint32_t* y, const std::int64_t* ts,
             std::size_t n, const Params& p, EncodeStats* stats) {
    validate(p);
    if ((!x || !y) && n) throw std::invalid_argument("null coordinate input");
    std::vector<std::uint64_t> codes(n);
    for (std::size_t i = 0; i < n; ++i) codes[i] = sfc_encode(x[i], y[i], p.sfc);
    EncodeStats s;
    auto containers = encode_codes(codes.data(), n, p, &s);
    const auto times = ts ? encode_timestamps(ts, n) : Bytes{};
    auto out = build_frame(containers, n, p.sfc, ts ? &times : nullptr);
    s.timestamp_bytes = times.size(); s.file_bytes = out.size();
    if (stats) *stats = s;
    return out;
}
Bytes encode(const float* x, const float* y, const std::int64_t* ts, std::size_t n, const Params& p, EncodeStats* stats) {
    validate(p);
    if ((!x || !y) && n) throw std::invalid_argument("null coordinate input");
    std::vector<std::uint32_t> xb(n), yb(n);
    if (n) { std::memcpy(xb.data(), x, n * sizeof(float)); std::memcpy(yb.data(), y, n * sizeof(float)); }
    return encode(xb.data(), yb.data(), ts, n, p, stats);
}
Decoded decode(const std::uint8_t* data, std::size_t size, std::size_t max_records) {
    const auto f = parse_frame(data, size, max_records);
    Decoded out; out.has_timestamps = f.has_timestamps; out.sfc = f.sfc;
    for (const auto& c : f.containers) {
        for (std::size_t i = 0; i < c.segments.size(); ++i) {
            const auto values = decode_segment(c, i);
            for (auto v : values) {
                const auto xy = sfc_decode(v, f.sfc);
                out.x_bits.push_back(xy.first); out.y_bits.push_back(xy.second);
            }
        }
    }
    if (f.has_timestamps) out.timestamps = decode_timestamps(f.timestamps, f.timestamp_bytes, f.records);
    return out;
}
}
