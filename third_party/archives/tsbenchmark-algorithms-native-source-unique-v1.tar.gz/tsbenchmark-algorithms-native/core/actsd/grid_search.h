#pragma once
#include "actsd.h"
namespace actsd {
Bytes encode_codes_container(const std::uint64_t* v, std::size_t n, const Params& p);
std::pair<int, int> grid_search(const std::uint64_t* v, std::size_t n, const Params& p);
// Low-level single-dimensional pipeline, used by the w/o SFC experiment.
std::vector<Bytes> encode_codes(const std::uint64_t* v, std::size_t n, Params p, EncodeStats* stats = nullptr);
}
