#pragma once
#include "actsd.h"
#include "errors.h"
#include "tsbits.h"
#include <cstring>
#include <limits>
namespace actsd {
// Signed arithmetic uses unsigned two's-complement bit patterns (E3).
inline std::uint64_t signed_bits(std::int64_t v) { std::uint64_t u; std::memcpy(&u, &v, 8); return u; }
inline std::int64_t as_signed(std::uint64_t u) { std::int64_t v; std::memcpy(&v, &u, 8); return v; }
inline std::uint64_t zigzag(std::uint64_t bits) { return (bits << 1) ^ (0 - (bits >> 63)); }
inline std::uint64_t unzigzag(std::uint64_t u) { return (u >> 1) ^ (0 - (u & 1)); }
inline void put_varuint(Bytes& out, std::uint64_t v) {
    while (v >= 128) { out.push_back(static_cast<std::uint8_t>(v) | 128); v >>= 7; }
    out.push_back(static_cast<std::uint8_t>(v));
}
inline void put_varint(Bytes& out, std::uint64_t bits) { put_varuint(out, zigzag(bits)); }
inline std::size_t varlen(std::uint64_t v) { std::size_t n = 1; while (v >= 128) { ++n; v >>= 7; } return n; }
inline std::size_t checked_size(std::uint64_t v, std::size_t limit) {
    require(v <= limit, ErrorCode::Limit, "length/count exceeds limit"); return static_cast<std::size_t>(v);
}
inline std::size_t times10(std::size_t n) {
    require(n <= std::numeric_limits<std::size_t>::max() / 10, ErrorCode::Limit, "count * 10 overflow"); return n * 10;
}
class Reader {
public:
    Reader(const std::uint8_t* p, std::size_t n) : p_(p), n_(n) { require(p || n == 0, ErrorCode::Truncated, "null buffer"); }
    std::size_t remaining() const { return n_ - pos_; }
    std::size_t position() const { return pos_; }
    const std::uint8_t* take(std::size_t n) {
        require(n <= remaining(), ErrorCode::Truncated, "truncated byte stream");
        const auto* p = p_ ? p_ + pos_ : nullptr; pos_ += n; return p;
    }
    std::uint64_t le(unsigned n = 8) { return tsbits::get_le(take(n), n); }
    std::uint64_t varuint() {
        std::uint64_t v = 0;
        for (unsigned i = 0; i < 10; ++i) {
            const auto b = le(1);
            require(i < 9 || b <= 1, ErrorCode::Varint, "varint exceeds 64 bits");
            v |= (b & 127) << (7 * i);
            if (!(b & 128)) {
                require(i == 0 || b != 0, ErrorCode::Varint, "non-canonical varint"); return v;
            }
        }
        throw FormatError(ErrorCode::Varint, "overlong varint");
    }
    std::uint64_t varint() { return unzigzag(varuint()); }
    void end() const { require(remaining() == 0, ErrorCode::Trailing, "trailing bytes"); }
private:
    const std::uint8_t* p_;
    std::size_t n_, pos_ = 0;
};
} // namespace actsd
