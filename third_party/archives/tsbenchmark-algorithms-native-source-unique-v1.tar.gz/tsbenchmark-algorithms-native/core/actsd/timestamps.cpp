#include "timestamps.h"
#include "varint.h"
#include "zstd_codec.h"
namespace actsd {
// Engineering timestamp stream: t0, d1, dd2, dd3, ... all modulo 2^64.
Bytes encode_timestamps(const std::int64_t* ts, std::size_t n) {
    if (!ts && n) throw std::invalid_argument("null timestamps");
    Bytes raw;
    std::uint64_t prev = 0, delta = 0;
    for (std::size_t i = 0; i < n; ++i) {
        const auto t = signed_bits(ts[i]), d = t - prev;
        put_varint(raw, i == 0 ? t : i == 1 ? d : d - delta);
        prev = t; delta = d;
    }
    return zstd_compress(raw, n);
}
std::vector<std::int64_t> decode_timestamps(const std::uint8_t* p, std::size_t bytes, std::size_t n) {
    const auto raw = zstd_decompress(p, bytes, times10(n));
    require(n <= raw.size(), ErrorCode::Count, "too few timestamps");
    Reader r(raw.data(), raw.size());
    std::vector<std::int64_t> ts;
    ts.reserve(n);
    std::uint64_t t = 0, delta = 0;
    for (std::size_t i = 0; i < n; ++i) {
        const auto u = r.varint();
        if (i == 0) t = u;
        else { delta = i == 1 ? u : delta + u; t += delta; }
        ts.push_back(as_signed(t));
    }
    r.end(); return ts;
}
}
