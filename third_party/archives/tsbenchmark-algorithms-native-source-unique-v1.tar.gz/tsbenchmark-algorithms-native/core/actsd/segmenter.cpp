#include "segmenter.h"
#include "attributes.h"
#include <stdexcept>
namespace actsd {
std::vector<std::size_t> segment(const std::uint64_t* v, std::size_t n, SegRule rule, int phi) {
    if (phi < 0 || phi > 65 || unsigned(rule) > 1 || (!v && n))
        throw std::invalid_argument("invalid segmentation parameters");
    std::vector<std::size_t> starts;
    if (n) starts.push_back(0);
    for (std::size_t i = 1; i < n; ++i) {
        const auto a = attributes(v[i-1], v[i]);
        // E9: frozen default R1; R2 is a sensitivity experiment.
        if ((rule == SegRule::FrontOverlapBelowPhi && int(a.frontOverlap) < phi) ||
            (rule == SegRule::HammingAbovePhi && int(a.hamDis) > phi)) starts.push_back(i);
    }
    return starts;
}
}
