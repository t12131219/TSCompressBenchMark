#pragma once
#include "actsd.h"
namespace actsd {
std::vector<std::size_t> segment(const std::uint64_t* v, std::size_t n, SegRule rule, int phi);
}
