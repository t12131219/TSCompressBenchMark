#pragma once
#include <cstdint>
namespace actsd {
struct Attributes { unsigned frontOverlap, backOverlap, hamDis, xorN, validN; };
inline unsigned popcount(std::uint64_t v) {
#if defined(__GNUC__) || defined(__clang__)
    return static_cast<unsigned>(__builtin_popcountll(v));
#else
    unsigned n = 0; while (v) { v &= v - 1; ++n; } return n;
#endif
}
inline Attributes attributes(std::uint64_t a, std::uint64_t b) {
    const auto v = a ^ b;
    unsigned bits = 0;
#if defined(__GNUC__) || defined(__clang__)
    if (v) bits = 64 - static_cast<unsigned>(__builtin_clzll(v));
#else
    for (auto u = v; u; u >>= 1) ++bits;
#endif
    const auto ham = popcount(v);
    return {64 - bits, bits - ham, ham, bits, 64}; // E2, Algorithm 3
}
}
