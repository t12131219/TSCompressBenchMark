#pragma once
#include "actsd.h"
namespace actsd {
int compression_level(std::size_t n);
unsigned zstd_version();
Bytes zstd_compress(const Bytes& input, std::size_t rows);
Bytes zstd_decompress(const std::uint8_t* data, std::size_t size, std::size_t limit);
}
