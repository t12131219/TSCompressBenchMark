#include "grid_search.h"
#include "container.h"
#include "segmenter.h"
#include <algorithm>
#include <limits>
#include <stdexcept>
namespace actsd {
Bytes encode_codes_container(const std::uint64_t* v, std::size_t n, const Params& p) {
    if (!n) throw std::invalid_argument("empty container");
    auto starts = p.segmentation ? segment(v, n, p.rule, p.phi) : std::vector<std::size_t>{0};
    auto b = build_container(v, n, starts, p.profile, p.theta);
    if (p.seg_fallback && starts.size() > 1) {
        auto single = build_container(v, n, {0}, p.profile, p.theta);
        if (single.size() <= b.size()) b = std::move(single); // ties -> single (§4.8)
    }
    return b;
}
std::pair<int, int> grid_search(const std::uint64_t* v, std::size_t n, const Params& p) {
    validate(p);
    if (!v && n) throw std::invalid_argument("null codes");
    const auto sample = p.sample_size ? std::min(n, p.sample_size) : n;
    std::size_t best = std::numeric_limits<std::size_t>::max();
    std::pair<int, int> answer{10, 10};
    for (int phi = 10; phi <= 30; phi += 5) for (int theta = 10; theta <= 30; theta += 5) {
        auto trial = p; trial.phi = phi; trial.theta = theta;
        // E10: sample is one container; objective includes all metadata.
        const auto size = sample ? encode_codes_container(v, sample, trial).size() : 0;
        if (size < best) { best = size; answer = {phi, theta}; }
    }
    return answer;
}
std::vector<Bytes> encode_codes(const std::uint64_t* v, std::size_t n, Params p, EncodeStats* stats) {
    validate(p);
    if (!v && n) throw std::invalid_argument("null codes");
    if (p.phi == -1) { const auto best = grid_search(v, n, p); p.phi = best.first; p.theta = best.second; }
    EncodeStats s; s.phi = p.phi; s.theta = p.theta;
    std::vector<Bytes> containers;
    for (std::size_t begin = 0; begin < n;) {
        const auto count = p.block_rows ? std::min(p.block_rows, n - begin) : n - begin;
        containers.push_back(encode_codes_container(v + begin, count, p));
        add_stats(s, containers.back()); begin += count;
    }
    if (stats) *stats = s;
    return containers;
}
}
