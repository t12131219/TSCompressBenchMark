#include "sfc.h"
#include <stdexcept>
namespace actsd {
namespace {
std::uint64_t spread(std::uint64_t v) {
    v = (v | (v << 16)) & UINT64_C(0x0000ffff0000ffff);
    v = (v | (v << 8)) & UINT64_C(0x00ff00ff00ff00ff);
    v = (v | (v << 4)) & UINT64_C(0x0f0f0f0f0f0f0f0f);
    v = (v | (v << 2)) & UINT64_C(0x3333333333333333);
    return (v | (v << 1)) & UINT64_C(0x5555555555555555);
}
std::uint32_t compact(std::uint64_t v) {
    v &= UINT64_C(0x5555555555555555);
    v = (v | (v >> 1)) & UINT64_C(0x3333333333333333);
    v = (v | (v >> 2)) & UINT64_C(0x0f0f0f0f0f0f0f0f);
    v = (v | (v >> 4)) & UINT64_C(0x00ff00ff00ff00ff);
    v = (v | (v >> 8)) & UINT64_C(0x0000ffff0000ffff);
    return static_cast<std::uint32_t>(v | (v >> 16));
}
}
std::uint64_t sfc_encode(std::uint32_t x, std::uint32_t y, Sfc s) {
    const auto a = std::uint64_t(x), b = std::uint64_t(y);
    switch (s) {
    case Sfc::ZOrder: return spread(a) | (spread(b) << 1); // X even, Fig.8
    case Sfc::COrder: return (a << 32) | b;
    case Sfc::Numerical:
        return ((a >> 31) << 63) | ((b >> 31) << 62)
             | (((a >> 23) & 255) << 54) | (((b >> 23) & 255) << 46)
             | ((a & 0x7fffff) << 23) | (b & 0x7fffff);
    }
    throw std::invalid_argument("unknown SFC");
}
std::pair<std::uint32_t, std::uint32_t> sfc_decode(std::uint64_t c, Sfc s) {
    switch (s) {
    case Sfc::ZOrder: return {compact(c), compact(c >> 1)};
    case Sfc::COrder: return {std::uint32_t(c >> 32), std::uint32_t(c)};
    case Sfc::Numerical: // E1: corrected signs in Algorithm 2
        return {std::uint32_t(((c >> 63) << 31) | (((c >> 54) & 255) << 23) | ((c >> 23) & 0x7fffff)),
                std::uint32_t((((c >> 62) & 1) << 31) | (((c >> 46) & 255) << 23) | (c & 0x7fffff))};
    }
    throw std::invalid_argument("unknown SFC");
}
}
