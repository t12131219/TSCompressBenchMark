#include "frame.h"
#include "varint.h"
namespace actsd {
Bytes build_frame(const std::vector<Bytes>& containers, std::size_t n, Sfc sfc, const Bytes* ts) {
    if (unsigned(sfc) > 2) throw std::invalid_argument("unknown SFC");
    Bytes out{'A', 'C', 'T', 'S', 1, static_cast<std::uint8_t>(sfc), static_cast<std::uint8_t>(ts != nullptr), 0};
    tsbits::put_le(out, n, 8); tsbits::put_le(out, containers.size(), 8);
    std::size_t total = 0;
    for (const auto& c : containers) {
        total += parse_container(c.data(), c.size(), n - total).count;
        tsbits::put_le(out, c.size(), 8); out.insert(out.end(), c.begin(), c.end());
    }
    if (total != n) throw std::invalid_argument("frame record count mismatch");
    if (ts) { tsbits::put_le(out, ts->size(), 8); out.insert(out.end(), ts->begin(), ts->end()); }
    tsbits::put_le(out, tsbits::crc32(out.data(), out.size()), 4); return out;
}
FrameView parse_frame(const std::uint8_t* p, std::size_t bytes, std::size_t max_records) {
    require(p && bytes >= 28, ErrorCode::Truncated, "frame shorter than 28 bytes");
    require(tsbits::crc32(p, bytes - 4) == tsbits::get_le(p + bytes - 4, 4), ErrorCode::Crc, "CRC-32 mismatch");
    Reader r(p, bytes - 4);
    require(r.le(4) == UINT64_C(0x53544341), ErrorCode::Header, "bad ACTS magic");
    require(r.le(1) == 1, ErrorCode::Header, "unsupported frame version");
    const auto sfc = r.le(1), flags = r.le(1), reserved = r.le(1);
    require(sfc <= 2 && flags <= 1 && reserved == 0, ErrorCode::Header, "invalid SFC, flags or reserved byte");
    FrameView f;
    f.sfc = static_cast<Sfc>(sfc); f.has_timestamps = flags != 0;
    f.records = checked_size(r.le(), max_records); // before any record allocation
    const auto m = r.le();
    require(m <= f.records && m <= r.remaining() / 50 && ((f.records == 0) == (m == 0)), ErrorCode::Count, "invalid container count");
    std::size_t count = 0;
    for (std::uint64_t i = 0; i < m; ++i) {
        const auto len64 = r.le();
        const auto len = checked_size(len64, r.remaining());
        f.containers.push_back(parse_container(r.take(len), len, f.records - count));
        count += f.containers.back().count;
    }
    require(count == f.records, ErrorCode::Count, "frame record count mismatch");
    if (f.has_timestamps) {
        const auto len = r.le();
        f.timestamp_bytes = checked_size(len, r.remaining()); f.timestamps = r.take(f.timestamp_bytes);
    }
    r.end(); return f;
}
}
