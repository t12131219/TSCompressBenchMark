#pragma once

// ACTSD, Information Sciences 754 (2026) 123710.
// Normative mapping: docs/actsd/paper_mapping.md v1.1, including E1--E18.
#include <array>
#include <cstddef>
#include <cstdint>
#include <utility>
#include <vector>

namespace actsd {
using Bytes = std::vector<std::uint8_t>;
enum class Sfc : std::uint8_t { ZOrder = 0, COrder = 1, Numerical = 2 };
enum class SegRule : std::uint8_t { FrontOverlapBelowPhi = 0, HammingAbovePhi = 1 };
enum class Profile : std::uint8_t { Paper = 0, Author2023 = 1 };
enum class SegType : std::uint8_t { DeltaConst = 2, Const = 3, DeltaZstd = 4, Rle = 7, Zstd = 8 };
struct Params {
    Sfc sfc = Sfc::ZOrder;
    SegRule rule = SegRule::FrontOverlapBelowPhi;
    Profile profile = Profile::Paper;
    int phi = -1, theta = -1;
    std::size_t sample_size = 1000; // E10: prefix sample; 0 = all
    std::size_t block_rows = 8192;  // E18: 0 = all
    bool segmentation = true, seg_fallback = true;
};
struct EncodeStats {
    int phi = 10, theta = 10;
    std::size_t containers = 0, segments = 0;
    std::array<std::size_t, 9> type_hits{};
    std::size_t container_bytes = 0, timestamp_bytes = 0, file_bytes = 0;
    std::size_t overhead_paper = 0, overhead_impl = 0;
};
struct Decoded {
    std::vector<std::uint32_t> x_bits, y_bits;
    std::vector<std::int64_t> timestamps;
    bool has_timestamps = false;
    Sfc sfc = Sfc::ZOrder;
};
void validate(const Params& p);
Bytes encode(const std::uint32_t* x, const std::uint32_t* y, const std::int64_t* ts,
             std::size_t n, const Params& p = {}, EncodeStats* stats = nullptr);
Bytes encode(const float* x, const float* y, const std::int64_t* ts,
             std::size_t n, const Params& p = {}, EncodeStats* stats = nullptr);
Decoded decode(const std::uint8_t* data, std::size_t size,
               std::size_t max_records = std::size_t(1) << 32);
} // namespace actsd
