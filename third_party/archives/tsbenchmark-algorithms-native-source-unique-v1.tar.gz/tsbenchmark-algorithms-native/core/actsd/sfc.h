#pragma once
#include "actsd.h"
namespace actsd {
std::uint64_t sfc_encode(std::uint32_t x, std::uint32_t y, Sfc sfc);
std::pair<std::uint32_t, std::uint32_t> sfc_decode(std::uint64_t code, Sfc sfc);
}
