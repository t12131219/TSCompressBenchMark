#pragma once
#include "actsd.h"
namespace actsd {
Bytes encode_timestamps(const std::int64_t* ts, std::size_t n);
std::vector<std::int64_t> decode_timestamps(const std::uint8_t* p, std::size_t bytes, std::size_t n);
}
