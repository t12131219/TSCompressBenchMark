#pragma once

// Bit-level helpers shared by the compression modules of this project.
//
// The bit stream layout (most-significant bit first, zero padding in the final
// byte) is the one already used by the accepted Kangaroo module
// (algorithms/kangaroo/src/bit_stream.h).  Kangaroo keeps its own copy for now
// so that its frozen byte format and tests are untouched; new modules use this
// header, and the two can be unified once Kangaroo's format is re-validated.

#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <limits>
#include <stdexcept>
#include <vector>

namespace tsbits {

// Writes the low `width` bits of `value`, most-significant bit first.
// Bits beyond `width` in the last byte stay zero.
class BitWriter {
public:
    void write(std::uint64_t value, unsigned width) {
        if (width > 64) {
            throw std::runtime_error("bit write width exceeds 64");
        }
        if (bit_size_ > std::numeric_limits<std::size_t>::max() - width) {
            throw std::length_error("bit stream length overflow");
        }
        unsigned remaining = width;
        while (remaining != 0) {
            const unsigned occupied = static_cast<unsigned>(bit_size_ % 8);
            if (occupied == 0) {
                bytes_.push_back(0);
            }
            const unsigned take = std::min(8U - occupied, remaining);
            const auto chunk = static_cast<std::uint8_t>(
                (value >> (remaining - take)) & ((UINT64_C(1) << take) - 1));
            bytes_.back() |= static_cast<std::uint8_t>(chunk << (8 - occupied - take));
            bit_size_ += take;
            remaining -= take;
        }
    }

    std::size_t bit_size() const noexcept { return bit_size_; }
    const std::vector<std::uint8_t>& bytes() const noexcept { return bytes_; }
    std::vector<std::uint8_t> take_bytes() { return std::move(bytes_); }

private:
    std::vector<std::uint8_t> bytes_;
    std::size_t bit_size_ = 0;
};

class BitReader {
public:
    BitReader(const std::uint8_t* data, std::size_t byte_size, std::size_t valid_bits)
        : data_(data), valid_bits_(valid_bits) {
        if (data == nullptr && byte_size != 0) {
            throw std::invalid_argument("null bit stream buffer");
        }
        const std::size_t required_bytes = valid_bits / 8 + (valid_bits % 8 != 0);
        if (required_bytes > byte_size) {
            throw std::invalid_argument("valid bits exceed bit stream buffer");
        }
    }

    std::uint64_t read(unsigned width) {
        if (width > 64) {
            throw std::runtime_error("bit read width exceeds 64");
        }
        if (width > remaining()) {
            throw std::runtime_error("truncated bit stream");
        }
        std::uint64_t value = 0;
        unsigned needed = width;
        while (needed != 0) {
            const unsigned offset = static_cast<unsigned>(position_ % 8);
            const unsigned take = std::min(8U - offset, needed);
            const unsigned chunk =
                (data_[position_ / 8] >> (8 - offset - take)) & ((1U << take) - 1);
            value = (value << take) | chunk;
            position_ += take;
            needed -= take;
        }
        return value;
    }

    std::size_t remaining() const noexcept { return valid_bits_ - position_; }
    std::size_t position() const noexcept { return position_; }

private:
    const std::uint8_t* data_;
    std::size_t valid_bits_;
    std::size_t position_ = 0;
};

// CRC-32/IEEE (0xedb88320, initial value and final xor 0xffffffff).
inline std::uint32_t crc32(const std::uint8_t* data, std::size_t length) {
    static const auto table = [] {
        std::vector<std::uint32_t> values(256);
        for (std::uint32_t i = 0; i < 256; ++i) {
            auto c = i;
            for (unsigned j = 0; j < 8; ++j) {
                c = (c >> 1) ^ ((c & 1) ? UINT32_C(0xedb88320) : 0);
            }
            values[i] = c;
        }
        return values;
    }();
    std::uint32_t state = UINT32_C(0xffffffff);
    for (std::size_t i = 0; i < length; ++i) {
        state = table[(state ^ data[i]) & 255] ^ (state >> 8);
    }
    return state ^ UINT32_C(0xffffffff);
}

inline void put_le(std::vector<std::uint8_t>& out, std::uint64_t value, unsigned bytes) {
    for (unsigned i = 0; i < bytes; ++i) {
        out.push_back(static_cast<std::uint8_t>(value >> (8 * i)));
    }
}

inline std::uint64_t get_le(const std::uint8_t* data, unsigned bytes) {
    std::uint64_t value = 0;
    for (unsigned i = 0; i < bytes; ++i) {
        value |= static_cast<std::uint64_t>(data[i]) << (8 * i);
    }
    return value;
}

// Number of bits needed to hold every value in [0, max_value].
inline unsigned bits_for(std::uint64_t max_value) {
    unsigned width = 0;
    while (max_value != 0) {
        ++width;
        max_value >>= 1;
    }
    return width;
}

}  // namespace tsbits
