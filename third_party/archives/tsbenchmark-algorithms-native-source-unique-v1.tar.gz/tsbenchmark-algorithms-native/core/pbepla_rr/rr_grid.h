#pragma once

// Resolution-reduced value grid (PBEPLA-RR paper, Equation (3) and Section 2.2).
//
// The whole possible value range [gmin, gmax] is split into 2^r blocks; only
// block centres may be used as line-segment endpoints, and an endpoint is
// stored as its r-bit block index.

#include <cstddef>
#include <cstdint>
#include <vector>
#include <optional>
#include <utility>

namespace pbepla_rr {

// One-sided residual band of the progressive decomposition: the approximation
// at tick t must satisfy z(t) - lower <= f(t) <= z(t) + upper.
// Progressive layers use (lower, upper) = (2*eps, 0); the symmetric BEPLA of
// the 2019 paper uses (eps, eps).
struct SidedBand {
    double lower = 0.0;
    double upper = 0.0;

    // Value the encoder aims for when it has a free choice.  For the
    // one-sided band this is z - lower + width/2 = z - eps, i.e. exactly the
    // centre of the symmetric band of half-width eps, which keeps the choice
    // identical to the "coded data point nearest to the original data" rule of
    // the 2019 paper.
    double center_offset() const noexcept { return (upper - lower) * 0.5; }
};

class RrGrid {
public:
    RrGrid() = default;
    RrGrid(double gmin, double gmax, unsigned resolution);

    double min() const noexcept { return gmin_; }
    double max() const noexcept { return gmax_; }
    unsigned resolution() const noexcept { return resolution_; }
    std::uint64_t block_count() const noexcept { return block_count_; }
    double block_width() const noexcept { return width_; }

    double center(std::uint64_t index) const;  // requires index < block_count
    bool is_valid_index(std::uint64_t index) const noexcept {
        return index < block_count_;
    }

    // All block indices whose centre lies in [a, b], in increasing order.
    // The result is the exact set (verified against brute-force enumeration in
    // the tests), not an estimate.
    std::vector<std::uint64_t> centers_in(double a, double b) const;
    // Inclusive feasible index range, without allocating candidate arrays.
    std::optional<std::pair<std::uint64_t, std::uint64_t>> center_bounds(double a, double b) const;

    // Index of the centre closest to `value`, clamped to the grid.  Ties go to
    // the lower index.
    std::uint64_t nearest(double value) const;

    // Index of the centre inside [a, b] closest to `value` (which is expected
    // to lie inside [a, b]).  Throws std::runtime_error if no centre exists,
    // which also signals that the caller's resolution is too coarse.
    std::uint64_t nearest_in(double a, double b, double value) const;

    // Minimal resolution r such that block_width(r) <= band_width, i.e. the
    // integer form of r_min = ceil(-log2(eps/R) - 1) from Equation (3).
    static unsigned minimal_resolution(double range, double band_width);

private:
    double gmin_ = 0.0;
    double gmax_ = 0.0;
    unsigned resolution_ = 0;
    std::uint64_t block_count_ = 0;
    double width_ = 0.0;
};

}  // namespace pbepla_rr
