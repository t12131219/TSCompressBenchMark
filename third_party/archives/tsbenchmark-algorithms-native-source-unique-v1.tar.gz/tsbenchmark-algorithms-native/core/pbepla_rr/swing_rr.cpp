#include "swing_rr.h"
#include "swing_stream.h"

#include <algorithm>
#include <cmath>
#include <limits>
#include <stdexcept>
#include <string>

namespace pbepla_rr {
namespace {

void require(bool condition, const char* message) {
    if (!condition) {
        throw std::runtime_error(std::string("swing_rr: ") + message);
    }
}

// Bits used by the span field of one segment (engineering decision D6): a
// disconnected segment covers `span + 1` ticks with span in [0, delay], so the
// field holds span and needs ceil(log2(delay + 1)) bits; a connected segment
// covers `span + 1` ticks with span in [1, delay], so it stores span - 1 and
// needs ceil(log2(delay)) bits.
unsigned span_field_bits(std::uint64_t max_delay, SegmentMode mode) {
    const std::uint64_t max_written =
        mode == SegmentMode::Disconnected ? max_delay : max_delay - 1;
    unsigned bits = 0;
    while ((UINT64_C(1) << bits) <= max_written) {
        ++bits;
    }
    return bits;
}

std::vector<Segment> run(const double* values, std::size_t n, const RrGrid& grid,
                         const SwingParams& params, const double* per_tick_eps) {
    if (values == nullptr && n != 0) {
        throw std::invalid_argument("swing_rr: null input");
    }
    if (grid.block_count() == 0) throw std::invalid_argument("swing_rr: uninitialized grid");
    if (params.max_delay == 0 || params.max_delay > 65536) {
        throw std::invalid_argument("swing_rr: max_delay must be in [1, 65536]");
    }
    if (params.mode != SegmentMode::Connected && params.mode != SegmentMode::Disconnected) {
        throw std::invalid_argument("swing_rr: unknown segment mode");
    }
    if (!std::isfinite(params.target_offset)) {
        throw std::invalid_argument("swing_rr: target offset must be finite");
    }
    (void)span_field_bits(params.max_delay, params.mode);
    if (n == 0) {
        return {};
    }
    const double* eps = per_tick_eps;
    if (eps == nullptr) {
        if (!(params.band.lower >= 0.0) || !(params.band.upper >= 0.0)
            || !std::isfinite(params.band.width()) || !(params.band.width() > 0.0)) {
            throw std::invalid_argument("swing_rr: band must be finite and non-empty");
        }
    }
    for (std::size_t i = 0; i < n; ++i) {
        if (!std::isfinite(values[i]) || !std::isfinite(values[i] + params.target_offset)) {
            throw std::invalid_argument("swing_rr: input contains a non-finite value");
        }
        const double e = eps == nullptr ? params.band.width() * 0.5 : eps[i];
        if (!(e > 0.0) || !std::isfinite(e)) {
            throw std::invalid_argument("swing_rr: error bound must be positive and finite");
        }
    }
    std::vector<Segment> segments;
    SwingStream engine(grid, params.max_delay, params.mode,
                       [&](const Segment& segment) { segments.push_back(segment); });
    for (std::size_t i = 0; i < n; ++i) {
        engine.push(values[i] + params.target_offset,
                    eps == nullptr ? params.band.width() * 0.5 : eps[i]);
    }
    engine.finish();
    return segments;
}

// The support lines are maintained in value space; reconstructing an interior
// point rounds the same quantity differently, so the exact re-check allows a
// relative slack of kIntervalSlack.  The publicly declared bound is enforced
// afterwards on the real decoded output (the encoder shrinks eps until the
// exact, unpadded check passes).  Without the slack the re-check would reject
// valid segmentations for a few ulps.
constexpr double kIntervalSlack = 1e-9;

double worst_violation(const double* values, const RrGrid& grid,
                       const std::vector<Segment>& segments, const double* eps,
                       double uniform_eps, double target_offset) {
    double worst = -std::numeric_limits<double>::infinity();
    for (const auto& segment : segments) {
        for (std::size_t tick = segment.start; tick <= segment.stop; ++tick) {
            const double approximated = reconstruct_point(segment, grid, tick);
            const double e = eps == nullptr ? uniform_eps : eps[tick];
            const double slack = e * kIntervalSlack;
            const double target = values[tick] + target_offset;
            worst = std::max(worst, approximated - (target + e + slack));
            worst = std::max(worst, (target - e - slack) - approximated);
        }
    }
    return worst;
}

}  // namespace

std::vector<Segment> swing_rr(const double* values, std::size_t n, const RrGrid& grid,
                              const SwingParams& params, SwingStats* stats,
                              const double* per_tick_eps) {
    SwingParams normalized = params;
    if (per_tick_eps == nullptr) {
        if (!(params.band.lower >= 0.0) || !(params.band.upper >= 0.0) ||
            !std::isfinite(params.band.width()) || !(params.band.width() > 0.0)) {
            throw std::invalid_argument("swing_rr: band must be finite and non-empty");
        }
        normalized.target_offset += (params.band.upper - params.band.lower) * 0.5;
        normalized.band = Band::symmetric(params.band.width() * 0.5);
    }
    auto segments = run(values, n, grid, normalized, per_tick_eps);
    const double* eps = per_tick_eps;
    if (n != 0) {
        require(worst_violation(values, grid, segments, eps, normalized.band.width() * 0.5,
                                normalized.target_offset) <= 0.0,
                "segmentation violates the band");
    }
    require(validate_segmentation(segments, n, grid, params.mode), "segmentation is not a cover");
    if (stats != nullptr) {
        stats->segments = segments.size();
        stats->max_span = 0;
        stats->effective_eps = 0.0;
        for (const auto& segment : segments) {
            stats->max_span = std::max(stats->max_span, segment.span());
        }
        if (n != 0) {
            stats->effective_eps = eps == nullptr ? normalized.band.width() * 0.5
                                                 : *std::min_element(eps, eps + n);
        }
    }
    return segments;
}

std::vector<Segment> swing_rr_with_shrink(const double* values, std::size_t n,
                                          const RrGrid& grid, SwingParams params,
                                          Band* effective, SwingStats* stats,
                                          const double* per_tick_eps) {
    if (n == 0) {
        auto result = swing_rr(values, n, grid, params, stats, per_tick_eps);
        if (effective != nullptr) *effective = params.band;
        return result;
    }
    const Band original_band = params.band;
    const double base = per_tick_eps == nullptr ? params.band.width() * 0.5
                                                : *std::max_element(per_tick_eps, per_tick_eps + n);
    std::vector<double> scaled;
    double scale = 1.0;
    for (int attempt = 0; attempt < 40; ++attempt) {
        const double* feed = nullptr;
        params.band = Band{original_band.lower * scale, original_band.upper * scale};
        if (per_tick_eps != nullptr) {
            scaled.resize(n);
            for (std::size_t i = 0; i < n; ++i) {
                scaled[i] = per_tick_eps[i] * scale;
            }
            feed = scaled.data();
        }
        try {
            auto segments = swing_rr(values, n, grid, params, stats, feed);
            if (effective != nullptr) {
                *effective = per_tick_eps == nullptr ? params.band : Band::symmetric(base * scale);
            }
            return segments;
        } catch (const std::runtime_error&) {
            if (n <= 1) {
                throw;
            }
            scale *= 1.0 - 1e-3;
        }
    }
    throw std::runtime_error("swing_rr: no feasible band even after shrinking");
}

double segment_violation(const double* values, std::size_t n, const RrGrid& grid,
                         const Segment& segment, const Band& band) {
    if (segment.stop >= n || segment.start > segment.stop) {
        return std::numeric_limits<double>::infinity();
    }
    double worst = -std::numeric_limits<double>::infinity();
    for (std::size_t tick = segment.start; tick <= segment.stop; ++tick) {
        const double approximated = reconstruct_point(segment, grid, tick);
        worst = std::max(worst, approximated - (values[tick] + band.upper));
        worst = std::max(worst, (values[tick] - band.lower) - approximated);
    }
    return worst;
}

bool validate_segmentation(const std::vector<Segment>& segments, std::size_t n,
                           const RrGrid& grid, SegmentMode mode) {
    if (n == 0) {
        return segments.empty();
    }
    if (segments.empty()) {
        return false;
    }
    if (segments.front().start != 0 || segments.back().stop != n - 1) {
        return false;
    }
    for (std::size_t i = 0; i < segments.size(); ++i) {
        const Segment& segment = segments[i];
        if (segment.start > segment.stop) return false;
        if (segment.stop >= n) return false;
        if (!grid.is_valid_index(segment.start_index) || !grid.is_valid_index(segment.stop_index)) {
            return false;
        }
        if (i != 0) {
            const Segment& previous = segments[i - 1];
            if (mode == SegmentMode::Connected) {
                if (segment.start != previous.stop || segment.start_index != previous.stop_index) return false;
            } else if (segment.start != previous.stop + 1) {
                return false;
            }
        }
    }
    return true;
}

}  // namespace pbepla_rr
