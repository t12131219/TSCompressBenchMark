#include "segment.h"

namespace pbepla_rr {

double reconstruct_point(const Segment& segment, const RrGrid& grid, std::size_t tick) {
    const double y_start = grid.center(segment.start_index);
    if (tick <= segment.start) {
        return y_start;
    }
    if (tick >= segment.stop) {
        return grid.center(segment.stop_index);
    }
    const double y_stop = grid.center(segment.stop_index);
    const double span = static_cast<double>(segment.span());
    const double distance = static_cast<double>(tick - segment.start);
    return y_start + distance * (y_stop - y_start) / span;
}

}  // namespace pbepla_rr
