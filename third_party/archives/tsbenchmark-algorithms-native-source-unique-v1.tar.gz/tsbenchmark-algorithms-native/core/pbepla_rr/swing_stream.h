#pragma once
#include <functional>
#include "swing_rr.h"

namespace pbepla_rr {
// Incremental Swing-RR core: constant state, synchronous segment emission.
// Input is the already-normalized target and its positive half-width.
// A callback failure invalidates this instance; discard it before retrying.
class SwingStream {
public:
    using Emit = std::function<void(const Segment&)>;
    SwingStream(const RrGrid& grid, std::uint64_t delay, SegmentMode mode, Emit emit);
    void push(double target, double epsilon);
    void finish();
private:
    void open(std::size_t tick, double target, double epsilon);
    void extend(std::size_t tick, double target, double epsilon);
    void close(std::size_t tick, double target, double epsilon);
    RrGrid grid_;
    std::uint64_t delay_;
    SegmentMode mode_;
    Emit emit_;
    Segment latest_{};
    std::size_t count_ = 0;
    bool opened_ = false, finished_ = false, boundary_ = false;
    double lower_ = 0, upper_ = 0;
};
}
