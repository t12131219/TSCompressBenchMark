/**
 * @file pbepla_rr.h
 * @brief PBEPLA-RR: Progressive Bounded Error Piecewise Linear Approximation
 *        with Resolution Reduction (Sensors 2025, 25, 145).
 *
 * A series is approximated by k layers.  Layer 1 approximates the input,
 * layer i approximates the residual of layer i-1, and the reconstruction of
 * version m is  Y_m = sum_{i<=m} f_i + eps_m  with
 *
 *     max_t |y(t) - Y_m(t)| <= eps_m.
 *
 * This module is lossy: correctness means the bound above, verified after a
 * real serialise/decode round trip.
 *
 * Container "PBEP" v1 is this implementation's own format (the paper defines
 * the payload fields but no byte layout); it is not claimed to be compatible
 * with the authors' code.  See docs/pbepla_rr/paper_mapping.md.
 */

#ifndef PBEPLA_RR_H
#define PBEPLA_RR_H

#include <cstddef>
#include <cstdint>
#include <functional>
#include <iosfwd>
#include <optional>
#include <vector>

#include "segment.h"

namespace pbepla_rr {

enum class SegmentMode : std::uint8_t {
    Connected = 0,
    Disconnected = 1,
};

struct EncodeParams {
    // Absolute error bounds, strictly decreasing and positive.  Layer i uses
    // at most error_bounds[i]; headers and stats record effective bounds.
    std::vector<double> error_bounds;
    // Per-layer resolutions, or empty for the minimal resolution of each
    // layer's grid and band (paper Equation (3)).
    std::vector<unsigned> resolutions;
    // Value range of the data source.  Empty means the min/max of `y`.
    std::optional<double> source_min;
    std::optional<double> source_max;
    std::uint64_t max_delay = 64;
    SegmentMode mode = SegmentMode::Disconnected;
    // Symmetric band [y - eps, y + eps] without the progressive offset,
    // i.e. the independent Swing-RR baseline of the 2019 paper.
    bool symmetric_band = false;
};

struct LayerStats {
    std::size_t segments = 0;
    std::uint64_t payload_bits = 0;
    unsigned resolution = 0;
    double grid_min = 0.0;
    double grid_max = 0.0;
};

struct EncodeStats {
    std::vector<LayerStats> layers;
    std::size_t header_bytes = 0;
    std::size_t payload_bytes = 0;
    // Effective bounds after numerical retries (0.999 per retry, at most 40
    // attempts per layer), also kept strictly below the preceding bound.
    std::vector<double> effective_eps;
};

struct DecodeLimits {
    std::size_t max_values = 16000000;
};

struct ContainerInfo {
    unsigned version = 0;
    unsigned flags = 0;
    unsigned layer_count = 0;   // k
    unsigned layer_present = 0; // m stored in this file
    std::size_t value_count = 0;
    std::uint64_t max_delay = 0;
    double grid_min = 0.0;
    double grid_max = 0.0;
    std::vector<double> error_bounds;
    std::vector<unsigned> resolutions;
    std::vector<std::uint64_t> payload_bits;
    std::size_t header_bytes = 0;
    std::size_t payload_bytes = 0;
    bool symmetric_band = false;
    SegmentMode mode = SegmentMode::Disconnected;
};

// Encodes `n` finite values.  Throws std::invalid_argument for invalid
// parameters and std::runtime_error if the request cannot be satisfied.
std::vector<std::uint8_t> encode_progressive(const double* values, std::size_t n,
                                             const EncodeParams& params,
                                             EncodeStats* stats = nullptr);

// Single-layer independent Swing-RR baseline (symmetric band).
std::vector<std::uint8_t> encode_independent(const double* values, std::size_t n, double eps,
                                             const EncodeParams& params,
                                             EncodeStats* stats = nullptr);

// Rewindable finite source. next returns false only at EOF; rewind restarts
// the identical sequence. Callbacks must throw on input errors.
struct ReplaySource {
    std::function<void()> rewind;
    std::function<bool(double&)> next;
};
struct StreamStats {
    EncodeStats encoded;
    std::size_t value_count = 0;
    std::size_t buffer_slots = 0;
    std::size_t source_passes = 0;
    std::size_t numerical_retries = 0;
};
// O(k*(delay+2)) resident sample slots, O(k) segment/bit states. Payloads
// are staged in automatically removed temporary FILEs (external storage,
// O(payload bytes)). No input/output-sized RAM arrays. A normal run scans
// input three times: range discovery, pipelined encoding, serialized check.
// Numerical failure replays transactionally before any caller output is
// written. A sink I/O failure may leave partial output and is propagated.
void encode_progressive_stream(const ReplaySource& source, std::ostream& output,
                               const EncodeParams& params, StreamStats* stats = nullptr);

// Sequential callback decoding of an existing PBEP container. Input bytes
// belong to the caller; auxiliary state is O(layers), no output-sized array.
void decode_layers_stream(const std::uint8_t* data, std::size_t size, unsigned layers,
                          const std::function<void(double)>& emit,
                          const DecodeLimits& limits = {});

ContainerInfo inspect(const std::uint8_t* data, std::size_t size);

// Layer values are the sum of the first m layers plus eps_m (no eps for the
// symmetric baseline).
std::vector<double> decode_layers(const std::uint8_t* data, std::size_t size, unsigned layers,
                                  const DecodeLimits& limits = {});

struct Approximation {
    std::vector<double> values;
    unsigned layers_used = 0;
    bool bound_met = false;
};

// Paper Algorithm 2: smallest version whose bound meets `eps_star`.
Approximation approximate(const std::uint8_t* data, std::size_t size, double eps_star,
                          const DecodeLimits& limits = {});

// Container holding only the first `layers` layers, independently decodable.
std::vector<std::uint8_t> extract_prefix(const std::uint8_t* data, std::size_t size,
                                         unsigned layers);

// Segments of one stored layer, in decode order.  Exposed for the independent
// reference comparison in the experiments; the values are exactly what
// decode_layers() walks.
std::vector<Segment> layer_segments(const std::uint8_t* data, std::size_t size, unsigned layer);

// max_t |original[t] - approximated[t]| with both series of the same length.
double max_abs_error(const double* original, const double* approximated, std::size_t n);

}  // namespace pbepla_rr

#endif  // PBEPLA_RR_H
