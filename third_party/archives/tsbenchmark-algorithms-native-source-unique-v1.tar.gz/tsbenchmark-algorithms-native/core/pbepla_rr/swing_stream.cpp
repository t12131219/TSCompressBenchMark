#include "swing_stream.h"
#include <algorithm>
#include <cmath>
#include <limits>
#include <stdexcept>
#include <utility>

namespace pbepla_rr {
SwingStream::SwingStream(const RrGrid& grid, std::uint64_t delay, SegmentMode mode, Emit emit)
    : grid_(grid), delay_(delay), mode_(mode), emit_(std::move(emit)) {
    if (!grid.block_count() || delay == 0 || delay > 65536 || !emit_ ||
        (mode != SegmentMode::Connected && mode != SegmentMode::Disconnected))
        throw std::invalid_argument("swing_rr: invalid streaming parameters");
}
void SwingStream::open(std::size_t tick, double target, double epsilon) {
    if (mode_ == SegmentMode::Connected && opened_) {
        latest_ = Segment{latest_.stop, latest_.stop, latest_.stop_index, latest_.stop_index};
    } else {
        const auto index = grid_.nearest_in(target - epsilon, target + epsilon, target);
        latest_ = Segment{tick, tick, index, index};
    }
    opened_ = true;
    lower_ = -std::numeric_limits<double>::infinity();
    upper_ = std::numeric_limits<double>::infinity();
}
void SwingStream::close(std::size_t tick, double target, double epsilon) {
    if (mode_ == SegmentMode::Connected && latest_.span() == 0)
        throw std::runtime_error("swing_rr: no feasible connected segment");
    emit_(latest_);
    open(tick, target, epsilon);
    if (mode_ == SegmentMode::Connected) extend(tick, target, epsilon);
}
void SwingStream::extend(std::size_t tick, double target, double epsilon) {
    const double span = static_cast<double>(tick - latest_.start);
    const double start = grid_.center(latest_.start_index);
    const double upper = std::min(upper_, (target + epsilon - start) / span);
    const double lower = std::max(lower_, (target - epsilon - start) / span);
    if (lower > upper) { close(tick, target, epsilon); return; }
    upper_ = upper; lower_ = lower;
    const auto candidates = grid_.center_bounds(start + lower * span, start + upper * span);
    if (!candidates) { close(tick, target, epsilon); return; }
    latest_.stop = tick;
    latest_.stop_index = candidates->first + (candidates->second - candidates->first) / 2;
}
void SwingStream::push(double target, double epsilon) {
    if (finished_) throw std::logic_error("swing_rr: push after finish");
    if (!std::isfinite(target) || !std::isfinite(epsilon) || !(epsilon > 0))
        throw std::invalid_argument("swing_rr: nonfinite target or invalid epsilon");
    if (count_ == std::numeric_limits<std::size_t>::max())
        throw std::length_error("swing_rr: input length overflow");
    const std::size_t tick = count_++;
    if (!opened_) open(tick, target, epsilon);
    else if (boundary_) {
        boundary_ = false;
        open(tick, target, epsilon);
        if (mode_ == SegmentMode::Connected) extend(tick, target, epsilon);
    }
    else extend(tick, target, epsilon);
    // Algorithm 1 lines 22-24: emit on the tick reaching delay, not on
    // arrival of the next tick. This matters for real-time bounded latency.
    if (latest_.span() >= delay_) { emit_(latest_); boundary_ = true; }
}
void SwingStream::finish() {
    if (finished_) throw std::logic_error("swing_rr: duplicate finish");
    finished_ = true;
    if (opened_ && !boundary_) emit_(latest_);
}
}
