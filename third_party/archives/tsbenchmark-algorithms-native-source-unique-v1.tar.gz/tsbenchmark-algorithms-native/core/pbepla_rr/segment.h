#pragma once

// One line segment of a BEPLA with resolution reduction.
//
// Both endpoints are coded data points, i.e. block centres of the layer grid,
// and only their block indices are stored.  The encoder and the decoder call
// the same reconstruct_point(), so the float evaluation order is identical on
// both sides (paper Section 2.1, Equation (2)).

#include <cstddef>
#include <cstdint>

#include "rr_grid.h"

namespace pbepla_rr {

struct Segment {
    std::size_t start = 0;       // x of the first tick
    std::size_t stop = 0;        // x of the last tick, stop >= start
    std::uint64_t start_index = 0;  // block index of the start centre
    std::uint64_t stop_index = 0;   // block index of the stop centre

    std::size_t span() const noexcept { return stop - start; }
};

// f(t) for one segment, with both endpoints evaluated as the exact centre and
// interior points linear in the cross-multiplied form of Equation (2).
double reconstruct_point(const Segment& segment, const RrGrid& grid, std::size_t tick);

}  // namespace pbepla_rr
