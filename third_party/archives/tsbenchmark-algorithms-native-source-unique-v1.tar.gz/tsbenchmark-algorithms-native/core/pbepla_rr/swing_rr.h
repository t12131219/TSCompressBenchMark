#pragma once

// Swing-RR, the single-layer segmenter referenced by both papers.
//
// State machine (Lin, Liao, Leu, Energies 2019, Algorithm 1) adapted for the
// PBEPLA-RR progressive band:
//
//   * a window starts with one coded data point inside the first tick's band;
//   * the two support lines from that start point are narrowed by every new
//     point (Swing filter), and a tick is accepted as a stop candidate iff a
//     coded data point exists between the narrowed bounds at that tick;
//   * if no coded data point exists at the new tick, or the slope cone would
//     become empty, the window is closed at the previous stop candidate and
//     the triggering tick opens the next window (it is the window's second
//     point in connected mode);
//   * a window is also closed once it reaches the maximal delay.
//
// The 2019 paper generates disconnected BEPLA only.  Connected mode is the
// PBEPLA-RR modification: on close, the new window starts at the previous
// stop point and the triggering tick becomes its second point.

#include <cstddef>
#include <cstdint>
#include <vector>

#include "pbepla_rr.h"
#include "rr_grid.h"
#include "segment.h"

namespace pbepla_rr {

// Band around the target value z(t): f(t) must satisfy z - lower <= f <= z + upper.
struct Band {
    double lower = 0.0;
    double upper = 0.0;

    static Band symmetric(double eps) { return Band{eps, eps}; }
    static Band progressive(double eps) { return Band{2.0 * eps, 0.0}; }

    double width() const noexcept { return lower + upper; }
};

struct SwingParams {
    Band band;                      // expected band, used for the final check
    double target_offset = 0.0;     // target value is z + target_offset at every tick
    std::uint64_t max_delay = 64;
    SegmentMode mode = SegmentMode::Disconnected;
};

// Vertical offset from z to the centre of the band that a layer targets:
//  - e for a progressive layer, whose band is [z - 2e, z];
//  - 0 for the independent Swing-RR baseline, whose band is [z - e, z + e].
inline double progressive_offset(double eps) noexcept { return -eps; }

struct SwingStats {
    std::size_t segments = 0;
    std::size_t max_span = 0;
    double effective_eps = 0.0;  // smallest per-tick half-width actually used
};

// Segments covering [0, n) in order.  Throws std::invalid_argument on
// malformed parameters and std::runtime_error if the band and grid cannot
// produce a feasible segmentation (e.g. resolution below the minimal one).
//
// With per_tick_eps non-null the band at tick t is centered on
// values[t] + params.target_offset with half-width eps[t]; params.band is
// ignored. Progressive encoding uses the scalar band path.
std::vector<Segment> swing_rr(const double* values, std::size_t n, const RrGrid& grid,
                              const SwingParams& params, SwingStats* stats = nullptr,
                              const double* per_tick_eps = nullptr);

// Same, but a runtime geometry/check failure retries after multiplying band
// widths by 0.999 (up to 40 attempts). Invalid parameters are not retried.
// Returns the band actually used in *effective (when non-null). The segment
// check has the same relative slack as swing_rr; the codec validates the
// actual container for the strict public error bound.
std::vector<Segment> swing_rr_with_shrink(const double* values, std::size_t n,
                                          const RrGrid& grid, SwingParams params,
                                          Band* effective, SwingStats* stats = nullptr,
                                          const double* per_tick_eps = nullptr);

// Exact check of one segment against the band; returns the largest violation
// (negative when the segment is inside the band).
double segment_violation(const double* values, std::size_t n, const RrGrid& grid,
                         const Segment& segment, const Band& band);

// Checks the structural invariants of a segmentation of [0, n): ordered,
// non-overlapping, no gap, stop >= start, indices inside the grid.
bool validate_segmentation(const std::vector<Segment>& segments, std::size_t n,
                           const RrGrid& grid, SegmentMode mode);

}  // namespace pbepla_rr
