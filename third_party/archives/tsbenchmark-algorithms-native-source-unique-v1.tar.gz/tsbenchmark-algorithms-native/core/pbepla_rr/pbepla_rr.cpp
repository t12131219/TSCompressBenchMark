#include "pbepla_rr.h"

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <memory>
#include <ostream>
#include <limits>
#include <stdexcept>
#include <string>

#include "rr_grid.h"
#include "segment.h"
#include "swing_rr.h"
#include "swing_stream.h"
#include "tsbits.h"

namespace pbepla_rr {
namespace {

constexpr unsigned kMaxLayers = 16;
constexpr unsigned kContainerVersion = 1;
constexpr unsigned kMaxResolution = 30;
constexpr std::uint64_t kMaxDelay = 65536;
constexpr double kShrinkFactor = 1.0 - 1e-3;
constexpr int kMaxShrinkAttempts = 40;
constexpr unsigned kFlagDisconnected = 1U << 0;
constexpr unsigned kFlagSymmetric = 1U << 1;
constexpr unsigned kKnownFlags = kFlagDisconnected | kFlagSymmetric;

void validate_encoded_versions(const std::uint8_t* data, std::size_t size,
                               const double* original, std::size_t n);


[[noreturn]] void invalid(const std::string& message) {
    throw std::invalid_argument("pbepla_rr: " + message);
}
[[noreturn]] void corrupt(const std::string& message) {
    throw std::runtime_error("pbepla_rr: " + message);
}

// Header layout (engineering decision D8, see docs/pbepla_rr/paper_mapping.md):
//   0 magic "PBEP"     4 version     5 flags     6 k     7 m
//   8 n (u64)         16 delay (u32)
//  20 layer-1 grid min (f64)   28 layer-1 grid max (f64)
//  36 eps[1..k] (f64)           36+8k resolution[1..k] (u8)
//  36+9k payload bits[1..m] (u64)
//  36+9k+8m payload CRC32 (u32) 40+9k+8m header CRC32 (u32)
std::size_t header_size(std::size_t k, std::size_t m) { return 44 + 9 * k + 8 * m; }
constexpr std::size_t kFixedHeader = 36;

void put_double(std::vector<std::uint8_t>& out, double value) {
    std::uint64_t bits = 0;
    std::memcpy(&bits, &value, sizeof bits);
    tsbits::put_le(out, bits, 8);
}

double get_double(const std::uint8_t* data) {
    const std::uint64_t bits = tsbits::get_le(data, 8);
    double value = 0.0;
    std::memcpy(&value, &bits, sizeof value);
    return value;
}

unsigned span_field_bits(std::uint64_t delay, SegmentMode mode) {
    const std::uint64_t max_written = mode == SegmentMode::Disconnected ? delay : delay - 1;
    return tsbits::bits_for(max_written);
}

struct LayerGeometry {
    double grid_min = 0.0;
    double grid_max = 0.0;
    unsigned resolution = 0;
};

LayerGeometry layer_geometry(const std::vector<double>& eps, std::size_t index,
                             bool symmetric, double header_grid_min, double header_grid_max,
                             const std::vector<unsigned>& resolutions) {
    LayerGeometry geometry;
    if (symmetric || index == 0) {
        geometry.grid_min = header_grid_min;
        geometry.grid_max = header_grid_max;
    } else {
        geometry.grid_min = -2.0 * eps[index];
        geometry.grid_max = 2.0 * eps[index - 1];
    }
    const double band_width = 2.0 * eps[index];
    geometry.resolution = resolutions.empty() ? RrGrid::minimal_resolution(
                                                    geometry.grid_max - geometry.grid_min,
                                                    band_width)
                                              : resolutions[index];
    return geometry;
}

// Adds one layer's reconstruction to `out`.  Connected segments share their
// endpoint with the previous segment, so the shared tick must be counted once;
// disconnected segments own both endpoints.
void reconstruct_layer(const std::vector<Segment>& segments, const RrGrid& grid,
                       std::vector<double>& out, SegmentMode mode) {
    for (std::size_t i = 0; i < segments.size(); ++i) {
        const Segment& segment = segments[i];
        if (mode == SegmentMode::Disconnected || i == 0) {
            out[segment.start] += grid.center(segment.start_index);
        }
        for (std::size_t tick = segment.start + 1; tick <= segment.stop; ++tick) {
            out[tick] += reconstruct_point(segment, grid, tick);
        }
    }
}

void validate_encode_params(const double* values, std::size_t n, const EncodeParams& params) {
    if (values == nullptr && n != 0) invalid("null input");
    if (params.mode != SegmentMode::Connected && params.mode != SegmentMode::Disconnected) {
        invalid("unknown segment mode");
    }
    if (params.source_min.has_value() != params.source_max.has_value()) {
        invalid("source_min and source_max must be supplied together");
    }
    if (params.source_min && (!std::isfinite(*params.source_min) ||
        !std::isfinite(*params.source_max) || !(*params.source_min < *params.source_max))) {
        invalid("declared source range must be finite and strictly increasing");
    }
    if (params.error_bounds.empty()) invalid("at least one error bound is required");
    if (params.error_bounds.size() > kMaxLayers) invalid("at most 16 layers are supported");
    for (std::size_t i = 0; i < params.error_bounds.size(); ++i) {
        const double eps = params.error_bounds[i];
        if (!std::isfinite(2.0 * eps) || !(eps > 0.0)) {
            invalid("error bounds must be finite and positive");
        }
        if (i > 0 && !(params.error_bounds[i] < params.error_bounds[i - 1])) {
            invalid("error bounds must be strictly decreasing");
        }
    }
    if (params.symmetric_band && params.error_bounds.size() != 1) {
        invalid("the symmetric baseline uses exactly one error bound");
    }
    if (!params.resolutions.empty() && params.resolutions.size() != params.error_bounds.size()) {
        invalid("resolutions must be empty or match the number of error bounds");
    }
    for (unsigned resolution : params.resolutions) {
        if (resolution > kMaxResolution) invalid("resolution exceeds 30 bits");
    }
    if (params.max_delay == 0 || params.max_delay > kMaxDelay) {
        invalid("max_delay must be in [1, 65536]");
    }
    for (std::size_t i = 0; i < n; ++i) {
        if (!std::isfinite(values[i])) invalid("input contains a non-finite value");
    }
}

unsigned container_flags(const EncodeParams& params) {
    unsigned flags = params.mode == SegmentMode::Disconnected ? kFlagDisconnected : 0U;
    if (params.symmetric_band) flags |= kFlagSymmetric;
    return flags;
}

std::vector<std::uint8_t> build_empty(const EncodeParams& params, EncodeStats* stats) {
    const std::size_t k = params.error_bounds.size();
    std::vector<uint8_t> out;
    out.push_back('P');
    out.push_back('B');
    out.push_back('E');
    out.push_back('P');
    out.push_back(static_cast<uint8_t>(kContainerVersion));
    out.push_back(static_cast<uint8_t>(container_flags(params)));
    out.push_back(static_cast<uint8_t>(k));
    out.push_back(static_cast<uint8_t>(k));
    tsbits::put_le(out, 0, 8);
    tsbits::put_le(out, params.max_delay, 4);
    put_double(out, params.source_min.value_or(-1.0));
    put_double(out, params.source_max.value_or(1.0));
    for (double eps : params.error_bounds) put_double(out, eps);
    for (std::size_t i = 0; i < k; ++i) {
        const LayerGeometry geometry =
            layer_geometry(params.error_bounds, i, params.symmetric_band,
                           params.source_min.value_or(-1.0), params.source_max.value_or(1.0),
                           params.resolutions);
        out.push_back(static_cast<uint8_t>(geometry.resolution));
    }
    for (std::size_t i = 0; i < k; ++i) tsbits::put_le(out, 0, 8);
    tsbits::put_le(out, tsbits::crc32(nullptr, 0), 4);
    tsbits::put_le(out, tsbits::crc32(out.data(), out.size()), 4);
    if (stats != nullptr) {
        stats->layers.assign(k, LayerStats{});
        stats->header_bytes = out.size();
        stats->payload_bytes = 0;
        stats->effective_eps = params.error_bounds;
    }
    return out;
}

}  // namespace

std::vector<std::uint8_t> encode_progressive(const double* values, std::size_t n,
                                             const EncodeParams& params, EncodeStats* stats) {
    validate_encode_params(values, n, params);
    if (n == 0) return build_empty(params, stats);

    double source_min = params.source_min.value_or(*std::min_element(values, values + n));
    double source_max = params.source_max.value_or(*std::max_element(values, values + n));
    if (!std::isfinite(source_min) || !std::isfinite(source_max)) {
        invalid("source range must be finite");
    }
    if (!(source_min < source_max)) {
        // Constant series (engineering decision D9): open a tiny range so a
        // positive resolution exists; the caller sees the bounds it passed.
        const double half = std::max(std::fabs(source_min) * 1e-12, 1e-12);
        source_min -= half;
        source_max += half;
    }
    for (std::size_t i = 0; i < n; ++i) {
        if (values[i] < source_min || values[i] > source_max) {
            invalid("input values leave the declared source range");
        }
    }

    const std::size_t k = params.error_bounds.size();
    const SegmentMode mode = params.mode;
    std::vector<LayerGeometry> geometries(k);
    std::vector<std::vector<Segment>> segments(k);
    std::vector<double> effective(k, 0.0);
    // Copy with an explicit guard: assigning from (nullptr, nullptr) trips a
    // GCC 13 -Wnonnull false positive inside std::vector::_M_assign_aux.
    std::vector<double> residual;
    residual.reserve(n);
    for (std::size_t i = 0; i < n; ++i) residual.push_back(values[i]);
    std::vector<double> scratch(n, 0.0);
    std::vector<double> cumulative(n, 0.0);

    for (std::size_t index = 0; index < k; ++index) {
        bool encoded = false;
        double attempt_eps = params.error_bounds[index];
        if (index > 0) {
            attempt_eps = std::min(attempt_eps, std::nextafter(effective[index - 1], 0.0));
        }
        for (int attempt = 0; attempt < kMaxShrinkAttempts && !encoded; ++attempt) {
            if (!(attempt_eps > 0.0)) invalid("error bound underflows during numerical retry");
            std::vector<double> bounds = params.error_bounds;
            // Previously committed bounds are authoritative for every later grid.
            std::copy(effective.begin(), effective.begin() + index, bounds.begin());
            bounds[index] = attempt_eps;
            LayerGeometry geometry = layer_geometry(bounds, index, params.symmetric_band,
                                                    source_min - 2.0 * params.error_bounds[0],
                                                    source_max, params.resolutions);
            if (params.symmetric_band) {
                geometry = layer_geometry(bounds, index, true,
                                          source_min - params.error_bounds[0],
                                          source_max + params.error_bounds[0], params.resolutions);
            }
            const RrGrid grid(geometry.grid_min, geometry.grid_max, geometry.resolution);
            if (grid.block_width() > 2.0 * attempt_eps) {
                invalid("explicit resolution is below the minimum for this layer");
            }
            SwingParams swing;
            swing.band = Band::symmetric(attempt_eps);
            swing.target_offset = params.symmetric_band ? 0.0 : progressive_offset(attempt_eps);
            swing.max_delay = params.max_delay;
            swing.mode = mode;

            std::vector<Segment> candidate;
            try {
                candidate = swing_rr(residual.data(), n, grid, swing);
            } catch (const std::runtime_error&) {
                attempt_eps *= kShrinkFactor;
                continue;
            }
            std::fill(scratch.begin(), scratch.end(), 0.0);
            reconstruct_layer(candidate, grid, scratch, mode);
            // The layer must reproduce the residual within the one-sided band
            // [residual - 2e, residual] (symmetric baseline: [r - e, r + e]).
            // Converting to "decoded + eps" form: the value the previous layer
            // left is residual + d where 0 <= d <= 2e.
            bool inside = true;
            for (std::size_t tick = 0; tick < n && inside; ++tick) {
                if (params.symmetric_band) {
                    inside = scratch[tick] >= residual[tick] - attempt_eps &&
                             scratch[tick] <= residual[tick] + attempt_eps;
                } else {
                    inside = scratch[tick] <= residual[tick] &&
                             scratch[tick] >= residual[tick] - 2.0 * attempt_eps;
                }
                const double sum = cumulative[tick] + scratch[tick];
                const double decoded = sum + (params.symmetric_band ? 0.0 : attempt_eps);
                inside = inside && std::isfinite(decoded) &&
                         std::fabs(values[tick] - decoded) <= attempt_eps;
                if (!params.symmetric_band) {
                    const double remaining = values[tick] - sum;
                    inside = inside && remaining >= 0.0 && remaining <= 2.0 * attempt_eps;
                }
            }
            if (!inside) {
                attempt_eps *= kShrinkFactor;
                continue;
            }
            // Commit: subtract exactly what the decoder will add.
            for (std::size_t tick = 0; tick < n; ++tick) {
                cumulative[tick] += scratch[tick];
                residual[tick] = values[tick] - cumulative[tick];
            }
            geometries[index] = geometry;
            segments[index] = std::move(candidate);
            effective[index] = attempt_eps;
            encoded = true;
        }
        if (!encoded) {
            throw std::runtime_error("pbepla_rr: layer " + std::to_string(index + 1) +
                                     " could not be encoded within its bound");
        }
    }

    const unsigned length_bits = span_field_bits(params.max_delay, mode);
    std::vector<std::vector<std::uint8_t>> payloads(k);
    std::vector<std::uint64_t> payload_bits(k, 0);
    for (std::size_t index = 0; index < k; ++index) {
        tsbits::BitWriter writer;
        const unsigned index_bits = geometries[index].resolution;
        if (mode == SegmentMode::Connected) {
            // The first segment's start point is written once; a one-point
            // series has no span to follow it.
            writer.write(segments[index].front().start_index, index_bits);
            for (const auto& segment : segments[index]) {
                if (segment.span() == 0) {
                    // Single-tick series: the start index above is the only
                    // field (paper record shape needs no length for one tick).
                    continue;
                }
                writer.write(segment.span() - 1, length_bits);
                writer.write(segment.stop_index, index_bits);
            }
        } else {
            for (const auto& segment : segments[index]) {
                writer.write(segment.start_index, index_bits);
                writer.write(segment.span(), length_bits);
                writer.write(segment.stop_index, index_bits);
            }
        }
        payload_bits[index] = writer.bit_size();
        payloads[index] = writer.take_bytes();
    }

    std::vector<std::uint8_t> header;
    header.reserve(header_size(k, k));
    header.push_back('P');
    header.push_back('B');
    header.push_back('E');
    header.push_back('P');
    header.push_back(static_cast<std::uint8_t>(kContainerVersion));
    header.push_back(static_cast<std::uint8_t>(container_flags(params)));
    header.push_back(static_cast<std::uint8_t>(k));
    header.push_back(static_cast<std::uint8_t>(k));
    tsbits::put_le(header, n, 8);
    tsbits::put_le(header, params.max_delay, 4);
    put_double(header, geometries[0].grid_min);
    put_double(header, geometries[0].grid_max);
    for (double eps : effective) put_double(header, eps);
    for (const auto& geometry : geometries) {
        header.push_back(static_cast<std::uint8_t>(geometry.resolution));
    }
    for (std::uint64_t bits : payload_bits) tsbits::put_le(header, bits, 8);

    std::vector<std::uint8_t> payload;
    for (const auto& layer : payloads) payload.insert(payload.end(), layer.begin(), layer.end());
    tsbits::put_le(header, tsbits::crc32(payload.data(), payload.size()), 4);
    tsbits::put_le(header, tsbits::crc32(header.data(), header.size()), 4);

    std::vector<std::uint8_t> out = std::move(header);
    out.insert(out.end(), payload.begin(), payload.end());
    // Check the actual container through the decoder, not encoder geometries.
    // This walks all versions once (O(k*n)), including floating-point offsets.
    validate_encoded_versions(out.data(), out.size(), values, n);

    if (stats != nullptr) {
        stats->layers.clear();
        for (std::size_t index = 0; index < k; ++index) {
            LayerStats layer_stats;
            layer_stats.segments = segments[index].size();
            layer_stats.payload_bits = payload_bits[index];
            layer_stats.resolution = geometries[index].resolution;
            layer_stats.grid_min = geometries[index].grid_min;
            layer_stats.grid_max = geometries[index].grid_max;
            stats->layers.push_back(layer_stats);
        }
        stats->header_bytes = out.size() - payload.size();
        stats->payload_bytes = payload.size();
        stats->effective_eps = effective;
    }
    return out;
}

std::vector<std::uint8_t> encode_independent(const double* values, std::size_t n, double eps,
                                             const EncodeParams& params, EncodeStats* stats) {
    EncodeParams baseline = params;
    baseline.error_bounds = {eps};
    baseline.resolutions.clear();
    baseline.symmetric_band = true;
    return encode_progressive(values, n, baseline, stats);
}

double max_abs_error(const double* original, const double* approximated, std::size_t n) {
    double worst = 0.0;
    for (std::size_t i = 0; i < n; ++i) {
        worst = std::max(worst, std::fabs(original[i] - approximated[i]));
    }
    return worst;
}

// ---------------------------------------------------------------------------
// Decoding
// ---------------------------------------------------------------------------

namespace {

struct Parsed {
    ContainerInfo info;
    std::size_t payload_offset = 0;
};

Parsed parse_header(const std::uint8_t* data, std::size_t size, const DecodeLimits& limits) {
    if (data == nullptr) corrupt("null buffer");
    if (size < kFixedHeader) corrupt("stream shorter than the fixed header");
    if (std::memcmp(data, "PBEP", 4) != 0) corrupt("bad magic");
    Parsed parsed;
    ContainerInfo& info = parsed.info;
    info.version = data[4];
    info.flags = data[5];
    info.layer_count = data[6];
    info.layer_present = data[7];
    if (info.version != kContainerVersion) corrupt("unsupported container version");
    if ((info.flags & ~kKnownFlags) != 0) corrupt("reserved flag bits are not zero");
    if (info.layer_count == 0 || info.layer_count > kMaxLayers) corrupt("layer count out of range");
    if (info.layer_present == 0 || info.layer_present > info.layer_count) {
        corrupt("present layer count out of range");
    }
    const std::uint64_t count = tsbits::get_le(data + 8, 8);
    if (count > limits.max_values) corrupt("value count exceeds the decode limit");
    info.value_count = static_cast<std::size_t>(count);
    info.max_delay = tsbits::get_le(data + 16, 4);
    if (info.max_delay == 0 || info.max_delay > kMaxDelay) corrupt("max_delay out of range");
    info.grid_min = get_double(data + 20);
    info.grid_max = get_double(data + 28);
    if (!std::isfinite(info.grid_min) || !std::isfinite(info.grid_max) ||
        !(info.grid_min < info.grid_max)) {
        corrupt("layer-1 grid is not a finite increasing range");
    }
    info.mode = (info.flags & kFlagDisconnected) ? SegmentMode::Disconnected
                                                 : SegmentMode::Connected;
    info.symmetric_band = (info.flags & kFlagSymmetric) != 0;
    if (info.symmetric_band && info.layer_count != 1) corrupt("baseline must have one layer");

    const std::size_t k = info.layer_count;
    const std::size_t m = info.layer_present;
    if (size < header_size(k, m)) corrupt("stream shorter than its header");
    info.error_bounds.resize(k);
    info.resolutions.resize(k);
    info.payload_bits.resize(m);
    for (std::size_t i = 0; i < k; ++i) {
        const double eps = get_double(data + kFixedHeader + 8 * i);
        if (!std::isfinite(2.0 * eps) || !(eps > 0.0)) corrupt("error bound is not finite and positive");
        if (i > 0 && !(eps < info.error_bounds[i - 1])) {
            corrupt("error bounds are not strictly decreasing");
        }
        info.error_bounds[i] = eps;
    }
    for (std::size_t i = 0; i < k; ++i) {
        const unsigned resolution = data[kFixedHeader + 8 * k + i];
        if (resolution > kMaxResolution) corrupt("resolution out of range");
        info.resolutions[i] = resolution;
    }
    const std::size_t bits_offset = kFixedHeader + 9 * k;
    std::uint64_t total_bits = 0;
    for (std::size_t i = 0; i < m; ++i) {
        info.payload_bits[i] = tsbits::get_le(data + bits_offset + 8 * i, 8);
        if (info.payload_bits[i] > (UINT64_C(1) << 40)) corrupt("layer bit count is implausible");
        total_bits += info.payload_bits[i] / 8 + (info.payload_bits[i] % 8 != 0);
    }
    info.header_bytes = header_size(k, m);
    parsed.payload_offset = info.header_bytes;
    if (size < info.header_bytes) corrupt("stream shorter than its header");
    const std::uint32_t stored_header_crc = static_cast<std::uint32_t>(
        tsbits::get_le(data + info.header_bytes - 4, 4));
    if (tsbits::crc32(data, info.header_bytes - 4) != stored_header_crc) {
        corrupt("header checksum mismatch");
    }
    if (size - info.header_bytes != total_bits) corrupt("payload length does not match the header");
    info.payload_bytes = static_cast<std::size_t>(total_bits);
    const std::uint32_t stored_payload_crc = static_cast<std::uint32_t>(
        tsbits::get_le(data + info.header_bytes - 8, 4));
    if (tsbits::crc32(data + info.header_bytes, info.payload_bytes) != stored_payload_crc) {
        corrupt("payload checksum mismatch");
    }
    return parsed;
}

std::uint64_t geometry_index_count(const LayerGeometry& geometry) {
    return UINT64_C(1) << geometry.resolution;
}

// Decodes the segments of one layer from its byte-aligned payload slice.
std::vector<Segment> decode_segments(const std::uint8_t* payload, std::size_t payload_bytes,
                                     std::uint64_t valid_bits, const ContainerInfo& info,
                                     std::size_t layer_index) {
    const LayerGeometry geometry = layer_geometry(info.error_bounds, layer_index,
                                                  info.symmetric_band, info.grid_min,
                                                  info.grid_max, info.resolutions);
    if (valid_bits % 8 != 0) {
        if (payload_bytes == 0) corrupt("bit count does not fit its payload");
        const std::uint8_t last = payload[payload_bytes - 1];
        const unsigned padding = static_cast<unsigned>(8 - valid_bits % 8);
        if ((last & ((1U << padding) - 1)) != 0) corrupt("non-zero padding bits in a layer");
    }
    tsbits::BitReader reader(payload, payload_bytes, static_cast<std::size_t>(valid_bits));
    const unsigned index_bits = geometry.resolution;
    const unsigned length_bits = span_field_bits(info.max_delay, info.mode);
    const std::size_t n = info.value_count;

    std::vector<Segment> segments;
    if (n == 0) {
        if (valid_bits != 0) corrupt("layer payload present for an empty series");
        return segments;
    }
    if (info.mode == SegmentMode::Connected) {
        std::uint64_t index = reader.read(index_bits);
        if (index >= geometry_index_count(geometry)) corrupt("start index out of range");
        std::size_t position = 0;
        if (n == 1) {
            // A one-tick series is a single one-point segment whose value is
            // the start index written above.
            segments.push_back(Segment{0, 0, index, index});
        }
        while (position + 1 < n) {
            const std::uint64_t written = reader.read(length_bits);
            const std::uint64_t stop_index = reader.read(index_bits);
            if (stop_index >= geometry_index_count(geometry)) corrupt("stop index out of range");
            const std::size_t span = static_cast<std::size_t>(written + 1);
            if (span > info.max_delay) corrupt("connected span exceeds the maximal delay");
            if (span > n - 1 - position) corrupt("connected span overruns the series");
            segments.push_back(Segment{position, position + span, index, stop_index});
            position += span;
            index = stop_index;
        }
    } else {
        std::size_t position = 0;
        while (position < n) {
            const std::uint64_t start_index = reader.read(index_bits);
            const std::uint64_t written = reader.read(length_bits);
            const std::uint64_t stop_index = reader.read(index_bits);
            if (start_index >= geometry_index_count(geometry) ||
                stop_index >= geometry_index_count(geometry)) {
                corrupt("segment index out of range");
            }
            const std::size_t span = static_cast<std::size_t>(written);
            if (span > info.max_delay) corrupt("disconnected span exceeds the maximal delay");
            if (span > n - 1 - position) corrupt("disconnected span overruns the series");
            segments.push_back(Segment{position, position + span, start_index, stop_index});
            position += span + 1;
        }
    }
    if (reader.remaining() != 0) corrupt("layer payload has unused bits");
    return segments;
}

}  // namespace


// ---------------------------------------------------------------------------
// Public decoding API
// ---------------------------------------------------------------------------

namespace {

// Layer slice offsets: layers are byte aligned in order.
std::vector<std::size_t> payload_offsets(const ContainerInfo& info) {
    std::vector<std::size_t> offsets(info.payload_bits.size() + 1, 0);
    for (std::size_t i = 0; i < info.payload_bits.size(); ++i) {
        offsets[i + 1] = offsets[i] + static_cast<std::size_t>(info.payload_bits[i] / 8 +
                                                               (info.payload_bits[i] % 8 != 0));
    }
    return offsets;
}

void validate_encoded_versions(const std::uint8_t* data, std::size_t size,
                               const double* original, std::size_t n) {
    const Parsed parsed = parse_header(data, size, DecodeLimits{n});
    const ContainerInfo& info = parsed.info;
    if (info.value_count != n) corrupt("encoded value count mismatch");
    const auto offsets = payload_offsets(info);
    std::vector<double> cumulative(n, 0.0);
    for (unsigned i = 0; i < info.layer_present; ++i) {
        const auto geometry = layer_geometry(info.error_bounds, i, info.symmetric_band,
                                             info.grid_min, info.grid_max, info.resolutions);
        const RrGrid grid(geometry.grid_min, geometry.grid_max, geometry.resolution);
        const auto segments = decode_segments(data + parsed.payload_offset + offsets[i],
            offsets[i + 1] - offsets[i], info.payload_bits[i], info, i);
        reconstruct_layer(segments, grid, cumulative, info.mode);
        const double offset = info.symmetric_band ? 0.0 : info.error_bounds[i];
        for (std::size_t t = 0; t < n; ++t) {
            const double decoded = cumulative[t] + offset;
            if (!std::isfinite(decoded) || std::fabs(original[t] - decoded) > info.error_bounds[i]) {
                throw std::runtime_error("pbepla_rr: serialized version " +
                    std::to_string(i + 1) + " exceeds its error bound");
            }
        }
    }
}

std::vector<double> decode_impl(const std::uint8_t* data, std::size_t size, unsigned layers,
                                const DecodeLimits& limits, ContainerInfo* info_out) {
    const Parsed parsed = parse_header(data, size, limits);
    const ContainerInfo& info = parsed.info;
    if (layers == 0 || layers > info.layer_present) {
        throw std::invalid_argument("pbepla_rr: requested layers exceed the stored layers");
    }
    std::vector<double> result(info.value_count, 0.0);
    const auto offsets = payload_offsets(info);
    for (unsigned i = 0; i < layers; ++i) {
        const LayerGeometry geometry = layer_geometry(info.error_bounds, i, info.symmetric_band,
                                                      info.grid_min, info.grid_max,
                                                      info.resolutions);
        const RrGrid grid(geometry.grid_min, geometry.grid_max, geometry.resolution);
        const auto segments = decode_segments(data + parsed.payload_offset + offsets[i],
                                              offsets[i + 1] - offsets[i], info.payload_bits[i],
                                              info, i);
        reconstruct_layer(segments, grid, result, info.mode);
    }
    const double offset = info.symmetric_band ? 0.0 : info.error_bounds[layers - 1];
    if (offset != 0.0) {
        for (double& value : result) value += offset;
    }
    if (info_out != nullptr) *info_out = info;
    return result;
}

}  // namespace

std::vector<Segment> layer_segments(const std::uint8_t* data, std::size_t size, unsigned layer) {
    const Parsed parsed = parse_header(data, size, DecodeLimits{});
    const ContainerInfo& info = parsed.info;
    if (layer == 0 || layer > info.layer_present) {
        throw std::invalid_argument("pbepla_rr: layer index out of range");
    }
    const auto offsets = payload_offsets(info);
    const std::size_t index = layer - 1;
    return decode_segments(data + parsed.payload_offset + offsets[index],
                           offsets[index + 1] - offsets[index], info.payload_bits[index], info,
                           index);
}

ContainerInfo inspect(const std::uint8_t* data, std::size_t size) {
    return parse_header(data, size, DecodeLimits{}).info;
}

std::vector<double> decode_layers(const std::uint8_t* data, std::size_t size, unsigned layers,
                                  const DecodeLimits& limits) {
    return decode_impl(data, size, layers, limits, nullptr);
}

Approximation approximate(const std::uint8_t* data, std::size_t size, double eps_star,
                          const DecodeLimits& limits) {
    if (!std::isfinite(eps_star) || !(eps_star > 0.0)) {
        throw std::invalid_argument("pbepla_rr: requested error bound must be finite and positive");
    }
    const ContainerInfo info = parse_header(data, size, limits).info;
    Approximation result;
    // Paper Algorithm 2: stop at the first version whose bound is at least as
    // tight as the request.
    unsigned chosen = info.layer_present;
    for (unsigned i = 1; i <= info.layer_present; ++i) {
        if (info.error_bounds[i - 1] <= eps_star) {
            chosen = i;
            break;
        }
    }
    result.values = decode_impl(data, size, chosen, limits, nullptr);
    result.layers_used = chosen;
    result.bound_met = info.error_bounds[chosen - 1] <= eps_star;
    return result;
}

std::vector<std::uint8_t> extract_prefix(const std::uint8_t* data, std::size_t size,
                                         unsigned layers) {
    const Parsed parsed = parse_header(data, size, DecodeLimits{});
    const ContainerInfo& info = parsed.info;
    if (layers == 0 || layers > info.layer_present) {
        throw std::invalid_argument("pbepla_rr: prefix length exceeds the stored layers");
    }
    const std::size_t k = info.layer_count;
    const std::size_t header_length = header_size(k, layers);
    const auto offsets = payload_offsets(info);
    const std::size_t payload_length = offsets[layers];

    std::vector<std::uint8_t> header;
    header.reserve(header_length);
    header.insert(header.end(), data, data + kFixedHeader);
    header[7] = static_cast<std::uint8_t>(layers);
    for (std::size_t i = 0; i < k; ++i) {
        const std::uint8_t* source = data + kFixedHeader + 8 * i;
        header.insert(header.end(), source, source + 8);
    }
    header.insert(header.end(), data + kFixedHeader + 8 * k, data + kFixedHeader + 9 * k);
    for (std::size_t i = 0; i < layers; ++i) {
        tsbits::put_le(header, info.payload_bits[i], 8);
    }
    const std::uint8_t* payload = data + parsed.payload_offset;
    tsbits::put_le(header, tsbits::crc32(payload, payload_length), 4);
    tsbits::put_le(header, tsbits::crc32(header.data(), header.size()), 4);
    header.insert(header.end(), payload, payload + payload_length);
    return header;
}

// ---------------------------------------------------------------------------
// Bounded-memory pipeline. Temporary files hold final payloads, not sample
// arrays; they are discarded on a retry and closed on every exception path.
// ---------------------------------------------------------------------------
namespace {
using TempFile = std::unique_ptr<std::FILE, decltype(&std::fclose)>;
TempFile temporary_payload() {
    TempFile file(std::tmpfile(), &std::fclose);
    if (!file) throw std::ios_base::failure("pbepla_rr: cannot create temporary payload");
    return file;
}
void rewind_payload(std::FILE* file) {
    if (std::fflush(file) != 0 || std::fseek(file, 0, SEEK_SET) != 0)
        throw std::ios_base::failure("pbepla_rr: cannot rewind temporary payload");
}
void write_byte(std::FILE* file, unsigned byte) {
    if (std::fputc(static_cast<int>(byte), file) == EOF)
        throw std::ios_base::failure("pbepla_rr: temporary payload write failed");
}
struct FileBitWriter {
    std::FILE* file;
    std::uint64_t bits = 0;
    unsigned pending = 0, used = 0;
    void write(std::uint64_t value, unsigned width) {
        if (bits > (UINT64_C(1) << 40) - width)
            throw std::length_error("pbepla_rr: payload exceeds container limit");
        bits += width;
        while (width != 0) {
            const unsigned take = std::min(8U - used, width);
            pending |= static_cast<unsigned>((value >> (width - take)) & ((1U << take) - 1))
                       << (8 - used - take);
            used += take; width -= take;
            if (used == 8) { write_byte(file, pending); used = 0; pending = 0; }
        }
    }
    void finish() { if (used != 0) { write_byte(file, pending); used = 0; pending = 0; } }
};
struct SequentialBits {
    const std::uint8_t* memory = nullptr;
    std::FILE* file = nullptr;
    std::uint64_t remaining = 0;
    std::size_t byte = 0;
    unsigned current = 0, available = 0;
    std::uint64_t read(unsigned width) {
        if (width > remaining) corrupt("truncated streaming payload");
        remaining -= width;
        std::uint64_t result = 0;
        while (width) {
            if (!available) {
                if (file) {
                    const int c = std::fgetc(file);
                    if (c == EOF) throw std::ios_base::failure("pbepla_rr: payload read failed");
                    current = static_cast<unsigned>(c);
                } else current = memory[byte++];
                available = 8;
            }
            const unsigned take = std::min(available, width);
            result = (result << take) | ((current >> (available - take)) & ((1U << take) - 1));
            available -= take; width -= take;
        }
        return result;
    }
    void finish() const {
        if (remaining != 0 || (available && (current & ((1U << available) - 1))))
            corrupt("unused or nonzero padding bits in streaming payload");
    }
};
struct SegmentCursor {
    SequentialBits bits;
    RrGrid grid;
    std::size_t n;
    std::uint64_t delay;
    SegmentMode mode;
    Segment segment{};
    bool started = false;
    unsigned length_bits;
    double at(std::size_t tick) {
        if (!started || tick > segment.stop) {
            const auto start = started ? segment.stop + (mode == SegmentMode::Disconnected) : 0;
            const auto first = mode == SegmentMode::Connected && started ? segment.stop_index
                                                                         : bits.read(grid.resolution());
            std::size_t span = 0;
            std::uint64_t last = first;
            if (mode == SegmentMode::Disconnected || n > 1) {
                span = static_cast<std::size_t>(bits.read(length_bits)) + (mode == SegmentMode::Connected);
                last = bits.read(grid.resolution());
            }
            if (span > delay || start >= n || span > n - 1 - start)
                corrupt("streaming segment overruns delay or series");
            segment = Segment{start, start + span, first, last};
            started = true;
        }
        return 0.0 + reconstruct_point(segment, grid, tick);
    }
};
std::uint32_t crc_update(std::uint32_t state, const std::uint8_t* data, std::size_t size) {
    static const auto table = [] {
        std::array<std::uint32_t, 256> t{};
        for (std::uint32_t i = 0; i < 256; ++i) {
            auto c = i;
            for (unsigned j = 0; j < 8; ++j) c = (c >> 1) ^ ((c & 1) ? 0xedb88320U : 0);
            t[i] = c;
        }
        return t;
    }();
    for (std::size_t i = 0; i < size; ++i) state = table[(state ^ data[i]) & 255] ^ (state >> 8);
    return state;
}
struct StreamSample { double original, cumulative; };
struct PipelineLayer {
    RrGrid grid;
    double eps;
    const EncodeParams& params;
    TempFile file = temporary_payload();
    FileBitWriter writer{file.get()};
    std::vector<StreamSample> pending;
    std::unique_ptr<SwingStream> swing;
    PipelineLayer* next = nullptr;
    std::size_t consumed = 0, emitted = 0, segments = 0;
    bool failed = false;
    PipelineLayer(const LayerGeometry& geometry, double bound, const EncodeParams& p)
        : grid(geometry.grid_min, geometry.grid_max, geometry.resolution), eps(bound), params(p),
          pending(static_cast<std::size_t>(p.max_delay) + 2) {
        swing = std::make_unique<SwingStream>(grid, p.max_delay, p.mode,
                                            [this](const Segment& s) { emit(s); });
    }
    void emit(const Segment& s) {
        // First validate every owned tick, then write the segment and feed
        // downstream. A connected shared endpoint belongs to its first segment.
        for (std::size_t tick = emitted; tick <= s.stop; ++tick) {
            const auto& sample = pending[tick % pending.size()];
            const double residual = sample.original - sample.cumulative;
            const double value = 0.0 + reconstruct_point(s, grid, tick);
            const double sum = sample.cumulative + value;
            const double decoded = sum + (params.symmetric_band ? 0.0 : eps);
            const double target = residual + (params.symmetric_band ? 0.0 : -eps);
            const double slack = eps * 1e-9;
            bool inside = value <= target + eps + slack && value >= target - eps - slack;
            if (params.symmetric_band) inside = inside && value >= residual - eps && value <= residual + eps;
            else inside = inside && value <= residual && value >= residual - 2.0 * eps &&
                          sample.original - sum >= 0 && sample.original - sum <= 2.0 * eps;
            if (!inside || !std::isfinite(decoded) || std::fabs(sample.original - decoded) > eps)
                throw std::runtime_error("pbepla_rr: streaming band violation");
        }
        const unsigned length = span_field_bits(params.max_delay, params.mode);
        if (params.mode == SegmentMode::Connected) {
            if (segments == 0) writer.write(s.start_index, grid.resolution());
            if (s.span()) { writer.write(s.span() - 1, length); writer.write(s.stop_index, grid.resolution()); }
        } else {
            writer.write(s.start_index, grid.resolution());
            writer.write(s.span(), length); writer.write(s.stop_index, grid.resolution());
        }
        ++segments;
        while (emitted <= s.stop) {
            auto sample = pending[emitted % pending.size()];
            sample.cumulative += 0.0 + reconstruct_point(s, grid, emitted);
            ++emitted;
            if (next) next->push(sample);
        }
    }
    template<class Action> void geometry_action(Action action) {
        if (failed) return;
        try { action(); }
        catch (const std::ios_base::failure&) { throw; }
        catch (const std::invalid_argument&) { throw; }
        catch (const std::runtime_error&) { failed = true; }
    }
    void push(StreamSample sample) {
        if (failed) return;
        pending[consumed % pending.size()] = sample; ++consumed;
        geometry_action([&] { swing->push(sample.original - sample.cumulative +
                                         (params.symmetric_band ? 0.0 : -eps), eps); });
    }
    void finish() { geometry_action([&] { swing->finish(); writer.finish(); }); }
};
}  // namespace

void decode_layers_stream(const std::uint8_t* data, std::size_t size, unsigned layers,
                          const std::function<void(double)>& emit, const DecodeLimits& limits) {
    if (!emit) invalid("missing streaming sink");
    const auto parsed = parse_header(data, size, limits);
    const auto& info = parsed.info;
    if (!layers || layers > info.layer_present) invalid("requested layers exceed stored layers");
    const auto offsets = payload_offsets(info);
    std::vector<SegmentCursor> cursors;
    for (unsigned i = 0; i < layers; ++i) {
        const auto g = layer_geometry(info.error_bounds, i, info.symmetric_band, info.grid_min,
                                       info.grid_max, info.resolutions);
        cursors.push_back({{data + parsed.payload_offset + offsets[i], nullptr, info.payload_bits[i]},
            RrGrid(g.grid_min, g.grid_max, g.resolution), info.value_count, info.max_delay, info.mode,
            {}, false, span_field_bits(info.max_delay, info.mode)});
    }
    for (std::size_t t = 0; t < info.value_count; ++t) {
        double sum = 0;
        for (auto& c : cursors) sum += c.at(t);
        emit(sum + (info.symmetric_band ? 0.0 : info.error_bounds[layers - 1]));
    }
    for (const auto& c : cursors) c.bits.finish();
}

void encode_progressive_stream(const ReplaySource& source, std::ostream& output,
                               const EncodeParams& params, StreamStats* stats) {
    validate_encode_params(nullptr, 0, params);
    if (!source.rewind || !source.next) invalid("missing replay source callback");
    StreamStats measured;
    std::uint32_t source_crc = 0xffffffffU;
    double lo = std::numeric_limits<double>::infinity(), hi = -lo;
    source.rewind(); ++measured.source_passes;
    double value;
    while (source.next(value)) {
        if (!std::isfinite(value)) invalid("input contains a non-finite value");
        if (measured.value_count == std::numeric_limits<std::size_t>::max()) invalid("input length overflow");
        ++measured.value_count;
        lo = std::min(lo, value); hi = std::max(hi, value);
        source_crc = crc_update(source_crc, reinterpret_cast<const std::uint8_t*>(&value), sizeof value);
    }
    if (!measured.value_count) {
        const auto bytes = build_empty(params, &measured.encoded);
        output.write(reinterpret_cast<const char*>(bytes.data()), static_cast<std::streamsize>(bytes.size()));
        if (!output) throw std::ios_base::failure("pbepla_rr: output write failed");
        if (stats) *stats = measured;
        return;
    }
    double source_min = params.source_min.value_or(lo), source_max = params.source_max.value_or(hi);
    if (!(source_min < source_max)) {
        const double half = std::max(std::fabs(source_min) * 1e-12, 1e-12);
        source_min -= half; source_max += half;
    }
    if (lo < source_min || hi > source_max) invalid("input values leave the declared source range");
    const std::size_t k = params.error_bounds.size();
    std::vector<double> effective = params.error_bounds;
    std::vector<int> attempts(k, 0);
    std::vector<LayerGeometry> geometries(k);
    std::vector<std::unique_ptr<PipelineLayer>> pipeline;
    measured.buffer_slots = k * (static_cast<std::size_t>(params.max_delay) + 2);
    auto replay = [&](const std::function<void(double, std::size_t)>& consume) {
        source.rewind(); ++measured.source_passes;
        std::size_t count = 0;
        std::uint32_t crc = 0xffffffffU;
        double x;
        while (source.next(x)) {
            if (count >= measured.value_count || !std::isfinite(x)) invalid("source changed during replay");
            crc = crc_update(crc, reinterpret_cast<const std::uint8_t*>(&x), sizeof x);
            consume(x, count++);
        }
        if (count != measured.value_count || crc != source_crc) invalid("source changed during replay");
    };
    for (;;) {
        pipeline.clear();
        for (std::size_t i = 0; i < k; ++i) {
            if (i) effective[i] = std::min(effective[i], std::nextafter(effective[i - 1], 0.0));
            if (!(effective[i] > 0)) invalid("error bound underflows during numerical retry");
            geometries[i] = layer_geometry(effective, i, params.symmetric_band,
                source_min - (params.symmetric_band ? 1.0 : 2.0) * params.error_bounds[0],
                source_max + (params.symmetric_band ? params.error_bounds[0] : 0.0), params.resolutions);
            const auto& g = geometries[i];
            const RrGrid grid(g.grid_min, g.grid_max, g.resolution);
            if (grid.block_width() > 2.0 * effective[i]) invalid("resolution below required minimum");
            pipeline.push_back(std::make_unique<PipelineLayer>(g, effective[i], params));
            if (i) pipeline[i - 1]->next = pipeline[i].get();
        }
        replay([&](double x, std::size_t) { pipeline[0]->push({x, 0.0}); });
        std::size_t failed = k;
        for (std::size_t i = 0; i < k; ++i) {
            pipeline[i]->finish();
            if (pipeline[i]->failed) { failed = i; break; }
            if (pipeline[i]->emitted != measured.value_count) corrupt("streaming layer is not a cover");
        }
        if (failed == k) break;
        if (++attempts[failed] >= kMaxShrinkAttempts) corrupt("streaming numerical retry budget exhausted");
        effective[failed] *= kShrinkFactor; ++measured.numerical_retries;
        // A failure in an earlier layer invalidates all downstream attempts.
        // This preserves the whole-array codec's first-successful-layer policy.
        for (std::size_t i = failed + 1; i < k; ++i) { effective[i] = params.error_bounds[i]; attempts[i] = 0; }
    }
    // Independently decode the staged bit payloads, one cursor per layer.
    std::vector<SegmentCursor> cursors;
    for (std::size_t i = 0; i < k; ++i) {
        auto& layer = *pipeline[i]; rewind_payload(layer.file.get());
        cursors.push_back({{nullptr, layer.file.get(), layer.writer.bits}, layer.grid,
            measured.value_count, params.max_delay, params.mode, {}, false,
            span_field_bits(params.max_delay, params.mode)});
    }
    replay([&](double original, std::size_t t) {
        double sum = 0;
        for (std::size_t i = 0; i < k; ++i) {
            sum += cursors[i].at(t);
            const double decoded = sum + (params.symmetric_band ? 0.0 : effective[i]);
            if (!std::isfinite(decoded) || std::fabs(original - decoded) > effective[i])
                corrupt("serialized streaming version exceeds its error bound");
        }
    });
    for (const auto& c : cursors) c.bits.finish();
    std::array<std::uint8_t, 8192> buffer{};
    std::uint32_t payload_crc = 0xffffffffU;
    for (auto& layer : pipeline) {
        rewind_payload(layer->file.get());
        for (;;) {
            const auto got = std::fread(buffer.data(), 1, buffer.size(), layer->file.get());
            payload_crc = crc_update(payload_crc, buffer.data(), got);
            if (got != buffer.size()) {
                if (std::ferror(layer->file.get())) throw std::ios_base::failure("pbepla_rr: payload read failed");
                break;
            }
        }
    }
    std::vector<std::uint8_t> header{'P', 'B', 'E', 'P', kContainerVersion,
        static_cast<std::uint8_t>(container_flags(params)), static_cast<std::uint8_t>(k), static_cast<std::uint8_t>(k)};
    tsbits::put_le(header, measured.value_count, 8); tsbits::put_le(header, params.max_delay, 4);
    put_double(header, geometries[0].grid_min); put_double(header, geometries[0].grid_max);
    for (double e : effective) put_double(header, e);
    for (const auto& g : geometries) header.push_back(static_cast<std::uint8_t>(g.resolution));
    for (const auto& layer : pipeline) tsbits::put_le(header, layer->writer.bits, 8);
    tsbits::put_le(header, payload_crc ^ 0xffffffffU, 4);
    tsbits::put_le(header, tsbits::crc32(header.data(), header.size()), 4);
    output.write(reinterpret_cast<const char*>(header.data()), static_cast<std::streamsize>(header.size()));
    measured.encoded.header_bytes = header.size(); measured.encoded.effective_eps = effective;
    for (const auto& layer : pipeline) {
        rewind_payload(layer->file.get());
        std::size_t bytes = 0;
        for (;;) {
            const auto got = std::fread(buffer.data(), 1, buffer.size(), layer->file.get());
            output.write(reinterpret_cast<const char*>(buffer.data()), static_cast<std::streamsize>(got));
            if (!output) throw std::ios_base::failure("pbepla_rr: output write failed");
            bytes += got;
            if (got != buffer.size()) {
                if (std::ferror(layer->file.get())) throw std::ios_base::failure("pbepla_rr: payload read failed");
                break;
            }
        }
        measured.encoded.payload_bytes += bytes;
        measured.encoded.layers.push_back({layer->segments, layer->writer.bits, layer->grid.resolution(),
                                           layer->grid.min(), layer->grid.max()});
    }
    if (stats) *stats = measured;
}

}  // namespace pbepla_rr
