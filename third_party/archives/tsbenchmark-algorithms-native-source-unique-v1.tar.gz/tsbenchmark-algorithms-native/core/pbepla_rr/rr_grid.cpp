#include "rr_grid.h"

#include <algorithm>
#include <cmath>
#include <limits>
#include <stdexcept>
#include <string>

namespace pbepla_rr {
namespace {

// Hard cap on the resolution.  The container stores r in one byte and the
// spec caps it at 30; anything above means the caller asked for a block finer
// than any paper scenario needs.
constexpr unsigned kMaxResolution = 30;

[[noreturn]] void fail(const std::string& message) {
    throw std::runtime_error("RrGrid: " + message);
}

}  // namespace

RrGrid::RrGrid(double gmin, double gmax, unsigned resolution) {
    if (!std::isfinite(gmin) || !std::isfinite(gmax) || !(gmin < gmax)) {
        fail("grid range must be finite with gmin < gmax");
    }
    if (resolution > kMaxResolution) {
        fail("resolution exceeds 30 bits");
    }
    gmin_ = gmin;
    gmax_ = gmax;
    resolution_ = resolution;
    block_count_ = std::uint64_t{1} << resolution;
    width_ = (gmax - gmin) / static_cast<double>(block_count_);
    if (!(width_ > 0.0) || !std::isfinite(width_)) {
        fail("block width is not a positive finite number");
    }
}

double RrGrid::center(std::uint64_t index) const {
    if (index >= block_count_) {
        fail("block index out of range");
    }
    return gmin_ + (static_cast<double>(index) + 0.5) * width_;
}

std::optional<std::pair<std::uint64_t, std::uint64_t>>
RrGrid::center_bounds(double a, double b) const {
    if (!(a <= b) || block_count_ == 0) return std::nullopt;
    // Search actual binary64 centres, preserving closed boundaries exactly.
    std::uint64_t lo = 0, hi = block_count_;
    while (lo < hi) {
        const auto mid = lo + (hi - lo) / 2;
        if (center(mid) < a) lo = mid + 1; else hi = mid;
    }
    const auto first = lo;
    hi = block_count_;
    while (lo < hi) {
        const auto mid = lo + (hi - lo) / 2;
        if (center(mid) <= b) lo = mid + 1; else hi = mid;
    }
    if (first == lo) return std::nullopt;
    return std::make_pair(first, lo - 1);
}

std::vector<std::uint64_t> RrGrid::centers_in(double a, double b) const {
    const auto bounds = center_bounds(a, b);
    if (!bounds) return {};
    std::vector<std::uint64_t> result;
    result.reserve(static_cast<std::size_t>(bounds->second - bounds->first + 1));
    for (auto j = bounds->first; j <= bounds->second; ++j) result.push_back(j);
    return result;
}

std::uint64_t RrGrid::nearest(double value) const {
    if (block_count_ == 0) fail("uninitialized grid");
    if (!std::isfinite(value)) fail("nearest target must be finite");
    const auto bounds = center_bounds(value, std::numeric_limits<double>::infinity());
    if (!bounds) return block_count_ - 1;
    const auto high = bounds->first;
    if (high == 0) return 0;
    const auto low = high - 1;
    return std::fabs(value - center(high)) < std::fabs(value - center(low)) ? high : low;
}

std::uint64_t RrGrid::nearest_in(double a, double b, double value) const {
    const auto bounds = center_bounds(a, b);
    if (!bounds) fail("band contains no coded data point");
    return std::clamp(nearest(value), bounds->first, bounds->second);
}

unsigned RrGrid::minimal_resolution(double range, double band_width) {
    if (!std::isfinite(range) || !(range > 0.0)) {
        fail("range must be a positive finite number");
    }
    if (!std::isfinite(band_width) || !(band_width > 0.0)) {
        fail("band width must be a positive finite number");
    }
    const double target = band_width;
    for (unsigned r = 0; r <= kMaxResolution; ++r) {
        const double width = std::ldexp(range, -static_cast<int>(r));
        if (width <= target) {
            return r;
        }
    }
    fail("no resolution up to 30 bits gives a block narrow enough");
}

}  // namespace pbepla_rr
