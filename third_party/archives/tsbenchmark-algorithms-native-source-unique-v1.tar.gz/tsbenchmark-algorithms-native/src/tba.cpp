#include "tba.h"
#include "kangaroo.h"
#include "pbepla_rr.h"
#include "actsd.h"
#include <cstdlib>
#include <cstring>
#include <cstdio>
#include <stdexcept>
#include <new>
namespace {
constexpr size_t limit=16000000;
template<class F> int boundary(tba_buffer* out,char* err,size_t cap,F fn) noexcept {
    if(!out || (cap && !err)) return -1;
    *out={nullptr,0,0};
    if(cap) err[0]=0;
    try { fn(); return 0; }
    catch(const std::exception& e) { if(cap) std::snprintf(err,cap,"%s",e.what()); }
    catch(...) { if(cap) std::snprintf(err,cap,"unknown C++ exception"); }
    tba_free(out); return -1;
}
void length(size_t n) { if(n>limit) throw std::length_error("TBA value limit exceeded"); }
void copy(tba_buffer* out,const void* data,size_t bytes,size_t n) {
    if(bytes) {
        out->data=std::malloc(bytes);
        if(!out->data) throw std::bad_alloc();
        std::memcpy(out->data,data,bytes);
    }
    out->bytes=bytes; out->count=n;
}
}
extern "C" {
void tba_free(tba_buffer* b) { if(b) { std::free(b->data); *b={nullptr,0,0}; } }
int tba_kangaroo_encode(const double* v,size_t n,tba_buffer* out,char* err,size_t cap) {
    return boundary(out,err,cap,[&]{ length(n); auto r=kangaroo::compress(v,n); copy(out,r.compressed_data.data(),r.compressed_data.size(),n); });
}
int tba_pbepla_encode(const double* v,size_t n,const double* eps,size_t k,tba_buffer* out,char* err,size_t cap) {
    return boundary(out,err,cap,[&]{
        length(n); if(!eps || k<1 || k>16) throw std::invalid_argument("invalid error bounds");
        pbepla_rr::EncodeParams p; p.error_bounds.assign(eps,eps+k);
        auto r=pbepla_rr::encode_progressive(v,n,p); copy(out,r.data(),r.size(),n);
    });
}
int tba_actsd_encode(const uint32_t* x,const uint32_t* y,size_t n,tba_buffer* out,char* err,size_t cap) {
    return boundary(out,err,cap,[&]{length(n); auto r=actsd::encode(x,y,nullptr,n); copy(out,r.data(),r.size(),n);});
}
int tba_decode(int32_t kind,const void* bytes,size_t size,unsigned layers,size_t max_values,tba_buffer* out,char* err,size_t cap) {
    return boundary(out,err,cap,[&]{
        length(max_values); auto p=static_cast<const uint8_t*>(bytes);
        if(kind==TBA_KANGAROO) {
            auto r=kangaroo::decompress(p,size,kangaroo::DecodeLimits{max_values});
            copy(out,r.data.data(),r.data.size()*sizeof(double),r.data.size());
        } else if(kind==TBA_PBEPLA_RR) {
            auto r=pbepla_rr::decode_layers(p,size,layers,pbepla_rr::DecodeLimits{max_values});
            copy(out,r.data(),r.size()*sizeof(double),r.size());
        } else if(kind==TBA_ACTSD) {
            auto r=actsd::decode(p,size,max_values);
            if(r.x_bits.size()!=r.y_bits.size()) throw std::runtime_error("coordinate count mismatch");
            r.x_bits.insert(r.x_bits.end(),r.y_bits.begin(),r.y_bits.end());
            copy(out,r.x_bits.data(),r.x_bits.size()*sizeof(uint32_t),r.y_bits.size());
        } else throw std::invalid_argument("unknown algorithm");
    });
}
}

#include <algorithm>
#include <ostream>
#include <streambuf>
namespace {
bool flag(int v){if(v!=0&&v!=1)throw std::invalid_argument("flag must be 0/1");return v!=0;}
pbepla_rr::EncodeParams pb_params(const tba_pbepla_options*p){
 if(!p||!p->eps||p->layers<1||p->layers>16)throw std::invalid_argument("invalid PBEPLA config");
 pbepla_rr::EncodeParams r;r.error_bounds.assign(p->eps,p->eps+p->layers);if(p->resolutions)r.resolutions.assign(p->resolutions,p->resolutions+p->layers);
 if(flag(p->has_source_range)){r.source_min=p->source_min;r.source_max=p->source_max;}
 r.max_delay=p->max_delay;r.mode=flag(p->connected)?pbepla_rr::SegmentMode::Connected:pbepla_rr::SegmentMode::Disconnected;r.symmetric_band=flag(p->symmetric_band);return r;
}
void pb_info(const pbepla_rr::ContainerInfo&i,tba_pbepla_info*out){
 if(!out)return;if(i.layer_count>16)throw std::length_error("PBEPLA C ABI layer limit");*out={};out->value_count=i.value_count;out->header_bytes=i.header_bytes;out->payload_bytes=i.payload_bytes;out->layer_count=i.layer_count;out->layer_present=i.layer_present;out->max_delay=i.max_delay;out->connected=i.mode==pbepla_rr::SegmentMode::Connected;out->symmetric_band=i.symmetric_band;out->grid_min=i.grid_min;out->grid_max=i.grid_max;
 for(size_t j=0;j<i.error_bounds.size();j++){out->effective_eps[j]=i.error_bounds[j];out->resolutions[j]=i.resolutions[j];out->payload_bits[j]=j<i.payload_bits.size()?i.payload_bits[j]:0;}
}
class CallbackBuffer:public std::streambuf {
 void*ctx;tba_write_fn write;
 std::streamsize xsputn(const char*s,std::streamsize n)override{if(n<0||write(ctx,s,size_t(n)))throw std::runtime_error("output sink failed");return n;}
 int_type overflow(int_type c)override{if(traits_type::eq_int_type(c,traits_type::eof()))return traits_type::not_eof(c);char v=traits_type::to_char_type(c);if(write(ctx,&v,1))throw std::runtime_error("output sink failed");return c;}
public:CallbackBuffer(void*c,tba_write_fn w):ctx(c),write(w){}
};
}
extern "C" {
tba_kangaroo_options tba_kangaroo_defaults(){return {32,1,0};}
tba_actsd_options tba_actsd_defaults(){return {0,0,0,-1,-1,1000,8192,1,1};}
tba_pbepla_options tba_pbepla_defaults(const double*e,size_t n){return {e,n,nullptr,0,0,0,64,0,0};}
int tba_kangaroo_encode_ex(const double*v,size_t n,const tba_kangaroo_options*p,tba_buffer*out,char*err,size_t cap){return boundary(out,err,cap,[&]{length(n);if(!p||p->reference_mode<0||p->reference_mode>1)throw std::invalid_argument("invalid Kangaroo config");kangaroo::CompressParams q;q.history_window=p->history_window;q.use_erasure=flag(p->use_erasure);q.reference_mode=p->reference_mode?kangaroo::ReferenceMode::Compact:kangaroo::ReferenceMode::Fast;auto r=kangaroo::compress(v,n,q);copy(out,r.compressed_data.data(),r.compressed_data.size(),n);});}
int tba_actsd_encode_ex(const uint32_t*x,const uint32_t*y,const int64_t*ts,size_t n,const tba_actsd_options*p,tba_actsd_stats*stats,tba_buffer*out,char*err,size_t cap){
 if(stats)*stats={};return boundary(out,err,cap,[&]{length(n);if(!p||p->sfc<0||p->sfc>2||p->rule<0||p->rule>1||p->profile<0||p->profile>1)throw std::invalid_argument("invalid ACTSD enum");actsd::Params q;q.sfc=static_cast<actsd::Sfc>(p->sfc);q.rule=static_cast<actsd::SegRule>(p->rule);q.profile=static_cast<actsd::Profile>(p->profile);q.phi=p->phi;q.theta=p->theta;q.sample_size=p->sample_size;q.block_rows=p->block_rows;q.segmentation=flag(p->segmentation);q.seg_fallback=flag(p->seg_fallback);actsd::EncodeStats st;auto r=actsd::encode(x,y,ts,n,q,&st);copy(out,r.data(),r.size(),n);if(stats){stats->phi=st.phi;stats->theta=st.theta;stats->containers=st.containers;stats->segments=st.segments;std::copy(st.type_hits.begin(),st.type_hits.end(),stats->type_hits);stats->container_bytes=st.container_bytes;stats->timestamp_bytes=st.timestamp_bytes;stats->file_bytes=st.file_bytes;}});
}
int tba_actsd_decode_ex(const void*data,size_t bytes,size_t max,int*has,int*sfc,tba_buffer*out,char*err,size_t cap){
 if(has)*has=0;if(sfc)*sfc=0;return boundary(out,err,cap,[&]{length(max);if(!has||!sfc)throw std::invalid_argument("metadata required");auto r=actsd::decode(static_cast<const uint8_t*>(data),bytes,max);size_t n=r.x_bits.size();if(n!=r.y_bits.size()||(r.has_timestamps&&n!=r.timestamps.size()))throw std::runtime_error("ACTSD counts mismatch");size_t total=n*(r.has_timestamps?16:8);if(total){out->data=std::malloc(total);if(!out->data)throw std::bad_alloc();auto p=static_cast<uint8_t*>(out->data);std::memcpy(p,r.x_bits.data(),4*n);std::memcpy(p+4*n,r.y_bits.data(),4*n);if(r.has_timestamps)std::memcpy(p+8*n,r.timestamps.data(),8*n);}out->bytes=total;out->count=n;*has=r.has_timestamps;*sfc=int(r.sfc);});
}
int tba_pbepla_encode_ex(const double*v,size_t n,const tba_pbepla_options*p,tba_pbepla_info*info,tba_buffer*out,char*err,size_t cap){if(info)*info={};return boundary(out,err,cap,[&]{length(n);auto r=pbepla_rr::encode_progressive(v,n,pb_params(p));pb_info(pbepla_rr::inspect(r.data(),r.size()),info);copy(out,r.data(),r.size(),n);});}
int tba_pbepla_inspect(const void*data,size_t bytes,tba_pbepla_info*info,char*err,size_t cap){if(info)*info={};tba_buffer dummy{};return boundary(&dummy,err,cap,[&]{if(!info)throw std::invalid_argument("info required");pb_info(pbepla_rr::inspect(static_cast<const uint8_t*>(data),bytes),info);});}
int tba_pbepla_prefix(const void*data,size_t bytes,unsigned layers,tba_buffer*out,char*err,size_t cap){return boundary(out,err,cap,[&]{auto r=pbepla_rr::extract_prefix(static_cast<const uint8_t*>(data),bytes,layers);auto i=pbepla_rr::inspect(r.data(),r.size());length(i.value_count);copy(out,r.data(),r.size(),i.value_count);});}
int tba_pbepla_approximate(const void*data,size_t bytes,double eps,size_t max,unsigned*layers,int*met,tba_buffer*out,char*err,size_t cap){if(layers)*layers=0;if(met)*met=0;return boundary(out,err,cap,[&]{length(max);if(!layers||!met)throw std::invalid_argument("metadata required");auto r=pbepla_rr::approximate(static_cast<const uint8_t*>(data),bytes,eps,pbepla_rr::DecodeLimits{max});copy(out,r.values.data(),r.values.size()*8,r.values.size());*layers=r.layers_used;*met=r.bound_met;});}
int tba_pbepla_encode_stream(void*source,tba_rewind_fn rewind,tba_next_fn next,void*sink,tba_write_fn write,const tba_pbepla_options*p,size_t max,tba_stream_stats*stats,char*err,size_t cap){
 if(stats)*stats={};tba_buffer dummy{};return boundary(&dummy,err,cap,[&]{length(max);if(!rewind||!next||!write)throw std::invalid_argument("stream callbacks required");size_t count=0;pbepla_rr::ReplaySource src;src.rewind=[&]{if(rewind(source))throw std::runtime_error("source rewind failed");count=0;};src.next=[&](double&v){int rc=next(source,&v);if(rc<0||rc>1)throw std::runtime_error("source next failed");if(rc==1&&count++>=max)throw std::length_error("source value limit");return rc==1;};CallbackBuffer buffer(sink,write);std::ostream output(&buffer);output.exceptions(std::ios::badbit|std::ios::failbit);pbepla_rr::StreamStats st;pbepla_rr::encode_progressive_stream(src,output,pb_params(p),&st);if(stats){stats->value_count=st.value_count;stats->buffer_slots=st.buffer_slots;stats->source_passes=st.source_passes;stats->numerical_retries=st.numerical_retries;for(size_t j=0;j<st.encoded.layers.size();j++){stats->effective_eps[j]=st.encoded.effective_eps[j];stats->resolutions[j]=st.encoded.layers[j].resolution;}}});
}
int tba_pbepla_decode_stream(const void*data,size_t bytes,unsigned layers,size_t max,void*sink,tba_emit_fn emit,char*err,size_t cap){tba_buffer dummy{};return boundary(&dummy,err,cap,[&]{length(max);if(!emit)throw std::invalid_argument("emit callback required");auto info=pbepla_rr::inspect(static_cast<const uint8_t*>(data),bytes);if(info.layer_count>16)throw std::length_error("C ABI layer limit");pbepla_rr::decode_layers_stream(static_cast<const uint8_t*>(data),bytes,layers,[&](double v){if(emit(sink,v))throw std::runtime_error("emit failed");},pbepla_rr::DecodeLimits{max});});}
}
