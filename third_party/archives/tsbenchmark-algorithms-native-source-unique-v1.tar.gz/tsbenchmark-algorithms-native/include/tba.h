#ifndef TBA_NATIVE_H
#define TBA_NATIVE_H
#include <stddef.h>
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
enum tba_algorithm { TBA_KANGAROO=0, TBA_PBEPLA_RR=1, TBA_ACTSD=2 };
typedef struct tba_buffer { void* data; size_t bytes; size_t count; } tba_buffer;
/* All calls return 0 on success, -1 on failure. out must be nonnull and empty;
 * on failure it is zeroed. err may be NULL iff err_capacity==0, otherwise it
 * receives a NUL-terminated diagnostic. Caller owns outputs until tba_free.
 * Inputs may not overlap out. n<=16000000, NULL inputs allowed only for n=0.
 * Stateless, concurrent independent calls allowed. No borrowed output/state.
 * C ABI uses the retained C++17 core, not a separate C algorithm.
 */
int tba_kangaroo_encode(const double* values, size_t n, tba_buffer* out, char* err, size_t err_capacity);
/* eps contains k strictly decreasing positive absolute bounds; k=1..16. */
int tba_pbepla_encode(const double* values, size_t n, const double* eps, size_t k,
                     tba_buffer* out, char* err, size_t err_capacity);
/* x/y are binary32 bits; implicit uniform tick, no timestamps. */
int tba_actsd_encode(const uint32_t* x, const uint32_t* y, size_t n,
                    tba_buffer* out, char* err, size_t err_capacity);
/* Trusted complete matching streams only. max_values<=16000000.
 * layers is used only for PBEP (1..stored layers).
 * Output: Kangaroo/PBEP count doubles; ACTSD count x bits followed by count y
 * bits, all uint32_t. bytes is actual output length, count is records.
 */
int tba_decode(int32_t kind, const void* bytes, size_t size, unsigned layers,
               size_t max_values, tba_buffer* out, char* err, size_t err_capacity);
/* fix2 explicit configurations; all pointer arrays are borrowed during call only.
 * Flags are exactly 0/1; enum fields checked before narrowing to upstream enums. */
typedef struct {size_t history_window;int use_erasure,reference_mode;} tba_kangaroo_options;
typedef struct {int sfc,rule,profile,phi,theta;size_t sample_size,block_rows;int segmentation,seg_fallback;} tba_actsd_options;
typedef struct {int phi,theta;size_t containers,segments,type_hits[9],container_bytes,timestamp_bytes,file_bytes;} tba_actsd_stats;
typedef struct {const double* eps;size_t layers;const unsigned* resolutions;int has_source_range;double source_min,source_max;uint64_t max_delay;int connected,symmetric_band;} tba_pbepla_options;
typedef struct {size_t value_count,header_bytes,payload_bytes;unsigned layer_count,layer_present;uint64_t max_delay;int connected,symmetric_band;double grid_min,grid_max,effective_eps[16];unsigned resolutions[16];uint64_t payload_bits[16];} tba_pbepla_info;
typedef struct {size_t value_count,buffer_slots,source_passes,numerical_retries;double effective_eps[16];unsigned resolutions[16];} tba_stream_stats;
tba_kangaroo_options tba_kangaroo_defaults(void);
tba_actsd_options tba_actsd_defaults(void);
tba_pbepla_options tba_pbepla_defaults(const double* eps,size_t layers);
int tba_kangaroo_encode_ex(const double*,size_t,const tba_kangaroo_options*,tba_buffer*,char*,size_t);
int tba_actsd_encode_ex(const uint32_t*,const uint32_t*,const int64_t* timestamps,size_t,const tba_actsd_options*,tba_actsd_stats*,tba_buffer*,char*,size_t);
/* x bits[n], y bits[n], then optional timestamps[n] as int64; bytes=8n or16n.
 * Timestamp stream uses upstream modulo-2^64 delta/delta-of-delta, no imposed
 * uniform clock or monotonicity. Unit is the caller's integer tick. */
int tba_actsd_decode_ex(const void*,size_t,size_t max_values,int* has_timestamps,int* sfc,tba_buffer*,char*,size_t);
int tba_pbepla_encode_ex(const double*,size_t,const tba_pbepla_options*,tba_pbepla_info*,tba_buffer*,char*,size_t);
int tba_pbepla_inspect(const void*,size_t,tba_pbepla_info*,char*,size_t);
int tba_pbepla_prefix(const void*,size_t,unsigned layers,tba_buffer*,char*,size_t);
int tba_pbepla_approximate(const void*,size_t,double eps_star,size_t max_values,unsigned* layers_used,int* bound_met,tba_buffer*,char*,size_t);
/* Replay encoder uses actual upstream bounded resident state + temporary FILE
 * payloads, not an input-sized buffer. Three passes normally; callback source
 * must rewind to identical data. rewind=0 success; next=1 value/0 EOF/-1 error;
 * sink/emit=0 success. Callbacks may not throw across the C boundary.
 * Sink failures can leave partial output. Decode receives complete container.
 */
typedef int (*tba_rewind_fn)(void*);
typedef int (*tba_next_fn)(void*,double*);
typedef int (*tba_write_fn)(void*,const void*,size_t);
typedef int (*tba_emit_fn)(void*,double);
int tba_pbepla_encode_stream(void* source,tba_rewind_fn,tba_next_fn,void* sink,tba_write_fn,const tba_pbepla_options*,size_t max_values,tba_stream_stats*,char*,size_t);
int tba_pbepla_decode_stream(const void*,size_t,unsigned layers,size_t max_values,void* sink,tba_emit_fn,char*,size_t);
void tba_free(tba_buffer* buffer);
#ifdef __cplusplus
}
#endif
#endif
