#include "entropy_port.hpp"
#include <algorithm>
#include <chrono>
#include <cstring>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

using namespace entropy_port;
namespace {
volatile std::uint64_t sink = 0;
using Clock = std::chrono::steady_clock;
Bytes load(const std::string& name) {
    std::ifstream f(name, std::ios::binary | std::ios::ate);
    if (!f) throw std::runtime_error("cannot open " + name);
    const auto size = f.tellg();
    if (size < 0 || std::uint64_t(size) > max_message + 1024 * 1024) throw std::runtime_error("input too large");
    Bytes b(static_cast<std::size_t>(size)); f.seekg(0);
    if (!b.empty() && !f.read(reinterpret_cast<char*>(b.data()), std::streamsize(b.size())))
        throw std::runtime_error("input read failed");
    return b;
}
void save(const std::string& name, const Bytes& b) {
    std::ofstream f(name, std::ios::binary);
    f.write(reinterpret_cast<const char*>(b.data()), std::streamsize(b.size()));
    if (!f) throw std::runtime_error("output write failed");
}
struct Block { std::size_t offset, stored, raw; unsigned mode; };
std::vector<Block> blocks(const Bytes& frame) {
    std::vector<Block> list;
    std::size_t p = 24;
    while (p < frame.size()) {
        const unsigned mode = frame.at(p++);
        auto u32 = [&]() {
            std::size_t n = 0;
            for (unsigned i = 0; i < 4; ++i) n |= std::size_t(frame.at(p++)) << (8 * i);
            return n;
        };
        const auto raw = u32(), stored = u32(); (void)u32();
        list.push_back({p, stored, raw, mode}); p += stored;
    }
    return list;
}
std::uint64_t run(const std::function<void()>& action, std::size_t iterations) {
    const auto start = Clock::now();
    for (std::size_t i = 0; i < iterations; ++i) action();
    return std::uint64_t(std::chrono::duration_cast<std::chrono::nanoseconds>(Clock::now() - start).count());
}
struct Measurement { std::size_t iterations; std::uint64_t elapsed; };
Measurement measure(const std::function<void()>& action, std::uint64_t target_ns) {
    action(); action();
    std::size_t count = 1;
    auto elapsed = run(action, count);
    while (elapsed < 2000000 && count < 1048576) { count *= 2; elapsed = run(action, count); }
    const double scale = double(target_ns) / double(std::max<std::uint64_t>(elapsed, 1));
    count = std::max<std::size_t>(1, std::min<std::size_t>(1048576, std::size_t(double(count) * scale)));
    return {count, run(action, count)};
}
void bench(Algorithm alg, const std::string& inputs, const std::string& output, unsigned milliseconds) {
    std::ifstream listing(inputs);
    if (!listing) throw std::runtime_error("cannot open inputs manifest");
    std::ofstream results(output);
    results << "implementation,algorithm,sample,scope,input_bytes,payload_bytes,representation_bytes,encode_iterations,encode_elapsed_ns,decode_iterations,decode_elapsed_ns,raw_blocks,rle_blocks,compressed_blocks\n";
    std::string path;
    while (std::getline(listing, path)) {
        if (path.empty()) continue;
        const auto input = load(path);
        Codec codec(alg);
        Bytes frame, restored, encoded;
        codec.encode(input, frame); codec.decode(frame, restored);
        if (restored != input) throw std::runtime_error("benchmark roundtrip failure");
        const auto list = blocks(frame);
        Bytes fixed_payload;
        std::size_t payload = 0; unsigned counts[3]{};
        for (const auto& b : list) {
            payload += b.stored; ++counts[b.mode];
            fixed_payload.insert(fixed_payload.end(), frame.begin()+std::ptrdiff_t(b.offset),
                                  frame.begin()+std::ptrdiff_t(b.offset+b.stored));
        }
        // Reserve outside steady-state; all actual writes, per-block reset,
        // checksum, scratch clearing, and output materialization stay timed.
        encoded.reserve(input.size() + 24 + list.size() * 13);
        restored.resize(input.size());
        for (const bool full : {false, true}) {
            auto encode = [&]() {
                codec.encode(input, encoded, full);
                sink = sink ^ encoded.size();
                if (!encoded.empty()) sink = sink ^ encoded[encoded.size()/2];
            };
            auto decode = [&]() {
                if (full) codec.decode(frame, restored);
                else {
                    std::size_t offset = 0;
                    for (const auto& b : list) {
                        codec.decode_block(frame.data()+b.offset, b.stored, restored.data()+offset, b.raw, b.mode);
                        offset += b.raw;
                    }
                }
                sink = sink ^ restored.size();
                if (!restored.empty()) sink = sink ^ restored[restored.size()/2];
            };
            const auto enc = measure(encode, std::uint64_t(milliseconds) * 1000000);
            const auto dec = measure(decode, std::uint64_t(milliseconds) * 1000000);
            if (restored != input) throw std::runtime_error("timed decode verification failed");
            if (full && encoded != frame) throw std::runtime_error("timed encode verification failed");
            if (!full && encoded != fixed_payload) throw std::runtime_error("timed payload verification failed");
            results << implementation_id() << ',' << unsigned(alg) << ',' << path << ',' << (full ? "frame" : "codec")
                    << ',' << input.size() << ',' << payload << ',' << frame.size()
                    << ',' << enc.iterations << ',' << enc.elapsed << ',' << dec.iterations << ',' << dec.elapsed
                    << ',' << counts[0] << ',' << counts[1] << ',' << counts[2] << '\n';
        }
    }
    if (!results) throw std::runtime_error("result write failed");
}
}
int main(int argc, char** argv) {
    try {
        if (argc == 2 && std::string(argv[1]) == "identity") {
            std::cout << implementation_id() << '\n'; return 0;
        }
        if (argc < 5) throw std::runtime_error("usage: worker encode|decode ALG INPUT OUTPUT; worker bench ALG INPUT_LIST CSV [ms_per_file]");
        const std::string mode = argv[1];
        const auto alg = Algorithm(unsigned(std::stoul(argv[2])));
        if (mode == "bench") {
            bench(alg, argv[3], argv[4], argc > 5 ? unsigned(std::stoul(argv[5])) : 20); return 0;
        }
        auto input = load(argv[3]); Bytes output;
        const auto start = Clock::now();
        {
            Codec codec(alg);
            if (mode == "encode") codec.encode(input, output);
            else if (mode == "decode") codec.decode(input, output);
            else throw std::runtime_error("unsupported command");
        }
        const auto elapsed = std::chrono::duration_cast<std::chrono::nanoseconds>(Clock::now()-start).count();
        save(argv[4], output);
        std::cout << implementation_id() << ' ' << mode << ' ' << input.size() << ' ' << output.size()
                  << " cold_ns=" << elapsed << '\n';
        return 0;
    } catch (const std::exception& e) {
        std::cerr << e.what() << '\n'; return 2;
    }
}
