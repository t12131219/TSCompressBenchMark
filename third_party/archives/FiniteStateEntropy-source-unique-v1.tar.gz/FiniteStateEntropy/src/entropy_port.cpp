#include "entropy_port.hpp"
#include <algorithm>
#include <array>
#include <cstring>
#include <stdexcept>
extern "C" {
#include "fse.h"
#define HUF_STATIC_LINKING_ONLY
#include "huf.h"
#include "zlibh.h"
}

namespace entropy_port {
namespace {
constexpr std::array<std::uint32_t, 256> make_crc() {
    std::array<std::uint32_t, 256> a{};
    for (unsigned i = 0; i < 256; ++i) {
        auto v = std::uint32_t(i);
        for (unsigned j = 0; j < 8; ++j) v = (v >> 1) ^ ((v & 1U) ? 0xedb88320U : 0U);
        a[i] = v;
    }
    return a;
}
constexpr auto crc_table = make_crc();
void put(Bytes& v, std::uint64_t n, unsigned bytes) {
    for (unsigned i = 0; i < bytes; ++i) { v.push_back(std::uint8_t(n)); n >>= 8; }
}
std::uint64_t get(const Bytes& v, std::size_t& p, unsigned bytes) {
    if (p > v.size() || bytes > v.size() - p) throw std::runtime_error("truncated frame");
    std::uint64_t n = 0;
    for (unsigned i = 0; i < bytes; ++i) n |= std::uint64_t(v[p++]) << (8 * i);
    return n;
}
}
std::uint32_t crc32(const std::uint8_t* p, std::size_t n) {
    std::uint32_t c = 0xffffffffU;
    for (std::size_t i = 0; i < n; ++i) c = crc_table[(c ^ p[i]) & 255U] ^ (c >> 8);
    return c ^ 0xffffffffU;
}
const char* implementation_id() {
#ifdef ENTROPY_REFERENCE
    return "upstream-original";
#else
    return "upstream-integration-bounded-fix1";
#endif
}
Codec::Codec(Algorithm algorithm) : Codec(algorithm, Options{}) {}
Codec::Codec(Algorithm algorithm, Options options) : algorithm_(algorithm), options_(options), scratch_(2 * block_size + 4096, 0) {
    if (options.max_symbol > 255 || (options.table_log && (options.table_log < 5 || options.table_log > 12)) ||
        (algorithm == Algorithm::Zlibh && (options.max_symbol != 255 || options.table_log)))
        throw std::runtime_error("unsupported entropy options");
    if (unsigned(algorithm) < 1 || unsigned(algorithm) > 3) throw std::runtime_error("unsupported algorithm");
}
std::size_t Codec::encode_block(const std::uint8_t* src, std::size_t n, unsigned& mode) {
    if (!n || n > block_size || !src) throw std::runtime_error("invalid block size");
    if (options_.max_symbol < 255 && std::any_of(src, src+n, [&](std::uint8_t x){ return x > options_.max_symbol; }))
        throw std::runtime_error("byte exceeds max_symbol");
    // Conservative capacity also covers zlibh's literal-only worst case. Do
    // not trust its historical n+256 bound for arbitrary input distributions.
    std::fill(scratch_.begin(), scratch_.end(), 0);
    std::size_t c;
    if (algorithm_ == Algorithm::FSE) {
        c = FSE_compress2(scratch_.data(), scratch_.size(), src, n, options_.max_symbol, options_.table_log ? options_.table_log : 11);
        if (FSE_isError(c)) throw std::runtime_error(FSE_getErrorName(c));
    } else if (algorithm_ == Algorithm::Huff) {
        c = HUF_compress2(scratch_.data(), scratch_.size(), src, n, options_.max_symbol, options_.table_log ? options_.table_log : 11);
        if (HUF_isError(c)) throw std::runtime_error(HUF_getErrorName(c));
    } else {
        const int result = ZLIBH_compress(reinterpret_cast<char*>(scratch_.data()),
                                         reinterpret_cast<const char*>(src), int(n));
        if (result <= 0 || std::size_t(result) > scratch_.size()) throw std::runtime_error("zlibh encode failed");
        c = std::size_t(result);
    }
    if ((algorithm_ != Algorithm::Zlibh && c == 0) || c >= n) {
        mode = 0; std::memcpy(scratch_.data(), src, n); return n;
    }
    if (algorithm_ != Algorithm::Zlibh && c == 1) {
        mode = 1; scratch_[0] = src[0]; return 1;
    }
    mode = 2; return c;
}
void Codec::decode_block(const std::uint8_t* src, std::size_t c, std::uint8_t* dst,
                         std::size_t n, unsigned mode) {
    if (!n || n > block_size || !c || c > n) throw std::runtime_error("invalid block bounds");
    if (mode == 0) {
        if (c != n) throw std::runtime_error("invalid raw size");
        std::memcpy(dst, src, n); return;
    }
    if (mode == 1) {
        if (c != 1 || algorithm_ == Algorithm::Zlibh) throw std::runtime_error("invalid RLE block");
        std::memset(dst, src[0], n); return;
    }
    if (mode != 2 || c >= n) throw std::runtime_error("invalid block mode");
    std::size_t result;
    if (algorithm_ == Algorithm::FSE) {
        result = FSE_decompress(dst, n, src, c);
        if (FSE_isError(result)) throw std::runtime_error(FSE_getErrorName(result));
    } else if (algorithm_ == Algorithm::Huff) {
        HUF_CREATE_STATIC_DTABLEX2(table, HUF_TABLELOG_MAX);
        unsigned workspace[HUF_DECOMPRESS_WORKSPACE_SIZE_U32];
        const int bmi2=std::strcmp(cpu_backend(),"runtime-bmi2")==0;
        result = HUF_decompress4X_hufOnly_wksp_bmi2(table,dst,n,src,c,workspace,sizeof(workspace),bmi2);
        if (HUF_isError(result)) throw std::runtime_error(HUF_getErrorName(result));
    } else {
#ifdef ENTROPY_REFERENCE
        // This historical API has neither length nor capacity. Only verified
        // encoder-produced streams enter the reference worker. Supply actual
        // initialized lookahead storage, which is not serialized payload.
        std::memcpy(scratch_.data(), src, c);
        std::fill_n(scratch_.data() + c, 16, std::uint8_t(0));
        result = std::size_t(ZLIBH_decompress(reinterpret_cast<char*>(dst),
                            reinterpret_cast<const char*>(scratch_.data())));
#else
        result = zlibh_decode_checked(src, c, dst, n);
#endif
    }
    if (result != n) throw std::runtime_error("decoded length mismatch");
}
void Codec::encode(const Bytes& input, Bytes& output, bool framed) {
    if (&input == &output) throw std::runtime_error("overlapping input/output unsupported");
    if (input.size() > max_message) throw std::runtime_error("resource limit");
    output.clear();
    if (framed) {
        output.push_back('F'); output.push_back('E'); output.push_back('C'); output.push_back('1');
        put(output, unsigned(algorithm_), 1); put(output, 0, 3);
        put(output, block_size, 4); put(output, input.size(), 8);
        put(output, (input.size() + block_size - 1) / block_size, 4);
    }
    for (std::size_t p = 0; p < input.size(); p += block_size) {
        const auto n = std::min(block_size, input.size() - p);
        unsigned mode;
        const auto c = encode_block(input.data() + p, n, mode);
        if (framed) {
            put(output, mode, 1); put(output, n, 4); put(output, c, 4);
            put(output, crc32(input.data() + p, n), 4);
        }
        output.insert(output.end(), scratch_.begin(), scratch_.begin() + std::ptrdiff_t(c));
    }
}
void Codec::decode(const Bytes& input, Bytes& output) {
    if (&input == &output) throw std::runtime_error("overlapping input/output unsupported");
    output.clear();
    if (input.size() < 24 || std::memcmp(input.data(), "FEC1", 4)) throw std::runtime_error("invalid magic");
    std::size_t p = 4;
    if (get(input, p, 1) != unsigned(algorithm_) || get(input, p, 3) != 0 || get(input, p, 4) != block_size)
        throw std::runtime_error("unsupported frame configuration");
    const auto total = get(input, p, 8), count = get(input, p, 4);
    if (total > max_message || count != (total + block_size - 1) / block_size)
        throw std::runtime_error("resource limit/invalid block count");
    // Validate the complete block map before allocating an advertised total.
    // This does not invoke a codec (the historical reference decoder still
    // requires trusted payloads), and does not change any valid FEC1 bytes.
    std::size_t scan = p, remaining = std::size_t(total);
    for (std::uint64_t i = 0; i < count; ++i) {
        const auto mode = unsigned(get(input, scan, 1));
        const auto n = std::size_t(get(input, scan, 4));
        const auto c = std::size_t(get(input, scan, 4));
        get(input, scan, 4); // CRC is checked after materialization below.
        if (n != std::min(block_size, remaining) || !c || c > input.size() - scan ||
            (mode == 0 ? c != n : mode == 1 ? c != 1 || algorithm_ == Algorithm::Zlibh :
             mode != 2 || c >= n))
            throw std::runtime_error("invalid/truncated block map");
        scan += c;
        remaining -= n;
    }
    if (scan != input.size() || remaining)
        throw std::runtime_error("trailing/missing bytes");
    output.resize(std::size_t(total));
    std::size_t written = 0;
    for (std::uint64_t i = 0; i < count; ++i) {
        const auto mode = unsigned(get(input, p, 1));
        const auto n = std::size_t(get(input, p, 4)), c = std::size_t(get(input, p, 4));
        const auto checksum = std::uint32_t(get(input, p, 4));
        if (n != std::min(block_size, output.size() - written) || c > input.size() - p)
            throw std::runtime_error("invalid/truncated block");
        decode_block(input.data() + p, c, output.data() + written, n, mode);
        if (crc32(output.data() + written, n) != checksum) throw std::runtime_error("checksum mismatch");
        p += c; written += n;
    }
    if (p != input.size() || written != output.size()) throw std::runtime_error("trailing/missing bytes");
}
}
