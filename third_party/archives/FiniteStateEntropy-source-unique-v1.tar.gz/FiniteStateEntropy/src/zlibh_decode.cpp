// Bounded decoder for the custom ZLIBH format, based on its documented source
// layout. Canonical code construction is independent of vendor inflate_table.
#include "entropy_port.hpp"
#include <algorithm>
#include <array>
#include <stdexcept>

namespace entropy_port {
namespace {
struct Reader {
    const std::uint8_t* p;
    std::size_t n, pos = 0;
    std::uint64_t hold = 0;
    unsigned bits = 0;
    void fill(unsigned wanted) {
        while (bits < wanted && pos < n) {
            hold |= std::uint64_t(p[pos++]) << bits;
            bits += 8;
        }
    }
    unsigned take(unsigned count) {
        fill(count);
        if (bits < count) throw std::runtime_error("truncated zlibh bits");
        const auto v = unsigned(hold & ((1U << count) - 1));
        hold >>= count; bits -= count;
        return v;
    }
};
struct Entry { std::uint16_t symbol = 0; std::uint8_t bits = 0; };
struct Table {
    std::array<Entry, 1U << 15> entries{};
    unsigned width = 0;
    void build(const unsigned* lengths, unsigned count, unsigned limit) {
        std::array<unsigned, 16> counts{}, next{};
        for (unsigned s = 0; s < count; ++s) {
            if (lengths[s] > limit) throw std::runtime_error("invalid zlibh length");
            if (lengths[s]) { ++counts[lengths[s]]; width = std::max(width, lengths[s]); }
        }
        if (!width) throw std::runtime_error("empty zlibh tree");
        int left = 1;
        for (unsigned b = 1; b <= width; ++b) {
            left = left * 2 - int(counts[b]);
            if (left < 0) throw std::runtime_error("oversubscribed zlibh tree");
        }
        // The encoder can emit a one-symbol, one-bit tree.
        if (left && !(width == 1 && counts[1] == 1))
            throw std::runtime_error("incomplete zlibh tree");
        unsigned code = 0;
        for (unsigned b = 1; b <= width; ++b) {
            code = (code + counts[b - 1]) << 1; next[b] = code;
        }
        for (unsigned s = 0; s < count; ++s) {
            const auto len = lengths[s];
            if (!len) continue;
            auto c = next[len]++; unsigned reverse = 0;
            for (unsigned b = 0; b < len; ++b) { reverse = (reverse << 1) | (c & 1U); c >>= 1; }
            for (unsigned slot = reverse; slot < (1U << width); slot += 1U << len)
                entries[slot] = {std::uint16_t(s), std::uint8_t(len)};
        }
    }
    unsigned read(Reader& r) const {
        r.fill(width);
        auto e = entries[unsigned(r.hold) & ((1U << width) - 1)];
        if (!e.bits || e.bits > r.bits) throw std::runtime_error("invalid/truncated zlibh code");
        r.hold >>= e.bits; r.bits -= e.bits;
        return e.symbol;
    }
};
}
std::size_t zlibh_decode_checked(const std::uint8_t* src, std::size_t size,
                                 std::uint8_t* dst, std::size_t capacity) {
    Reader reader{src, size};
    std::array<unsigned, 288> lengths{};
    const bool fixed = reader.take(1) != 0;
    if (fixed) {
        for (unsigned s = 0; s < 288; ++s)
            lengths[s] = s < 144 ? 8U : s < 256 ? 9U : s < 280 ? 7U : 8U;
    } else {
        constexpr unsigned order[19] = {16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15};
        const unsigned ncode = reader.take(4) + 4;
        std::array<unsigned, 19> cl{};
        for (unsigned i = 0; i < ncode; ++i) cl[order[i]] = reader.take(3);
        Table code_lengths;
        code_lengths.build(cl.data(), 19, 7);
        unsigned i = 0;
        while (i < 257) {
            const unsigned v = code_lengths.read(reader);
            if (v < 16) { lengths[i++] = v; continue; }
            if (v == 16 && i == 0) throw std::runtime_error("zlibh repeat without predecessor");
            const unsigned len = v == 16 ? lengths[i - 1] : 0;
            const unsigned repeat = v == 16 ? reader.take(2) + 3 :
                                    v == 17 ? reader.take(3) + 3 : reader.take(7) + 11;
            if (repeat > 257 - i) throw std::runtime_error("zlibh length repeat overflow");
            for (unsigned j = 0; j < repeat; ++j) lengths[i++] = len;
        }
        if (!lengths[256]) throw std::runtime_error("zlibh missing end code");
    }
    Table literals;
    literals.build(lengths.data(), fixed ? 288 : 257, 15);
    std::size_t written = 0;
    for (;;) {
        const unsigned s = literals.read(reader);
        if (s == 256) break;
        if (s > 255 || written == capacity) throw std::runtime_error("zlibh output overflow/invalid symbol");
        dst[written++] = std::uint8_t(s);
    }
    const auto consumed = reader.pos - reader.bits / 8;
    if (consumed != size) throw std::runtime_error("zlibh trailing bytes");
    return written;
}
}
