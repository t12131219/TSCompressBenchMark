#include "entropy_port.hpp"
#include <algorithm>
#include <charconv>
#include <chrono>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <string>
using namespace entropy_port;
using Clock=std::chrono::steady_clock;
static unsigned number(const char* s) {
    unsigned n=0;const auto e=s+std::char_traits<char>::length(s);const auto r=std::from_chars(s,e,n);
    if(r.ec!=std::errc() || r.ptr!=e)throw std::runtime_error("invalid integer");return n;
}
static long long ns(Clock::time_point a) {return std::chrono::duration_cast<std::chrono::nanoseconds>(Clock::now()-a).count();}
int main(int argc,char** argv) {
 try {
    if(argc!=7 && argc!=8)throw std::runtime_error("usage: entropy_features ALGORITHM TABLE_LOG MAX_SYMBOL REUSE(0|1) INPUT ITERATIONS [HUFFMAN_STREAMS(1|4)]");
    const unsigned streams=argc==8?number(argv[7]):4;
    const auto alg=Algorithm(number(argv[1]));const unsigned log=number(argv[2]),max=number(argv[3]),reuse=number(argv[4]),iters=number(argv[6]);
    if(reuse>1 || iters<1 || iters>10000 || max>255)throw std::runtime_error("invalid configuration");
    std::ifstream in(argv[5],std::ios::binary|std::ios::ate);if(!in)throw std::runtime_error("open input failed");
    const auto len=in.tellg();if(len<0 || std::uint64_t(len)>max_message)throw std::runtime_error("input too large");
    Bytes input{ };input.resize(std::size_t(len));in.seekg(0);
    if(!input.empty() && !in.read(reinterpret_cast<char*>(input.data()),std::streamsize(input.size())))throw std::runtime_error("read failed");
    const auto start=Clock::now();std::unique_ptr<TableCodec> table,reader;std::unique_ptr<Codec> codec;
    if(reuse) {
        if(max!=255)throw std::runtime_error("add-one table profile requires max_symbol=255");
        Bytes train(input.begin(),input.begin()+std::ptrdiff_t(std::min(input.size(),block_size)));
        if(train.empty())train.push_back(0);
        table.reset(new TableCodec(alg,train,log,streams));reader.reset(new TableCodec(table->model()));
    } else codec.reset(new Codec(alg,Options{max,log}));
    const auto setup_ns=ns(start);
    std::vector<Bytes> encoded;Bytes frame,restored;std::size_t stored=0;
    auto encode=[&] {
        if(!reuse){codec->encode(input,frame);stored=frame.size();return;}
        encoded.clear();stored=table->model().size();
        for(std::size_t p=0;p<input.size();p+=block_size){
            Bytes b(input.begin()+std::ptrdiff_t(p),input.begin()+std::ptrdiff_t(std::min(p+block_size,input.size())));
            encoded.push_back(table->encode_block(b));stored+=encoded.back().size();
        }
    };
    auto decode=[&] {
        if(!reuse){codec->decode(frame,restored);return;}
        restored.clear();for(const auto& b:encoded){auto d=reader->decode_block(b);restored.insert(restored.end(),d.begin(),d.end());}
    };
    encode();decode();if(input!=restored)throw std::runtime_error("recovery failed");
    auto t=Clock::now();for(unsigned i=0;i<iters;++i)encode();const auto enc=ns(t);
    t=Clock::now();for(unsigned i=0;i<iters;++i)decode();const auto dec=ns(t);
    if(input!=restored)throw std::runtime_error("timed recovery failed");
    std::cout<<"{\"profile\":\""<<(reuse?"ETB1-add-one-reuse":"FEC1-independent")<<"\",\"algorithm\":"<<unsigned(alg)
      <<",\"requested_table_log\":"<<log<<",\"effective_model_table_log\":"<<(reuse?table->effective_table_log():0)
      <<",\"huffman_streams\":"<<(reuse?table->huffman_streams():0)
      <<",\"max_symbol\":"<<max<<",\"backend\":\""<<(alg==Algorithm::Huff?cpu_backend():"portable")<<"\",\"input_bytes\":"<<input.size()
      <<",\"representation_bytes\":"<<stored<<",\"model_bytes\":"<<(reuse?table->model().size():0)
      <<",\"model_crc32\":"<<(reuse?crc32(table->model().data(),table->model().size()):0)
      <<",\"setup_ns\":"<<setup_ns<<",\"iterations\":"<<iters<<",\"encode_ns\":"<<enc<<",\"decode_ns\":"<<dec<<",\"verified\":true}\n";
 }catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}
}
