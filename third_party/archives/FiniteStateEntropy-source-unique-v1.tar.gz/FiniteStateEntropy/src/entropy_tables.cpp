#include "entropy_port.hpp"
#include <array>
#include <algorithm>
#include <cstring>
#include <stdexcept>
#include <string>
extern "C" {
#define FSE_STATIC_LINKING_ONLY
#define HUF_STATIC_LINKING_ONLY
#include "fse.h"
#include "huf.h"
}
namespace entropy_port {
const char* cpu_backend() {
#if ENTROPY_DYNAMIC_BMI2 && (defined(__x86_64__) || defined(__i386__)) && (defined(__GNUC__) || defined(__clang__))
    return __builtin_cpu_supports("bmi2") ? "runtime-bmi2" : "runtime-portable";
#else
    return "portable";
#endif
}
namespace {
std::size_t checked(std::size_t n, const char* op="entropy") {
    if (FSE_isError(n)) throw std::runtime_error(std::string(op)+": "+FSE_getErrorName(n));
    return n;
}
void put32(Bytes& b, std::size_t n) {
    for (unsigned j=0; j<4; ++j) b.push_back(std::uint8_t(n>>(8*j)));
}
std::size_t get32(const Bytes& b, std::size_t p) {
    if (p>b.size() || b.size()-p<4) throw std::runtime_error("truncated entropy block");
    std::size_t n=0; for (unsigned j=0;j<4;++j) n|=std::size_t(b[p+j])<<(8*j); return n;
}
}
struct TableCodec::Impl {
    Algorithm alg;
    unsigned log=0, streams=0;
    Bytes header;
    std::array<unsigned, FSE_CTABLE_SIZE_U32(12,255)> fc{};
    std::array<unsigned, FSE_DTABLE_SIZE_U32(12)> fd{};
    std::array<unsigned, HUF_CTABLE_SIZE_U32(255)> hc{};
    std::array<unsigned, HUF_DTABLE_SIZE(12)> hd{};
    HUF_CElt* hct() { return reinterpret_cast<HUF_CElt*>(hc.data()); }
    const HUF_CElt* hct() const { return reinterpret_cast<const HUF_CElt*>(hc.data()); }
    void load(const Bytes& b) {
        if(b.size()<9 || b.size()>1024 || std::memcmp(b.data(),"ETB1",4) || b[7]!=0 || (b[4]!=1 && b[4]!=2))
            throw std::runtime_error("invalid entropy model");
        alg=Algorithm(b[4]);log=b[5];streams=b[6];
        if(alg==Algorithm::FSE ? streams!=0 : streams!=1 && streams!=4) throw std::runtime_error("invalid entropy streams");
        if(log<9U || log>12) throw std::runtime_error("invalid entropy model log");
        if(alg==Algorithm::FSE) {
            short norm[256]{};unsigned max=255,actual=0;
            const auto used=checked(FSE_readNCount(norm,&max,&actual,b.data()+8,b.size()-8));
            if(used!=b.size()-8 || actual!=log || max!=255) throw std::runtime_error("invalid FSE model");
            for(auto v:norm) if(!v) throw std::runtime_error("model must cover every byte");
            checked(FSE_buildCTable(fc.data(),norm,max,log));checked(FSE_buildDTable(fd.data(),norm,max,log));
        } else {
            unsigned max=255,zeros=0;
            const auto used=checked(HUF_readCTable(hct(),&max,b.data()+8,b.size()-8,&zeros),"HUF_readCTable");
            if(used!=b.size()-8 || max!=255 || zeros) throw std::runtime_error("invalid HUF model");
            hd[0]=12*0x01000001U;
            if(checked(HUF_readDTableX2(hd.data(),b.data()+8,b.size()-8),"HUF_readDTableX2")!=b.size()-8)
                throw std::runtime_error("invalid HUF model length");
        }
        header=b;
    }
};
TableCodec::TableCodec(Algorithm alg,const Bytes& training,unsigned log,unsigned streams):impl_(new Impl) {
    if((alg==Algorithm::Huff && streams!=1 && streams!=4) || (alg!=Algorithm::FSE && alg!=Algorithm::Huff) || training.empty() || training.size()>block_size || (log && (log<9U || log>12)))
        throw std::runtime_error("invalid entropy training options");
    std::array<unsigned,256> counts;counts.fill(1);
    for(auto x:training) ++counts[x];
    Bytes model(1024);model[0]='E';model[1]='T';model[2]='B';model[3]='1';model[4]=std::uint8_t(alg);model[6]=std::uint8_t(alg==Algorithm::Huff?streams:0);
    std::size_t size;
    if(alg==Algorithm::FSE) {
        short norm[256]{};
        if(!log) log=FSE_optimalTableLog(0,training.size()+256,255);
        log=unsigned(checked(FSE_normalizeCount(norm,log,counts.data(),training.size()+256,255)));
        size=checked(FSE_writeNCount(model.data()+8,model.size()-8,norm,255,log));
    } else {
        if(!log) log=HUF_TABLELOG_DEFAULT;
        log=unsigned(checked(HUF_buildCTable(impl_->hct(),counts.data(),255,log),"HUF_buildCTable"));
        size=checked(HUF_writeCTable(model.data()+8,model.size()-8,impl_->hct(),255,log),"HUF_writeCTable");
    }
    model[5]=std::uint8_t(log);model.resize(size+8);impl_->load(model);
}
TableCodec::TableCodec(const Bytes& model):impl_(new Impl) { impl_->load(model); }
TableCodec::~TableCodec()=default;
const Bytes& TableCodec::model() const { return impl_->header; }
unsigned TableCodec::effective_table_log() const { return impl_->log; }
unsigned TableCodec::huffman_streams() const { return impl_->streams; }
Bytes TableCodec::encode_block(const Bytes& input) const {
    if(input.size()>block_size) throw std::runtime_error("entropy table block too large");
    Bytes b(9+2*block_size+4096);std::size_t c=0;
    if(input.size()>1) {
        if(impl_->alg==Algorithm::FSE)
            c=checked(FSE_compress_usingCTable(b.data()+9,b.size()-9,input.data(),input.size(),impl_->fc.data()));
        else c=checked(impl_->streams==1 ? HUF_compress1X_usingCTable(b.data()+9,b.size()-9,input.data(),input.size(),impl_->hct()) : HUF_compress4X_usingCTable(b.data()+9,b.size()-9,input.data(),input.size(),impl_->hct()));
    }
    const bool compressed=c>0 && c<input.size();
    if(!compressed) { c=input.size();if(c) std::memcpy(b.data()+9,input.data(),c); }
    b[0]=std::uint8_t(compressed);Bytes h{b[0]};put32(h,input.size());put32(h,c);
    std::copy(h.begin(),h.end(),b.begin());b.resize(9+c);return b;
}
Bytes TableCodec::decode_block(const Bytes& b) const {
    if(b.size()<9 || b[0]>1) throw std::runtime_error("invalid entropy block");
    const auto n=get32(b,1),c=get32(b,5);
    if(n>block_size || c!=b.size()-9 || (b[0] ? !c || c>=n : c!=n)) throw std::runtime_error("invalid entropy block bounds");
    Bytes out(n);
    if(!b[0]) { if(n)std::memcpy(out.data(),b.data()+9,n); }
    else {
        std::size_t r;
        if(impl_->alg==Algorithm::FSE)r=checked(FSE_decompress_usingDTable(out.data(),n,b.data()+9,c,impl_->fd.data()));
        else { const int bmi2=std::strcmp(cpu_backend(),"runtime-bmi2")==0;
            r=checked(impl_->streams==1 ? HUF_decompress1X_usingDTable_bmi2(out.data(),n,b.data()+9,c,impl_->hd.data(),bmi2) : HUF_decompress4X_usingDTable_bmi2(out.data(),n,b.data()+9,c,impl_->hd.data(),bmi2)); }
        if(r!=n)throw std::runtime_error("entropy table decoded length");
    }
    return out;
}
}
