#pragma once
#include <cstddef>
#include <cstdint>
#include <vector>
#include <memory>

namespace entropy_port {
using Bytes = std::vector<std::uint8_t>;
enum class Algorithm : unsigned { FSE = 1, Huff = 2, Zlibh = 3 };
constexpr std::size_t block_size = 32768;
constexpr std::size_t max_message = 256 * 1024 * 1024;
struct Options {
    unsigned max_symbol = 255;
    unsigned table_log = 0; // 0 = frozen upstream default; effective log can be smaller
};
const char* cpu_backend();
// Stateless independent blocks. Storage may be reused; history is never shared.
class Codec {
public:
    explicit Codec(Algorithm algorithm);
    Codec(Algorithm algorithm, Options options);
    Options options() const { return options_; }
    void encode(const Bytes& input, Bytes& output, bool framed = true);
    void decode(const Bytes& input, Bytes& output);
    // Valid block API for the standalone codec-only measurement.
    std::size_t encode_block(const std::uint8_t*, std::size_t, unsigned& mode);
    void decode_block(const std::uint8_t*, std::size_t, std::uint8_t*, std::size_t, unsigned mode);
    const Bytes& scratch() const { return scratch_; }
private:
    Algorithm algorithm_;
    Options options_;
    Bytes scratch_;
};
// Explicit model profile: a frozen native entropy table, transmitted once,
// then independent blocks. Model and each block are separate serialized Bytes.
// Training uses add-one byte counts so any subsequent byte is representable.
// No dependency on an external language, database or implicit training state.
class TableCodec {
public:
    TableCodec(Algorithm, const Bytes& training, unsigned table_log = 0, unsigned huffman_streams = 4);
    explicit TableCodec(const Bytes& model);
    ~TableCodec();
    TableCodec(const TableCodec&) = delete;
    TableCodec& operator=(const TableCodec&) = delete;
    const Bytes& model() const;
    unsigned effective_table_log() const;
    unsigned huffman_streams() const;
    Bytes encode_block(const Bytes&) const; // 0..32768 bytes, 9 B block header
    Bytes decode_block(const Bytes&) const; // bounded by block_size
private:
    struct Impl;
    std::unique_ptr<Impl> impl_;
};
// Length/capacity checked, independently implemented canonical Huffman decoder.
std::size_t zlibh_decode_checked(const std::uint8_t*, std::size_t,
                                 std::uint8_t*, std::size_t);
std::uint32_t crc32(const std::uint8_t*, std::size_t);
const char* implementation_id();
}
