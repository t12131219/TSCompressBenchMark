# Sources and attribution

CORAD source: https://github.com/eXascaleInfolab/CORAD, master commit `083824eb3e0b3ad72a00d4f585bc77b5adb5c1be`. Source authors/README contributors: Abdelouahab Khelifati and Mourad Khayati. Citation: Khelifati, Khayati, Cudré-Mauroux, Big Data 2019, pp.2289–2298, DOI 10.1109/BigData47090.2019.9005580.

The repository tree at this commit has no LICENSE file and no explicit license grant in the README. Its snapshot is retained with original notices; no MIT/Apache permission is invented here. This local engineering deliverable is not an assertion of upstream redistribution rights.

The OMP Cholesky/permutation contract follows the algorithm used by scikit-learn 1.3.0 `_gram_omp`. The native encoders are new C11/C++17 implementations with independent memory management. scikit-learn BSD-3-Clause notice is included in `third_party/scikit-learn-COPYING`. Actual original sparse coding and dictionary learning are executed through installed scikit-learn 1.3.0. NumPy 1.24.3, SciPy 1.11.1, pandas 2.0.3 and Python 3.11.5 are build/test/oracle dependencies, not linked native runtime dependencies.

There are no upstream-source patches. AST extraction selects unchanged named function nodes, omitting inactive plotting, luminol and CLI imports. Adaptation ledger and source hashes define what is executed. `corad_c` is compiled and linked as C, requires libm/libc, and does not require libstdc++. Combined `corad` includes the C++ encoder and shares the C serializer/decoder. Both independently implement OMP and correlation selection. Native inference APIs need a trained dictionary supplied by caller; the original offline learner is intentionally retained and is not a native dictionary learner.
