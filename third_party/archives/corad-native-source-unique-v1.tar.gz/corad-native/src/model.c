/* Portable frozen model: an existing self-contained CRD1 frame with zero rows. */
#include "internal.h"
#include <stdlib.h>
struct corad_model {corad_config cfg;double *dictionary,*mean,*scale;};
void corad_model_free(corad_model *m) {if(m){free(m->dictionary);free(m->mean);free(m->scale);free(m);}}
int corad_model_pack(const corad_config *cfg,const double *dictionary,const double *mean,const double *scale,
                     uint8_t *out,size_t cap,size_t *written) {
  if(!written)return CORAD_INVALID;
  *written=0;if(!cfg)return CORAD_INVALID;
  corad_config c=*cfg;c.rows=0;
  return corad_c_encode(&c,NULL,dictionary,mean,scale,out,cap,written);
}
int corad_model_load(const uint8_t *p,size_t size,corad_model **result) {
  if(!result)return CORAD_INVALID;
  *result=NULL;
  /* corad_decode checks full lengths, schema, finite dictionary and positive scales. */
  corad_config c;size_t count=0;
  int e=corad_decode(p,size,NULL,0,0,&count,&c);if(e)return e;
  if(c.rows)return CORAD_STREAM;
  corad_model *m=calloc(1,sizeof(*m));if(!m)return CORAD_MEMORY;
  m->cfg=c;size_t k=(size_t)c.atoms*c.tricklet;
  m->dictionary=malloc(k*sizeof(double));m->mean=malloc(c.columns*sizeof(double));m->scale=malloc(c.columns*sizeof(double));
  if(!m->dictionary||!m->mean||!m->scale){corad_model_free(m);return CORAD_MEMORY;}
  const uint8_t *at=p+32;
  for(size_t j=0;j<k;j++)m->dictionary[j]=cr_rf64(&at);
  for(size_t j=0;j<c.columns;j++){m->mean[j]=cr_rf64(&at);m->scale[j]=cr_rf64(&at);}
  *result=m;return CORAD_OK;
}
int corad_model_config(const corad_model *m,uint32_t rows,uint16_t nonzero,double threshold,corad_config *cfg) {
  if(!m||!cfg)return CORAD_INVALID;
  corad_config c=m->cfg;c.rows=rows;c.nonzero=nonzero;c.threshold=threshold;
  if(!cr_valid(&c))return CORAD_INVALID;
  *cfg=c;return CORAD_OK;
}
int corad_model_info(const corad_model *m,corad_config *cfg) {if(!m||!cfg)return CORAD_INVALID;*cfg=m->cfg;return CORAD_OK;}
int corad_model_encode(const corad_model *m,const corad_config *cfg,const double *x,uint8_t *out,size_t cap,size_t *written) {
  if(!written)return CORAD_INVALID;
  *written=0;
  if(!m||!cfg||cfg->columns!=m->cfg.columns||cfg->tricklet!=m->cfg.tricklet||cfg->atoms!=m->cfg.atoms)return CORAD_INVALID;
  return corad_c_encode(cfg,x,m->dictionary,m->mean,m->scale,out,cap,written);
}

size_t corad_model_size(const corad_model*m){return m?corad_bound(&m->cfg):0;}
int corad_model_save(const corad_model*m,uint8_t*out,size_t capacity,size_t*written){
 if(written)*written=0;if(!m||!written)return CORAD_INVALID;
 return corad_model_pack(&m->cfg,m->dictionary,m->mean,m->scale,out,capacity,written);
}
