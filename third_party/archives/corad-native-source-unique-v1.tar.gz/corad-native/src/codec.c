#include "internal.h"
#include <stdlib.h>
size_t corad_bound(const corad_config *c) {
  if (!cr_valid(c))
    return 0;
  size_t per = 2 + ((size_t)c->nonzero * 10 > 2 ? (size_t)c->nonzero * 10 : 2);
  return 32 + (size_t)c->atoms * c->tricklet * 8 + (size_t)c->columns * 16 +
         (size_t)(c->rows / c->tricklet) * c->columns * per +
         (size_t)(c->rows % c->tricklet) * c->columns * 8;
}
int corad_decode(const uint8_t *data, size_t size, double *out, size_t capacity,
                 size_t max_values, size_t *count, corad_config *cfg) {
  if (!count)
    return CORAD_INVALID;
  *count = 0;
  if (!data || size < 32)
    return CORAD_STREAM;
  const uint8_t *p = data, *end = data + size;
  if (memcmp(p, "CRD1", 4))
    return CORAD_STREAM;
  p += 4;
  corad_config c;
  c.rows = cr_r32(&p);
  c.columns = cr_r16(&p);
  c.tricklet = cr_r16(&p);
  c.atoms = cr_r16(&p);
  c.nonzero = cr_r16(&p);
  c.threshold = cr_rf64(&p);
  uint64_t total = cr_r64(&p);
  if (!cr_valid(&c) || total != size)
    return CORAD_STREAM;
  size_t values = (size_t)c.rows * c.columns;
  if (values > capacity || values > max_values || (!out && values))
    return CORAD_CAPACITY;
  size_t model = (size_t)c.atoms * c.tricklet;
  if ((size_t)(end - p) < model * 8 + (size_t)c.columns * 16)
    return CORAD_STREAM;
  double *d = (double *)malloc(model * sizeof(double));
  double *z = (double *)calloc((size_t)c.columns * c.tricklet, sizeof(double));
  if (!d || !z) {
    free(d);
    free(z);
    return CORAD_MEMORY;
  }
  int status = CORAD_STREAM;
  double mean[64], scale[64];
  for (size_t i = 0; i < model; i++) {
    d[i] = cr_rf64(&p);
    if (!isfinite(d[i]))
      goto done;
  }
  for (int i = 0; i < c.columns; i++) {
    mean[i] = cr_rf64(&p);
    scale[i] = cr_rf64(&p);
    if (!isfinite(mean[i]) || !isfinite(scale[i]) || scale[i] <= 0)
      goto done;
  }
  for (size_t w = 0; w < c.rows / c.tricklet; w++) {
    int refs[64];
    memset(z, 0, (size_t)c.columns * c.tricklet * sizeof(double));
    for (int col = 0; col < c.columns; col++) {
      if (end - p < 2)
        goto done;
      uint16_t nz = cr_r16(&p);
      refs[col] = -1;
      if (nz == 65535) {
        if (end - p < 2)
          goto done;
        refs[col] = cr_r16(&p);
        if (refs[col] >= c.columns || refs[col] == col)
          goto done;
      } else {
        if (nz > c.nonzero || (size_t)(end - p) < (size_t)nz * 10)
          goto done;
        int last = -1;
        for (int j = 0; j < nz; j++) {
          uint16_t atom = cr_r16(&p);
          double coef = cr_rf64(&p);
          if (atom >= c.atoms || atom <= last || !isfinite(coef) || coef == 0)
            goto done;
          last = atom;
          for (int t = 0; t < c.tricklet; t++)
            z[(size_t)col * c.tricklet + t] +=
                coef * d[(size_t)atom * c.tricklet + t];
        }
      }
    }
    for (int col = 0; col < c.columns; col++)
      if (refs[col] >= 0) {
        if (refs[refs[col]] >= 0)
          goto done;
        memcpy(z + (size_t)col * c.tricklet, z + (size_t)refs[col] * c.tricklet,
               c.tricklet * sizeof(double));
      }
    for (int col = 0; col < c.columns; col++)
      for (int t = 0; t < c.tricklet; t++) {
        double value = z[(size_t)col * c.tricklet + t] * scale[col] + mean[col];
        if (!isfinite(value))
          goto done;
        out[(size_t)col * c.rows + w * c.tricklet + t] = value;
      }
  }
  for (int col = 0; col < c.columns; col++)
    for (size_t t = (c.rows / c.tricklet) * c.tricklet; t < c.rows; t++) {
      if (end - p < 8)
        goto done;
      double v = cr_rf64(&p);
      if (!isfinite(v))
        goto done;
      out[(size_t)col * c.rows + t] = v;
    }
  if (p != end)
    goto done;
  *count = values;
  if (cfg)
    *cfg = c;
  status = CORAD_OK;
done:
  free(d);
  free(z);
  return status;
}
