#ifndef CORAD_INTERNAL_H
#define CORAD_INTERNAL_H
#include "corad.h"
#include <float.h>
#include <math.h>
#include <string.h>
static inline void cr_u16(uint8_t **p, uint16_t x) {
  (*p)[0] = (uint8_t)x;
  (*p)[1] = (uint8_t)(x >> 8);
  *p += 2;
}
static inline void cr_u32(uint8_t **p, uint32_t x) {
  for (int i = 0; i < 4; i++)
    (*p)[i] = (uint8_t)(x >> (i * 8));
  *p += 4;
}
static inline void cr_u64(uint8_t **p, uint64_t x) {
  for (int i = 0; i < 8; i++)
    (*p)[i] = (uint8_t)(x >> (i * 8));
  *p += 8;
}
static inline void cr_f64(uint8_t **p, double x) {
  uint64_t u;
  memcpy(&u, &x, 8);
  cr_u64(p, u);
}
static inline uint16_t cr_r16(const uint8_t **p) {
  uint16_t u = (uint16_t)((*p)[0] | (uint16_t)(*p)[1] << 8);
  *p += 2;
  return u;
}
static inline uint32_t cr_r32(const uint8_t **p) {
  uint32_t u = 0;
  for (int i = 0; i < 4; i++)
    u |= (uint32_t)(*p)[i] << (8 * i);
  *p += 4;
  return u;
}
static inline uint64_t cr_r64(const uint8_t **p) {
  uint64_t u = 0;
  for (int i = 0; i < 8; i++)
    u |= (uint64_t)(*p)[i] << (8 * i);
  *p += 8;
  return u;
}
static inline double cr_rf64(const uint8_t **p) {
  uint64_t u = cr_r64(p);
  double x;
  memcpy(&x, &u, 8);
  return x;
}
static inline int cr_valid(const corad_config *c) {
  return c && c->rows <= 1000000 && c->columns && c->columns <= 64 &&
         (size_t)c->rows * c->columns <= 8000000 && c->tricklet &&
         c->tricklet <= 128 && c->atoms && c->atoms <= 512 && c->nonzero &&
         c->nonzero <= 32 && c->nonzero <= c->atoms &&
         c->nonzero <= c->tricklet && isfinite(c->threshold) &&
         c->threshold >= -1 && c->threshold <= 1;
}
static inline int cr_inputs(const corad_config *c, const double *x,
                            const double *d, const double *m, const double *s) {
  if (!cr_valid(c) || (!x && c->rows) || !d || !m || !s)
    return 0;
  for (size_t i = 0; i < (size_t)c->atoms * c->tricklet; i++)
    if (!isfinite(d[i]))
      return 0;
  for (int i = 0; i < c->columns; i++)
    if (!isfinite(m[i]) || !isfinite(s[i]) || s[i] <= 0)
      return 0;
  for (size_t i = 0; i < (size_t)c->rows * c->columns; i++)
    if (!isfinite(x[i]))
      return 0;
  return 1;
}
static inline uint8_t *cr_header(uint8_t *out, const corad_config *c,
                                 const double *d, const double *m,
                                 const double *s) {
  uint8_t *p = out;
  memcpy(p, "CRD1", 4);
  p += 4;
  cr_u32(&p, c->rows);
  cr_u16(&p, c->columns);
  cr_u16(&p, c->tricklet);
  cr_u16(&p, c->atoms);
  cr_u16(&p, c->nonzero);
  cr_f64(&p, c->threshold);
  cr_u64(&p, 0);
  for (size_t i = 0; i < (size_t)c->atoms * c->tricklet; i++)
    cr_f64(&p, d[i]);
  for (int i = 0; i < c->columns; i++) {
    cr_f64(&p, m[i]);
    cr_f64(&p, s[i]);
  }
  return p;
}
#endif
