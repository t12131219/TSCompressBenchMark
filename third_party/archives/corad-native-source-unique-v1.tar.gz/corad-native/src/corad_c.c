#include "internal.h"
#include <stdlib.h>
/* Gram OMP with permutation indirection avoids sklearn's full Gram copy per
 * target. */
static int omp_c(const double *g, const double *d, const double *y, int k,
                 int l, int target, double *co) {
  double xy[512], alpha[512], chol[32 * 32] = {0}, gamma[32] = {0};
  int perm[512];
  for (int i = 0; i < k; i++) {
    xy[i] = 0;
    perm[i] = i;
    co[i] = 0;
    for (int t = 0; t < l; t++)
      xy[i] += d[(size_t)i * l + t] * y[t];
    alpha[i] = xy[i];
  }
  int active = 0;
  while (active < target) {
    int best = 0;
    for (int i = 1; i < k; i++)
      if (fabs(alpha[i]) > fabs(alpha[best]))
        best = i;
    if (best < active || alpha[best] * alpha[best] < DBL_EPSILON)
      break;
    double diag = g[(size_t)perm[best] * k + perm[best]];
    if (active) {
      double sum = 0;
      for (int i = 0; i < active; i++) {
        double v = g[(size_t)perm[best] * k + perm[i]];
        for (int j = 0; j < i; j++)
          v -= chol[active * 32 + j] * chol[i * 32 + j];
        v /= chol[i * 32 + i];
        chol[active * 32 + i] = v;
        sum += v * v;
      }
      diag -= sum;
      if (diag <= DBL_EPSILON)
        break;
    }
    if (!isfinite(diag) || diag <= 0)
      return CORAD_INVALID;
    chol[active * 32 + active] = sqrt(diag);
    int ip = perm[active];
    perm[active] = perm[best];
    perm[best] = ip;
    double xp = xy[active];
    xy[active] = xy[best];
    xy[best] = xp;
    active++;
    for (int i = 0; i < active; i++) {
      double v = xy[i];
      for (int j = 0; j < i; j++)
        v -= chol[i * 32 + j] * gamma[j];
      gamma[i] = v / chol[i * 32 + i];
    }
    for (int i = active - 1; i >= 0; i--) {
      double v = gamma[i];
      for (int j = i + 1; j < active; j++)
        v -= chol[j * 32 + i] * gamma[j];
      gamma[i] = v / chol[i * 32 + i];
    }
    for (int i = 0; i < k; i++) {
      double beta = 0;
      for (int j = 0; j < active; j++)
        beta += g[(size_t)perm[i] * k + perm[j]] * gamma[j];
      alpha[i] = xy[i] - beta;
    }
  }
  for (int i = 0; i < active; i++) {
    if (!isfinite(gamma[i]))
      return CORAD_INVALID;
    co[perm[i]] = gamma[i];
  }
  return CORAD_OK;
}
static double pearson_c(const double *x, const double *y, int n) {
  double mx = 0, my = 0, sx = 0, sy = 0, cv = 0;
  for (int t = 0; t < n; t++) {
    double dx = x[t] - mx, dy = y[t] - my;
    mx += dx / (t + 1);
    my += dy / (t + 1);
    sx += (x[t] - mx) * dx;
    sy += (y[t] - my) * dy;
    cv += (x[t] - mx) * dy;
  }
  if (!isfinite(sx) || !isfinite(sy) || !isfinite(cv) || !isfinite(sx * sy))
    return INFINITY;
  double den = sqrt(sx * sy);
  if (den == 0)
    return NAN;
  double v = cv / den;
  if (v > 1)
    v = 1;
  if (v < -1)
    v = -1;
  return v;
}
int corad_c_encode(const corad_config *c, const double *x, const double *d,
                   const double *m, const double *s, uint8_t *out,
                   size_t capacity, size_t *written) {
  if (!written)
    return CORAD_INVALID;
  *written = 0;
  if (!cr_inputs(c, x, d, m, s) || !out)
    return CORAD_INVALID;
  if (capacity < corad_bound(c))
    return CORAD_CAPACITY;
  int k = c->atoms, l = c->tricklet, cols = c->columns, status = CORAD_INVALID;
  double *g = (double *)malloc((size_t)k * k * sizeof(double));
  double *z = (double *)malloc((size_t)cols * l * sizeof(double));
  double *co = (double *)malloc((size_t)cols * k * sizeof(double));
  if (!g || !z || !co) {
    status = CORAD_MEMORY;
    goto done;
  }
  if (c->rows >= (unsigned)l)
    for (int i = 0; i < k; i++)
      for (int j = 0; j <= i; j++) {
        double v = 0;
        for (int t = 0; t < l; t++)
          v += d[(size_t)i * l + t] * d[(size_t)j * l + t];
        if (!isfinite(v))
          goto done;
        g[(size_t)i * k + j] = g[(size_t)j * k + i] = v;
      }
  uint8_t *p = cr_header(out, c, d, m, s);
  for (size_t w = 0; w < c->rows / (size_t)l; w++) {
    double corr[64 * 64], sums[64];
    int order[64], stored[64] = {0}, refs[64];
    for (int a = 0; a < cols; a++) {
      for (int t = 0; t < l; t++) {
        z[(size_t)a * l + t] =
            (x[(size_t)a * c->rows + w * l + t] - m[a]) / s[a];
        if (!isfinite(z[(size_t)a * l + t]))
          goto done;
      }
      if (omp_c(g, d, z + (size_t)a * l, k, l, c->nonzero, co + (size_t)a * k))
        goto done;
    }
    for (int a = 0; a < cols; a++)
      for (int b = 0; b <= a; b++) {
        double v = pearson_c(z + (size_t)a * l, z + (size_t)b * l, l);
        if (isinf(v))
          goto done;
        corr[a * 64 + b] = corr[b * 64 + a] = v;
      }
    for (int a = 0; a < cols; a++) {
      sums[a] = 0;
      order[a] = a;
      for (int b = 0; b < cols; b++)
        sums[a] += corr[a * 64 + b];
    }
    for (int a = 1; a < cols; a++) {
      int id = order[a], j = a;
      while (j > 0 && sums[id] > sums[order[j - 1]]) {
        order[j] = order[j - 1];
        j--;
      }
      order[j] = id;
    }
    for (int q = 0; q < cols; q++) {
      int a = order[q], best = -1;
      double top = -INFINITY;
      for (int b = 0; b < cols; b++)
        if (stored[b] && b != a && corr[a * 64 + b] >= c->threshold &&
            corr[a * 64 + b] > top) {
          best = b;
          top = corr[a * 64 + b];
        }
      refs[a] = best;
      if (best < 0)
        stored[a] = 1;
    }
    for (int a = 0; a < cols; a++) {
      if (refs[a] >= 0) {
        cr_u16(&p, 65535);
        cr_u16(&p, (uint16_t)refs[a]);
      } else {
        int nz = 0;
        for (int j = 0; j < k; j++)
          nz += co[(size_t)a * k + j] != 0;
        cr_u16(&p, (uint16_t)nz);
        for (int j = 0; j < k; j++)
          if (co[(size_t)a * k + j] != 0) {
            cr_u16(&p, (uint16_t)j);
            cr_f64(&p, co[(size_t)a * k + j]);
          }
      }
    }
  }
  for (int a = 0; a < cols; a++)
    for (size_t t = (c->rows / (size_t)l) * l; t < c->rows; t++)
      cr_f64(&p, x[(size_t)a * c->rows + t]);
  *written = (size_t)(p - out);
  p = out + 24;
  cr_u64(&p, *written);
  status = CORAD_OK;
done:
  free(g);
  free(z);
  free(co);
  return status;
}
