/* Batch dictionary learning, C11. LASSO uses a signed active-set homotopy
 * (LARS with drop events); coordinate descent is a separately named option.
 * Initialization is a covariance Jacobi SVD. Portable RNG resampling does not
 * claim sklearn/NumPy RNG byte identity. Dictionary projection matches source. */
#include "internal.h"
#include <stdlib.h>
#define LIMIT ((size_t)1<<26)
static uint64_t rng64(uint64_t*s){uint64_t x=*s;x^=x>>12;x^=x<<25;x^=x>>27;*s=x;return x*UINT64_C(2685821657736338717);}
static double uniform(uint64_t*s){return ((rng64(s)>>11)+.5)*0x1.0p-53;}
static double normal(uint64_t*s){return sqrt(-2*log(uniform(s)))*cos(6.2831853071795864769*uniform(s));}
static double dot(const double*a,const double*b,size_t n){double s=0;for(size_t j=0;j<n;j++)s+=a[j]*b[j];return s;}
void corad_train_options_init(corad_train_options*t){if(!t)return;memset(t,0,sizeof(*t));t->size=sizeof(*t);t->version=1;t->max_iter=10;t->solver_max_iter=1000;t->alpha=1;t->tolerance=1e-8;t->solver_tolerance=1e-9;t->seed=20261103;t->normalize=1;t->max_training_samples=65536;}
static int options_valid(const corad_train_options*t){return t&&t->size==sizeof(*t)&&t->version==1&&t->max_iter&&t->max_iter<=10000&&t->solver_max_iter&&t->solver_max_iter<=100000&&t->solver<=1&&t->normalize<=1&&t->max_training_samples&&t->max_training_samples<=8000000&&isfinite(t->alpha)&&t->alpha>0&&isfinite(t->tolerance)&&t->tolerance>=0&&isfinite(t->solver_tolerance)&&t->solver_tolerance>0;}
static void gram(const double*d,size_t k,size_t f,double*g){for(size_t i=0;i<k;i++)for(size_t j=0;j<=i;j++)g[i*k+j]=g[j*k+i]=dot(d+i*f,d+j*f,f);}
static double kkt(const double*g,const double*b,const double*x,size_t k,double alpha){double worst=0;for(size_t j=0;j<k;j++){double c=b[j]-dot(g+j*k,x,k),v=x[j]?fabs(c-(x[j]>0?alpha:-alpha)):fmax(0,fabs(c)-alpha);if(!isfinite(v))return INFINITY;if(v>worst)worst=v;}return worst;}
static int sparse(const double*g,const double*b,size_t k,const corad_train_options*t,double*x,double*violation){
 memset(x,0,k*sizeof(double));
 double *corr=malloc(k*sizeof(double)),*direction=malloc(k*sizeof(double)),*h=malloc(k*sizeof(double)),*L=calloc(k*k,sizeof(double)),*rhs=malloc(k*sizeof(double));
 size_t*active=malloc(k*sizeof(size_t));unsigned char*in=calloc(k,1);
 if(!corr||!direction||!h||!L||!rhs||!active||!in){free(corr);free(direction);free(h);free(L);free(rhs);free(active);free(in);return CORAD_MEMORY;}
 int status=CORAD_OK;
 if(t->solver==1){
  memcpy(corr,b,k*sizeof(double));
  for(unsigned iter=0;iter<t->solver_max_iter;iter++){
   for(size_t j=0;j<k;j++)if(g[j*k+j]>1e-20){double z=corr[j]+g[j*k+j]*x[j],v=(z>t->alpha?z-t->alpha:z < -t->alpha?z+t->alpha:0)/g[j*k+j],change=v-x[j];x[j]=v;if(change)for(size_t i=0;i<k;i++)corr[i]-=g[i*k+j]*change;}
   if(kkt(g,b,x,k,t->alpha)<=t->solver_tolerance)break;
  }
 }else{
  memcpy(corr,b,k*sizeof(double));double lambda=0;size_t entering=0,na=0;
  for(size_t j=0;j<k;j++)if(fabs(corr[j])>lambda){lambda=fabs(corr[j]);entering=j;}
  if(lambda>t->alpha){active[na++]=entering;in[entering]=1;}
  for(unsigned step=0;lambda>t->alpha+t->solver_tolerance&&na&&step<t->solver_max_iter;step++){
   // Cholesky solve on the active Gram; rejected collinear candidates are blocked.
   int singular=0;memset(L,0,k*k*sizeof(double));
   for(size_t i=0;i<na&&!singular;i++)for(size_t j=0;j<=i;j++){
    double v=g[active[i]*k+active[j]];for(size_t z=0;z<j;z++)v-=L[i*k+z]*L[j*k+z];
    if(i==j){if(v<=1e-14){singular=1;break;}L[i*k+j]=sqrt(v);}else L[i*k+j]=v/L[j*k+j];
   }
   if(singular){in[active[--na]]=2;if(!na){status=CORAD_CONVERGENCE;break;}continue;}
   for(size_t i=0;i<na;i++){double v=corr[active[i]]>=0?1:-1;for(size_t j=0;j<i;j++)v-=L[i*k+j]*rhs[j];rhs[i]=v/L[i*k+i];}
   for(size_t ii=na;ii>0;ii--){size_t i=ii-1;double v=rhs[i];for(size_t j=i+1;j<na;j++)v-=L[j*k+i]*direction[j];direction[i]=v/L[i*k+i];}
   for(size_t j=0;j<k;j++){h[j]=0;for(size_t z=0;z<na;z++)h[j]+=g[j*k+active[z]]*direction[z];}
   double gamma=lambda-t->alpha;size_t join=SIZE_MAX,drop=SIZE_MAX;
   for(size_t j=0;j<k;j++)if(!in[j]){
    double numerator[2]={lambda-corr[j],lambda+corr[j]},denominator[2]={1-h[j],1+h[j]};
    for(unsigned z=0;z<2;z++)if(denominator[z]>1e-14){double v=numerator[z]/denominator[z];if(v>=-1e-12&&v<gamma){gamma=fmax(0,v);join=j;drop=SIZE_MAX;}}
   }
   for(size_t z=0;z<na;z++)if(direction[z]!=0){double v=-x[active[z]]/direction[z];if(v>1e-12&&v<=gamma){gamma=v;drop=z;join=SIZE_MAX;}}
   for(size_t z=0;z<na;z++)x[active[z]]+=gamma*direction[z];
   for(size_t j=0;j<k;j++)corr[j]-=gamma*h[j];lambda-=gamma;
   if(drop!=SIZE_MAX){size_t id=active[drop];x[id]=0;in[id]=0;memmove(active+drop,active+drop+1,(na-drop-1)*sizeof(*active));na--;}
   else if(join!=SIZE_MAX){active[na++]=join;in[join]=1;}
   else break;
  }
 }
 double v=kkt(g,b,x,k,t->alpha);if(violation)*violation=v;
 if(!isfinite(v)||v>t->solver_tolerance*10)status=CORAD_CONVERGENCE;
 free(corr);free(direction);free(h);free(L);free(rhs);free(active);free(in);return status;
}
int corad_sparse_code(const double*d,size_t k,size_t f,const double*y,const corad_train_options*t,double*code,double*violation){
 if(violation)*violation=0;if(!d||!y||!code||!options_valid(t)||!k||k>512||!f||f>128)return CORAD_INVALID;
 for(size_t j=0;j<k*f;j++)if(!isfinite(d[j]))return CORAD_INVALID;
 for(size_t j=0;j<f;j++)if(!isfinite(y[j]))return CORAD_INVALID;
 double*g=malloc(k*k*sizeof(double)),*b=malloc(k*sizeof(double));if(!g||!b){free(g);free(b);return CORAD_MEMORY;}
 gram(d,k,f,g);for(size_t j=0;j<k;j++)b[j]=dot(d+j*f,y,f);
 int rc=sparse(g,b,k,t,code,violation);free(g);free(b);return rc;
}
static int svd_init(const double*y,size_t n,size_t f,size_t k,double*d){
 double*a=calloc(f*f,sizeof(double)),*v=calloc(f*f,sizeof(double));size_t*order=malloc(f*sizeof(size_t));
 if(!a||!v||!order){free(a);free(v);free(order);return CORAD_MEMORY;}
 for(size_t j=0;j<f;j++){v[j*f+j]=1;order[j]=j;for(size_t z=0;z<=j;z++){double s=0;for(size_t i=0;i<n;i++)s+=y[i*f+j]*y[i*f+z];a[j*f+z]=a[z*f+j]=s;}}
 for(unsigned sweep=0;sweep<100;sweep++){
  double off=0,diag=0;for(size_t j=0;j<f;j++){diag+=fabs(a[j*f+j]);for(size_t z=j+1;z<f;z++)off+=fabs(a[j*f+z]);}if(off<=1e-14*fmax(diag,1))break;
  for(size_t p=0;p<f;p++)for(size_t q=p+1;q<f;q++)if(fabs(a[p*f+q])>1e-16*fmax(diag,1)){
   double angle=.5*atan2(2*a[p*f+q],a[q*f+q]-a[p*f+p]),c=cos(angle),s=sin(angle),app=a[p*f+p],aqq=a[q*f+q],apq=a[p*f+q];
   a[p*f+p]=c*c*app-2*s*c*apq+s*s*aqq;a[q*f+q]=s*s*app+2*s*c*apq+c*c*aqq;a[p*f+q]=a[q*f+p]=0;
   for(size_t j=0;j<f;j++){if(j!=p&&j!=q){double x=a[j*f+p],z=a[j*f+q];a[j*f+p]=a[p*f+j]=c*x-s*z;a[j*f+q]=a[q*f+j]=s*x+c*z;}double x=v[j*f+p],z=v[j*f+q];v[j*f+p]=c*x-s*z;v[j*f+q]=s*x+c*z;}
  }
 }
 for(size_t i=1;i<f;i++){size_t q=order[i],j=i;while(j&&a[order[j-1]*f+order[j-1]]<a[q*f+q]){order[j]=order[j-1];j--;}order[j]=q;}
 memset(d,0,k*f*sizeof(double));for(size_t h=0;h<k&&h<f&&h<n;h++){size_t at=order[h],largest=0;for(size_t j=1;j<f;j++)if(fabs(v[j*f+at])>fabs(v[largest*f+at]))largest=j;double scale=sqrt(fmax(0,a[at*f+at]));if(v[largest*f+at]<0)scale=-scale;for(size_t j=0;j<f;j++)d[h*f+j]=scale*v[j*f+at];}
 free(a);free(v);free(order);return CORAD_OK;
}
int corad_dictionary_fit(const double*y,size_t n,size_t f,size_t k,const corad_train_options*t,const double*initial,double*d,corad_train_stats*stats){
 if(stats)memset(stats,0,sizeof(*stats));
 if(!y||!d||!stats||!options_valid(t)||!n||n>t->max_training_samples||!f||f>128||!k||k>512||n>LIMIT/k||n>LIMIT/f)return CORAD_INVALID;
 for(size_t j=0;j<n*f;j++)if(!isfinite(y[j]))return CORAD_INVALID;
 if(initial){for(size_t j=0;j<k*f;j++)if(!isfinite(initial[j]))return CORAD_INVALID;memcpy(d,initial,k*f*sizeof(double));}
 else{int rc=svd_init(y,n,f,k,d);if(rc)return rc;}
 double*code=calloc(n*k,sizeof(double)),*g=malloc(k*k*sizeof(double)),*b=malloc(k*sizeof(double)),*A=malloc(k*k*sizeof(double)),*B=malloc(k*f*sizeof(double));
 if(!code||!g||!b||!A||!B){free(code);free(g);free(b);free(A);free(B);return CORAD_MEMORY;}
 uint64_t rng=t->seed+UINT64_C(0x9e3779b97f4a7c15);double previous=INFINITY;int status=CORAD_OK;
 for(unsigned iter=0;iter<t->max_iter;iter++){
  gram(d,k,f,g);
  for(size_t i=0;i<n;i++){for(size_t h=0;h<k;h++)b[h]=dot(d+h*f,y+i*f,f);double violation=0;status=sparse(g,b,k,t,code+i*k,&violation);if(violation>stats->max_kkt_violation)stats->max_kkt_violation=violation;if(status)goto done;}
  memset(A,0,k*k*sizeof(double));memset(B,0,k*f*sizeof(double));
  for(size_t i=0;i<n;i++)for(size_t h=0;h<k;h++)if(code[i*k+h]){double c=code[i*k+h];for(size_t z=0;z<k;z++)if(code[i*k+z])A[h*k+z]+=c*code[i*k+z];for(size_t j=0;j<f;j++)B[h*f+j]+=c*y[i*f+j];}
  for(size_t h=0;h<k;h++){
   if(A[h*k+h]>1e-6){for(size_t j=0;j<f;j++){double residual=B[h*f+j];for(size_t z=0;z<k;z++)residual-=A[h*k+z]*d[z*f+j];d[h*f+j]+=residual/A[h*k+h];}}
   else{size_t at=rng64(&rng)%n;double mean=0,sd=0;for(size_t j=0;j<f;j++)mean+=y[at*f+j];mean/=f;for(size_t j=0;j<f;j++){double z=y[at*f+j]-mean;sd+=z*z;}sd=.01*(sd>0?sqrt(sd/f):1);for(size_t j=0;j<f;j++)d[h*f+j]=y[at*f+j]+sd*normal(&rng);for(size_t i=0;i<n;i++)code[i*k+h]=0;stats->resampled_atoms++;}
   double norm=sqrt(dot(d+h*f,d+h*f,f));if(norm>1)for(size_t j=0;j<f;j++)d[h*f+j]/=norm;
  }
  double objective=0;for(size_t i=0;i<n;i++){for(size_t j=0;j<f;j++){double residual=y[i*f+j];for(size_t h=0;h<k;h++)residual-=code[i*k+h]*d[h*f+j];objective+=.5*residual*residual;}for(size_t h=0;h<k;h++)objective+=t->alpha*fabs(code[i*k+h]);}
  if(!isfinite(objective)){status=CORAD_CONVERGENCE;goto done;}
  stats->iterations=iter+1;stats->objective=objective;stats->training_samples=n;
  if(iter&&previous-objective<t->tolerance*objective){stats->converged=1;break;}previous=objective;
 }
done:
 free(code);free(g);free(b);free(A);free(B);return status;
}
int corad_model_train(const corad_config*c,const double*x,const corad_train_options*t,corad_model**model,corad_train_stats*stats){
 if(!model)return CORAD_INVALID;*model=NULL;if(stats)memset(stats,0,sizeof(*stats));
 if(!cr_valid(c)||!x||!stats||!options_valid(t))return CORAD_INVALID;
 for(size_t j=0;j<(size_t)c->rows*c->columns;j++)if(!isfinite(x[j]))return CORAD_INVALID;
 uint64_t mask=t->training_columns;
 if(c->columns<64&&(mask>>c->columns))return CORAD_INVALID;
 if(!mask){if(c->columns==1)mask=1;else for(unsigned j=1;j<c->columns&&j<8;j++)mask|=UINT64_C(1)<<j;}
 size_t columns=0;for(unsigned j=0;j<c->columns;j++)if(mask&(UINT64_C(1)<<j))columns++;
 size_t per=c->rows/c->tricklet,n=per*columns;if(n>t->max_training_samples||n>LIMIT/c->tricklet)return CORAD_CAPACITY;
 double*d=calloc((size_t)c->atoms*c->tricklet,sizeof(double)),*mean=calloc(c->columns,sizeof(double)),*scale=malloc(c->columns*sizeof(double)),*y=malloc((n?n:1)*c->tricklet*sizeof(double));
 if(!d||!mean||!scale||!y){free(d);free(mean);free(scale);free(y);return CORAD_MEMORY;}
 int status=CORAD_OK;
 for(unsigned j=0;j<c->columns;j++){
  scale[j]=1;if(t->normalize&&c->rows){double m=0,M2=0;for(size_t i=0;i<c->rows;i++){double delta=x[(size_t)j*c->rows+i]-m;m+=delta/(i+1);M2+=delta*(x[(size_t)j*c->rows+i]-m);}mean[j]=m;scale[j]=sqrt(fmax(0,M2/c->rows));if(scale[j]==0)scale[j]=1;if(!isfinite(mean[j])||!isfinite(scale[j])){status=CORAD_INVALID;goto done;}}
 }
 size_t at=0;for(unsigned j=0;j<c->columns;j++)if(mask&(UINT64_C(1)<<j))for(size_t i=0;i<per;i++)for(unsigned f=0;f<c->tricklet;f++)y[at++]=(x[(size_t)j*c->rows+i*c->tricklet+f]-mean[j])/scale[j];
 if(n){status=corad_dictionary_fit(y,n,c->tricklet,c->atoms,t,NULL,d,stats);if(status)goto done;}
 {size_t cap=corad_bound(c),written=0;uint8_t*wire=malloc(cap);if(!wire){status=CORAD_MEMORY;goto done;}status=corad_model_pack(c,d,mean,scale,wire,cap,&written);if(!status)status=corad_model_load(wire,written,model);free(wire);}
done:
 free(d);free(mean);free(scale);free(y);return status;
}
