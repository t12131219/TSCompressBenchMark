# Source training bridge
`train.py` runs the frozen CORAD `sklearn.decomposition.DictionaryLearning`
path (`max_iter=10` as in the source) and exports the learned dictionary JSON.
The C11 trainer remains available as an explicitly different solver; its model
must not be described as sklearn-equivalent.
