#!/usr/bin/env python3
"""Exact frozen CORAD sklearn DictionaryLearning training bridge."""
import argparse,json,os,numpy as np
p=argparse.ArgumentParser();p.add_argument('--input',required=True);p.add_argument('--output',required=True);p.add_argument('--atoms',type=int,required=True);p.add_argument('--alpha',type=float,default=1.0);p.add_argument('--source-root',default=os.environ.get('UNIQUE_SOURCE_ROOT'));a=p.parse_args()
if not a.source_root:raise SystemExit('UNIQUE_SOURCE_ROOT is required')
from sklearn.decomposition import DictionaryLearning
x=np.asarray(np.load(a.input),dtype=float);x=x.reshape((-1,x.shape[-1])) if x.ndim>1 else x[:,None]
# Source dictionary_learning.py deliberately fixes max_iter=10; mirror that source contract.
m=DictionaryLearning(n_components=a.atoms,alpha=a.alpha,max_iter=10);d=m.fit(x).components_
with open(a.output,'w') as f:json.dump({'backend':'upstream-CORAD-sklearn-DictionaryLearning','max_iter':10,'alpha':a.alpha,'dictionary':d.tolist(),'rows':int(x.shape[0]),'features':int(x.shape[1])},f)
