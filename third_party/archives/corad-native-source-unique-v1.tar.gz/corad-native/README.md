# corad-native · unique-v1

本工程只交付一个主选实现 `corad_c`，覆盖 80 CORAD。

## 构建

```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j4
```

支持Linux x86_64，GCC/G++、CMake≥3.22、make。ISA要求及运行约束见下表。工程自带所需源码依赖；构建输出不在发布包内。

默认构建包含本工程主选功能组件。

独立C/C++对照、历史版本、上游oracle及独立验证程序不交付。辅助库、共享格式代码、ISA加速和训练/流式等模块服务于同一主实现。`reference`、`fpc-original` 等历史target名称是CSV主选标识，不代表存在另一份并列实现。

## 80. CORAD

| 属性 | 支持范围与限制 |
| --- | --- |
| 技术家族 | 稀疏字典+列相关引用 |
| 方法角色 | 有损多变量codec |
| 编码流水线 | population zscore+C11字典训练(LARS/LASSO、SVD/交替更新)+原OMP稀疏推理+相关列引用 |
| 原生类型 | 有限binary64 |
| 输入适配 | 数值归一化/稀疏重建 |
| 数值域与特殊值 | 未确认：本次静态证据未建立该项保证 |
| 形状与多变量 | 同步多列联合相关模型 |
| 时间轴或显式x | 不支持：仅隐式样本序号 |
| 布局与stride | 核心column-major |
| 缺失值语义 | 未声明原生mask；不隐式插补 |
| 恢复与质量合同 | 相关阈值/稀疏近似，非strict逐点epsilon |
| 核心参数 | 主选固定模型推理L40/K200/nonzero4/threshold0.8；原tricklet1..128/atoms1..512等参数保留；显式训练solver、alpha、seed、iterations及列mask |
| 批处理 | 支持：整输入调用 |
| 增量编码 | 不支持：所选核心无此公开入口 |
| 增量解码 | 批量完整恢复 |
| 状态与复用 | 独立调用；无跨消息学习 |
| 点范围与seek | 不支持：所选核心无此公开入口 |
| 渐进恢复 | 不支持：所选核心无此公开入口 |
| 压缩域计算 | 不支持：所选核心无此公开入口 |
| 训练或在线学习 | 支持：C11 corad_sparse_code signed LARS/LASSO(solver0)/CD(solver1)、corad_dictionary_fit SVD/Jacobi初始化、单位范数字典更新及闲置原子重采样；corad_model_train默认列1..7(单列0)或mask，默认10轮；KKT不收敛明确返回CORAD_CONVERGENCE |
| 字典码本复用 | C11训练/保存/加载可复用CRD1字典、均值、尺度和列schema；完整帧模型字节计费 |
| SIMD或ISA | 未确认：不以编译器自动向量化宣称显式SIMD |
| 内部并行编码 | 原生训练及推理串行；不借用sklearn/BLAS线程作C并行能力 |
| 内部并行解码 | 不支持：所选调用路径串行 |
| GPU | 未确认：未对该冻结核心建立GPU入口证据 |
| 并发与所有权 | 原生独立对象并发；同对象独占；训练使用自身选项/随机状态，不强制全局NumPy RNG |
| 格式与兼容 | CRD1完整帧；rows=0的CRD1冻结模型 |
| 独立恢复依赖 | 每帧完整字典/mean/scale；NPZ不是重复必需解码字节 |
| 运行与构建依赖 | 唯一C11训练和推理；corad_train/corad_native无需Python。 |
| 长度尾部与资源 | ≤64列、列顺序须匹配模型；仅完整tricklet参加训练而全部尾行参与编码；训练样本/工作内存有上限并显式拒绝，不悄悄采样 |
| 确定性条件 | 原生RNG和SVD路径不同于sklearn；不保证最终模型逐字节相同；相同初始化一轮更新及320组稀疏目标有独立对照 |
| 许可范围 | 源码许可声明及 fix_ReWrite/corad-native/licenses 中的冻结归属材料。 |
| 已知限制与身份 | C训练已交付；KKT不收敛会报错，RNG/SVD/最终模型与sklearn非字节等价；不新增逐点误差保证，原生数组不自动识别错列；训练/加载/推理单列计费 |
