#ifndef CORAD_H
#define CORAD_H
#include <stddef.h>
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
/* Finite binary64, column-major x[col*rows+row]. No buffer overlap.
 * Caller owns all memory. Stateless, reentrant. On error the written or count
 * result is zero; output contents unspecified. max_values and capacity for
 * decode are doubles. Dictionary is row-major atoms x tricklet. See contract.md
 * for full domain. */
typedef struct {
  uint32_t rows;
  uint16_t columns, tricklet, atoms, nonzero;
  double threshold;
} corad_config;
enum {
  CORAD_OK = 0,
  CORAD_INVALID = 1,
  CORAD_CAPACITY = 2,
  CORAD_MEMORY = 3,
  CORAD_STREAM = 4,
  CORAD_CONVERGENCE = 5
};
size_t corad_bound(const corad_config *cfg);
int corad_c_encode(const corad_config *cfg, const double *x,
                   const double *dictionary, const double *mean,
                   const double *scale, uint8_t *out, size_t capacity,
                   size_t *written);
/* Shared C bounded decoder: exact single CRD1 frame, no trailing bytes. */
int corad_decode(const uint8_t *data, size_t size, double *out, size_t capacity,
                 size_t max_values, size_t *count, corad_config *cfg);
/* Frozen model API. CRD1 with rows=0 is the portable model artifact; all
 * dictionary/statistics bytes are included again in every encoded data frame.
 * Model owns copied arrays and is immutable/reentrant; caller owns output.
 * No Python, NPZ parser, trainer, or process invocation in these APIs.
 * Column order is positional and must match the training/export schema.
 */
typedef struct corad_model corad_model;
int corad_model_pack(const corad_config *, const double *, const double *, const double *,
                     uint8_t *, size_t, size_t *);
int corad_model_load(const uint8_t *, size_t, corad_model **);
void corad_model_free(corad_model *);
size_t corad_model_size(const corad_model*);
int corad_model_save(const corad_model*,uint8_t*,size_t,size_t*);
int corad_model_info(const corad_model *, corad_config *);
int corad_model_config(const corad_model *, uint32_t rows, uint16_t nonzero,
                       double threshold, corad_config *);
int corad_model_encode(const corad_model *, const corad_config *, const double *,
                       uint8_t *, size_t, size_t *);
/* C11 batch dictionary training. Source objective is
 * .5||Y-CD||_F^2 + alpha||C||_1 with ||D_atom||_2 <= 1.
 * solver=0 signed LARS/LASSO homotopy, 1 cyclic coordinate descent.
 * Covariance Jacobi SVD initialization and portable RNG; not NumPy byte identity.
 * Optional initial dictionary allows controlled numerical comparisons.
 * training_columns bit mask: 0 selects source columns 1..7, or 0 if sole column.
 * normalize=1 population zscore on whole columns; complete tricklets only.
 * max_training_samples rejects oversize work; no silent sampling.
 * Nonconverged sparse solves return CORAD_CONVERGENCE, never a usable model.
 * Stats objective is after dictionary update, matching source outer-loop timing. */
typedef struct {
 uint32_t size,version,max_iter,solver_max_iter,solver,normalize;
 uint64_t seed,training_columns;size_t max_training_samples;
 double alpha,tolerance,solver_tolerance;
} corad_train_options;
typedef struct {size_t training_samples,resampled_atoms;unsigned iterations;int converged;double objective,max_kkt_violation;} corad_train_stats;
void corad_train_options_init(corad_train_options*);
int corad_sparse_code(const double*dict,size_t atoms,size_t features,const double*sample,const corad_train_options*,double*code,double*kkt_violation);
int corad_dictionary_fit(const double*samples,size_t count,size_t features,size_t atoms,const corad_train_options*,const double*initial_dictionary,double*dictionary,corad_train_stats*);
int corad_model_train(const corad_config*,const double*column_major,const corad_train_options*,corad_model**,corad_train_stats*);
#ifdef __cplusplus
}
#endif
#endif
