#include "native_bench.h"
#include "corad.h"
int main(int argc,char **argv) {
  nb_platform();
  if(argc==4&&!strcmp(argv[1],"decode")) {
    size_t bytes,count=0;uint8_t *p=nb_read(argv[2],100000000,&bytes);double *y=nb_alloc(8000000*8);
    if(corad_decode(p,bytes,y,8000000,8000000,&count,NULL))nb_fail("invalid CRD1 frame");
    nb_write(argv[3],y,count*8);free(y);free(p);return 0;
  }
  if(argc<5||argc>9||argc==6||strcmp(argv[1],"bench"))nb_fail("usage: corad_native bench MODEL.crdm INPUT.column-major.f64 REPEATS [NONZERO THRESHOLD [FRAME [OUTPUT.f64]]] | decode FRAME OUTPUT");
  size_t mb,bytes,used=0,count=0;uint8_t *model=nb_read(argv[2],600000,&mb),*input=nb_read(argv[3],8000000*8,&bytes);
  if(bytes%8)nb_fail("input needs complete f64 values");
  size_t n=bytes/8,repeats=nb_number(argv[4],1000000);if(!repeats)nb_fail("positive repeats required");
  double t=nb_clock();corad_model *m=NULL;corad_config c;
  if(corad_model_load(model,mb,&m)||corad_model_info(m,&c))nb_fail("invalid frozen CRD1 model");
  if(n%c.columns||n/c.columns>1000000)nb_fail("input shape differs from model");
  unsigned nz=argc>5?(unsigned)nb_number(argv[5],32):c.nonzero;double threshold=argc>6?nb_real(argv[6]):c.threshold;
  if(corad_model_config(m,(uint32_t)(n/c.columns),(uint16_t)nz,threshold,&c))nb_fail("invalid inference configuration");
  double setup=nb_clock()-t;free(model);nb_finite((double*)input,n);
  size_t cap=corad_bound(&c);uint8_t *wire=nb_alloc(cap);double *y=nb_alloc(bytes);double et=0,dt=0;
  for(size_t r=0;r<repeats;r++) {
    t=nb_clock();int e=corad_model_encode(m,&c,(double*)input,wire,cap,&used);et+=nb_clock()-t;if(e)nb_fail("native CORAD encode failed");
    t=nb_clock();e=corad_decode(wire,used,y,n,n,&count,NULL);dt+=nb_clock()-t;if(e||count!=n)nb_fail("native CORAD decode failed");
  }
  double maximum,rmse;nb_quality((double*)input,y,n,&maximum,&rmse);
  if(argc>7)nb_write(argv[7],wire,used);
  if(argc>8)nb_write(argv[8],y,bytes);
  char configuration[512];snprintf(configuration,sizeof configuration,"{\"model_artifact_bytes\":%zu,\"rows\":%u,\"columns\":%u,\"tricklet\":%u,\"atoms\":%u,\"nonzero\":%u,\"threshold\":%.17g,\"internal_threads\":1}",mb,c.rows,c.columns,c.tricklet,c.atoms,c.nonzero,c.threshold);
  nb_report("C11-CORAD-frozen-model",bytes,used,repeats,setup,et,dt,maximum,rmse,configuration);
  corad_model_free(m);free(input);free(wire);free(y);return 0;
}
