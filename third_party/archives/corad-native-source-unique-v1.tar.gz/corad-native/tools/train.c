#include "native_bench.h"
#include "corad.h"
int main(int argc,char**argv){
 nb_platform();if(argc<8||argc>10)nb_fail("usage: corad_train INPUT.column-major.f64 COLUMNS TRICKLET ATOMS NONZERO ALPHA OUTPUT.crdm [ITERATIONS [SOLVER:0=LARS,1=CD]]");
 size_t bytes;uint8_t*raw=nb_read(argv[1],64000000,&bytes);unsigned columns=(unsigned)nb_number(argv[2],64);if(!columns||bytes%(8*columns))nb_fail("shape");
 corad_config c={(uint32_t)(bytes/(8*columns)),(uint16_t)columns,(uint16_t)nb_number(argv[3],128),(uint16_t)nb_number(argv[4],512),(uint16_t)nb_number(argv[5],32),.5};corad_train_options t;corad_train_options_init(&t);t.alpha=nb_real(argv[6]);if(argc>8)t.max_iter=(uint32_t)nb_number(argv[8],10000);if(argc>9)t.solver=(uint32_t)nb_number(argv[9],1);
 double start=nb_clock();corad_model*m=NULL;corad_train_stats stats;int rc=corad_model_train(&c,(double*)raw,&t,&m,&stats);double elapsed=nb_clock()-start;if(rc){fprintf(stderr,"training failed status=%d (5=sparse solver convergence)\n",rc);free(raw);return 2;}
 size_t cap=corad_model_size(m),written=0;uint8_t*wire=nb_alloc(cap);if(corad_model_save(m,wire,cap,&written))nb_fail("model save");nb_write(argv[7],wire,written);
 printf("{\"status\":\"PASS\",\"trainer\":\"C11-batch-dictionary\",\"solver\":%u,\"training_samples\":%zu,\"iterations\":%u,\"resampled_atoms\":%zu,\"objective\":%.17g,\"max_kkt_violation\":%.17g,\"model_bytes\":%zu,\"training_seconds\":%.9g}\n",t.solver,stats.training_samples,stats.iterations,stats.resampled_atoms,stats.objective,stats.max_kkt_violation,written,elapsed);
 free(wire);free(raw);corad_model_free(m);return 0;
}
