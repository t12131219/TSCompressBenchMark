#ifndef ZN_INTERNAL_H
#define ZN_INTERNAL_H
#include "zfp_native.h"
#include "zfp.h"
struct zn_context {
  zn_config config;
  zfp_stream* stream;
  zfp_field* field;
  bitstream* bits;
  unsigned char* buffer;
  size_t capacity, raw_size;
  zn_options options;
  ptrdiff_t min_offset,max_offset;
  int extended;
};
#ifdef __cplusplus
extern "C" {
#endif
zn_status zn_prepare_encode(zn_context*, const void*, size_t, size_t*);
zn_status zn_prepare_decode(zn_context*, const void*, size_t, void*, size_t);
zn_status zn_finish_decode(zn_context*, size_t);
#ifdef __cplusplus
}
#endif
#endif
