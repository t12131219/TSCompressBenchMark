#include "internal.h"
#include <math.h>
#include <stdint.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#ifdef ZN_WITH_CUDA
#include <cuda_runtime_api.h>
#endif
#ifdef _OPENMP
#include <omp.h>
#endif

/* Bound allocations and keep every shape/stride/bound calculation representable.
 * This is a resource policy, not a claim of corruption-safe upstream decoding. */
#define ZN_MAX_ALLOCATION ((size_t)1 << 30)
zn_config zn_config_1d(zn_type type, size_t count)
{
  zn_config c = {type, 1, {count, 1, 1, 1}, ZN_REVERSIBLE, 0};
  return c;
}
zn_status zn_create(const zn_config* c, zn_context** out)
{
  zn_context* p;
  size_t count = 1, width;
  unsigned d;
  if (!out) return ZN_INVALID;
  *out = NULL;
  if (!c || c->dims < 1 || c->dims > 4 || c->type < ZN_I32 || c->type > ZN_F64)
    return ZN_INVALID;
  width = c->type == ZN_I32 || c->type == ZN_F32 ? 4 : 8;
  for (d = 0; d < 4; ++d) {
    if (!c->size[d] || (d >= c->dims && c->size[d] != 1) ||
        c->size[d] > ZN_MAX_ALLOCATION / width / count) return ZN_INVALID;
    count *= c->size[d];
  }
  if (count > (size_t)PTRDIFF_MAX / width) return ZN_INVALID;
  if (c->mode < ZN_REVERSIBLE || c->mode > ZN_ACCURACY) return ZN_INVALID;
  if (c->mode != ZN_REVERSIBLE && (!isfinite(c->parameter) || c->parameter <= 0))
    return ZN_INVALID;
  if (c->mode == ZN_PRECISION &&
      (c->parameter > width * 8 || floor(c->parameter) != c->parameter)) return ZN_INVALID;
  if (c->mode == ZN_RATE && c->parameter > width * 8) return ZN_INVALID;
  if (c->mode == ZN_ACCURACY && c->type < ZN_F32) return ZN_INVALID;
  p = (zn_context*)calloc(1, sizeof(*p));
  if (!p) return ZN_NOMEM;
  p->config = *c;
  p->options=zn_defaults();
  p->raw_size = count * width;
  switch (c->dims) {
    case 1: p->field = zfp_field_1d(NULL, (zfp_type)c->type, c->size[0]); break;
    case 2: p->field = zfp_field_2d(NULL, (zfp_type)c->type, c->size[0], c->size[1]); break;
    case 3: p->field = zfp_field_3d(NULL, (zfp_type)c->type, c->size[0], c->size[1], c->size[2]); break;
    case 4: p->field = zfp_field_4d(NULL, (zfp_type)c->type, c->size[0], c->size[1], c->size[2], c->size[3]); break;
  }
  p->stream = zfp_stream_open(NULL);
  if (!p->field || !p->stream) { zn_destroy(p); return ZN_NOMEM; }
  switch (c->mode) {
    case ZN_REVERSIBLE: zfp_stream_set_reversible(p->stream); break;
    case ZN_RATE: zfp_stream_set_rate(p->stream, c->parameter, (zfp_type)c->type, c->dims, zfp_false); break;
    case ZN_PRECISION: zfp_stream_set_precision(p->stream, (unsigned)c->parameter); break;
    case ZN_ACCURACY: zfp_stream_set_accuracy(p->stream, c->parameter); break;
  }
  p->capacity = zfp_stream_maximum_size(p->stream, p->field);
  if (!p->capacity || p->capacity > ZN_MAX_ALLOCATION) { zn_destroy(p); return ZN_INVALID; }
  p->buffer = (unsigned char*)calloc(1, p->capacity);
  if (!p->buffer) { zn_destroy(p); return ZN_NOMEM; }
  p->bits = stream_open(p->buffer, p->capacity);
  if (!p->bits) { zn_destroy(p); return ZN_NOMEM; }
  zfp_stream_set_bit_stream(p->stream, p->bits);
  *out = p;
  return ZN_OK;
}
void zn_destroy(zn_context* p)
{
  if (p) {
    if (p->bits) stream_close(p->bits);
    if (p->stream) zfp_stream_close(p->stream);
    if (p->field) zfp_field_free(p->field);
    free(p->buffer);
    free(p);
  }
}
size_t zn_raw_size(const zn_context* p) { return p ? p->raw_size : 0; }
size_t zn_capacity(const zn_context* p) { return p ? p->capacity : 0; }
const unsigned char* zn_data(const zn_context* p) { return p ? p->buffer : NULL; }
zn_status zn_prepare_encode(zn_context* p, const void* input, size_t bytes, size_t* written)
{
  if (written) *written = 0;
  if (!p || p->extended || !input || !written || bytes != p->raw_size) return ZN_INVALID;
  zfp_field_set_pointer(p->field, (void*)input);
  zfp_stream_rewind(p->stream);
  return ZN_OK;
}
zn_status zn_encode(zn_context* p, const void* input, size_t bytes, size_t* written)
{
  zn_status status = zn_prepare_encode(p, input, bytes, written);
  if (status != ZN_OK) return status;
  *written = zfp_compress(p->stream, p->field);
  return *written && *written <= p->capacity ? ZN_OK : ZN_CODEC;
}
zn_status zn_prepare_decode(zn_context* p, const void* input, size_t bytes, void* output, size_t output_bytes)
{
  if (!p || p->extended || !input || !output || output_bytes != p->raw_size || !bytes ||
      bytes % 8 || bytes > p->capacity) return ZN_INVALID;
  /* Upstream requires word-aligned readable storage. Copy external inputs into
   * aligned, worst-case-sized storage; decoding the current encode is zero-copy. */
  if (input != p->buffer) memmove(p->buffer, input, bytes);
  memset(p->buffer + bytes, 0, p->capacity - bytes);
  zfp_field_set_pointer(p->field, output);
  zfp_stream_rewind(p->stream);
  return ZN_OK;
}
zn_status zn_finish_decode(zn_context* p, size_t bytes)
{
  return stream_size(p->bits) == bytes ? ZN_OK : ZN_CODEC;
}
zn_status zn_decode(zn_context* p, const void* input, size_t bytes, void* output, size_t output_bytes)
{
  zn_status status = zn_prepare_decode(p, input, bytes, output, output_bytes);
  if (status != ZN_OK) return status;
  if (!zfp_decompress(p->stream, p->field)) return ZN_CODEC;
  return zn_finish_decode(p, bytes);
}
const char* zn_error(zn_status s)
{
  switch (s) {
    case ZN_OK: return "success";
    case ZN_INVALID: return "invalid configuration, size, or argument";
    case ZN_NOMEM: return "allocation failed";
    case ZN_CODEC: return "codec failed or consumed length mismatch";
    default: return "unknown status";
  }
}

zn_options zn_defaults(void){zn_options o={ZN_SERIAL,1,0,{0,0,0,0}};return o;}
int zn_cuda_built(void){
#ifdef ZN_WITH_CUDA
 return 1;
#else
 return 0;
#endif
}
int zn_cuda_available(void){
#ifdef ZN_WITH_CUDA
 int count=0;return cudaGetDeviceCount(&count)==cudaSuccess&&count>0;
#else
 return 0;
#endif
}
static int gpu_status(void){
#ifdef ZN_WITH_CUDA
 return cudaDeviceSynchronize()==cudaSuccess&&cudaGetLastError()==cudaSuccess;
#else
 return 0;
#endif
}
static int policy(zn_context*p){
 if(p->options.execution==ZN_CUDA)return zn_cuda_available()&&zfp_stream_set_execution(p->stream,zfp_exec_cuda);
 if(p->options.execution==ZN_SERIAL)return zfp_stream_set_execution(p->stream,zfp_exec_serial);
 return zfp_stream_set_omp_threads(p->stream,p->options.threads)&&zfp_stream_set_omp_chunk_size(p->stream,p->options.chunk_size);
}
zn_status zn_create_ex(const zn_config*c,const zn_options*o,zn_context**out){
 if(!out)return ZN_INVALID;*out=NULL;
 if(!o||(o->execution!=ZN_SERIAL&&o->execution!=ZN_OPENMP&&o->execution!=ZN_CUDA)||!o->threads||o->threads>256||(o->execution!=ZN_OPENMP&&(o->threads!=1||o->chunk_size)))return ZN_INVALID;
 if(o->execution==ZN_CUDA){
  if(!c||c->mode!=ZN_RATE||c->dims>3||!zn_cuda_available())return ZN_INVALID;
  for(unsigned d=0;d<4;d++)if(o->stride[d])return ZN_INVALID;
 }
 zn_context*p=NULL;zn_status rc=zn_create(c,&p);if(rc)return rc;p->options=*o;
 ptrdiff_t strides[4]={0,0,0,0};size_t width=(c->type==ZN_I32||c->type==ZN_F32)?4:8,product=1,covered=1;
 size_t absstr[4];unsigned axes[4];
 for(unsigned d=0;d<4;d++){
  if(d>=c->dims){if(o->stride[d])goto invalid;continue;}
  ptrdiff_t s=o->stride[d]?o->stride[d]:(ptrdiff_t)product;if(s==PTRDIFF_MIN)goto invalid;size_t mag=(size_t)(s<0?-s:s);
  if(!mag||mag>ZN_MAX_ALLOCATION/width||c->size[d]-1>(ZN_MAX_ALLOCATION/width-1)/mag)goto invalid;
  ptrdiff_t offset=s*(ptrdiff_t)(c->size[d]-1);if(offset<0)p->min_offset+=offset;else p->max_offset+=offset;
  strides[d]=s;absstr[d]=mag;axes[d]=d;product*=c->size[d];
 }
 if((size_t)(p->max_offset-p->min_offset)+1>ZN_MAX_ALLOCATION/width)goto invalid;
 for(unsigned i=0;i<c->dims;i++)for(unsigned j=i+1;j<c->dims;j++)if(absstr[axes[j]]<absstr[axes[i]]){unsigned t=axes[i];axes[i]=axes[j];axes[j]=t;}
 for(unsigned j=0;j<c->dims;j++){unsigned d=axes[j];if(c->size[d]>1&&absstr[d]<covered)goto invalid;covered+=(c->size[d]-1)*absstr[d];}
 for(unsigned d=0;d<4;d++)p->options.stride[d]=strides[d];
 switch(c->dims){case 1:zfp_field_set_stride_1d(p->field,strides[0]);break;case 2:zfp_field_set_stride_2d(p->field,strides[0],strides[1]);break;case 3:zfp_field_set_stride_3d(p->field,strides[0],strides[1],strides[2]);break;case 4:zfp_field_set_stride_4d(p->field,strides[0],strides[1],strides[2],strides[3]);break;}
 if(!policy(p))goto invalid;p->extended=1;*out=p;return ZN_OK;
invalid:zn_destroy(p);return ZN_INVALID;
}
zn_status zn_get_info(const zn_context*p,zn_info*out){
 if(!p||!out)return ZN_INVALID;memset(out,0,sizeof(*out));out->config=p->config;out->options=p->options;out->options.execution=(zn_execution)zfp_stream_execution(p->stream);if(out->options.execution==ZN_OPENMP){out->options.threads=zfp_stream_omp_threads(p->stream);out->options.chunk_size=zfp_stream_omp_chunk_size(p->stream);}
 out->logical_bytes=p->raw_size;out->min_offset=p->min_offset;out->max_offset=p->max_offset;out->decode_execution=p->options.execution==ZN_CUDA?ZN_CUDA:ZN_SERIAL;
 if(p->config.mode==ZN_RATE)out->effective_parameter=zfp_stream_rate(p->stream,p->config.dims);else if(p->config.mode==ZN_PRECISION)out->effective_parameter=zfp_stream_precision(p->stream);else if(p->config.mode==ZN_ACCURACY)out->effective_parameter=zfp_stream_accuracy(p->stream);
#ifdef _OPENMP
 out->openmp_built=1;out->omp_dynamic=omp_get_dynamic();out->omp_thread_limit=omp_get_thread_limit();
#endif
 return ZN_OK;
}
static void* address(zn_context*p,void*base,size_t bytes,size_t origin){
 if(!p||!p->extended||!base||!bytes||bytes>ZN_MAX_ALLOCATION)return NULL;size_t width=(p->config.type==ZN_I32||p->config.type==ZN_F32)?4:8;
 if(bytes%width||(uintptr_t)base%width||origin>bytes/width||origin<(size_t)(-p->min_offset)||origin+(size_t)p->max_offset>=bytes/width)return NULL;
 return (unsigned char*)base+origin*width;
}
zn_status zn_encode_field(zn_context*p,const void*base,size_t span,size_t origin,size_t*written){
 if(written)*written=0;void*input=address(p,(void*)base,span,origin);if(!input||!written)return ZN_INVALID;zfp_field_set_pointer(p->field,input);zfp_stream_rewind(p->stream);*written=zfp_compress(p->stream,p->field);if(!*written||*written>p->capacity||(p->options.execution==ZN_CUDA&&!gpu_status())){*written=0;return ZN_CODEC;}return ZN_OK;
}
zn_status zn_decode_field(zn_context*p,const void*input,size_t bytes,void*base,size_t span,size_t origin){
 void*output=address(p,base,span,origin);if(!output||!input||!bytes||bytes%8||bytes>p->capacity)return ZN_INVALID;
 if(input!=p->buffer)memmove(p->buffer,input,bytes);memset(p->buffer+bytes,0,p->capacity-bytes);zfp_field_set_pointer(p->field,output);zfp_stream_rewind(p->stream);
 if(!zfp_stream_set_execution(p->stream,p->options.execution==ZN_CUDA?zfp_exec_cuda:zfp_exec_serial))return ZN_CODEC;
 size_t used=zfp_decompress(p->stream,p->field);int device_ok=p->options.execution!=ZN_CUDA||gpu_status();int restore=policy(p);return used&&restore&&device_ok?zn_finish_decode(p,bytes):ZN_CODEC;
}
int zn_cuda_runtime_available(void){
#ifdef ZN_WITH_CUDA
#ifdef __linux__
 return access("/dev/nvidiactl",F_OK)==0 || access("/dev/nvidia0",F_OK)==0;
#else
 return 0;
#endif
#else
 return 0;
#endif
}
const char* zn_backend_info(void){return zn_cuda_built()?(zn_cuda_runtime_available()?"cpu+cuda-built-runtime-visible":"cpu+cuda-built-runtime-unavailable"):"cpu-only";}
