/* Random access uses public C block codecs, never the C++ compressed-array API. */
#include "zfp_native.h"
#include "zfp.h"
#include <stdlib.h>
#include <string.h>
#include <math.h>
struct zn_array {
 zn_config c;size_t count,width,blocks[4],nblocks,block_bits,bytes,cached;
 unsigned ext[4];int dirty;unsigned char*data;zfp_stream*z;bitstream*bits;
 union {double d[256];float f[256];} cache;
};
static size_t block_codec(zn_array*a,int encode){
 if(a->c.type==ZN_F32)switch(a->c.dims){
 case 1:return encode?zfp_encode_partial_block_strided_float_1(a->z,a->cache.f,a->ext[0],1):zfp_decode_partial_block_strided_float_1(a->z,a->cache.f,a->ext[0],1);
 case 2:return encode?zfp_encode_partial_block_strided_float_2(a->z,a->cache.f,a->ext[0],a->ext[1],1,4):zfp_decode_partial_block_strided_float_2(a->z,a->cache.f,a->ext[0],a->ext[1],1,4);
 case 3:return encode?zfp_encode_partial_block_strided_float_3(a->z,a->cache.f,a->ext[0],a->ext[1],a->ext[2],1,4,16):zfp_decode_partial_block_strided_float_3(a->z,a->cache.f,a->ext[0],a->ext[1],a->ext[2],1,4,16);
 case 4:return encode?zfp_encode_partial_block_strided_float_4(a->z,a->cache.f,a->ext[0],a->ext[1],a->ext[2],a->ext[3],1,4,16,64):zfp_decode_partial_block_strided_float_4(a->z,a->cache.f,a->ext[0],a->ext[1],a->ext[2],a->ext[3],1,4,16,64);
 }
 if(a->c.type==ZN_F64)switch(a->c.dims){
 case 1:return encode?zfp_encode_partial_block_strided_double_1(a->z,a->cache.d,a->ext[0],1):zfp_decode_partial_block_strided_double_1(a->z,a->cache.d,a->ext[0],1);
 case 2:return encode?zfp_encode_partial_block_strided_double_2(a->z,a->cache.d,a->ext[0],a->ext[1],1,4):zfp_decode_partial_block_strided_double_2(a->z,a->cache.d,a->ext[0],a->ext[1],1,4);
 case 3:return encode?zfp_encode_partial_block_strided_double_3(a->z,a->cache.d,a->ext[0],a->ext[1],a->ext[2],1,4,16):zfp_decode_partial_block_strided_double_3(a->z,a->cache.d,a->ext[0],a->ext[1],a->ext[2],1,4,16);
 case 4:return encode?zfp_encode_partial_block_strided_double_4(a->z,a->cache.d,a->ext[0],a->ext[1],a->ext[2],a->ext[3],1,4,16,64):zfp_decode_partial_block_strided_double_4(a->z,a->cache.d,a->ext[0],a->ext[1],a->ext[2],a->ext[3],1,4,16,64);
 }
 return 0;
}
static void extent(zn_array*a,size_t block){
 for(unsigned j=0;j<4;j++){size_t b=block%a->blocks[j];block/=a->blocks[j];size_t n=a->c.size[j]-4*b;a->ext[j]=(unsigned)(n<4?n:4);}
}
zn_status zn_array_flush(zn_array*a){
 if(!a)return ZN_INVALID;
 if(a->dirty){stream_wseek(a->bits,a->cached*a->block_bits);if(block_codec(a,1)!=a->block_bits)return ZN_CODEC;stream_flush(a->bits);a->dirty=0;}
 a->cached=SIZE_MAX;return ZN_OK;
}
static zn_status select_block(zn_array*a,size_t block){
 if(a->cached==block)return ZN_OK;
 zn_status s=zn_array_flush(a);if(s)return s;
 a->cached=block;extent(a,block);memset(&a->cache,0,sizeof(a->cache));
 stream_rseek(a->bits,block*a->block_bits);if(block_codec(a,0)!=a->block_bits){a->cached=SIZE_MAX;return ZN_CODEC;}stream_align(a->bits);return ZN_OK;
}
void zn_array_destroy(zn_array*a){if(a){if(a->bits)stream_close(a->bits);if(a->z)zfp_stream_close(a->z);free(a->data);free(a);}}
size_t zn_array_count(const zn_array*a){return a?a->count:0;}
size_t zn_array_compressed_size(const zn_array*a){return a?a->bytes:0;}
double zn_array_rate(const zn_array*a){return a?zfp_stream_rate(a->z,a->c.dims):0;}
zn_status zn_array_create(const zn_config*c,const void*initial,size_t bytes,zn_array**out){
 if(!out)return ZN_INVALID;*out=NULL;
 if(!c||c->mode!=ZN_RATE||(c->type!=ZN_F32&&c->type!=ZN_F64))return ZN_INVALID;
 zn_context*check=NULL;zn_status s=zn_create(c,&check);if(s)return s;
 size_t raw=zn_raw_size(check);zn_destroy(check);
 if((initial&&bytes!=raw)||(!initial&&bytes))return ZN_INVALID;
 zn_array*a=calloc(1,sizeof(*a));if(!a)return ZN_NOMEM;
 a->c=*c;a->width=c->type==ZN_F32?4:8;a->count=raw/a->width;
 if(initial)for(size_t i=0;i<a->count;i++){double v;if(a->width==4){float f;memcpy(&f,(const unsigned char*)initial+4*i,4);v=f;}else memcpy(&v,(const unsigned char*)initial+8*i,8);if(!isfinite(v)){zn_array_destroy(a);return ZN_INVALID;}}
 a->nblocks=1;a->cached=SIZE_MAX;
 for(unsigned j=0;j<4;j++){a->blocks[j]=(c->size[j]+3)/4;a->nblocks*=a->blocks[j];}
 a->z=zfp_stream_open(NULL);if(!a->z){zn_array_destroy(a);return ZN_NOMEM;}
 zfp_stream_set_rate(a->z,c->parameter,(zfp_type)c->type,c->dims,zfp_true);a->block_bits=a->z->maxbits;
 if(a->nblocks>((size_t)1<<30)/((a->block_bits+7)/8)){zn_array_destroy(a);return ZN_INVALID;}
 a->bytes=((a->nblocks*a->block_bits+63)/64)*8;
 a->data=calloc(1,a->bytes);if(!a->data){zn_array_destroy(a);return ZN_NOMEM;}
 a->bits=stream_open(a->data,a->bytes);if(!a->bits){zn_array_destroy(a);return ZN_NOMEM;}
 zfp_stream_set_bit_stream(a->z,a->bits);
 for(size_t b=0;b<a->nblocks;b++){
  a->cached=b;extent(a,b);memset(&a->cache,0,sizeof(a->cache));
  if(initial){
   size_t block=b,origin=0,stride=1;
   for(unsigned j=0;j<c->dims;j++){origin+=(block%a->blocks[j])*4*stride;block/=a->blocks[j];stride*=c->size[j];}
   for(size_t i=0;i<((size_t)1<<(2*c->dims));i++){
    size_t local=i,at=origin,step=1;int valid=1;
    for(unsigned j=0;j<c->dims;j++){size_t x=local%4;local/=4;if(x>=a->ext[j])valid=0;at+=x*step;step*=c->size[j];}
    if(valid)memcpy((unsigned char*)&a->cache+i*a->width,(const unsigned char*)initial+at*a->width,a->width);
   }
  }
  a->dirty=1;s=zn_array_flush(a);if(s){zn_array_destroy(a);return s;}
 }
 a->cached=SIZE_MAX;*out=a;return ZN_OK;
}
static zn_status locate(zn_array*a,size_t index,size_t*local){
 if(!a||index>=a->count)return ZN_INVALID;
 size_t block=0,mult=1,l=0;
 for(unsigned j=0;j<a->c.dims;j++){size_t x=index%a->c.size[j];index/=a->c.size[j];block+=(x/4)*mult;mult*=a->blocks[j];l+=(x%4)*((size_t)1<<(2*j));}
 *local=l;return select_block(a,block);
}
zn_status zn_array_get(zn_array*a,size_t index,void*value){
 if(!value)return ZN_INVALID;size_t l;zn_status s=locate(a,index,&l);if(!s)memcpy(value,(unsigned char*)&a->cache+l*a->width,a->width);return s;
}
zn_status zn_array_set(zn_array*a,size_t index,const void*value){
 if(!a||!value)return ZN_INVALID;
 double v;if(a->width==4){float f;memcpy(&f,value,4);v=f;}else memcpy(&v,value,8);
 if(!isfinite(v))return ZN_INVALID;size_t l;zn_status s=locate(a,index,&l);if(!s){memcpy((unsigned char*)&a->cache+l*a->width,value,a->width);a->dirty=1;}return s;
}
static zn_status range(zn_array*a,size_t start,size_t count,void*values,size_t bytes,int write){
 if(!a||start>a->count||count>a->count-start||bytes!=count*a->width||(count&&!values))return ZN_INVALID;
 if(write)for(size_t i=0;i<count;i++){double v;if(a->width==4){float f;memcpy(&f,(unsigned char*)values+4*i,4);v=f;}else memcpy(&v,(unsigned char*)values+8*i,8);if(!isfinite(v))return ZN_INVALID;}
 for(size_t i=0;i<count;i++){zn_status s=write?zn_array_set(a,start+i,(unsigned char*)values+i*a->width):zn_array_get(a,start+i,(unsigned char*)values+i*a->width);if(s)return s;}return ZN_OK;
}
zn_status zn_array_get_range(zn_array*a,size_t s,size_t n,void*v,size_t b){return range(a,s,n,v,b,0);}
zn_status zn_array_set_range(zn_array*a,size_t s,size_t n,const void*v,size_t b){return range(a,s,n,(void*)v,b,1);}
zn_status zn_array_export(zn_array*a,void*out,size_t cap,size_t*written){
 if(written)*written=0;if(!a||!out||!written||cap<a->bytes)return ZN_INVALID;zn_status s=zn_array_flush(a);if(!s){memcpy(out,a->data,a->bytes);*written=a->bytes;}return s;
}
zn_status zn_array_import(const zn_config*c,const void*data,size_t bytes,zn_array**out){
 if(!out)return ZN_INVALID;*out=NULL;if(!data)return ZN_INVALID;
 zn_array*a=NULL;zn_status s=zn_array_create(c,NULL,0,&a);if(s)return s;
 if(bytes!=a->bytes){zn_array_destroy(a);return ZN_INVALID;}memcpy(a->data,data,bytes);*out=a;return ZN_OK;
}
size_t zn_array_cache_size(const zn_array*a){return a?a->cached==SIZE_MAX?0:256*a->width:0;}
zn_status zn_array_set_cache_size(zn_array*a,size_t bytes){(void)bytes;return a?zn_array_flush(a):ZN_INVALID;}
zn_status zn_array_flush_cache(zn_array*a){return zn_array_flush(a);}
