#ifndef ZFP_NATIVE_CPP_HPP
#define ZFP_NATIVE_CPP_HPP
/* The public upstream compressed-array implementation is part of this target.
 * Include the exact zfp::array1..array4 and views; callers get cache_size,
 * set_cache_size, flush_cache, iterators, subviews, compressed_data and
 * size_bytes semantics from the frozen source. */
#include <zfp/array1.hpp>
#include <zfp/array2.hpp>
#include <zfp/array3.hpp>
#include <zfp/array4.hpp>
#include <zfp/constarray1.hpp>
#include <zfp/constarray2.hpp>
#include <zfp/constarray3.hpp>
#include <zfp/constarray4.hpp>
#endif
