#ifndef ZFP_NATIVE_H
#define ZFP_NATIVE_H
#include <stddef.h>
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
/* Raw ZFP codec; shape, scalar type and mode are external metadata.
 * No frame/header/CRC is added. Contexts are reusable, not thread-safe.
 * Decode only trusted ZFP streams with matching configuration. The upstream
 * bit reader is not a validator for arbitrary/malicious compressed input. */
typedef enum { ZN_I32=1, ZN_I64=2, ZN_F32=3, ZN_F64=4 } zn_type;
typedef enum { ZN_REVERSIBLE=0, ZN_RATE=1, ZN_PRECISION=2, ZN_ACCURACY=3 } zn_mode;
typedef enum { ZN_OK=0, ZN_INVALID=1, ZN_NOMEM=2, ZN_CODEC=3 } zn_status;
typedef struct {
  zn_type type;
  unsigned dims;
  size_t size[4]; /* x fastest, unused extents must be 1; contiguous storage */
  zn_mode mode;
  double parameter; /* rate bits/value, precision bits, or absolute accuracy */
} zn_config;
typedef struct zn_context zn_context;
zn_config zn_config_1d(zn_type type, size_t count);
zn_status zn_create(const zn_config* config, zn_context** context);
void zn_destroy(zn_context* context);
size_t zn_raw_size(const zn_context* context);
size_t zn_capacity(const zn_context* context);
const unsigned char* zn_data(const zn_context* context);
/* data() remains valid until the next encode/decode/destroy on this context.
 * input/output are naturally aligned, nonoverlapping typed arrays; their byte
 * counts must exactly match raw_size(). Allocation and field
 * setup happen in create(), outside encode/decode. Output is 64-bit padded. */
zn_status zn_encode(zn_context*, const void* input, size_t bytes, size_t* written);
zn_status zn_decode(zn_context*, const void* input, size_t bytes, void* output, size_t output_bytes);
/* fix2 native CPU field configuration; strides are in scalar elements.
 * Zero stride selects upstream contiguous default. Nonzero strides support
 * permutation, padding and negative direction for nonoverlapping rectangular
 * layouts (sorted absolute stride must cover preceding axes). No staging copy.
 * Span base includes all padding; origin_elements points at logical (0,...,0).
 * Span <=1GiB and all logical addresses must lie inside it. */
typedef enum {ZN_SERIAL=0,ZN_OPENMP=1,ZN_CUDA=2} zn_execution;
typedef struct {zn_execution execution;unsigned threads,chunk_size;ptrdiff_t stride[4];} zn_options;
typedef struct {zn_config config;zn_options options;double effective_parameter;size_t logical_bytes;ptrdiff_t min_offset,max_offset;int openmp_built,omp_dynamic,omp_thread_limit,decode_execution;} zn_info;
zn_options zn_defaults(void);
zn_status zn_create_ex(const zn_config*,const zn_options*,zn_context**);
zn_status zn_get_info(const zn_context*,zn_info*);
zn_status zn_encode_field(zn_context*,const void* span_base,size_t span_bytes,size_t origin_elements,size_t*written);
zn_status zn_decode_field(zn_context*,const void*compressed,size_t bytes,void*span_base,size_t span_bytes,size_t origin_elements);
/* OpenMP encoding only: upstream has no OpenMP decompressor. Field decode
 * temporarily selects serial and restores configured encode policy. Explicit
 * threads1..256; serial requires threads=1/chunk_size=0. Context owns reusable
 * bitstream/field; separate contexts can run concurrently; one owner per context.
 * Legacy zn_encode/decode remain for legacy contiguous serial contexts only. */
/* Optional upstream CUDA kernels: fixed-rate, contiguous host fields, 1..3D.
 * C11 host API; device implementation is compiled by nvcc (CUDA C++).
 * built() distinguishes compilation from runtime driver/device availability. */
int zn_cuda_built(void);
int zn_cuda_available(void);
/* Pure C compressed arrays. Float/double, fixed rate, 1..4D, x-fastest indexing.
 * One dirty 4^dims block cache; get/set never decompress the whole array.
 * The exported bytes are upstream block-array storage (word-aligned block rate),
 * external zn_config is required. Import accepts trusted streams only.
 * flush/export quantize pending updates; cached reads before flush see exact writes.
 * Context has a single owner. Output points/ranges use native scalar type. */
typedef struct zn_array zn_array;
zn_status zn_array_create(const zn_config*,const void*initial,size_t bytes,zn_array**);
void zn_array_destroy(zn_array*);
size_t zn_array_count(const zn_array*);
size_t zn_array_compressed_size(const zn_array*);
double zn_array_rate(const zn_array*);
zn_status zn_array_get(zn_array*,size_t index,void*value);
zn_status zn_array_set(zn_array*,size_t index,const void*value);
zn_status zn_array_get_range(zn_array*,size_t start,size_t count,void*values,size_t bytes);
zn_status zn_array_set_range(zn_array*,size_t start,size_t count,const void*values,size_t bytes);
zn_status zn_array_flush(zn_array*);
zn_status zn_array_export(zn_array*,void*compressed,size_t capacity,size_t*written);
zn_status zn_array_import(const zn_config*,const void*compressed,size_t bytes,zn_array**);
const char* zn_error(zn_status status);
#ifdef __cplusplus
}
#endif
#endif
#ifdef __cplusplus
extern "C" {
#endif
/* C ABI cache controls mirror upstream's cache lifecycle. A dirty block is
 * flushed before switching; explicit flush commits all dirty blocks. */
size_t zn_array_cache_size(const zn_array*);
zn_status zn_array_set_cache_size(zn_array*,size_t bytes);
zn_status zn_array_flush_cache(zn_array*);
/* Runtime CUDA capability: build is independent from driver/device presence. */
int zn_cuda_built(void);
int zn_cuda_runtime_available(void);
const char* zn_backend_info(void);
#ifdef __cplusplus
}
#endif
