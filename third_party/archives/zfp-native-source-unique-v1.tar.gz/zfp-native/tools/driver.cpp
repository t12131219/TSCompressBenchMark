#include "adapter.hpp"
#include <chrono>
#include <cmath>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>

static size_t number(const std::string& s) {
  if(s.empty() || s.find_first_not_of("0123456789")!=std::string::npos) throw std::invalid_argument("positive size expected");
  size_t end=0; auto v=std::stoull(s,&end);
  if(end!=s.size() || !v || v>size_t(1)<<30) throw std::invalid_argument("size out of range");
  return size_t(v);
}
template<class T> std::vector<T> read(const std::string& path) {
  std::ifstream f(path,std::ios::binary|std::ios::ate);
  auto n=f.tellg();
  if(!f || n<=0 || size_t(n)%sizeof(T) || size_t(n)>(size_t(1)<<30))
    throw std::runtime_error("invalid input file: "+path);
  std::vector<T> v(size_t(n)/sizeof(T));
  f.seekg(0); f.read((char*)v.data(),n);
  if(!f) throw std::runtime_error("read failed");
  return v;
}
static void write(const std::string& p,const void* data,size_t n) {
  std::ofstream f(p,std::ios::binary); f.write((const char*)data,n);
  if(!f) throw std::runtime_error("write failed: "+p);
  f.close(); if(!f) throw std::runtime_error("close failed: "+p);
}
template<class T> static int codec(int argc,char** argv) {
  if(argc!=9) throw std::invalid_argument("encode|decode f32|f64 reversible|rate|precision|accuracy parameter nx[,ny,nz,nw] input output");
  zn_config c={std::is_same_v<T,float>?ZN_F32:ZN_F64,0,{1,1,1,1},ZN_REVERSIBLE,0};
  const std::string mode=argv[4];
  if(mode=="rate") c.mode=ZN_RATE;
  else if(mode=="precision") c.mode=ZN_PRECISION;
  else if(mode=="accuracy") c.mode=ZN_ACCURACY;
  else if(mode!="reversible") throw std::invalid_argument("mode");
  size_t end=0; c.parameter=std::stod(argv[5],&end);
  if(end!=std::strlen(argv[5]) || !std::isfinite(c.parameter)) throw std::invalid_argument("parameter");
  if(!*argv[6] || std::string(argv[6]).back()==',') throw std::invalid_argument("shape");
  std::istringstream shape(argv[6]); std::string s;
  size_t count=1;
  while(std::getline(shape,s,',')) {
    if(c.dims==4) throw std::invalid_argument("at most 4 dimensions");
    auto n=number(s);
    if(n>((size_t(1)<<30)/sizeof(T))/count) throw std::invalid_argument("shape too large");
    c.size[c.dims++]=n; count*=n;
  }
  if(!c.dims || (c.mode!=ZN_REVERSIBLE && c.parameter<=0) ||
     (c.mode==ZN_PRECISION && (c.parameter>8*sizeof(T) || std::floor(c.parameter)!=c.parameter)) ||
     (c.mode==ZN_RATE && c.parameter>8*sizeof(T))) throw std::invalid_argument("configuration");
  Adapter<T> a(c);
  if(std::string(argv[2])=="encode") {
    auto v=read<T>(argv[7]);
    if(v.size()!=count) throw std::invalid_argument("shape/input mismatch");
    auto n=a.encode(v.data(),count); write(argv[8],a.data(),n);
  } else if(std::string(argv[2])=="decode") {
    auto v=read<unsigned char>(argv[7]); std::vector<T> out(count);
    a.decode(v.data(),v.size(),out.data(),count); write(argv[8],out.data(),out.size()*sizeof(T));
  } else throw std::invalid_argument("encode or decode expected");
  return 0;
}
using Clock=std::chrono::steady_clock;
template<class F> static double measure(F&& f,size_t repeats) {
  const auto start=Clock::now();
  for(size_t i=0;i<repeats;++i) f();
  return std::chrono::duration<double>(Clock::now()-start).count();
}
static double median(std::vector<double> v) {
  std::sort(v.begin(),v.end()); return v[v.size()/2];
}
template<class T> static int bench(int argc,char** argv) {
  if(argc!=9) throw std::invalid_argument("bench f32|f64 reversible manifest.tsv output_prefix chunk samples min_ms");
  std::ifstream manifest(argv[4]); if(!manifest) throw std::runtime_error("manifest not found");
  const size_t chunk=number(argv[6]), samples=number(argv[7]);
  const double target=double(number(argv[8]))/1000;
  if(samples%2==0) throw std::invalid_argument("odd sample count required");
  std::string line;
  while(std::getline(manifest,line)) {
    auto tab=line.find('\t'); if(tab==std::string::npos) throw std::runtime_error("manifest format");
    auto id=line.substr(0,tab); auto v=read<T>(line.substr(tab+1));
    struct Block {
      size_t offset,count,bytes=0;
      Adapter<T> codec;
      std::vector<T> out;
      Block(size_t o,size_t n):offset(o),count(n),
        codec(zn_config{std::is_same_v<T,float>?ZN_F32:ZN_F64,1,{n,1,1,1},ZN_REVERSIBLE,0}),out(n) {}
    };
    std::vector<std::unique_ptr<Block>> blocks;
    for(size_t i=0;i<v.size();i+=chunk) blocks.push_back(std::make_unique<Block>(i,std::min(chunk,v.size()-i)));
    auto enc=[&] { for(auto& b:blocks) b->bytes=b->codec.encode(v.data()+b->offset,b->count); };
    auto dec=[&] { for(auto& b:blocks) b->codec.decode(b->codec.data(),b->bytes,b->out.data(),b->count); };
    enc(); dec();
    size_t compressed=0;
    std::ofstream payload(std::string(argv[5])+"-"+id+".zfp",std::ios::binary);
    std::ofstream lengths(std::string(argv[5])+"-"+id+".lengths");
    for(auto& b:blocks) {
      if(std::memcmp(v.data()+b->offset,b->out.data(),b->count*sizeof(T)))
        throw std::runtime_error("bitwise roundtrip failed: "+id);
      compressed+=b->bytes;
      payload.write((const char*)b->codec.data(),b->bytes); lengths<<b->bytes<<'\n';
    }
    payload.close(); lengths.close();
    if(!payload || !lengths) throw std::runtime_error("output write failed");
    std::vector<double> et,dt;
    auto calibration=[&](auto& action) {
      size_t n=1;
      while(measure(action,n)<target/4 && n<100000) n*=2;
      return n*4;
    };
    const auto er=calibration(enc),dr=calibration(dec);
    for(size_t i=0;i<samples;++i) {
      if(i%2) { dt.push_back(measure(dec,dr)/dr); et.push_back(measure(enc,er)/er); }
      else { et.push_back(measure(enc,er)/er); dt.push_back(measure(dec,dr)/dr); }
    }
    // Verify again outside timing, after every measured loop has executed.
    dec();
    for(auto& b:blocks) if(std::memcmp(v.data()+b->offset,b->out.data(),b->count*sizeof(T)))
      throw std::runtime_error("post-timing roundtrip failed");
    std::cout<<std::setprecision(17)<<"{\"id\":\""<<id<<"\",\"implementation\":\""<<implementation
      <<"\",\"width\":"<<8*sizeof(T)<<",\"count\":"<<v.size()<<",\"blocks\":"<<blocks.size()
      <<",\"raw_bytes\":"<<v.size()*sizeof(T)<<",\"compressed_bytes\":"<<compressed
      <<",\"encode_seconds\":"<<median(et)<<",\"decode_seconds\":"<<median(dt)
      <<",\"encode_repeats\":"<<er<<",\"decode_repeats\":"<<dr<<",\"encode_samples\":[";
    for(size_t i=0;i<et.size();++i) std::cout<<(i?",":"")<<et[i];
    std::cout<<"],\"decode_samples\":[";
    for(size_t i=0;i<dt.size();++i) std::cout<<(i?",":"")<<dt[i];
    std::cout<<"]}"<<std::endl;
  }
  return 0;
}
int main(int argc,char** argv) {
  try {
    // The first positional argument selects bench or codec, then a subcommand
    // for codec. Keeping these separate avoids ambiguous mode parsing.
    if(argc<4) throw std::invalid_argument("usage: zfp_IMPL bench f32|f64 ... OR zfp_IMPL codec encode|decode f32|f64 ...");
    std::string type=std::string(argv[1])=="codec"?argv[3]:argv[2];
    if(type!="f32" && type!="f64") throw std::invalid_argument("type must be f32 or f64");
    if(std::string(argv[1])=="codec") return type=="f32"?codec<float>(argc,argv):codec<double>(argc,argv);
    if(std::string(argv[1])=="bench") {
      // bench uses argv[3] as a reserved label (reversible), keeping argv[4..8]
      // identical in both driver paths.
      if(std::string(argv[3])!="reversible") throw std::invalid_argument("benchmark is reversible only");
      return type=="f32"?bench<float>(argc,argv):bench<double>(argc,argv);
    }
    throw std::invalid_argument("unknown command");
  } catch(const std::exception& e) { std::cerr<<e.what()<<'\n'; return 1; }
}
