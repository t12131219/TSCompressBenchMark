#include "zfp_native_cpp.hpp"
#include <cstddef>
int main(){float v[16]={}; zfp::array1<float> a(16,8,v,1024); a[0]=1; a.flush_cache(); return a.cache_size()?0:1;}
