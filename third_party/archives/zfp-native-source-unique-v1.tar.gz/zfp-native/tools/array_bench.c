#define _POSIX_C_SOURCE 200809L
#include "zfp_native.h"
#include <errno.h>
#include <inttypes.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
static void fail(const char*s){fprintf(stderr,"%s\n",s);exit(2);}
static void check(zn_status s){if(s)fail(zn_error(s));}
static uint64_t now(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return (uint64_t)t.tv_sec*UINT64_C(1000000000)+(uint64_t)t.tv_nsec;}
int main(int argc,char**argv){
 if(argc!=4)fail("usage: zn_array_bench INPUT.f64 RATE POINT_OPERATIONS");
 char*end;errno=0;double rate=strtod(argv[2],&end);
 if(errno||!*argv[2]||*end||!isfinite(rate)||rate<=0)fail("invalid rate");
 errno=0;unsigned long operations=strtoul(argv[3],&end,10);
 if(errno||!*argv[3]||*end||argv[3][0]=='-'||!operations||operations>100000000)fail("invalid operations");
 FILE*f=fopen(argv[1],"rb");if(!f)fail("open input");
 if(fseek(f,0,SEEK_END))fail("seek input");long length=ftell(f);
 if(length<=0||length>(1L<<30)||length%8)fail("input size");rewind(f);
 size_t bytes=(size_t)length,n=bytes/8;double*x=malloc(bytes),*decoded=malloc(bytes);
 if(!x||!decoded)fail("allocate input");if(fread(x,1,bytes,f)!=bytes||fclose(f))fail("read input");
 zn_config c=zn_config_1d(ZN_F64,n);c.mode=ZN_RATE;c.parameter=rate;
 zn_array*a=NULL,*b=NULL;uint64_t start=now();check(zn_array_create(&c,x,bytes,&a));uint64_t build_ns=now()-start;
 check(zn_array_get_range(a,0,n,decoded,bytes));
 double max_error=0,checksum=0;for(size_t i=0;i<n;i++){double e=fabs(decoded[i]-x[i]);if(e>max_error)max_error=e;}
 uint64_t rng=9143;start=now();
 for(unsigned long i=0;i<operations;i++){rng=rng*UINT64_C(6364136223846793005)+1;double v;size_t at=(size_t)(rng%n);check(zn_array_get(a,at,&v));if(memcmp(&v,decoded+at,8))fail("random access differs from range");checksum+=v;}
 uint64_t read_ns=now()-start;double update=1.25;check(zn_array_set(a,n/2,&update));
 size_t compressed=zn_array_compressed_size(a),written=0;void*wire=malloc(compressed);if(!wire)fail("allocate export");
 check(zn_array_export(a,wire,compressed,&written));check(zn_array_import(&c,wire,written,&b));
 double v1,v2;check(zn_array_get(a,n/2,&v1));check(zn_array_get(b,n/2,&v2));if(memcmp(&v1,&v2,8))fail("export/import mismatch");
 printf("{\"backend\":\"C11-block-array\",\"values\":%zu,\"compressed_bytes\":%zu,\"effective_rate\":%.17g,\"build_ns\":%"PRIu64",\"point_operations\":%lu,\"point_read_ns\":%"PRIu64",\"initial_max_abs_error\":%.17g,\"checksum\":%.17g,\"verified\":true}\n",n,compressed,zn_array_rate(a),build_ns,operations,read_ns,max_error,checksum);
 zn_array_destroy(a);zn_array_destroy(b);free(wire);free(x);free(decoded);return 0;
}
