#pragma once
#include "zfp_native.h"
#include <algorithm>
#include <cstring>
#include <memory>
#include <stdexcept>
#include <type_traits>
#include <vector>
#if defined(ZN_IMPL_original)
#include "zfp.h"
static constexpr const char* implementation = "original-c";
template<class T> class Adapter {
  struct StreamDeleter { void operator()(zfp_stream* p) const { zfp_stream_close(p); } };
  struct FieldDeleter { void operator()(zfp_field* p) const { zfp_field_free(p); } };
  struct BitsDeleter { void operator()(bitstream* p) const { stream_close(p); } };
  std::unique_ptr<zfp_stream,StreamDeleter> z;
  std::unique_ptr<zfp_field,FieldDeleter> f;
  std::vector<uint64_t> storage;
  std::unique_ptr<bitstream,BitsDeleter> bits;
  size_t raw_size;
public:
  explicit Adapter(zn_config c) {
    raw_size=sizeof(T);
    for(unsigned d=0;d<c.dims;++d) raw_size*=c.size[d];
    z.reset(zfp_stream_open(nullptr));
    const auto type=std::is_same_v<T,float> ? zfp_type_float : zfp_type_double;
    switch(c.dims) {
      case 1: f.reset(zfp_field_1d(nullptr,type,c.size[0])); break;
      case 2: f.reset(zfp_field_2d(nullptr,type,c.size[0],c.size[1])); break;
      case 3: f.reset(zfp_field_3d(nullptr,type,c.size[0],c.size[1],c.size[2])); break;
      case 4: f.reset(zfp_field_4d(nullptr,type,c.size[0],c.size[1],c.size[2],c.size[3])); break;
      default: throw std::invalid_argument("dimensions");
    }
    if(!z || !f) throw std::bad_alloc();
    switch(c.mode) {
      case ZN_REVERSIBLE: zfp_stream_set_reversible(z.get()); break;
      case ZN_RATE: zfp_stream_set_rate(z.get(),c.parameter,type,c.dims,zfp_false); break;
      case ZN_PRECISION: zfp_stream_set_precision(z.get(),(unsigned)c.parameter); break;
      case ZN_ACCURACY: zfp_stream_set_accuracy(z.get(),c.parameter); break;
    }
    storage.resize((zfp_stream_maximum_size(z.get(),f.get())+7)/8);
    bits.reset(stream_open(storage.data(),storage.size()*8));
    if(!bits) throw std::bad_alloc();
    zfp_stream_set_bit_stream(z.get(),bits.get());
  }
  size_t encode(const T* v,size_t n) {
    if(n*sizeof(T)!=raw_size) throw std::invalid_argument("count");
    zfp_field_set_pointer(f.get(),(void*)v);
    zfp_stream_rewind(z.get());
    size_t bytes=zfp_compress(z.get(),f.get());
    if(!bytes) throw std::runtime_error("zfp_compress failed");
    return bytes;
  }
  void decode(const void* input,size_t bytes,T* output,size_t count) {
    if(count*sizeof(T)!=raw_size || !bytes || bytes%8 || bytes>storage.size()*8)
      throw std::invalid_argument("decode size");
    if(input!=storage.data()) std::memmove(storage.data(),input,bytes);
    std::memset((unsigned char*)storage.data()+bytes,0,storage.size()*8-bytes);
    zfp_field_set_pointer(f.get(),output);
    zfp_stream_rewind(z.get());
    if(zfp_decompress(z.get(),f.get())!=bytes) throw std::runtime_error("decode length mismatch");
  }
  const unsigned char* data() const { return (const unsigned char*)storage.data(); }
};
#elif defined(ZN_IMPL_c)
static constexpr const char* implementation = "port-c11";
template<class T> class Adapter {
  zn_context* p=nullptr;
  static void check(zn_status s) { if(s!=ZN_OK) throw std::runtime_error(zn_error(s)); }
public:
  explicit Adapter(zn_config c) { check(zn_create(&c,&p)); }
  ~Adapter() { zn_destroy(p); }
  Adapter(const Adapter&)=delete;
  Adapter& operator=(const Adapter&)=delete;
  size_t encode(const T* data,size_t n) { size_t b; check(zn_encode(p,data,n*sizeof(T),&b)); return b; }
  void decode(const void* data,size_t b,T* out,size_t n) { check(zn_decode(p,data,b,out,n*sizeof(T))); }
  const unsigned char* data() const { return zn_data(p); }
};
#else
#include "zfp_native.hpp"
static constexpr const char* implementation = "port-cpp17";
template<class T> using Adapter = zfp_native::Codec<T>;
#endif
