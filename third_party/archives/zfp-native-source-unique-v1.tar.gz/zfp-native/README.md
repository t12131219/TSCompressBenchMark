# zfp-native · unique-v1

本工程只交付一个主选实现 `zfp_native_c`，覆盖 31 ZFP。

## 构建

```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j4
```

支持Linux x86_64，GCC/G++、CMake≥3.22、make。ISA要求及运行约束见下表。工程自带所需源码依赖；构建输出不在发布包内。

ZN_WITH_OPENMP=ON（默认）；ZN_WITH_CUDA=ON 可编译GPU组件，CMAKE_CUDA_ARCHITECTURES可覆盖（默认75）；本机驱动不可用，GPU运行未验证。

独立C/C++对照、历史版本、上游oracle及独立验证程序不交付。辅助库、共享格式代码、ISA加速和训练/流式等模块服务于同一主实现。`reference`、`fpc-original` 等历史target名称是CSV主选标识，不代表存在另一份并列实现。

## 31. ZFP

| 属性 | 支持范围与限制 |
| --- | --- |
| 技术家族 | 块变换+位平面 |
| 方法角色 | 规则field codec；扩展C11 fixed-rate压缩数组 |
| 编码流水线 | 4^d块变换+嵌入位平面；reversible使用可逆算法 |
| 原生类型 | i32 / i64 / f32 / f64 |
| 输入适配 | 原生数值field |
| 数值域与特殊值 | reversible保留IEEE特殊位型；有损模式不继承该保证 |
| 形状与多变量 | 规则1–4维field，非不规则时间轴 |
| 时间轴或显式x | 不支持：仅隐式样本序号 |
| 布局与stride | field接口支持规则非重叠正/负stride、padding；无隐藏连续化副本 |
| 缺失值语义 | 未声明原生mask；不隐式插补 |
| 恢复与质量合同 | reversible位级无损；rate/precision/accuracy有损，accuracy仅浮点及数值适用条件 |
| 核心参数 | field四类型/1..4D/四模式，serial/OpenMP及threads/chunk；数组f32/f64、1..4D fixed-rate；CUDA另限连续host field 1..3D fixed-rate；默认f64/1D/reversible/serial |
| 批处理 | 支持：整输入调用 |
| 增量编码 | 不支持：所选核心无此公开入口 |
| 增量解码 | 批量完整恢复 |
| 状态与复用 | field独立context；数组单块dirty cache，驱逐/flush触发有损重压缩，flush前后读值语义有区别 |
| 点范围与seek | 支持：C11 zn_array_*的点/范围读写、flush、导入导出；每次只加载4^dims块；单dirty块缓存；不包含完整C++容器/迭代器/视图API |
| 渐进恢复 | 不支持：所选核心无此公开入口 |
| 压缩域计算 | 不支持：所选核心无此公开入口 |
| 训练或在线学习 | 无需外部训练 |
| 字典码本复用 | 不支持：所选核心无此公开入口 |
| SIMD或ISA | 未确认：不以编译器自动向量化宣称显式SIMD |
| 内部并行编码 | 条件支持：field OpenMP编码 |
| 内部并行解码 | 无OpenMP解码：冻结ftable为空；CPU解码serial |
| GPU | 条件支持：ZN_CUDA显式策略、built/available检测，可选fixed-rate连续host field 1..3D；nvcc11.8编译成功，驱动不可用，runtime跳过未验证；设备为上游CUDA C++，host API为C11 |
| 并发与所有权 | 独立context可并发，同context单所有者 |
| 格式与兼容 | field ZFP bitstream/可选头；数组word-aligned fixed-rate块，外部dtype/shape/rate；非完整自描述数组容器 |
| 独立恢复依赖 | field裸流须保存dtype/shape/模式参数；数组导入须保存dtype/shape/rate且仅接收可信流 |
| 运行与构建依赖 | CPU C11包装及C block codec，数组无C++运行依赖；可选OpenMP；CUDA需nvcc和驱动，设备实现为上游CUDA C++ |
| 长度尾部与资源 | field span/逻辑分配≤1GiB并拒绝别名；数组限f32/f64 fixed-rate 1..4D；CUDA限连续host field 1..3D fixed-rate，实机未验 |
| 确定性条件 | 未确认：未建立跨平台字节确定性保证 |
| 许可范围 | 源码许可声明及 fix_ReWrite/zfp-native/licenses 中的冻结归属材料。 |
| 已知限制与身份 | 数组单块缓存与上游多块缓存重压缩时机不同，统一flush顺序72组块字节/值一致；不声称完整C++数组API。GPU只确认编译，未确认实机运行；新增扩展非默认开启 |
